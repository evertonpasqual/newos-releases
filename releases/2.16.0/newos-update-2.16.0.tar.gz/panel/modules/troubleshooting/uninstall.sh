#!/usr/bin/env bash
# =====================================================================
#  Modulo Troubleshooting - desligar
#  Interrompe o que estiver rodando e apaga os resultados guardados
#  (podem listar equipamentos e portas da rede do cliente).
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="troubleshooting"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

for u in $(systemctl list-units 'newos-tshoot-*' --no-legend --plain 2>/dev/null | awk '{print $1}'); do
    systemctl stop "${u}" 2>/dev/null || true
done
rm -rf /var/lib/newos/troubleshoot
mod_info "Troubleshooting desligado. Os resultados guardados foram apagados."
