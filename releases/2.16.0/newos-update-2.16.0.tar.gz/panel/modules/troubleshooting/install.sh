#!/usr/bin/env bash
# =====================================================================
#  Modulo Troubleshooting - instalacao
#  Chamado por: newos-modctl install troubleshooting
#  nmap (portas e descoberta), mtr (rota), dig, ethtool, ping, tcpdump
#  (captura), curl/openssl (HTTP/TLS) e snmp (cliente), do Debian.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="troubleshooting"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

missing=()
for p in nmap mtr-tiny dnsutils ethtool iputils-ping tcpdump curl openssl snmp; do
    pkg_installed "${p}" || missing+=("${p}")
done
if ((${#missing[@]} > 0)); then
    apt_require_healthy
    apt_ensure_lists
    mod_info "Instalando ${missing[*]}..."
    apt_install "${missing[@]}"
fi
install -d -m 0700 /var/lib/newos/troubleshoot
mod_info "Pronto. As ferramentas ficam em Network > Troubleshooting."
