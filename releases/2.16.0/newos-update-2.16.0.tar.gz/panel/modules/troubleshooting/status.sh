#!/usr/bin/env bash
set -Eeuo pipefail
ok=no
command -v nmap >/dev/null 2>&1 && command -v mtr >/dev/null 2>&1 && command -v dig >/dev/null 2>&1 && command -v tcpdump >/dev/null 2>&1 && command -v snmpget >/dev/null 2>&1 && ok=yes
printf 'installed=%s\n' "${ok}"
printf 'active=%s\n' "${ok}"
