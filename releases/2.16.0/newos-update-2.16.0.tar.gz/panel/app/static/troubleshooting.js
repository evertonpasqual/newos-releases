/* =====================================================================
   NewOS Panel - Troubleshooting
   formulario -> POST /api/troubleshooting/iniciar -> acompanha ao vivo
   Toda saida vem de hosts da rede: sempre escapada (esc).
   ===================================================================== */
(function () {
    "use strict";

    function $(s, el) { return (el || document).querySelector(s); }
    function $$(s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); }
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function num(n, dec) {
        if (n == null || isNaN(n)) return "—";
        return Number(n).toLocaleString("pt-BR", { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 });
    }
    function api(url, body) {
        var o = { credentials: "same-origin", cache: "no-store", headers: {} };
        if (body !== undefined) { o.method = "POST"; o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
        return fetch(url, o).then(function (r) {
            if (r.status === 401) { location.href = "/login"; throw new Error("sessao"); }
            return r.json();
        });
    }
    function badge(cls, txt) { return '<span class="badge ' + cls + ' mini">' + esc(txt) + "</span>"; }
    function table(head, rows, empty) {
        if (!rows.length) return '<div class="empty">' + esc(empty) + "</div>";
        return '<div class="ts-scroll"><table class="data"><thead><tr>' + head.map(function (h) { return "<th>" + esc(h) + "</th>"; }).join("") +
            "</tr></thead><tbody>" + rows.join("") + "</tbody></table></div>";
    }
    function tiles(items) {
        return '<div class="ts-tiles">' + items.map(function (i) {
            return '<div class="ts-tile"><span>' + esc(i[0]) + "</span><strong>" + esc(i[1]) + "</strong></div>";
        }).join("") + "</div>";
    }

    var LABEL = { dns: "DNS", ping: "Ping", rota: "Rota (MTR)", portas: "Portas abertas", descoberta: "Descoberta de rede", interfaces: "Saúde das interfaces",
        loop: "Loop na rede", dhcp: "DHCP e IP duplicado", lldp: "Vizinhos LLDP/CDP", captura: "Captura de pacotes", mtu: "MTU do caminho", http: "HTTP/TLS", snmp: "SNMP" };
    function verdict(level, okText, signs) {
        var cls = level === "erro" ? "alert-erro" : level === "aviso" ? "alert-aviso" : "alert-ok";
        var ico = level === "erro" ? "bi-x-octagon" : level === "aviso" ? "bi-exclamation-triangle" : "bi-check-circle";
        var body = signs && signs.length ? signs.map(esc).join("<br>") : esc(okText);
        return '<div class="alert ' + cls + '"><span class="ico"><i class="bi ' + ico + '"></i></span><span>' + body + "</span></div>";
    }
    function kb(n) { return n >= 1048576 ? num(n / 1048576, 1) + " MB" : num(n / 1024, 0) + " KB"; }
    var render = {
        dns: function (r) {
            var html = r.diverge ? '<div class="alert alert-aviso"><span class="ico"><i class="bi bi-exclamation-triangle"></i></span><span>Os servidores responderam diferente. Em sites com CDN isso pode ser normal; em nomes internos, confira a zona.</span></div>' : "";
            return html + table(["Servidor", "Situação", "Tempo", "Respostas"], r.servers.map(function (s) {
                var ok = s.status === "NOERROR";
                var ans = s.answers.length ? s.answers.map(function (a) { return '<div class="mono">' + esc(a.type) + " " + esc(a.value) + ' <span class="nic-sub">TTL ' + esc(a.ttl) + "</span></div>"; }).join("") : '<span class="nic-sub">sem registros</span>';
                return '<tr><td class="mono">' + esc(s.server) + (s.default ? ' <span class="nic-sub">(deste servidor)</span>' : "") + "</td><td>" + badge(ok ? "badge-up" : "badge-err", s.status) + "</td><td>" + (s.ms == null ? "—" : esc(s.ms) + " ms") + "</td><td>" + ans + "</td></tr>";
            }), "Sem resposta.");
        },
        ping: function (r) {
            return tiles([["Enviados", num(r.sent)], ["Recebidos", num(r.received)], ["Perda", r.loss == null ? "—" : num(r.loss, 1) + "%"], ["Mínimo", r.min == null ? "—" : num(r.min, 1) + " ms"], ["Média", r.avg == null ? "—" : num(r.avg, 1) + " ms"], ["Máximo", r.max == null ? "—" : num(r.max, 1) + " ms"]]);
        },
        rota: function (r) {
            var last = r.hubs.length - 1;
            var html = table(["Salto", "Host", "Perda", "Enviados", "Último", "Média", "Melhor", "Pior"], r.hubs.map(function (h) {
                var cls = h.loss > 0 ? "badge-warn" : "badge-up";
                return "<tr><td>" + esc(h.hop) + '</td><td class="mono">' + esc(h.host) + "</td><td>" + badge(cls, num(h.loss, 1) + "%") + "</td><td>" + esc(h.sent) + "</td><td>" + num(h.last, 1) + "</td><td>" + num(h.avg, 1) + "</td><td>" + num(h.best, 1) + "</td><td>" + num(h.worst, 1) + "</td></tr>";
            }), "Nenhum salto respondeu.");
            if (last >= 0) html += '<p class="hint">Perda só num salto do meio, sem perda no destino, costuma ser o roteador limitando respostas, e não um problema real.</p>';
            return html;
        },
        portas: function (r) {
            return tiles([["Host", r.address || r.target], ["Abertas", num(r.ports.length)], ["Fechadas", num(r.closed)], ["Filtradas", num(r.filtered)]]) +
                table(["Porta", "Situação", "Serviço", "Versão"], r.ports.map(function (p) {
                    return '<tr><td class="mono">' + esc(p.port) + "/" + esc(p.proto) + "</td><td>" + badge("badge-up", p.state === "open" ? "aberta" : p.state) + "</td><td>" + esc(p.service) + "</td><td>" + esc(p.version) + "</td></tr>";
                }), "Nenhuma porta aberta nas portas verificadas.");
        },
        descoberta: function (r) {
            var html = tiles([["Faixa", r.cidr], ["Encontrados", num(r.hosts.length)], ["Endereços", num(r.total)], ["Via", r.local ? r.iface + " (rede local)" : "roteada"]]);
            if (!r.local) html += '<div class="alert alert-aviso"><span class="ico"><i class="bi bi-info-circle"></i></span><span>Esta faixa é roteada: MAC e fabricante não aparecem, e hosts que não respondem a ping ficam de fora.</span></div>';
            return html + table(["IP", "MAC", "Fabricante", "Nome"], r.hosts.map(function (h) {
                return '<tr><td class="mono">' + esc(h.ip) + (h.self ? ' <span class="nic-sub">(este servidor)</span>' : "") + '</td><td class="mono">' + esc(h.mac || "—") + "</td><td>" + esc(h.vendor || "—") + '</td><td class="mono">' + esc(h.name || "—") + "</td></tr>";
            }), "Nenhum host respondeu nessa faixa.");
        },
        loop: function (r) {
            var html = verdict(r.level, "Sem sinais de loop em " + r.seconds + " s: o quadro de teste não voltou, sem quadros repetidos e broadcast normal.", r.signs);
            html += tiles([["Quadros recebidos", num(r.total)], ["Broadcast por segundo", num(r.bcast_pps, 1)], ["Multicast", num(r.multicast)],
                ["Quadro de teste voltou", num(r.returned) + "×"], ["Quadros repetidos", num(r.repeated)], ["BPDUs do STP", num(r.bpdus) + (r.tcn || r.tc ? " (" + num(r.tcn + r.tc) + " mudanças)" : "")]]);
            if (r.roots.length) html += '<p class="hint">Root bridge anunciado: <span class="mono">' + r.roots.map(esc).join(", ") + "</span></p>";
            return html + table(["Quem mais mandou broadcast (MAC)", "Quadros", "Por segundo"], r.top.map(function (t) {
                return '<tr><td class="mono">' + esc(t.mac) + "</td><td>" + num(t.count) + "</td><td>" + num(t.pps, 1) + "</td></tr>";
            }), "Nenhum broadcast no período.");
        },
        dhcp: function (r) {
            var html = verdict(r.level, "Um servidor DHCP respondendo e nenhum IP duplicado.", r.signs);
            html += "<h3 class=\"ts-sub\">Servidores DHCP que responderam</h3>" + table(["Servidor", "MAC", "IP oferecido", "Máscara", "Gateway", "DNS", "Concessão"], r.servers.map(function (s) {
                return '<tr><td class="mono">' + esc(s.server) + '</td><td class="mono">' + esc(s.mac) + '</td><td class="mono">' + esc(s.ip) + '</td><td class="mono">' + esc(s.mask || "—") + '</td><td class="mono">' + esc(s.router || "—") + '</td><td class="mono">' + esc(s.dns || "—") + "</td><td>" + (s.lease == null ? "—" : num(s.lease / 3600, 1) + " h") + "</td></tr>";
            }), "Nenhum servidor DHCP respondeu.");
            if (r.duplicates.length) {
                var st = { ok: ["badge-up", "sem conflito"], livre: ["badge-down", "livre"], "em uso": ["badge-up", "em uso"], duplicado: ["badge-err", "duplicado"] };
                html += "<h3 class=\"ts-sub\">IP duplicado</h3>" + table(["IP", "Situação", "Respondido por (MAC)"], r.duplicates.map(function (d) {
                    var b = st[d.state] || ["badge-warn", d.state];
                    return '<tr><td class="mono">' + esc(d.ip) + (d.own ? ' <span class="nic-sub">(deste servidor)</span>' : "") + "</td><td>" + badge(b[0], b[1]) + '</td><td class="mono">' + (d.macs.length ? d.macs.map(esc).join("<br>") : "—") + "</td></tr>";
                }), "");
            }
            return html;
        },
        lldp: function (r) {
            if (!r.neighbors.length) return '<div class="empty">Nenhum vizinho anunciou LLDP ou CDP em ' + esc(r.seconds) + " s. O protocolo pode estar desligado no switch, ou a interface está ligada a algo que não anuncia (outro servidor, conversor de mídia).</div>";
            return table(["Protocolo", "Equipamento", "Porta", "VLAN nativa", "IP de gerência", "Tipo", "Sistema"], r.neighbors.map(function (n) {
                return "<tr><td>" + badge("badge-up", n.proto) + '</td><td class="mono">' + esc(n.name || n.chassis) + (n.name && n.chassis && n.name !== n.chassis ? '<div class="nic-sub">' + esc(n.chassis) + "</div>" : "") +
                    '</td><td class="mono">' + esc(n.port) + (n.port_descr && n.port_descr !== n.port ? '<div class="nic-sub">' + esc(n.port_descr) + "</div>" : "") + "</td><td>" + (n.vlan == null ? "—" : esc(n.vlan)) +
                    '</td><td class="mono">' + esc(n.mgmt || "—") + "</td><td>" + esc(n.caps.join(", ") || "—") + '</td><td class="ts-descr">' + esc(n.descr || "—") + "</td></tr>";
            }), "");
        },
        captura: function (r, j) {
            var why = { tempo: "tempo esgotado", pacotes: "limite de pacotes", tamanho: "limite de 20 MB" }[r.stopped_by] || r.stopped_by;
            var html = tiles([["Pacotes", num(r.packets)], ["Tamanho", kb(r.size)], ["Duração", num(r.seconds, 1) + " s"], ["Parou por", why], ["Descartados pelo kernel", num(r.dropped)]]);
            html += '<p><a class="btn" href="/api/troubleshooting/job/' + encodeURIComponent(j.id) + '/pcap"><i class="bi bi-download"></i> Baixar .pcap (Wireshark)</a></p>';
            html += '<div class="grid grid-2"><div><h3 class="ts-sub">Quem mais conversou</h3>' + table(["Origem → destino", "Pacotes"], r.talkers.map(function (t) {
                return '<tr><td class="mono">' + esc(t.pair) + "</td><td>" + num(t.count) + "</td></tr>";
            }), "Nenhum pacote IP.") + '</div><div><h3 class="ts-sub">Protocolos</h3>' + table(["Protocolo", "Pacotes"], r.protocols.map(function (t) {
                return '<tr><td class="mono">' + esc(t.name) + "</td><td>" + num(t.count) + "</td></tr>";
            }), "Nenhum pacote.") + "</div></div>";
            if (r.preview.length) html += '<details class="ts-raw"><summary>Primeiros ' + num(r.preview.length) + ' pacotes</summary><pre class="mono">' + esc(r.preview.join("\n")) + "</pre></details>";
            return html;
        },
        mtu: function (r) {
            var level = r.blackhole ? "erro" : r.path_mtu < r.limit ? "aviso" : "ok";
            var html = verdict(level, "O caminho aceita o MTU inteiro da interface (" + r.limit + " bytes).", r.notes);
            return html + tiles([["MTU do caminho", num(r.path_mtu) + " bytes"], ["MTU da interface" + (r.iface ? " " + r.iface : ""), num(r.local_mtu) + " bytes"],
                ["Maior ping sem fragmentar", num(r.payload) + " bytes de dados"], ["Destino", r.address]]);
        },
        http: function (r) {
            var html = "";
            if (r.error) html += verdict("erro", "", [r.error]);
            if (r.status >= 500) html += verdict("erro", "", ["O servidor respondeu com erro " + r.status + "."]);
            else if (r.status >= 400) html += verdict("aviso", "", ["O servidor respondeu " + r.status + " (página inexistente ou acesso negado)."]);
            html += tiles([["Código HTTP", r.status ? String(r.status) : "sem resposta"], ["Versão", r.http_version ? "HTTP/" + r.http_version : "—"], ["IP", r.ip || "—"], ["Tempo total", num(r.times.total, 0) + " ms"]]);
            if (r.location) html += '<p class="hint">Redireciona para <span class="mono">' + esc(r.location) + "</span></p>";
            var t = r.times;
            html += table(["DNS", "Conexão", "TLS", "Primeiro byte", "Total"], ["<tr><td>" + num(t.namelookup, 0) + " ms</td><td>" + num(t.connect, 0) + " ms</td><td>" + (r.tls ? num(t.appconnect, 0) + " ms" : "—") + "</td><td>" + num(t.starttransfer, 0) + " ms</td><td>" + num(t.total, 0) + " ms</td></tr>"], "");
            if (r.tls) {
                var c = r.tls.cert || {};
                var lvl = !r.tls.verified ? "erro" : c.days_left != null && c.days_left < 30 ? "aviso" : "ok";
                var msg = !r.tls.verified ? ["Certificado não confiável: " + (r.tls.error || "falhou a verificação")] :
                    c.days_left != null && c.days_left < 30 ? ["Certificado confiável, mas vence em " + c.days_left + " dias."] : [];
                html += '<h3 class="ts-sub">Certificado</h3>' + verdict(lvl, "Certificado confiável, válido por mais " + (c.days_left == null ? "?" : c.days_left) + " dias.", msg);
                html += table(["Campo", "Valor"], [["Protocolo", (r.tls.version || "—") + " · " + (r.tls.cipher || "—")], ["Emitido para", c.subject], ["Emitido por", c.issuer],
                    ["Válido de", c.not_before], ["Válido até", c.not_after + (c.days_left == null ? "" : " (" + c.days_left + " dias)")], ["Nomes (SAN)", (c.san || []).join(", ")], ["SHA-256", c.sha256]]
                    .map(function (x) { return "<tr><td>" + esc(x[0]) + '</td><td class="mono ts-descr">' + esc(x[1] || "—") + "</td></tr>"; }), "");
            }
            if (r.headers.length) html += '<details class="ts-raw"><summary>Cabeçalhos da resposta</summary>' + table(["Cabeçalho", "Valor"], r.headers.map(function (h) {
                return '<tr><td class="mono">' + esc(h.name) + '</td><td class="mono ts-descr">' + esc(h.value) + "</td></tr>";
            }), "") + "</details>";
            return html;
        },
        snmp: function (r) {
            var s = r.system;
            var html = verdict("ok", "O equipamento respondeu por SNMP " + r.version + " em " + r.ms + " ms.", []);
            html += tiles([["Nome", s.name || "—"], ["Uptime", s.uptime_text || s.uptime || "—"], ["Local", s.location || "—"], ["Contato", s.contact || "—"]]);
            html += table(["Campo", "Valor"], [["Descrição", s.descr], ["Object ID", s.object_id]].map(function (x) {
                return "<tr><td>" + esc(x[0]) + '</td><td class="mono ts-descr">' + esc(x[1] || "—") + "</td></tr>";
            }), "");
            if (r.interfaces.length) html += '<h3 class="ts-sub">Interfaces (' + num(r.interfaces.length) + ")</h3>" + table(["#", "Interface", "Descrição", "Estado", "Velocidade"], r.interfaces.map(function (i) {
                return "<tr><td>" + esc(i.index) + '</td><td class="mono">' + esc(i.descr) + "</td><td>" + esc(i.alias || "—") + "</td><td>" + badge(i.oper === "up" ? "badge-up" : "badge-down", i.oper || "?") + "</td><td>" + (i.speed ? num(i.speed) + " Mb/s" : "—") + "</td></tr>";
            }), "");
            return html;
        },
        interfaces: function (r) {
            return table(["Interface", "Link", "Velocidade", "Duplex", "Erros (RX/TX)", "Descartes (RX/TX)", "Observações"], r.ifaces.map(function (i) {
                var cls = i.level === "erro" ? "badge-err" : i.level === "aviso" ? "badge-warn" : "badge-up";
                var notes = i.notes.length ? i.notes.map(esc).join("<br>") : '<span class="nic-sub">sem observações</span>';
                var grow = Object.keys(i.growing);
                if (grow.length) notes += '<div class="mono nic-sub">' + grow.map(function (k) { return esc(k) + " +" + esc(i.growing[k]); }).join(", ") + "</div>";
                return '<tr><td class="mono">' + esc(i.name) + '<div class="nic-sub">' + esc(i.driver || (i.physical ? "física" : "virtual")) + "</div></td><td>" + badge(cls, i.up ? "ativo" : "sem link") + "</td><td>" + (i.speed ? num(i.speed) + " Mb/s" : "—") + "</td><td>" + esc(i.duplex && i.duplex !== "Unknown" ? i.duplex : "—") + "</td><td>" + num(i.errors.rx_errors) + " / " + num(i.errors.tx_errors) + "</td><td>" + num(i.errors.rx_dropped) + " / " + num(i.errors.tx_dropped) + "</td><td>" + notes + "</td></tr>";
            }), "Nenhuma interface encontrada.");
        }
    };

    /* ---------------- abas e campos condicionais -------------------- */
    $$("#ts-tabs button").forEach(function (b) {
        b.addEventListener("click", function () {
            $$("#ts-tabs button").forEach(function (x) { x.classList.toggle("on", x === b); });
            $$("[data-ts-form]").forEach(function (f) { f.hidden = f.getAttribute("data-ts-form") !== b.getAttribute("data-tab"); });
        });
    });
    var pingForm = $('[data-ts-form="ping"]'), portForm = $('[data-ts-form="portas"]'), discForm = $('[data-ts-form="descoberta"]');
    pingForm.elements.tool.addEventListener("change", function () {
        $(".ts-size", pingForm).hidden = this.value !== "ping";
        $(".ts-count", pingForm).hidden = this.value === "mtu";
        $(".ts-mtu-hint", pingForm).hidden = this.value !== "mtu";
    });
    var snmpForm = $('[data-ts-form="snmp"]');
    function snmpFields() {
        var v3 = snmpForm.elements.version.value === "3", lvl = snmpForm.elements.level.value;
        $(".ts-v2", snmpForm).hidden = v3;
        $(".ts-v3", snmpForm).hidden = !v3;
        $(".ts-auth", snmpForm).hidden = lvl === "noAuthNoPriv";
        $(".ts-priv", snmpForm).hidden = lvl !== "authPriv";
        snmpForm.elements.community.required = !v3;
        snmpForm.elements.v3user.required = v3;
    }
    snmpForm.elements.version.addEventListener("change", snmpFields);
    snmpForm.elements.level.addEventListener("change", snmpFields);
    snmpFields();
    portForm.elements.profile.addEventListener("change", function () {
        var list = this.value === "lista";
        $(".ts-ports", portForm).hidden = !list;
        portForm.elements.ports.required = list;
    });
    $$("[data-cidr]", discForm).forEach(function (b) { b.addEventListener("click", function () { discForm.elements.cidr.value = b.getAttribute("data-cidr"); }); });

    /* ---------------- execucao -------------------------------------- */
    var box = $("#ts-run"), timer = null, current = null;
    function setState(html) { $("#ts-state").innerHTML = html; }
    function poll() {
        if (!current) return;
        var id = current;
        api("/api/troubleshooting/job/" + id).then(function (j) {
            if (id !== current) return;
            if (!j.ok) { setState(badge("badge-err", "falhou")); $("#ts-result").innerHTML = '<div class="empty">' + esc(j.message) + "</div>"; $("#ts-stop").hidden = true; return; }
            $("#ts-title").innerHTML = '<i class="bi bi-terminal"></i> ' + esc(LABEL[j.tool] || j.tool) + ' <span class="nic-sub mono">' + esc(j.target) + "</span>";
            var raw = $("#ts-raw"), follow = raw.scrollTop + raw.clientHeight >= raw.scrollHeight - 30;
            raw.textContent = j.output || "";
            if (follow) raw.scrollTop = raw.scrollHeight;
            if (j.state === "running") {
                setState('<span class="tr-live"><span class="live-dot"></span> rodando</span>');
                $("#ts-stop").hidden = false;
                $("#ts-raw-box").open = true;
                $("#ts-result").innerHTML = "";
                timer = setTimeout(poll, 1000);
                return;
            }
            $("#ts-stop").hidden = true;
            if (j.state === "done") {
                setState(badge("badge-up", "concluído"));
                $("#ts-raw-box").open = false;
                $("#ts-result").innerHTML = render[j.tool](j.result, j);
            } else if (j.state === "stopped") {
                setState(badge("badge-down", "interrompido"));
                $("#ts-result").innerHTML = "";
            } else {
                setState(badge("badge-err", "falhou"));
                $("#ts-result").innerHTML = '<div class="alert alert-erro"><span class="ico"><i class="bi bi-x-circle"></i></span><span>' + esc(j.error) + "</span></div>";
            }
        }).catch(function () { if (id === current) timer = setTimeout(poll, 3000); });
    }
    function open(id) {
        clearTimeout(timer);
        current = id;
        box.hidden = false;
        $("#ts-result").innerHTML = "";
        $("#ts-raw").textContent = "";
        setState("");
        box.scrollIntoView({ behavior: "smooth", block: "start" });
        poll();
    }
    $$("[data-ts-form]").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var kind = form.getAttribute("data-ts-form"), body = { tool: kind };
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name) return;
                body[el.name] = el.type === "checkbox" ? el.checked : el.value;
            });
            var btn = $("button[type=submit]", form);
            btn.disabled = true;
            api("/api/troubleshooting/iniciar", body).then(function (r) {
                btn.disabled = false;
                if (r.ok) { open(r.id); return; }
                box.hidden = false;
                current = null;
                clearTimeout(timer);
                $("#ts-stop").hidden = true;
                $("#ts-title").innerHTML = '<i class="bi bi-terminal"></i> Resultado';
                setState(badge("badge-err", "recusado"));
                $("#ts-raw").textContent = "";
                $("#ts-result").innerHTML = '<div class="alert alert-erro"><span class="ico"><i class="bi bi-x-circle"></i></span><span>' + esc(r.message) + "</span></div>";
            }).catch(function () { btn.disabled = false; });
        });
    });
    $("#ts-stop").addEventListener("click", function () {
        if (!current) return;
        api("/api/troubleshooting/job/" + current + "/parar", {}).then(function () { clearTimeout(timer); poll(); });
    });
    $$("[data-ts-open]").forEach(function (b) { b.addEventListener("click", function () { open(b.getAttribute("data-ts-open")); }); });
})();
