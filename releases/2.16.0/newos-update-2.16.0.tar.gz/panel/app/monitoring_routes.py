"""
NewOS Panel - telas de Monitoramento.

    /monitoramento/zabbix          visao geral: versao do repositorio,
                                   Agent e Proxy (ligar/desligar), estado
    /monitoramento/zabbix/agent    Zabbix Agent 2: configuracao, teste, log
    /monitoramento/zabbix/proxy    Zabbix Proxy: configuracao, teste, log

O Zabbix vem SEMPRE do repositorio oficial (repo.zabbix.com), na versao
escolhida aqui (7.0 LTS, 7.4 ou 8.0).
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from datetime import datetime
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, grafana, modules, offline

log = logging.getLogger("newos.panel.monitoring")

ZBX_COMPONENTS = {
    "agent": {"key": "agent2", "title": "Zabbix Agent", "service": "zabbix-agent2",
              "icon": "bi-cpu", "active": "zabbix-agent"},
    "proxy": {"key": "proxy", "title": "Zabbix Proxy", "service": "zabbix-proxy",
              "icon": "bi-diagram-3", "active": "zabbix-proxy"},
}
ZBX_VERSIONS = [
    ("7.0", "7.0 LTS", "Suporte longo (até 2029). A escolha mais conservadora."),
    ("7.4", "7.4", "Última versão da série 7, com os recursos mais novos dela."),
    ("8.0", "8.0 LTS", "Versão estável mais nova, com suporte longo. Confira se o seu Zabbix Server já é 8.0."),
]


def _since(value: str) -> float | None:
    """'Wed 2026-10-22 11:57:18 -03' -> timestamp."""
    try:
        return datetime.strptime(" ".join(value.split()[1:3]), "%Y-%m-%d %H:%M:%S").timestamp()
    except (ValueError, IndexError):
        return None


ZBX_IFACE_TYPES = {"1": "Agente", "2": "SNMP", "3": "IPMI", "4": "JMX"}


def parse_proxy_hosts(raw: str) -> list[dict[str, Any]]:
    """Saida de 'action zabbix proxy-hosts' (H/I/C em TSV) -> lista de hosts."""
    hosts: dict[str, dict[str, Any]] = {}
    rows = [ln.split("\t") for ln in raw.splitlines()]
    for r in rows:
        if r[0] == "H" and len(r) == 5:
            hosts[r[1]] = {"host": r[2], "name": r[3] or r[2], "enabled": r[4] == "0", "interfaces": [], "items": 0}
    for r in rows:
        if r[0] == "I" and len(r) == 7 and r[1] in hosts:
            hosts[r[1]]["interfaces"].append({"type": ZBX_IFACE_TYPES.get(r[2], r[2]),
                                              "address": r[4] if r[3] == "1" else r[5], "port": r[6]})
        elif r[0] == "C" and len(r) == 3 and r[1] in hosts and r[2].isdigit():
            hosts[r[1]]["items"] = int(r[2])
    return sorted(hosts.values(), key=lambda h: h["name"].lower())


def zabbix_state() -> dict[str, Any]:
    mod = modules.get_module("zabbix") or {}
    info = modules.module_action_kv("zabbix", "info") if mod.get("enabled") else {}
    comps = {c["key"]: c for c in mod.get("components", [])}
    for name, meta in ZBX_COMPONENTS.items():
        k = meta["key"]
        info[f"{k}_since_ts"] = _since(info.get(f"{k}_since", ""))
        mem = info.get(f"{k}_mem", "")
        info[f"{k}_mem_bytes"] = int(mem) if mem.isdigit() else None
    return {"module": mod, "info": info, "components": comps}


def panel_address() -> str:
    """IP principal deste NewOS + porta do painel: o endereco que os hosts usam."""
    import socket
    from .config import get_settings
    ip = "IP-DO-NEWOS"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("1.1.1.1", 80))          # nao envia nada: so escolhe a rota
            ip = sk.getsockname()[0]
    except OSError:
        pass
    port = get_settings().http_port
    return ip if int(port) == 80 else f"{ip}:{port}"


def panel_addresses(request: Request) -> list[str]:
    """Enderecos deste NewOS para o comando do host: o que o navegador usou
    primeiro (o administrador costuma estar na mesma rede dos hosts), depois
    o IP da rota padrao e os demais IPs das placas."""
    from .config import get_settings
    port = int(get_settings().http_port)
    ips = [panel_address().rsplit(":", 1)[0] if port != 80 else panel_address()]
    try:
        out = subprocess.run(["ip", "-j", "-4", "addr", "show", "scope", "global"],
                             capture_output=True, text=True, timeout=5, check=False).stdout
        ips += [a["local"] for i in json.loads(out or "[]") for a in i.get("addr_info", [])]
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    host = (request.url.hostname or "").strip("[]")
    if host and host not in ("localhost", "127.0.0.1") and re.match(r"^[A-Za-z0-9.-]{1,253}$", host):
        ips.insert(0, host)
    ips = [ip for ip in dict.fromkeys(ips) if ip and ip != "IP-DO-NEWOS"] or ["IP-DO-NEWOS"]
    return [ip if port == 80 else f"{ip}:{port}" for ip in ips[:6]]


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        mod = modules.get_module("zabbix") or {}
        if not mod.get("enabled"):
            flash(request, "aviso", "Ligue o módulo Zabbix em Sistema > Módulos.")
            return None, redirect("/modulos")
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "zabbix", what, auth.client_ip(request))
        log.info("Zabbix por %s: %s", user["username"], what)

    # -----------------------------------------------------------------
    @app.get("/monitoramento/zabbix", response_class=HTMLResponse)
    async def zabbix_home(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        st = await run_in_threadpool(zabbix_state)
        return render(request, "zabbix_overview.html", active="zabbix", st=st,
                      versions=ZBX_VERSIONS, comps=ZBX_COMPONENTS,
                      panel_hosts=await run_in_threadpool(panel_addresses, request),
                      offline_zabbix=offline.group_info("zabbix"))

    @app.post("/monitoramento/zabbix/versao", response_class=HTMLResponse)
    async def zabbix_version(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        form = await request.form()
        version = str(form.get("version", ""))
        if version not in {v for v, _, _ in ZBX_VERSIONS}:
            flash(request, "erro", "Versão inválida.")
            return redirect("/monitoramento/zabbix")
        try:
            out = await run_in_threadpool(modules.module_action, "zabbix", "set-version",
                                          version, timeout=1800)
            audit(request, user, f"trocou o repositório para {version}")
            last = [ln for ln in out.splitlines() if ln.strip()][-1:] or ["Feito."]
            flash(request, "ok", f"Zabbix {version}: {last[0].removeprefix('[zabbix] ')}")
        except modules.ModuleError as exc:
            flash(request, "erro", str(exc))
        return redirect("/monitoramento/zabbix")

    # -----------------------------------------------------------------
    async def component_page(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        meta = ZBX_COMPONENTS[name]
        st = await run_in_threadpool(zabbix_state)
        comp = st["components"].get(meta["key"]) or {}
        if not comp.get("enabled"):
            flash(request, "aviso", f"O {meta['title']} está desligado. Ligue-o aqui.")
            return redirect("/monitoramento/zabbix")
        config = await run_in_threadpool(modules.get_config, "zabbix", meta["key"])
        raw = await run_in_threadpool(modules.get_raw_config, "zabbix", meta["key"])
        return render(request, "zabbix_component.html", active=meta["active"], st=st,
                      meta=meta, name=name, config=config, raw=raw)

    @app.get("/monitoramento/zabbix/agent", response_class=HTMLResponse)
    async def zabbix_agent_page(request: Request):
        return await component_page(request, "agent")

    @app.get("/monitoramento/zabbix/proxy", response_class=HTMLResponse)
    async def zabbix_proxy_page(request: Request):
        return await component_page(request, "proxy")

    @app.get("/monitoramento/zabbix/proxy/hosts", response_class=HTMLResponse)
    async def zabbix_proxy_hosts(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        st = await run_in_threadpool(zabbix_state)
        if not (st["components"].get("proxy") or {}).get("enabled"):
            flash(request, "aviso", "O Zabbix Proxy está desligado. Ligue-o aqui.")
            return redirect("/monitoramento/zabbix")
        error = ""
        hosts: list[dict[str, Any]] = []
        try:
            raw = await run_in_threadpool(lambda: modules.module_action("zabbix", "proxy-hosts", timeout=60))
            hosts = parse_proxy_hosts(raw)
        except modules.ModuleError as exc:
            error = str(exc)
        config = await run_in_threadpool(modules.get_config, "zabbix", "proxy")
        return render(request, "zabbix_proxy_hosts.html", active=ZBX_COMPONENTS["proxy"]["active"], st=st,
                      hosts=hosts, error=error, config=config)

    async def save(request: Request, name: str, raw_file: bool):
        user, bounce = guard(request)
        if bounce:
            return bounce
        meta = ZBX_COMPONENTS[name]
        form = await request.form()
        try:
            if raw_file:
                await run_in_threadpool(modules.set_raw_config, "zabbix", meta["key"],
                                        str(form.get("conteudo", "")))
                audit(request, user, f"editou o arquivo do {meta['title']}")
                flash(request, "ok", f"Arquivo do {meta['title']} gravado e serviço reiniciado "
                                     f"(a cópia anterior ficou como .bak).")
            else:
                values = {k: str(v) for k, v in form.items()}
                await run_in_threadpool(modules.set_config, "zabbix", meta["key"], values)
                audit(request, user, f"configurou {meta['title']}: {', '.join(sorted(values))}")
                flash(request, "ok", f"Configuração do {meta['title']} salva e aplicada.")
        except modules.ModuleError as exc:
            flash(request, "erro", str(exc))
        return redirect(f"/monitoramento/zabbix/{name}")

    # Os formularios postam no nome do componente (agent2/proxy).
    @app.post("/monitoramento/zabbix/agent2", response_class=HTMLResponse)
    async def zabbix_save_agent(request: Request):
        return await save(request, "agent", False)

    @app.post("/monitoramento/zabbix/proxy", response_class=HTMLResponse)
    async def zabbix_save_proxy(request: Request):
        return await save(request, "proxy", False)

    @app.post("/monitoramento/zabbix/proxy/otimizar", response_class=HTMLResponse)
    async def zabbix_tune_proxy(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            out = await run_in_threadpool(modules.module_action, "zabbix", "tune-proxy", timeout=300)
            audit(request, user, "aplicou o perfil otimizado do Zabbix Proxy")
            last = [ln for ln in out.splitlines() if ln.strip()][-2:] or ["Feito."]
            flash(request, "ok", " ".join(ln.removeprefix("[zabbix] ") for ln in last))
        except modules.ModuleError as exc:
            flash(request, "erro", str(exc))
        return redirect("/monitoramento/zabbix/proxy")

    @app.post("/monitoramento/zabbix/agent2/arquivo", response_class=HTMLResponse)
    async def zabbix_file_agent(request: Request):
        return await save(request, "agent", True)

    @app.post("/monitoramento/zabbix/proxy/arquivo", response_class=HTMLResponse)
    async def zabbix_file_proxy(request: Request):
        return await save(request, "proxy", True)

    # ----------------------------------------------------------------- API
    @app.get("/api/zabbix/{name}/teste")
    async def zabbix_test(request: Request, name: str):
        if not auth.current_user(request) or name not in ZBX_COMPONENTS:
            return JSONResponse({"ok": False}, status_code=401)
        try:
            raw = await run_in_threadpool(modules.module_action, "zabbix", "test",
                                          ZBX_COMPONENTS[name]["key"], timeout=120)
        except modules.ModuleError as exc:
            return {"ok": False, "message": str(exc), "results": []}
        results = []
        for line in raw.splitlines():
            parts = line.split(" ", 2)
            if len(parts) >= 2 and parts[0] in ("ok", "fail", "skip"):
                results.append({"state": parts[0], "target": parts[1],
                                "message": parts[2] if len(parts) > 2 else ""})
        return {"ok": True, "results": results}

    @app.get("/api/zabbix/{name}/log")
    async def zabbix_log(request: Request, name: str):
        if not auth.current_user(request) or name not in ZBX_COMPONENTS:
            return JSONResponse({"ok": False}, status_code=401)
        try:
            raw = await run_in_threadpool(modules.module_action, "zabbix", "log",
                                          ZBX_COMPONENTS[name]["key"], timeout=60)
        except modules.ModuleError as exc:
            return {"ok": False, "message": str(exc), "lines": []}
        lines = [ln for ln in raw.splitlines() if ln.strip() and not ln.startswith("[")][-80:]
        return {"ok": True, "lines": lines}

    @app.get("/api/zabbix/estado")
    async def zabbix_live(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        st = await run_in_threadpool(zabbix_state)
        i = st["info"]
        return {"ok": True, **{k: i.get(k) for k in ("agent2_active", "proxy_active",
                                                       "agent2_mem_bytes", "proxy_mem_bytes",
                                                       "proxy_db_bytes")}}


# =====================================================================
#  Prometheus
#
#    /monitoramento/prometheus                visao geral (ao vivo)
#    /monitoramento/prometheus/alvos          hosts, Proxmox, vCenter, Ceph, SNMP
#    /monitoramento/prometheus/configuracao   global, remote_write, jobs extras,
#                                             prometheus.yml (ver / modo manual)
# =====================================================================

PROM_SECTIONS = {"node", "pve", "vmware", "ceph", "snmp", "snmp_auth", "snmp_type", "job", "cluster"}
IMPORT_FILES = ("prometheus", "hosts", "pve", "snmp")


def register_prometheus(app: FastAPI, *, render: Callable[..., HTMLResponse],
                        flash: Callable[[Request, str, str], None],
                        redirect: Callable[[str], Any]) -> None:
    from fastapi.responses import FileResponse
    from . import prometheus as prom

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        mod = modules.get_module("prometheus") or {}
        if not mod.get("enabled"):
            flash(request, "aviso", "Ligue o módulo Prometheus em Sistema > Módulos.")
            return None, redirect("/modulos")
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "prometheus", what, auth.client_ip(request))
        log.info("Prometheus por %s: %s", user["username"], what)

    async def form_dict(request: Request) -> dict[str, Any]:
        raw = await request.form()
        return {k: (raw.getlist(k) if len(raw.getlist(k)) > 1 else str(raw.get(k))) for k in raw.keys()}

    async def do(request: Request, user: dict[str, Any], fn: Callable[..., str], *args: Any) -> bool:
        try:
            msg = await run_in_threadpool(fn, *args)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return False
        flash(request, "ok", msg or "Feito.")
        audit(request, user, msg or "alteracao")
        return True

    def module_info() -> dict[str, Any]:
        return modules.get_module("prometheus") or {}

    # -----------------------------------------------------------------
    @app.get("/monitoramento/prometheus", response_class=HTMLResponse)
    async def prom_home(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(prom.state)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            st = {}
        ov = await run_in_threadpool(prom.overview)
        return render(request, "prometheus_overview.html", active="prometheus", st=st, ov=ov,
                      mod=module_info(), panel_hosts=await run_in_threadpool(panel_addresses, request),
                      offline_exporters=offline.group_info("exporters"))

    @app.get("/api/prometheus/versoes")
    async def prom_versions(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            return {"ok": True, "versions": await run_in_threadpool(prom.versions)}
        except prom.PromError as exc:
            return {"ok": False, "message": str(exc)}

    @app.post("/monitoramento/prometheus/atualizar/{kind}", response_class=HTMLResponse)
    async def prom_update(request: Request, kind: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if kind in ("prometheus", "node", "snmp", "pve", "vmware"):
            await do(request, user, prom.update, kind)
        return redirect("/monitoramento/prometheus")

    @app.get("/api/prometheus/alvos")
    async def prom_targets_json(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        tg = await run_in_threadpool(prom.targets)
        return {"ok": True, "targets": [{k: t[k] for k in ("job", "instance", "health", "error",
                                                            "last", "duration", "address")} for t in tg]}

    # -----------------------------------------------------------------
    @app.get("/monitoramento/prometheus/alvos", response_class=HTMLResponse)
    async def prom_targets(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(prom.state)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus")
        tg = await run_in_threadpool(prom.targets)
        by_job: dict[str, list[dict[str, Any]]] = {}
        for t in tg:
            by_job.setdefault(t["job"], []).append(t)
        snmp_test = request.session.pop("prom_snmp_test", None)
        warnings = request.session.pop("prom_import_warnings", None)
        down = sum(1 for t in tg if t["health"] != "up")
        return render(request, "prometheus_targets.html", active="prometheus-alvos", st=st,
                      by_job=by_job, targets=tg, snmp_test=snmp_test, mod=module_info(),
                      import_warnings=warnings, down=down)

    @app.post("/monitoramento/prometheus/alvos/{section}/{op}", response_class=HTMLResponse)
    async def prom_target_change(request: Request, section: str, op: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if section not in PROM_SECTIONS or op not in ("save", "delete", "cluster", "edit"):
            return redirect("/monitoramento/prometheus/alvos")
        f = await form_dict(request)
        if section == "node" and op == "save" and "jobs" in f:
            f["jobs"] = (await request.form()).getlist("jobs")
        if section == "node" and op == "delete" and "addresses" in f:
            f["addresses"] = (await request.form()).getlist("addresses")
        await do(request, user, prom.apply, section, f, op)
        if section == "snmp_type":
            return redirect("/monitoramento/prometheus/snmp#tipos")
        anchor = {"node": "hosts", "pve": "proxmox", "vmware": "vmware", "ceph": "ceph",
                  "snmp": "snmp", "snmp_auth": "snmp", "job": "organizacao",
                  "cluster": "organizacao"}[section]
        return redirect(f"/monitoramento/prometheus/alvos#{anchor}")

    # -----------------------------------------------------------------
    #  SNMP: tipos de equipamento, arquivos de modulos, MIBs e gerador
    # -----------------------------------------------------------------
    @app.get("/monitoramento/prometheus/snmp", response_class=HTMLResponse)
    async def prom_snmp_page(request: Request, arquivo: str = "personalizado.yml"):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            info = await run_in_threadpool(prom.snmp_info)
            names = [f["name"] for f in info["files"]]
            cur = await run_in_threadpool(prom.snmp_file_get, arquivo if arquivo in names else "personalizado.yml")
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus/alvos#snmp")
        return render(request, "prometheus_snmp.html", active="prometheus-snmp", info=info, cur=cur,
                      mod=module_info())

    async def api_user(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        return user, None

    async def api_call(request: Request, user: dict[str, Any], what: str, fn: Callable[..., Any], *args: Any):
        try:
            res = await run_in_threadpool(fn, *args)
        except prom.PromError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
        if what:
            audit(request, user, what)
        return res

    @app.get("/api/prometheus/snmp/arquivo/{name}")
    async def prom_snmp_file(request: Request, name: str):
        user, bad = await api_user(request)
        if bad:
            return bad
        return await api_call(request, user, "", prom.snmp_file_get, name)

    @app.post("/api/prometheus/snmp/arquivo/{name}")
    async def prom_snmp_file_save(request: Request, name: str):
        user, bad = await api_user(request)
        if bad:
            return bad
        body = await request.json()
        return await api_call(request, user, f"editou o SNMP {name}", prom.snmp_file_set, name,
                              str(body.get("text", "")))

    @app.post("/api/prometheus/snmp/mib")
    async def prom_snmp_mib(request: Request):
        import base64
        user, bad = await api_user(request)
        if bad:
            return bad
        form = await request.form()
        done, errors = [], []
        for up in form.getlist("mib"):
            if not hasattr(up, "read"):
                continue
            data = await up.read(8 * 1024 * 1024 + 1)
            try:
                res = await run_in_threadpool(prom.snmp_mib_add, up.filename or "",
                                              base64.b64encode(data).decode())
                done.append(res.get("mib") or up.filename)
            except prom.PromError as exc:
                errors.append(str(exc))
        if done:
            audit(request, user, f"enviou MIB(s): {', '.join(done)}")
        return {"ok": not errors, "done": done, "errors": errors,
                "message": (f"{len(done)} MIB(s) recebida(s). " if done else "") + " ".join(errors)}

    @app.post("/api/prometheus/snmp/mib/apagar")
    async def prom_snmp_mib_del(request: Request):
        user, bad = await api_user(request)
        if bad:
            return bad
        body = await request.json()
        name = str(body.get("file", ""))
        return await api_call(request, user, f"apagou a MIB {name}", prom.snmp_mib_del, name)

    @app.post("/api/prometheus/snmp/gerar")
    async def prom_snmp_generate(request: Request):
        user, bad = await api_user(request)
        if bad:
            return bad
        body = await request.json()
        return await api_call(request, user, "gerou modulos SNMP (gerador)", prom.snmp_generate,
                              str(body.get("text", "")))

    @app.post("/api/prometheus/snmp/testar")
    async def prom_snmp_try(request: Request):
        user, bad = await api_user(request)
        if bad:
            return bad
        b = await request.json()
        return await api_call(request, user, "", prom.snmp_try, str(b.get("ip", "")), str(b.get("auth", "")),
                              str(b.get("module", "")))

    # -----------------------------------------------------------------
    #  Importar um Prometheus em funcionamento
    # -----------------------------------------------------------------
    @app.get("/monitoramento/prometheus/importar", response_class=HTMLResponse)
    async def prom_import_page(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        return render(request, "prometheus_import.html", active="prometheus-importar", plan=None,
                      mod=module_info())

    @app.post("/monitoramento/prometheus/importar", response_class=HTMLResponse)
    async def prom_import_preview(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        # Colado na caixa de texto o conteudo vira campo comum, limitado a 1 MiB
        # pelo Starlette; o snmp.yml do generator passa facil disso.
        from starlette.formparsers import MultiPartParser, MultiPartException
        parser = MultiPartParser(request.headers, request.stream(), max_files=8, max_fields=16)
        parser.max_part_size = 64 * 1024 * 1024
        try:
            form = await parser.parse()
        except MultiPartException as exc:
            flash(request, "erro", f"Envio invalido: {exc}")
            return redirect("/monitoramento/prometheus/importar")
        texts: dict[str, str] = {}
        for key in IMPORT_FILES:
            up = form.get(f"{key}_file")
            text = ""
            if up is not None and getattr(up, "filename", ""):
                text = (await up.read()).decode("utf-8", "replace")
            texts[key] = text or str(form.get(f"{key}_text", ""))
        try:
            res = await run_in_threadpool(prom.import_preview, texts)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus/importar")
        return render(request, "prometheus_import.html", active="prometheus-importar", plan=res["plan"],
                      iid=res["id"], mod=module_info())

    @app.post("/monitoramento/prometheus/importar/{iid}", response_class=HTMLResponse)
    async def prom_import_apply(request: Request, iid: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        form = await request.form()
        try:
            res = await run_in_threadpool(prom.import_apply, iid, {
                "use_global": bool(form.get("use_global")), "hosts": bool(form.get("hosts"))})
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus/importar")
        audit(request, user, res.get("message", "importacao"))
        flash(request, "ok", res.get("message", "Importado."))
        request.session["prom_import_warnings"] = [w[:300] for w in (res.get("warnings") or [])[:8]]
        return redirect("/monitoramento/prometheus/alvos")

    @app.post("/monitoramento/prometheus/snmp-descobrir", response_class=HTMLResponse)
    async def prom_snmp_discover(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_dict(request)
        community = str(f.get("community", "")).strip()
        try:
            if community:
                # community digitada na hora: cria (ou reaproveita) a credencial
                ip = str(f.get("ip", "")).strip()
                made = await run_in_threadpool(prom.apply_full, "snmp_auth", {
                    "name": str(f.get("cred_name", "")).strip() or f"v2c {community[:2]}… ({ip})",
                    "version": "2", "community": community, "reuse": "1"})
                f["auth"] = made.get("cred", "newio_v2")
            res = await run_in_threadpool(prom.test, "snmp", str(f.get("ip", "")), str(f.get("auth", "")))
            request.session["prom_snmp_test"] = {**{k: res.get(k) for k in (
                "online", "message", "vendor", "suggested", "sysname", "descr", "modules")},
                "ip": f.get("ip"), "auth": f.get("auth")}
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
        return redirect("/monitoramento/prometheus/alvos#snmp")

    @app.get("/api/prometheus/teste")
    async def prom_test(request: Request, kind: str, target: str, extra: str = ""):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            return await run_in_threadpool(prom.test, kind, target, extra)
        except prom.PromError as exc:
            return {"ok": False, "online": False, "message": str(exc)}

    # Dashboard pronta para UM alvo (host, cluster, Proxmox, Ceph): botao em Alvos.
    @app.get("/monitoramento/prometheus/grafana/{kind}/{key}")
    async def prom_grafana_target(request: Request, kind: str, key: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        fn = {"host": grafana.for_host, "cluster": grafana.for_cluster,
              "pve": grafana.for_pve, "ceph": grafana.for_ceph}.get(kind)
        if not fn:
            return JSONResponse({"ok": False}, status_code=404)
        try:
            st = await run_in_threadpool(prom.state)
            fname, dash = fn(st, key)
        except (prom.PromError, grafana.GrafanaError, OSError) as exc:
            flash(request, "erro", f"Dashboard não gerada: {exc}")
            return redirect("/monitoramento/prometheus/alvos")
        audit(request, user, f"baixou a dashboard do Grafana de {kind} {key}")
        return JSONResponse(dash, headers={"Content-Disposition": f'attachment; filename="{fname}"'})

    @app.get("/monitoramento/prometheus/grafana/{name}.json")
    async def prom_grafana_dashboard(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if name not in grafana.GENERIC:
            return JSONResponse({"ok": False}, status_code=404)
        path = f"/opt/newos-panel/modules/prometheus/files/grafana/{name}.json"
        return FileResponse(path, media_type="application/json", filename=f"{name}.json")

    @app.get("/monitoramento/prometheus/instalar-node-exporter.sh")
    async def prom_node_installer(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        return offline.script_response(request, "instalar-node-exporter.sh")

    # -----------------------------------------------------------------
    @app.get("/monitoramento/prometheus/configuracao", response_class=HTMLResponse)
    async def prom_config(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(prom.state)
            raw = await run_in_threadpool(prom.raw_get)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus")
        return render(request, "prometheus_config.html", active="prometheus-config", st=st,
                      raw=raw.get("yaml", ""), mod=module_info())

    @app.post("/monitoramento/prometheus/configuracao/{section}", response_class=HTMLResponse)
    async def prom_config_save(request: Request, section: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_dict(request)
        if section == "global":
            await do(request, user, prom.apply, "global", f)
        elif section == "remote_write":
            urls = f.get("url", [])
            urls = urls if isinstance(urls, list) else [urls]
            def col(name: str) -> list[str]:
                v = f.get(name, [])
                v = v if isinstance(v, list) else [v]
                return v + [""] * (len(urls) - len(v))
            users, pws = col("username"), col("password")
            insec = set(f.get("insecure", []) if isinstance(f.get("insecure"), list) else [f.get("insecure")])
            items = [{"url": u, "username": users[i], "password": pws[i], "insecure": str(i) in insec}
                     for i, u in enumerate(urls)]
            await do(request, user, prom.apply, "remote_write", {"items": items})
        elif section == "custom_jobs":
            await do(request, user, prom.apply, "custom_jobs", {"yaml": f.get("yaml", "")})
        elif section == "raw":
            await do(request, user, prom.raw_set, str(f.get("yaml", "")))
        elif section == "modo":
            await do(request, user, prom.set_mode, str(f.get("mode", "")))
        return redirect("/monitoramento/prometheus/configuracao")


def register_prometheus_alerts(app: FastAPI, *, render: Callable[..., HTMLResponse],
                               flash: Callable[[Request, str, str], None],
                               redirect: Callable[[str], Any]) -> None:
    from . import prometheus as prom

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        mod = modules.get_module("prometheus") or {}
        comps = {c["key"]: c["enabled"] for c in mod.get("components", [])}
        if not mod.get("enabled") or not comps.get("alertmanager"):
            flash(request, "aviso", "Ligue o componente Alertmanager em Monitoramento > Prometheus.")
            return None, redirect("/monitoramento/prometheus" if mod.get("enabled") else "/modulos")
        return user, None

    async def do(request: Request, user: dict[str, Any], fn: Callable[..., str], *args: Any) -> bool:
        try:
            msg = await run_in_threadpool(fn, *args)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return False
        flash(request, "ok", msg or "Feito.")
        db.log_audit(user["username"], "prometheus", msg or "alertas", auth.client_ip(request))
        return True

    @app.get("/monitoramento/prometheus/alertas", response_class=HTMLResponse)
    async def prom_alerts(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(prom.state)
            det = await run_in_threadpool(prom.alerts_detect)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            return redirect("/monitoramento/prometheus")
        try:
            cat = await run_in_threadpool(prom.rules)
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
            cat = {"packs": [], "template": "", "custom_template": False}
        return render(request, "prometheus_alerts.html", active="prometheus-alertas", st=st, det=det,
                      alerts=await run_in_threadpool(prom.active_alerts), cat=cat)

    @app.post("/monitoramento/prometheus/alertas/regras/{op}", response_class=HTMLResponse)
    async def prom_rules_change(request: Request, op: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if op not in ("pack_add", "pack_refresh", "pack_toggle", "pack_delete",
                      "rule_toggle", "rule_save", "rule_reset"):
            return redirect("/monitoramento/prometheus/alertas")
        raw = await request.form()
        data: dict[str, Any] = {k: str(raw.get(k)) for k in raw.keys() if k != "limits"}
        if "limits" in raw:
            data["limits"] = [str(v) for v in raw.getlist("limits")]
        await do(request, user, prom.apply, "rules", data, op)
        anchor = f"#pk-{data.get('pack', '')}" if data.get("pack") else "#regras"
        return redirect("/monitoramento/prometheus/alertas" + anchor)

    @app.post("/monitoramento/prometheus/alertas/mensagem/{op}", response_class=HTMLResponse)
    async def prom_template_change(request: Request, op: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        raw = await request.form()
        await do(request, user, prom.apply, "tg_template", {"template": str(raw.get("template", ""))},
                 "reset" if op == "padrao" else "save")
        return redirect("/monitoramento/prometheus/alertas#mensagem")

    @app.post("/monitoramento/prometheus/alertas", response_class=HTMLResponse)
    async def prom_alerts_save(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        raw = await request.form()
        data = {k: str(raw.get(k)) for k in raw.keys() if k != "modules"}
        data["modules"] = [str(v) for v in raw.getlist("modules")]
        try:
            msg = await run_in_threadpool(prom.apply, "alerts", data)
            flash(request, "ok", msg)
            db.log_audit(user["username"], "prometheus", "configurou os alertas", auth.client_ip(request))
        except prom.PromError as exc:
            flash(request, "erro", str(exc))
        return redirect("/monitoramento/prometheus/alertas")

    @app.get("/api/prometheus/alertas/teste")
    async def prom_alerts_test(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            return await run_in_threadpool(prom.alerts_test)
        except prom.PromError as exc:
            return {"ok": False, "online": False, "message": str(exc)}
