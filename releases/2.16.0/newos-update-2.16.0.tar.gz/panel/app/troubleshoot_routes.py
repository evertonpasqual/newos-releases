"""
NewOS Panel - modulo Troubleshooting (Network > Troubleshooting).

    /network/troubleshooting                  as ferramentas
    POST /api/troubleshooting/iniciar         {"tool": ...}  -> {"id"}
    GET  /api/troubleshooting/job/<id>        estado, saida ao vivo, resultado
    POST /api/troubleshooting/job/<id>/parar
    GET  /api/troubleshooting/job/<id>/pcap   baixa a captura de pacotes

Somente administradores. O helper newos-troubleshoot valida cada campo e
executa fora do sandbox do painel; cada execucao vai para a auditoria.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules, terminal_routes

log = logging.getLogger("newos.panel.troubleshoot")
HELPER = "/usr/local/sbin/newos-troubleshoot"
ID_RE = re.compile(r"^\d{8}-\d{6}-[0-9a-f]{6}$")
TOOL_LABEL = {"dns": "DNS", "ping": "Ping", "rota": "Rota (MTR)", "portas": "Portas abertas",
              "descoberta": "Descoberta de rede", "interfaces": "Saúde das interfaces", "loop": "Loop na rede",
              "dhcp": "DHCP e IP duplicado", "lldp": "Vizinhos LLDP/CDP", "captura": "Captura de pacotes",
              "mtu": "MTU do caminho", "http": "HTTP/TLS", "snmp": "SNMP"}


class ToolError(Exception):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=60, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise ToolError(f"Não foi possível executar a ferramenta: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise ToolError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def pcap_bytes(jid: str) -> bytes:
    """Bytes do .pcap (ate 20 MB, o limite da captura)."""
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, "pcap", jid], capture_output=True, timeout=60, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise ToolError(f"Não foi possível ler a captura: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in proc.stderr.decode("utf-8", "replace").splitlines() if ln.strip()]
        raise ToolError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return proc.stdout


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("troubleshooting") or {}).get("enabled"))

    async def api_guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão encerrada."}, status_code=401)
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            return None, JSONResponse({"ok": False, "message": "Só administradores usam o Troubleshooting."}, status_code=403)
        if not enabled():
            return None, JSONResponse({"ok": False, "message": "Módulo Troubleshooting desligado."}, status_code=409)
        return user, None

    @app.get("/network/troubleshooting", response_class=HTMLResponse)
    async def tshoot_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Troubleshooting em Sistema > Módulos.")
            return redirect("/modulos")
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            flash(request, "erro", "Só administradores usam o Troubleshooting.")
            return redirect("/")
        try:
            info = await run_in_threadpool(helper, ["ifaces"])
            ifaces, links, default = info.get("ifaces", []), info.get("links", []), info.get("default", "")
            history = (await run_in_threadpool(helper, ["list"])).get("items", [])
        except ToolError as exc:
            log.warning("Troubleshooting: %s", exc)
            ifaces, links, default, history = [], [], "", []
        return render(request, "troubleshooting.html", active="troubleshooting", ifaces=ifaces, links=links,
                      default_iface=default, history=history, labels=TOOL_LABEL)

    @app.post("/api/troubleshooting/iniciar")
    async def tshoot_start(request: Request):
        user, bad = await api_guard(request)
        if bad:
            return bad
        try:
            body = await request.json()
        except ValueError:
            return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)
        if not isinstance(body, dict):
            return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)
        body["user"] = user["username"]
        try:
            res = await run_in_threadpool(helper, ["start"], body)
        except ToolError as exc:
            return {"ok": False, "message": str(exc)}
        what = TOOL_LABEL.get(body.get("tool"), "?")
        db.log_audit(user["username"], "troubleshooting", f"{what}: {res.get('target', '')} ({res['id']})", auth.client_ip(request))
        return res

    @app.get("/api/troubleshooting/job/{jid}")
    async def tshoot_status(request: Request, jid: str):
        _, bad = await api_guard(request)
        if bad:
            return bad
        if not ID_RE.match(jid):
            return JSONResponse({"ok": False, "message": "Identificador inválido."}, status_code=400)
        try:
            return await run_in_threadpool(helper, ["status", jid])
        except ToolError as exc:
            return {"ok": False, "message": str(exc)}

    @app.post("/api/troubleshooting/job/{jid}/parar")
    async def tshoot_stop(request: Request, jid: str):
        user, bad = await api_guard(request)
        if bad:
            return bad
        if not ID_RE.match(jid):
            return JSONResponse({"ok": False, "message": "Identificador inválido."}, status_code=400)
        try:
            res = await run_in_threadpool(helper, ["stop", jid])
        except ToolError as exc:
            return {"ok": False, "message": str(exc)}
        db.log_audit(user["username"], "troubleshooting", f"interrompeu {jid}", auth.client_ip(request))
        return res

    @app.get("/api/troubleshooting/job/{jid}/pcap")
    async def tshoot_pcap(request: Request, jid: str):
        user, bad = await api_guard(request)
        if bad:
            return bad
        if not ID_RE.match(jid):
            return JSONResponse({"ok": False, "message": "Identificador inválido."}, status_code=400)
        try:
            data = await run_in_threadpool(pcap_bytes, jid)
        except ToolError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=404)
        db.log_audit(user["username"], "troubleshooting", f"baixou a captura {jid}", auth.client_ip(request))
        return Response(data, media_type="application/vnd.tcpdump.pcap",
                        headers={"Content-Disposition": f'attachment; filename="captura-{jid}.pcap"',
                                 "Cache-Control": "no-store"})
