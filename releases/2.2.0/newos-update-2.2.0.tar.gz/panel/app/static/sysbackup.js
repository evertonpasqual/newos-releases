/* =====================================================================
   NewOS Panel - Sistema > Backup e restauracao
   - campos que aparecem conforme a escolha (radio, select, checkbox)
   - "Testar bucket" sem sair da tela
   - copias no S3 carregadas depois da pagina (o bucket pode demorar)
   - arquivo escolhido / arrastado para restaurar
   - andamento da restauracao ao vivo; no fim os usuarios do painel
     podem ter mudado: a sessao cai e a tela leva ao login
   ===================================================================== */
(function () {
    "use strict";

    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }

    /* ---------------- campos condicionais ------------------------------ */
    function wireRadio(el) {
        var m = el.getAttribute("data-show-radio").split("=");
        var form = el.closest("form");
        function upd() {
            var c = form.querySelector('input[name="' + m[0] + '"]:checked');
            el.hidden = !(c && c.value === m[1]);
        }
        form.querySelectorAll('input[name="' + m[0] + '"]').forEach(function (r) { r.addEventListener("change", upd); });
        upd();
    }
    document.querySelectorAll("[data-show-radio]").forEach(wireRadio);

    document.querySelectorAll("[data-show-select]").forEach(function (el) {
        var m = el.getAttribute("data-show-select").split("=");
        var sel = el.closest("form").querySelector('select[name="' + m[0] + '"]');
        function upd() { el.style.display = sel.value === m[1] ? "" : "none"; }
        sel.addEventListener("change", upd);
        upd();
    });

    document.querySelectorAll("[data-toggle-box]").forEach(function (cb) {
        var box = document.getElementById(cb.getAttribute("data-toggle-box"));
        function upd() { box.classList.toggle("is-off", !cb.checked); }
        cb.addEventListener("change", upd);
        upd();
    });

    /* ---------------- testar o bucket ---------------------------------- */
    var testBtn = document.querySelector("[data-s3-test]");
    if (testBtn) {
        testBtn.addEventListener("click", function () {
            var out = document.getElementById("sbk-s3-result");
            out.className = "sbk-test";
            out.innerHTML = '<span class="bk-pulse"></span> testando…';
            testBtn.disabled = true;
            fetch("/sistema/backup/s3-testar", { method: "POST", credentials: "same-origin",
                                                  body: new FormData(testBtn.closest("form")) })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    out.className = "sbk-test " + (d.ok ? "good" : "bad");
                    out.innerHTML = '<i class="bi ' + (d.ok ? "bi-check2-circle" : "bi-x-octagon") + '"></i> ' + esc(d.message);
                })
                .catch(function () { out.className = "sbk-test bad"; out.textContent = "sem resposta do painel"; })
                .then(function () { testBtn.disabled = false; });
        });
    }

    /* ---------------- copias no S3 ------------------------------------- */
    var rows = document.getElementById("sbk-rows");
    if (rows && rows.getAttribute("data-s3")) {
        fetch("/api/sysbackup/remoto", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                var loading = rows.querySelector(".sbk-s3-loading");
                if (loading) loading.remove();
                if (d.s3_error || d.message) {
                    rows.insertAdjacentHTML("beforeend", '<tr><td colspan="6" class="empty"><i class="bi bi-exclamation-triangle zbx-bad"></i> ' + esc(d.s3_error || d.message) + "</td></tr>");
                }
                (d.s3 || []).forEach(function (b, i) {
                    var q = "origem=s3&nome=" + encodeURIComponent(b.name);
                    rows.insertAdjacentHTML("beforeend",
                        '<tr class="sbk-new" style="--r:' + Math.min(i, 10) + '">' +
                        '<td><span class="badge badge-up"><i class="bi bi-bucket"></i> S3</span></td>' +
                        '<td class="strong">' + esc(b.host) + "</td><td>" + esc(b.when) + '</td><td class="mono">' + esc(b.version) + "</td>" +
                        "<td>" + esc(b.size_h) + " " + (b.encrypted ? '<i class="bi bi-lock-fill sys-ok" title="protegido por senha"></i>' : '<i class="bi bi-unlock muted" title="sem senha"></i>') + "</td>" +
                        '<td class="sbk-acts"><a class="btn btn-ghost btn-sm" href="/sistema/backup/baixar?' + q + '"><i class="bi bi-download"></i> Baixar</a>' +
                        '<form method="post" action="/sistema/backup/restaurar/usar" data-busy><input type="hidden" name="origem" value="s3"><input type="hidden" name="nome" value="' + esc(b.name) + '">' +
                        '<button class="btn btn-ghost btn-sm" type="submit"><i class="bi bi-arrow-counterclockwise"></i> Restaurar…</button></form>' +
                        '<details class="act"><summary class="btn btn-ghost btn-sm"><i class="bi bi-trash"></i> </summary><div class="act-body">' +
                        '<form method="post" action="/sistema/backup/apagar" data-busy><input type="hidden" name="origem" value="s3"><input type="hidden" name="nome" value="' + esc(b.name) + '">' +
                        '<p class="card-text">Apaga <span class="mono">' + esc(b.name) + '</span> do bucket.</p>' +
                        '<div class="field confirm-field"><label>Para confirmar, digite <span class="mono strong">apagar</span></label><input type="text" name="confirm" required autocomplete="off" placeholder="apagar" pattern="apagar"></div>' +
                        '<button class="btn btn-danger btn-sm" type="submit">Apagar cópia</button></form></div></details></td></tr>');
                });
                var n = rows.querySelectorAll("tr").length - rows.querySelectorAll("td.empty").length;
                var sum = document.getElementById("sbk-count");
                if (sum) sum.textContent = n + " cópia" + (n === 1 ? "" : "s");
            })
            .catch(function () {
                var loading = rows.querySelector(".sbk-s3-loading");
                if (loading) loading.querySelector("td").textContent = "Não foi possível consultar o S3.";
            });
    }

    /* ---------------- arquivo para restaurar --------------------------- */
    var drop = document.getElementById("sbk-drop");
    if (drop) {
        var input = drop.querySelector("input[type=file]");
        var label = document.getElementById("sbk-file");
        input.addEventListener("change", function () {
            var f = input.files && input.files[0];
            label.textContent = f ? f.name + " (" + (f.size / 1048576).toFixed(1) + " MiB)" : "Escolha ou arraste o arquivo";
            drop.classList.toggle("has-file", !!f);
        });
        ["dragenter", "dragover"].forEach(function (ev) {
            drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("drag"); });
        });
        ["dragleave", "drop"].forEach(function (ev) {
            drop.addEventListener(ev, function () { drop.classList.remove("drag"); });
        });
        drop.addEventListener("drop", function (e) {
            e.preventDefault();
            if (e.dataTransfer && e.dataTransfer.files.length) {
                input.files = e.dataTransfer.files;
                input.dispatchEvent(new Event("change"));
            }
        });
    }

    /* ---------------- rede marcada => sugerir reiniciar ---------------- */
    var net = document.querySelector("[data-net]");
    var reboot = document.querySelector("[data-reboot]");
    if (net && reboot) {
        function sync() { reboot.checked = net.checked; }
        net.addEventListener("change", sync);
        sync();
    }

    /* ---------------- andamento da restauracao ------------------------- */
    var box = document.getElementById("restauracao");
    if (!box || box.getAttribute("data-status") !== "running") return;
    var logBox = document.getElementById("sbk-log");
    var title = document.getElementById("sbk-title");
    var msg = document.getElementById("sbk-msg");
    var step = document.getElementById("sbk-step");
    var working = document.getElementById("sbk-working");
    logBox.scrollTop = logBox.scrollHeight;

    var timer = setInterval(function () {
        fetch("/api/sysbackup/restauracao", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) {
                if (r.status === 401) {
                    clearInterval(timer);
                    working.classList.remove("show");
                    title.textContent = "Restauração concluída";
                    msg.innerHTML = 'Os usuários do painel agora são os do backup. <a href="/login">Entre de novo</a> com eles.';
                    return null;
                }
                return r.json();
            })
            .then(function (d) {
                if (!d || !d.ok) return;
                logBox.innerHTML = (d.log || []).map(function (l) {
                    return '<div class="bk-log-line ' + (/AVISO|FALHOU/.test(l) ? "err" : "") + '"><span class="bk-log-text">' + esc(l) + "</span></div>";
                }).join("");
                logBox.scrollTop = logBox.scrollHeight;
                var st = d.state || {};
                if (st.step) step.textContent = st.step;
                if (st.status && st.status !== "running") {
                    clearInterval(timer);
                    working.classList.remove("show");
                    title.textContent = st.status === "failed" ? "A restauração parou" : "Restauração concluída";
                    msg.textContent = st.message || "";
                    setTimeout(function () { location.reload(); }, 4000);
                }
            })
            .catch(function () { step.textContent = "aguardando o servidor…"; });
    }, 2500);

    /* ---------------- restaurar de outro NewOS (S3) ------------------- */
    var nav = document.getElementById("s3nav");
    if (nav) {
        var hostsBox = document.getElementById("s3n-hosts"), itemsBox = document.getElementById("s3n-items");
        var msg = document.getElementById("s3n-msg"), search = document.getElementById("s3n-search");
        var alt = nav.querySelector(".s3n-alt");
        function conn() {
            if (!alt.open) return null;              // usa o S3 configurado
            var o = {};
            nav.querySelectorAll("[data-s3n]").forEach(function (el) {
                o[el.getAttribute("data-s3n")] = el.type === "checkbox" ? el.checked : el.value.trim();
            });
            return o;
        }
        function post(url, body) {
            return fetch(url, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body) }).then(function (r) { if (r.status === 401) { location.href = "/login"; throw 0; } return r.json(); });
        }
        function busy(t) { msg.innerHTML = t ? '<span class="bk-pulse"></span> ' + esc(t) : ""; }
        function hosts() {
            busy("consultando o bucket…"); itemsBox.hidden = true; hostsBox.hidden = false;
            post("/api/sysbackup/s3/navegar", { s3: conn() }).then(function (d) {
                busy("");
                if (!d.ok) { msg.innerHTML = '<span class="zbx-bad"><i class="bi bi-x-octagon"></i> ' + esc(d.message) + "</span>"; return; }
                document.getElementById("s3n-where").innerHTML = '<i class="bi bi-hdd-network"></i> <span class="mono">s3://' + esc(d.where.bucket) + "/" + esc(d.where.prefix) +
                    '</span> <span class="nic-sub">' + esc(d.where.endpoint) + " · " + d.hosts.length + " servidor(es)</span>";
                hostsBox.innerHTML = d.hosts.length ? d.hosts.map(function (h, i) {
                    return '<button type="button" class="s3n-host" style="--i:' + Math.min(i, 20) + '" data-host="' + esc(h.host) + '">' +
                        '<i class="bi bi-hdd-rack"></i><span class="s3n-name">' + esc(h.host) + (h.host === d.mine ? ' <span class="badge badge-role mini">este</span>' : "") + "</span>" +
                        '<span class="nic-sub">' + h.count + " backup(s) · último " + esc(h.last) + "</span>" +
                        '<span class="nic-sub">NewOS ' + esc(h.version) + " · " + esc(h.human) + "</span></button>";
                }).join("") : '<div class="empty">Nenhum backup do NewOS neste bucket/prefixo.</div>';
                filter();
            }).catch(function () { busy(""); });
        }
        function items(host) {
            busy("listando os backups de " + host + "…");
            post("/api/sysbackup/s3/navegar", { s3: conn(), host: host }).then(function (d) {
                busy("");
                if (!d.ok) { msg.innerHTML = '<span class="zbx-bad">' + esc(d.message) + "</span>"; return; }
                hostsBox.hidden = true; itemsBox.hidden = false;
                document.getElementById("s3n-host").textContent = host + " · " + d.items.length + " backup(s)";
                document.getElementById("s3n-rows").innerHTML = d.items.map(function (b, i) {
                    return '<tr style="--r:' + Math.min(i, 10) + '"><td>' + esc(b.when) + '</td><td class="mono">' + esc(b.version) + "</td><td>" + esc(b.human) + " " +
                        (b.encrypted ? '<i class="bi bi-lock-fill sys-ok" title="protegido por senha"></i>' : '<i class="bi bi-unlock muted" title="sem senha"></i>') +
                        '</td><td><button type="button" class="btn btn-sm" data-key="' + esc(b.key) + '"><i class="bi bi-arrow-counterclockwise"></i> Restaurar este…</button></td></tr>';
                }).join("");
            });
        }
        function filter() {
            var q = (search.value || "").toLowerCase();
            hostsBox.querySelectorAll(".s3n-host").forEach(function (b) { b.hidden = q && b.getAttribute("data-host").toLowerCase().indexOf(q) < 0; });
        }
        document.getElementById("s3n-go").addEventListener("click", hosts);
        document.getElementById("s3n-back").addEventListener("click", function () { itemsBox.hidden = true; hostsBox.hidden = false; });
        search.addEventListener("input", filter);
        hostsBox.addEventListener("click", function (e) { var b = e.target.closest("[data-host]"); if (b) items(b.getAttribute("data-host")); });
        document.getElementById("s3n-rows").addEventListener("click", function (e) {
            var b = e.target.closest("[data-key]"); if (!b) return;
            b.disabled = true; busy("baixando o backup do bucket…");
            post("/api/sysbackup/s3/usar", { s3: conn(), key: b.getAttribute("data-key") }).then(function (d) {
                if (d.ok) { location.href = d.url; return; }
                b.disabled = false; busy(""); msg.innerHTML = '<span class="zbx-bad">' + esc(d.message) + "</span>";
            });
        });
        if (nav.classList.contains("open") && !alt.open) hosts();
    }
})();
