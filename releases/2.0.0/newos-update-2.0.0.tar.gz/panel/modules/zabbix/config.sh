#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - leitura e escrita da configuracao pela web
# ---------------------------------------------------------------------
#  Uso:
#     config.sh show     <agent2|proxy>
#     config.sh set      <agent2|proxy> KEY=VALOR [KEY=VALOR...]
#     config.sh raw-show <agent2|proxy>            -> imprime o .conf inteiro
#     config.sh raw-set  <agent2|proxy>            -> le o .conf novo do stdin
#
#  Somente as chaves da ALLOWLIST abaixo podem ser alteradas. Isso evita
#  que a interface web consiga escrever qualquer diretiva no .conf --
#  incluindo as perigosas, como AllowKey ou LoadModulePath.
# =====================================================================
set -Eeuo pipefail

ACTION="${1:?uso: config.sh <show|set> <componente> [KEY=VALOR...]}"
COMPONENT="${2:?uso: config.sh <show|set> <componente> [KEY=VALOR...]}"
shift 2 || true

case "${COMPONENT}" in
    agent2) CONF="/etc/zabbix/zabbix_agent2.conf"
            SERVICE="zabbix-agent2"
            ALLOWED="Server ServerActive Hostname HostMetadata ListenPort RefreshActiveChecks Timeout LogFileSize DebugLevel"
            ;;
    proxy)  CONF="/etc/zabbix/zabbix_proxy.conf"
            SERVICE="zabbix-proxy"
            ALLOWED="ProxyMode Server Hostname ListenPort ProxyConfigFrequency DataSenderFrequency StartPollers CacheSize Timeout DebugLevel ProxyLocalBuffer ProxyOfflineBuffer"
            ;;
    *) echo "Componente invalido: ${COMPONENT}" >&2; exit 1 ;;
esac

[[ -f "${CONF}" ]] || { echo "ERRO: ${CONF} nao existe. O componente esta instalado?" >&2; exit 1; }

# =====================================================================
#  restart_or_rollback
#    Reinicia o servico so se ele ja estava rodando. Se nao subir com a
#    configuracao nova, volta o .bak e sobe de novo -- o painel nunca
#    deixa o servico caido por causa de uma edicao.
# =====================================================================
restart_or_rollback() {
    if ! systemctl is-active --quiet "${SERVICE}"; then
        echo "[zabbix] ${SERVICE} nao esta rodando; configuracao salva."
        return 0
    fi

    echo "[zabbix] Reiniciando ${SERVICE}..."
    systemctl restart "${SERVICE}" || true
    sleep 2

    if systemctl is-active --quiet "${SERVICE}"; then
        echo "[zabbix] ${SERVICE} reiniciado."
        return 0
    fi

    echo "[zabbix] ERRO: ${SERVICE} nao subiu com a nova configuracao." >&2
    journalctl -u "${SERVICE}" --no-pager -n 15 2>&1 | \
        sed 's/^/[zabbix]   /' >&2 || true
    echo "[zabbix] Voltando o arquivo anterior..." >&2
    cp -f "${CONF}.bak" "${CONF}"
    systemctl restart "${SERVICE}" || true
    exit 1
}

# =====================================================================
#  EDICAO DO ARQUIVO INTEIRO
# ---------------------------------------------------------------------
#  A allowlist acima cobre o dia a dia. Estas duas acoes existem para
#  quando e preciso mexer em qualquer diretiva -- o painel entrega o
#  arquivo como ele e, grava o que voltar e desfaz sozinho se o servico
#  nao subir.
# =====================================================================
if [[ "${ACTION}" == "raw-show" ]]; then
    cat "${CONF}"
    exit 0
fi

if [[ "${ACTION}" == "raw-set" ]]; then
    TMP="$(mktemp)"
    trap 'rm -f "${TMP}"' EXIT
    cat >"${TMP}"

    # Recusa arquivo vazio: seria a forma mais facil de derrubar o servico.
    if [[ ! -s "${TMP}" ]]; then
        echo "ERRO: o conteudo enviado esta vazio. Nada foi gravado." >&2
        exit 1
    fi
    # Recusa byte nulo: nao e um arquivo de configuracao.
    if grep -qP '\x00' "${TMP}" 2>/dev/null; then
        echo "ERRO: o conteudo enviado tem bytes nulos. Nada foi gravado." >&2
        exit 1
    fi
    # Limite de tamanho, so por seguranca.
    if (( $(stat -c%s "${TMP}") > 524288 )); then
        echo "ERRO: o arquivo passou de 512 KB. Nada foi gravado." >&2
        exit 1
    fi

    cp -f "${CONF}" "${CONF}.bak"
    # Normaliza CRLF: o navegador manda \r\n e o Zabbix nao gosta.
    tr -d '\r' <"${TMP}" >"${CONF}"
    chown root:zabbix "${CONF}" 2>/dev/null || true
    chmod 0640 "${CONF}" 2>/dev/null || true
    echo "[zabbix] ${CONF} gravado (copia anterior em ${CONF}.bak)."

    restart_or_rollback
    exit 0
fi

# ---------------------------------------------------------------------
# show - imprime as chaves gerenciadas, uma por linha
# ---------------------------------------------------------------------
if [[ "${ACTION}" == "show" ]]; then
    for key in ${ALLOWED}; do
        value="$(grep -oP "^\s*${key}\s*=\s*\K.*$" "${CONF}" 2>/dev/null | tail -1 || true)"
        printf '%s=%s\n' "${key}" "${value}"
    done
    exit 0
fi

[[ "${ACTION}" == "set" ]] || { echo "Acao invalida: ${ACTION}" >&2; exit 1; }
(( $# >= 1 )) || { echo "Nada a alterar." >&2; exit 1; }

# ---------------------------------------------------------------------
# set - valida cada par contra a allowlist e grava
# ---------------------------------------------------------------------
for pair in "$@"; do
    key="${pair%%=*}"
    ok=0
    for a in ${ALLOWED}; do [[ "${key}" == "${a}" ]] && ok=1; done
    (( ok == 1 )) || { echo "ERRO: a chave '${key}' nao pode ser alterada pelo painel." >&2; exit 1; }
done

cp -f "${CONF}" "${CONF}.bak"

python3 - "${CONF}" "$@" <<'PY'
import re, sys
path = sys.argv[1]
pairs = {}
for arg in sys.argv[2:]:
    k, _, v = arg.partition("=")
    pairs[k] = v

with open(path, encoding="utf-8", errors="replace") as fh:
    lines = fh.read().splitlines()

seen = set()
out = []
for line in lines:
    m = re.match(r"^\s*(\w+)\s*=", line)
    if m and m.group(1) in pairs:
        key = m.group(1)
        if key in seen:
            continue                       # remove duplicatas antigas
        value = pairs[key]
        # Valor vazio: comenta a diretiva em vez de gravar "Key="
        out.append(f"{key}={value}" if value else f"# {key}=")
        seen.add(key)
    else:
        out.append(line)

missing = [k for k in pairs if k not in seen and pairs[k]]
if missing:
    out.append("")
    out.append("### NewOS - definido pelo painel web")
    out += [f"{k}={pairs[k]}" for k in missing]

with open(path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
print(f"[zabbix] {len(pairs)} chave(s) aplicada(s) em {path}")
PY

chown root:zabbix "${CONF}" 2>/dev/null || true
chmod 0640 "${CONF}" 2>/dev/null || true

# ---------------------------------------------------------------------
# Reinicia so se o servico ja estava rodando.
# ---------------------------------------------------------------------
restart_or_rollback
