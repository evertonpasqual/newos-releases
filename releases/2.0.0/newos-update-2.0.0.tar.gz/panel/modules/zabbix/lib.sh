#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - versao do repositorio oficial
# ---------------------------------------------------------------------
#  A versao escolhida no painel fica em /etc/newos/zabbix.version
#  (padrao 7.4). Sempre do repositorio oficial da Zabbix:
#      https://www.zabbix.com/download
#  O 7.0 LTS usa o caminho antigo (sem "release/"); 7.4 e 8.0, o novo.
# =====================================================================
# shellcheck disable=SC2034
ZBX_VERSION_FILE="/etc/newos/zabbix.version"
ZBX_VERSIONS="7.0 7.4 8.0"

zbx_version() {
    local v
    v="$(tr -d ' \n' <"${ZBX_VERSION_FILE}" 2>/dev/null || true)"
    [[ " ${ZBX_VERSIONS} " == *" ${v} "* ]] || v="7.4"
    printf '%s' "${v}"
}

zbx_release_url() {
    local v="$1" path="release/debian"
    [[ "${v}" == "7.0" ]] && path="debian"
    printf 'https://repo.zabbix.com/zabbix/%s/%s/pool/main/z/zabbix-release/zabbix-release_latest_%s+debian13_all.deb' \
        "${v}" "${path}" "${v}"
}

# Versao do repositorio instalado agora ("7.4"), lida do zabbix-release.
zbx_repo_installed() {
    dpkg-query -W -f='${Version}' zabbix-release 2>/dev/null | sed -nE 's/^([0-9]+:)?([0-9]+\.[0-9]+).*/\2/p'
}
