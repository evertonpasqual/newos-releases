"""
NewOS Panel - Sistema > Backup e restauracao (do proprio NewOS).

    /sistema/backup                          copias, agendamento, restaurar
    POST /sistema/backup/gerar               gera agora (senha opcional)
    POST /sistema/backup/agenda              agendamento, destinos, retencao
    POST /sistema/backup/s3-testar           (JSON) testa o bucket
    GET  /api/sysbackup/remoto               (JSON) copias na pasta e no S3
    GET  /sistema/backup/baixar              download de uma copia
    POST /sistema/backup/apagar
    POST /sistema/backup/restaurar/enviar    recebe um pacote (upload)
    POST /sistema/backup/restaurar/usar      usa uma copia ja guardada
    GET  /sistema/backup/restaurar/<id>      confere e mostra o que volta
    POST /sistema/backup/restaurar/<id>/abrir     senha do pacote
    POST /sistema/backup/restaurar/<id>/aplicar   restaura (2o plano)
    POST /sistema/backup/restaurar/<id>/descartar
    GET  /api/sysbackup/restauracao          (JSON) andamento
    POST /sistema/backup/restauracao/fechar  some com o quadro de andamento

Quem faz tudo e o helper newos-sysbackup (root, via sudo).
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.background import BackgroundTask
from starlette.concurrency import run_in_threadpool

from . import auth, db

log = logging.getLogger("newos.panel.sysbackup")
HELPER = "/usr/local/sbin/newos-sysbackup"
STAGE_RE = re.compile(r"^[a-f0-9]{16}$")
SOURCES = ("local", "dest", "s3")


class SysBackupError(Exception):
    pass


def _parse(proc: subprocess.CompletedProcess) -> dict[str, Any]:
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout or "").splitlines() if ln.strip()]
        raise SysBackupError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError) as exc:
        raise SysBackupError("Resposta inesperada do helper.") from exc


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SysBackupError(f"Nao foi possivel executar o helper: {exc}") from exc
    return _parse(proc)


def stage_upload(fileobj, filename: str) -> dict[str, Any]:
    """Entrega o arquivo enviado ao helper pela entrada padrao, aos pedacos."""
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", os.path.basename(filename or "upload"))[:120]
    try:
        proc = subprocess.Popen(["sudo", "-n", HELPER, "stage", safe], stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except OSError as exc:
        raise SysBackupError(f"Nao foi possivel executar o helper: {exc}") from exc
    try:
        fileobj.seek(0)
        while chunk := fileobj.read(1 << 20):
            proc.stdin.write(chunk)
    except BrokenPipeError:
        pass                    # o helper recusou e saiu: o motivo vem no stderr
    out, err = proc.communicate(timeout=1200)   # fecha a entrada e espera
    return _parse(subprocess.CompletedProcess(proc.args, proc.returncode,
                                              out.decode("utf-8", "replace"), err.decode("utf-8", "replace")))


WEEKDAYS = [("mon", "segunda"), ("tue", "terça"), ("wed", "quarta"), ("thu", "quinta"),
            ("fri", "sexta"), ("sat", "sábado"), ("sun", "domingo")]
SECTION_INFO = {
    "identity": ("bi-tag", "Nome do servidor", "hostname, domínio e /etc/hosts"),
    "network": ("bi-diagram-2", "Rede", "interfaces, bonds, VLANs, rotas e DNS"),
    "storage": ("bi-hdd-stack", "Montagens", "discos montados e pools ZFS"),
    "modules": ("bi-puzzle", "Módulos", "liga os mesmos módulos e componentes com a mesma configuração"),
    "panel": ("bi-people", "Painel", "usuários, ajustes e histórico"),
    "ssh": ("bi-key", "Acesso SSH", "chaves do servidor e chaves autorizadas"),
}


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    @app.get("/sistema/backup", response_class=HTMLResponse)
    async def sysbackup_page(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        try:
            info = await run_in_threadpool(helper, ["info"])
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            info = {}
        rs = {}
        if (info.get("restore") or {}).get("status"):
            try:
                rs = await run_in_threadpool(helper, ["restore-status"])
            except SysBackupError:
                rs = {}
        return render(request, "sysbackup.html", active="sysbackup", info=info, rs=rs,
                      weekdays=WEEKDAYS)

    @app.post("/sistema/backup/gerar", response_class=HTMLResponse)
    async def sysbackup_create(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        f = await request.form()
        mode = str(f.get("protect", "none"))
        payload = {"send": bool(f.get("send")), "password": "", "use_saved_password": mode == "saved"}
        if mode == "new":
            pw, pw2 = str(f.get("password", "")), str(f.get("password2", ""))
            if pw != pw2:
                flash(request, "erro", "As senhas não conferem.")
                return redirect("/sistema/backup")
            payload["password"] = pw
        try:
            res = await run_in_threadpool(helper, ["create"], payload, 3600)
            db.log_audit(user["username"], "sysbackup", f"gerou {res.get('name')}", auth.client_ip(request))
            flash(request, "aviso" if res.get("errors") else "ok", res["message"])
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/backup")

    def _schedule_payload(f) -> dict[str, Any]:
        return {
            "enabled": bool(f.get("enabled")), "frequency": str(f.get("frequency", "daily")),
            "time": str(f.get("time", "02:30")), "weekday": str(f.get("weekday", "sun")),
            "keep_local": str(f.get("keep_local", "7")),
            "password": str(f.get("password", "")), "clear_password": bool(f.get("clear_password")),
            "dest_local": {"enabled": bool(f.get("local_enabled")), "path": str(f.get("local_path", "")),
                           "keep": str(f.get("local_keep", "14"))},
            "dest_s3": {"enabled": bool(f.get("s3_enabled")), "endpoint": str(f.get("s3_endpoint", "")),
                        "region": str(f.get("s3_region", "")), "bucket": str(f.get("s3_bucket", "")),
                        "prefix": str(f.get("s3_prefix", "")), "access_key": str(f.get("s3_access", "")),
                        "secret_key": str(f.get("s3_secret", "")),
                        "path_style": bool(f.get("s3_path_style")), "keep": str(f.get("s3_keep", "30"))},
        }

    @app.post("/sistema/backup/agenda", response_class=HTMLResponse)
    async def sysbackup_schedule(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        f = await request.form()
        if f.get("password") and str(f.get("password")) != str(f.get("password2", "")):
            flash(request, "erro", "As senhas de proteção não conferem.")
            return redirect("/sistema/backup#agenda")
        try:
            res = await run_in_threadpool(helper, ["schedule-set"], _schedule_payload(f))
            db.log_audit(user["username"], "sysbackup", "alterou o agendamento do backup do sistema",
                         auth.client_ip(request))
            flash(request, "ok", res["message"])
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/backup#agenda")

    @app.post("/sistema/backup/s3-testar")
    async def sysbackup_s3_test(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        f = await request.form()
        s3 = _schedule_payload(f)["dest_s3"]
        try:
            res = await run_in_threadpool(helper, ["s3-test"], s3, 120)
            return {"ok": True, "message": res["message"]}
        except SysBackupError as exc:
            return {"ok": False, "message": str(exc)}

    @app.get("/api/sysbackup/remoto")
    async def sysbackup_remote(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            return await run_in_threadpool(helper, ["list-remote"], None, 90)
        except SysBackupError as exc:
            return {"ok": False, "message": str(exc), "dest": [], "s3": []}

    @app.get("/sistema/backup/baixar")
    async def sysbackup_download(request: Request, origem: str = "", nome: str = ""):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if origem not in SOURCES:
            return redirect("/sistema/backup")
        try:
            res = await run_in_threadpool(helper, ["export", origem, nome], None, 1800)
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/sistema/backup")
        db.log_audit(user["username"], "sysbackup", f"baixou {nome}", auth.client_ip(request))

        def _cleanup(path: str = res["path"]) -> None:
            try:
                os.remove(path)
            except OSError:
                pass
        return FileResponse(res["path"], filename=res["name"], media_type="application/octet-stream",
                            background=BackgroundTask(_cleanup))

    @app.post("/sistema/backup/apagar", response_class=HTMLResponse)
    async def sysbackup_delete(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        f = await request.form()
        origem, nome = str(f.get("origem", "")), str(f.get("nome", ""))
        if origem not in SOURCES:
            return redirect("/sistema/backup")
        if str(f.get("confirm", "")).strip().lower() != "apagar":
            flash(request, "erro", "Confirmação não confere: digite apagar.")
            return redirect("/sistema/backup#copias")
        try:
            res = await run_in_threadpool(helper, ["delete", origem, nome], None, 300)
            db.log_audit(user["username"], "sysbackup", f"apagou {nome} ({origem})", auth.client_ip(request))
            flash(request, "ok", res["message"])
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/backup#copias")

    # ------------------------------------------------------------------
    #  Restaurar
    # ------------------------------------------------------------------

    @app.post("/sistema/backup/restaurar/enviar", response_class=HTMLResponse)
    async def sysbackup_upload(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        f = await request.form()
        up = f.get("arquivo")
        if not up or not getattr(up, "filename", ""):
            flash(request, "erro", "Escolha o arquivo do backup (.tar.gz ou .tar.gz.enc).")
            return redirect("/sistema/backup#restaurar")
        try:
            res = await run_in_threadpool(stage_upload, up.file, up.filename)
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/sistema/backup#restaurar")
        finally:
            await up.close()
        return redirect(f"/sistema/backup/restaurar/{res['id']}")

    @app.post("/sistema/backup/restaurar/usar", response_class=HTMLResponse)
    async def sysbackup_use(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        f = await request.form()
        origem, nome = str(f.get("origem", "")), str(f.get("nome", ""))
        if origem not in SOURCES:
            return redirect("/sistema/backup")
        try:
            res = await run_in_threadpool(helper, ["stage-from", origem, nome], None, 1800)
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/sistema/backup#copias")
        return redirect(f"/sistema/backup/restaurar/{res['id']}")

    async def _preview(request: Request, sid: str, password: str = ""):
        try:
            data = await run_in_threadpool(helper, ["inspect", sid], {"password": password}, 1800)
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/sistema/backup#restaurar")
        return render(request, "sysbackup_restore.html", active="sysbackup", sid=sid, data=data,
                      sections=SECTION_INFO)

    @app.get("/sistema/backup/restaurar/{sid}", response_class=HTMLResponse)
    async def sysbackup_preview(request: Request, sid: str):
        if not auth.current_user(request):
            return redirect("/login")
        if not STAGE_RE.match(sid):
            return redirect("/sistema/backup")
        return await _preview(request, sid)

    @app.post("/sistema/backup/restaurar/{sid}/abrir", response_class=HTMLResponse)
    async def sysbackup_open(request: Request, sid: str):
        if not auth.current_user(request):
            return redirect("/login")
        if not STAGE_RE.match(sid):
            return redirect("/sistema/backup")
        f = await request.form()
        return await _preview(request, sid, str(f.get("password", "")))

    @app.post("/sistema/backup/restaurar/{sid}/aplicar", response_class=HTMLResponse)
    async def sysbackup_apply(request: Request, sid: str):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not STAGE_RE.match(sid):
            return redirect("/sistema/backup")
        f = await request.form()
        if str(f.get("confirm", "")).strip().upper() != "RESTAURAR":
            flash(request, "erro", "Confirmação não confere: digite RESTAURAR.")
            return redirect(f"/sistema/backup/restaurar/{sid}")
        sections = [s for s in f.getlist("sections") if s in SECTION_INFO]
        try:
            await run_in_threadpool(helper, ["restore", sid],
                                    {"sections": sections, "reboot": bool(f.get("reboot"))}, 120)
            db.log_audit(user["username"], "sysbackup", f"iniciou a restauracao ({', '.join(sections)})",
                         auth.client_ip(request))
            flash(request, "ok", "Restauração iniciada. Acompanhe abaixo.")
        except SysBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect(f"/sistema/backup/restaurar/{sid}")
        return redirect("/sistema/backup#restauracao")

    @app.post("/sistema/backup/restaurar/{sid}/descartar", response_class=HTMLResponse)
    async def sysbackup_discard(request: Request, sid: str):
        if not auth.current_user(request):
            return redirect("/login")
        if STAGE_RE.match(sid):
            try:
                await run_in_threadpool(helper, ["restore-discard", sid])
            except SysBackupError:
                pass
        return redirect("/sistema/backup")

    @app.get("/api/sysbackup/restauracao")
    async def sysbackup_restore_status(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False, "auth": False}, status_code=401)
        try:
            return await run_in_threadpool(helper, ["restore-status"])
        except SysBackupError as exc:
            return {"ok": False, "message": str(exc)}

    @app.post("/sistema/backup/restauracao/fechar", response_class=HTMLResponse)
    async def sysbackup_restore_close(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        try:
            await run_in_threadpool(helper, ["restore-discard"])
        except SysBackupError:
            pass
        return redirect("/sistema/backup")
