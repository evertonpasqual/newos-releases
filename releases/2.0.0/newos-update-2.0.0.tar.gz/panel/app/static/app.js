/* =====================================================================
   NewOS Panel - dashboard ao vivo
   ---------------------------------------------------------------------
   A cada 3 s busca /api/stats e:
     - anima os numeros ate o valor novo (contagem)
     - move as barras (transicao no CSS)
     - acrescenta um ponto no grafico de cada medidor (ultimos 2 min)
     - calcula o trafego de rede POR SEGUNDO (diferenca dos contadores)

   Regras seguidas:
     - a cor nunca e a unica informacao: numero + palavra do estado
     - um grafico = uma serie: o titulo do cartao a nomeia (sem legenda)
     - passe o mouse (ou o foco) no grafico para ler qualquer ponto
     - quem pede "reduzir movimento" no sistema nao ve animacao
   ===================================================================== */
(function () {
    "use strict";

    var INTERVAL_MS = 3000;
    var HISTORY = 40;                 // 40 x 3 s = 2 minutos
    var WARNING_AT = 75;
    var CRITICAL_AT = 90;
    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var LABELS = { ok: "normal", warning: "atenção", critical: "crítico" };

    var failures = 0;
    var lastNet = null;               // {t, perNic: {nome: {rx, tx}}}
    var series = {};                  // id -> [{t, v}]

    function $(id) { return document.getElementById(id); }

    /* ---------------- formatacao (pt-BR) ----------------------------- */
    function num(v, decimals) {
        var d = decimals === undefined ? 1 : decimals;
        return Number(v || 0).toLocaleString("pt-BR", { maximumFractionDigits: d });
    }

    function humanBytes(value) {
        var units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"];
        var i = 0, v = Math.max(0, Number(value) || 0);
        while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
        return (i === 0 ? Math.round(v) : num(v, 1)) + " " + units[i];
    }

    function rate(bytesPerSec) {
        var bits = bytesPerSec * 8;
        var units = ["b/s", "kb/s", "Mb/s", "Gb/s"];
        var i = 0;
        while (bits >= 1000 && i < units.length - 1) { bits /= 1000; i += 1; }
        return num(bits, bits < 10 && i > 0 ? 1 : 0) + " " + units[i];
    }

    function clock(t) {
        var d = new Date(t);
        return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    }

    /* ---------------- numeros que contam ------------------------------ */
    function countTo(el, target, decimals) {
        if (!el) return;
        var from = parseFloat(el.getAttribute("data-shown") || "0") || 0;
        el.setAttribute("data-shown", target);
        if (REDUCED || Math.abs(target - from) < 0.05) { el.textContent = num(target, decimals); return; }
        var start = null, dur = 650;
        function step(ts) {
            if (start === null) start = ts;
            var k = Math.min(1, (ts - start) / dur);
            var eased = 1 - Math.pow(1 - k, 3);
            el.textContent = num(from + (target - from) * eased, decimals);
            if (k < 1) window.requestAnimationFrame(step);
        }
        window.requestAnimationFrame(step);
    }

    /* ---------------- medidor (barra + estado) ------------------------ */
    function levelOf(p) { return p >= CRITICAL_AT ? "critical" : (p >= WARNING_AT ? "warning" : "ok"); }

    function setMeter(prefix, percent) {
        var pct = Math.max(0, Math.min(100, Number(percent) || 0));
        var level = levelOf(pct);
        countTo($(prefix + "-value"), pct, 1);
        var bar = $(prefix + "-bar");
        if (bar) {
            bar.style.width = pct + "%";
            bar.classList.toggle("is-warning", level === "warning");
            bar.classList.toggle("is-critical", level === "critical");
        }
        var st = $(prefix + "-state");
        if (st) {
            st.classList.toggle("is-warning", level === "warning");
            st.classList.toggle("is-critical", level === "critical");
            var txt = st.querySelector(".txt");
            if (txt) txt.textContent = LABELS[level];
        }
    }

    /* ---------------- graficos (sparkline com leitura) ---------------- */
    var SVG_NS = "http://www.w3.org/2000/svg";
    var W = 300, H = 56, PAD = 3;

    function push(id, value) {
        var s = series[id] || (series[id] = []);
        s.push({ t: Date.now(), v: Number(value) || 0 });
        if (s.length > HISTORY) s.shift();
        draw(id);
    }

    function draw(id) {
        var box = $(id);
        var data = series[id];
        if (!box || !data || data.length < 2) return;

        var fixedMax = parseFloat(box.getAttribute("data-max"));
        var max = fixedMax || Math.max.apply(null, data.map(function (d) { return d.v; })) * 1.15 || 1;
        var stepX = (W - 2 * PAD) / (HISTORY - 1);
        var offset = (HISTORY - data.length) * stepX;
        var pts = data.map(function (d, i) {
            return [PAD + offset + i * stepX, H - PAD - (Math.min(d.v, max) / max) * (H - 2 * PAD)];
        });

        var svg = box.querySelector("svg");
        if (!svg) {
            svg = document.createElementNS(SVG_NS, "svg");
            svg.setAttribute("viewBox", "0 0 " + W + " " + H);
            svg.setAttribute("preserveAspectRatio", "none");
            svg.innerHTML = '<line class="spark-base" x1="0" x2="' + W + '" y1="' + (H - PAD) + '" y2="' + (H - PAD) + '"></line>' +
                '<path class="spark-area"></path><path class="spark-line"></path>' +
                '<line class="spark-cross" y1="0" y2="' + H + '" hidden></line>' +
                '<circle class="spark-dot" r="3.5"></circle><circle class="spark-hover" r="4" hidden></circle>';
            box.appendChild(svg);
            box.tabIndex = 0;
            wireHover(box, id);
        }
        var line = pts.map(function (p, i) { return (i ? "L" : "M") + p[0].toFixed(1) + "," + p[1].toFixed(1); }).join(" ");
        svg.querySelector(".spark-line").setAttribute("d", line);
        svg.querySelector(".spark-area").setAttribute("d",
            line + " L" + pts[pts.length - 1][0].toFixed(1) + "," + (H - PAD) + " L" + pts[0][0].toFixed(1) + "," + (H - PAD) + " Z");
        var last = pts[pts.length - 1];
        var dot = svg.querySelector(".spark-dot");
        dot.setAttribute("cx", last[0]);
        dot.setAttribute("cy", last[1]);
        box._pts = pts;
    }

    function formatValue(box, v) {
        return box.getAttribute("data-unit") === "bytes" ? rate(v) : num(v, 1) + "%";
    }

    /* Leitura: linha vertical acompanha o ponteiro e trava no ponto mais
       proximo; a dica mostra valor (forte) e horario (apoio). */
    function wireHover(box, id) {
        var tip = $("chartTip");
        var svg = box.querySelector("svg");
        var cross = svg.querySelector(".spark-cross");
        var hov = svg.querySelector(".spark-hover");

        function show(index) {
            var data = series[id], pts = box._pts;
            if (!data || !pts || !data[index]) return;
            var p = pts[index];
            cross.setAttribute("x1", p[0]); cross.setAttribute("x2", p[0]);
            cross.hidden = false;
            hov.setAttribute("cx", p[0]); hov.setAttribute("cy", p[1]); hov.hidden = false;
            tip.textContent = "";
            var strong = document.createElement("strong");
            strong.textContent = formatValue(box, data[index].v);
            var sub = document.createElement("span");
            sub.textContent = clock(data[index].t);
            tip.appendChild(strong); tip.appendChild(sub);
            var r = box.getBoundingClientRect();
            tip.hidden = false;
            tip.style.left = (r.left + (p[0] / W) * r.width + window.scrollX) + "px";
            tip.style.top = (r.top + window.scrollY - 6) + "px";
        }
        function hide() { cross.hidden = true; hov.hidden = true; tip.hidden = true; }

        box.addEventListener("pointermove", function (ev) {
            var pts = box._pts; if (!pts) return;
            var r = box.getBoundingClientRect();
            var x = ((ev.clientX - r.left) / r.width) * W;
            var best = 0;
            pts.forEach(function (p, i) { if (Math.abs(p[0] - x) < Math.abs(pts[best][0] - x)) best = i; });
            show(best);
        });
        box.addEventListener("pointerleave", hide);
        box.addEventListener("focus", function () { if (box._pts) show(box._pts.length - 1); });
        box.addEventListener("blur", hide);
    }

    /* ---------------- dica do mapa de disco ---------------------------- */
    function wireDiskTips() {
        var tip = $("chartTip");
        if (!tip) return;
        // Mapa dos discos e colunas do grafico de Backups (mesma dica).
        document.querySelectorAll(".disk-map .seg, .bk-col").forEach(function (seg) {
            function show() {
                tip.textContent = "";
                var strong = document.createElement("strong");
                strong.textContent = seg.getAttribute("data-tip-value");
                var title = document.createElement("span");
                title.textContent = seg.getAttribute("data-tip-title");
                var sub = document.createElement("span");
                sub.textContent = seg.getAttribute("data-tip-sub");
                tip.appendChild(strong); tip.appendChild(title); tip.appendChild(sub);
                var bar = seg.querySelector(".bk-bar");
                var r = (bar && bar.offsetHeight > 4 ? bar : seg).getBoundingClientRect();
                tip.hidden = false;
                tip.style.left = (r.left + r.width / 2 + window.scrollX) + "px";
                tip.style.top = (r.top + window.scrollY - 6) + "px";
            }
            function hide() { tip.hidden = true; }
            seg.addEventListener("pointerenter", show);
            seg.addEventListener("pointerleave", hide);
            seg.addEventListener("focus", show);
            seg.addEventListener("blur", hide);
        });
    }

    /* ---------------- rede: taxa por segundo --------------------------- */
    function applyNetwork(list) {
        var now = Date.now();
        var per = {};
        var totalRx = 0, totalTx = 0;
        (list || []).forEach(function (n) { per[n.name] = { rx: n.rx_bytes, tx: n.tx_bytes }; });

        if (lastNet) {
            var dt = (now - lastNet.t) / 1000;
            Object.keys(per).forEach(function (name) {
                var prev = lastNet.perNic[name];
                if (!prev || dt <= 0) return;
                var rx = Math.max(0, (per[name].rx - prev.rx) / dt);
                var tx = Math.max(0, (per[name].tx - prev.tx) / dt);
                // VLANs passam pela placa/bond: somar duplicaria o trafego.
                var row = document.querySelector('.rate[data-nic="' + name + '"]');
                if (row) {
                    row.querySelector(".rate-rx").textContent = "↓ " + rate(rx);
                    row.querySelector(".rate-tx").textContent = "↑ " + rate(tx);
                }
                if (name.indexOf(".") < 0 && !/^bond/.test(name)) { totalRx += rx; totalTx += tx; }
            });
            var rxEl = $("net-rx"), txEl = $("net-tx");
            if (rxEl) rxEl.textContent = rate(totalRx);
            if (txEl) txEl.textContent = rate(totalTx);
            push("net-spark", totalRx);
        }
        lastNet = { t: now, perNic: per };
    }

    /* ---------------- ciclo ------------------------------------------- */
    function apply(data) {
        setMeter("cpu", data.cpu.percent);
        push("cpu-spark", data.cpu.percent);
        var load = $("cpu-load"); if (load) load.textContent = num(data.cpu.load["1m"], 2);
        if (data.cpu.temperature_c != null && $("cpu-temp")) $("cpu-temp").textContent = num(data.cpu.temperature_c, 1);

        setMeter("mem", data.memory.percent);
        push("mem-spark", data.memory.percent);
        if ($("mem-used")) $("mem-used").textContent = humanBytes(data.memory.used);
        if (data.memory.swap_total && $("swap-used")) $("swap-used").textContent = humanBytes(data.memory.swap_used);

        if (data.disks && data.disks.length) {
            setMeter("disk", data.disks[0].percent);
            push("disk-spark", data.disks[0].percent);
            if ($("disk-used")) $("disk-used").textContent = humanBytes(data.disks[0].used);
        }

        applyNetwork(data.network);
        if ($("proc-count")) $("proc-count").textContent = data.system.processes;
        if ($("last-update")) $("last-update").textContent = data.system.now.split(" ")[1] || "agora";
    }

    function tick() {
        fetch("/api/stats", { credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (resp) {
                if (resp.status === 401) { window.location.href = "/login"; throw new Error("sessao expirada"); }
                if (!resp.ok) throw new Error("HTTP " + resp.status);
                return resp.json();
            })
            .then(function (data) {
                failures = 0;
                document.body.classList.remove("is-offline");
                apply(data);
            })
            .catch(function (err) {
                failures += 1;
                if (failures === 3) {
                    if ($("last-update")) $("last-update").textContent = "sem conexão";
                    document.body.classList.add("is-offline");
                }
                if (window.console && failures < 5) console.warn("[NewOS] falha ao atualizar:", err.message);
            });
    }

    document.addEventListener("DOMContentLoaded", function () {
        // Primeira pintura: os numeros sobem de 0 ate o valor da pagina.
        ["cpu", "mem", "disk"].forEach(function (p) {
            var el = $(p + "-value");
            if (!el) return;
            var v = parseFloat(el.getAttribute("data-count"));
            el.textContent = num(0);
            setMeter(p, v);
            push(p + "-spark", v);
        });
        wireDiskTips();
        if (!$("cpu-value")) return;            // fora do dashboard: so as dicas
        tick();                                 // a rede precisa de 2 leituras
        setInterval(tick, INTERVAL_MS);
    });
}());
