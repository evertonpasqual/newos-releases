"""
NewOS Panel - coleta de metricas do sistema (CPU, memoria, disco, rede).

Tudo vem do psutil e de /proc, sem privilegio nenhum.
"""

from __future__ import annotations

import os
import platform
import socket
import time
from datetime import datetime, timedelta
from typing import Any

import psutil

# Sistemas de arquivos virtuais que nao interessam no dashboard.
_IGNORED_FSTYPES = {
    "tmpfs", "devtmpfs", "squashfs", "overlay", "proc", "sysfs",
    "cgroup", "cgroup2", "devpts", "mqueue", "hugetlbfs", "debugfs",
    "tracefs", "securityfs", "pstore", "bpf", "configfs", "fusectl",
    "efivarfs", "autofs", "binfmt_misc", "ramfs", "nsfs",
}


def _pct(part: float, total: float) -> float:
    return round((part / total) * 100, 1) if total else 0.0


def cpu_info() -> dict[str, Any]:
    freq = None
    try:
        f = psutil.cpu_freq()
        freq = round(f.current) if f else None
    except (OSError, AttributeError):
        freq = None

    try:
        load1, load5, load15 = os.getloadavg()
    except OSError:
        load1 = load5 = load15 = 0.0

    temp = None
    try:
        sensors = psutil.sensors_temperatures() or {}
        for key in ("coretemp", "k10temp", "cpu_thermal", "acpitz"):
            if key in sensors and sensors[key]:
                temp = round(sensors[key][0].current, 1)
                break
    except (AttributeError, OSError):
        temp = None

    return {
        "percent": psutil.cpu_percent(interval=None),
        "per_core": psutil.cpu_percent(interval=None, percpu=True),
        "cores_physical": psutil.cpu_count(logical=False) or 0,
        "cores_logical": psutil.cpu_count(logical=True) or 0,
        "freq_mhz": freq,
        "load": {"1m": round(load1, 2), "5m": round(load5, 2), "15m": round(load15, 2)},
        "temperature_c": temp,
        "model": _cpu_model(),
    }


def _cpu_model() -> str:
    try:
        with open("/proc/cpuinfo", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or "desconhecido"


def memory_info() -> dict[str, Any]:
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    return {
        "total": vm.total,
        "used": vm.total - vm.available,
        "available": vm.available,
        "percent": vm.percent,
        "cached": getattr(vm, "cached", 0),
        "buffers": getattr(vm, "buffers", 0),
        "swap_total": sw.total,
        "swap_used": sw.used,
        "swap_percent": sw.percent,
    }


def disk_info() -> list[dict[str, Any]]:
    disks: list[dict[str, Any]] = []
    seen_devices: set[str] = set()

    for part in psutil.disk_partitions(all=False):
        if part.fstype in _IGNORED_FSTYPES or not part.fstype:
            continue
        # Evita listar o mesmo dispositivo duas vezes (bind mounts).
        if part.device in seen_devices:
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except (PermissionError, OSError):
            continue
        seen_devices.add(part.device)
        disks.append(
            {
                "device": part.device,
                "mountpoint": part.mountpoint,
                "fstype": part.fstype,
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": usage.percent,
            }
        )

    disks.sort(key=lambda d: (d["mountpoint"] != "/", d["mountpoint"]))
    return disks


def network_info() -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    addrs = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    counters = psutil.net_io_counters(pernic=True)

    for name, addr_list in sorted(addrs.items()):
        if name == "lo":
            continue
        ipv4 = ""
        netmask = ""
        mac = ""
        addresses = []
        for addr in addr_list:
            if addr.family == socket.AF_INET:
                prefix = ""
                if addr.netmask:
                    prefix = "/" + str(sum(bin(int(o)).count("1") for o in addr.netmask.split(".")))
                addresses.append(f"{addr.address}{prefix}")
                if not ipv4:
                    ipv4 = addr.address
                    netmask = addr.netmask or ""
            elif addr.family == psutil.AF_LINK and not mac:
                mac = addr.address
        if os.path.isdir(f"/sys/class/net/{name}/bonding"):
            kind = "bond"
        elif os.path.exists(f"/proc/net/vlan/{name}"):
            kind = "vlan"
        else:
            kind = "ethernet"

        st = stats.get(name)
        io = counters.get(name)
        result.append(
            {
                "name": name,
                "ipv4": ipv4,
                "addresses": addresses,
                "kind": kind,
                "netmask": netmask,
                "mac": mac,
                "up": bool(st.isup) if st else False,
                "speed_mbps": st.speed if st else 0,
                "mtu": st.mtu if st else 0,
                "rx_bytes": io.bytes_recv if io else 0,
                "tx_bytes": io.bytes_sent if io else 0,
                "is_vlan": kind == "vlan",
            }
        )
    return result


def uptime_info() -> dict[str, Any]:
    boot = psutil.boot_time()
    seconds = int(time.time() - boot)
    delta = timedelta(seconds=seconds)
    days = delta.days
    hours, rem = divmod(delta.seconds, 3600)
    minutes = rem // 60

    parts: list[str] = []
    if days:
        parts.append(f"{days}d")
    if hours or days:
        parts.append(f"{hours}h")
    parts.append(f"{minutes}min")

    return {
        "boot_time": datetime.fromtimestamp(boot).strftime("%d/%m/%Y %H:%M"),
        "seconds": seconds,
        "human": " ".join(parts),
    }


def system_info() -> dict[str, Any]:
    pretty = ""
    try:
        with open("/etc/os-release", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("PRETTY_NAME="):
                    pretty = line.split("=", 1)[1].strip().strip('"')
                    break
    except OSError:
        pass

    return {
        "hostname": socket.gethostname(),
        "fqdn": socket.getfqdn(),
        "os": pretty or platform.platform(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "processes": len(psutil.pids()),
        "now": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
    }


def collect_all() -> dict[str, Any]:
    """Snapshot completo usado pelo endpoint /api/stats."""
    return {
        "cpu": cpu_info(),
        "memory": memory_info(),
        "disks": disk_info(),
        "network": network_info(),
        "uptime": uptime_info(),
        "system": system_info(),
    }


def num(value: Any, decimals: int = 1) -> str:
    """12.5 -> '12,5' ; 13.0 -> '13' (formato brasileiro, sem zero inutil)."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return str(value)
    text = f"{v:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    if "," in text:
        text = text.rstrip("0").rstrip(",")
    return text


def human_bytes(value: float) -> str:
    """1536 -> '1,5 KiB' (formato brasileiro, com virgula)."""
    units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]
    index = 0
    val = float(value or 0)
    while val >= 1024 and index < len(units) - 1:
        val /= 1024
        index += 1
    if index == 0:
        return f"{int(val)} {units[index]}"
    return f"{val:.1f}".replace(".", ",") + f" {units[index]}"


# Aquece o psutil.cpu_percent: a primeira chamada sempre retorna 0.0
psutil.cpu_percent(interval=None)
psutil.cpu_percent(interval=None, percpu=True)
