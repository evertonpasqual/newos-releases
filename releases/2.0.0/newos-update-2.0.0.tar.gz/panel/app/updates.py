"""
NewOS Panel - atualizacoes do NewOS (versoes MENOR e CORRECAO, sem ISO).

O helper newos-update consulta o repositorio publico de releases, confere
a assinatura da NewFront e aplica pelo update-panel.sh. A ultima consulta
fica em /var/lib/newos-update/check.json (leitura publica): a faixa de
"versao nova" do topo le direto dali, sem chamar o helper a cada pagina.
"""

from __future__ import annotations

import json
import subprocess
import time
from typing import Any

HELPER = "/usr/local/sbin/newos-update"
CACHE = "/var/lib/newos-update/check.json"

_memo: dict[str, Any] = {"t": 0.0, "data": {}}


class UpdateError(Exception):
    """Erro para mostrar ao administrador."""


def cached() -> dict[str, Any]:
    """Ultima verificacao (memorizada por 60 s: e lida em toda pagina)."""
    if time.time() - _memo["t"] > 60:
        try:
            with open(CACHE, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        # A versao instalada vem do sistema, nunca do cache: logo depois
        # de atualizar o cache ainda diz a versao antiga.
        current = installed_version()
        if data.get("latest"):
            data["current"] = current
            newer = _vt(data["latest"]) > _vt(current)
            data["available"] = newer
            data["kind"] = data.get("kind") if newer else "none"
            data["notes"] = [n for n in data.get("notes", []) if _vt(n.get("version", "0.0.0")) > _vt(current)]
        _memo["data"] = data
        _memo["t"] = time.time()
    return _memo["data"]


def _vt(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0, 0, 0)


def installed_version() -> str:
    try:
        with open("/etc/newos/release", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("NEWOS_VERSION="):
                    return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return "0.0.0"


def _helper(args: list[str], timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True,
                              timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise UpdateError(f"Nao foi possivel executar o atualizador: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise UpdateError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    _memo["t"] = 0.0
    return json.loads(proc.stdout.strip().splitlines()[-1])


def check() -> dict[str, Any]:
    return _helper(["check"])


def apply(version: str) -> str:
    return _helper(["apply", version], timeout=600).get("message", "")


def status() -> dict[str, Any]:
    return _helper(["status"], timeout=30)


def md_to_html(text: str) -> str:
    """Markdown minimo das notas de versao (titulos, listas, negrito, codigo)."""
    import html
    import re
    out, in_list = [], False
    for raw in (text or "").splitlines():
        line = html.escape(raw.rstrip())
        line = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", line)
        line = re.sub(r"`([^`]+)`", r"<code>\1</code>", line)
        m_item = re.match(r"^\s*[-*] (.*)$", line)
        cont = re.match(r"^\s{2,}(\S.*)$", line)
        if m_item:
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{m_item.group(1)}")
            continue
        if cont and in_list:
            out[-1] += " " + cont.group(1)
            continue
        if in_list:
            out.append("</ul>")
            in_list = False
        if line.startswith("### "):
            out.append(f"<h4>{line[4:]}</h4>")
        elif line.strip():
            out.append(f"<p>{line}</p>")
    if in_list:
        out.append("</ul>")
    return "\n".join(out)
