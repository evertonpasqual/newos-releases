/* =====================================================================
   NewOS Panel - Modulos e Servicos
   ---------------------------------------------------------------------
   - Modulos: filtro por categoria (e "Ligados")
   - Servicos: busca por nome/descricao + filtro rodando/parados; os
     grupos com resultado abrem sozinhos durante a busca
   - #svc-<modulo> na URL (vindo de Modulos) abre e destaca o grupo
   ===================================================================== */
(function () {
    "use strict";

    function chips(group, onChange) {
        var box = document.querySelector('[data-filter-group="' + group + '"]');
        if (!box) return null;
        var current = "";
        box.querySelectorAll(".sys-chip").forEach(function (b) {
            b.addEventListener("click", function () {
                box.querySelectorAll(".sys-chip").forEach(function (o) { o.classList.toggle("active", o === b); });
                current = b.getAttribute("data-filter");
                onChange(current);
            });
        });
        return function () { return current; };
    }
    function showNone(visible) {
        var none = document.querySelector(".sys-none");
        if (none) none.hidden = visible > 0;
    }

    /* ---------------- Modulos -------------------------------------- */
    var mods = document.querySelectorAll(".sys-mod");
    if (mods.length) {
        chips("cat", function (f) {
            var n = 0;
            mods.forEach(function (m) {
                var ok = !f || (f === "@on" ? m.getAttribute("data-on") === "1" : m.getAttribute("data-cat") === f);
                m.hidden = !ok;
                if (ok) n++;
            });
            showNone(n);
        });
    }

    /* ---------------- Servicos ------------------------------------- */
    var groups = document.querySelectorAll(".sys-group");
    var search = document.getElementById("svc-search");
    if (groups.length) {
        var stateFilter = "";
        var apply = function () {
            var q = (search && search.value || "").trim().toLowerCase();
            var total = 0;
            groups.forEach(function (g) {
                var n = 0;
                g.querySelectorAll("tbody tr").forEach(function (tr) {
                    var txt = (tr.getAttribute("data-svc") || "").toLowerCase();
                    var run = tr.getAttribute("data-running") === "1";
                    var ok = (!q || txt.indexOf(q) !== -1) &&
                             (!stateFilter || (stateFilter === "@running" ? run : !run));
                    tr.hidden = !ok;
                    if (ok) n++;
                });
                g.hidden = n === 0;
                total += n;
                // Buscando: abre os grupos com resultado (sem lembrar).
                if ((q || stateFilter) && n && !g.classList.contains("open")) {
                    g.classList.add("open", "settled");
                    g.setAttribute("data-auto-open", "1");
                } else if (!q && !stateFilter && g.getAttribute("data-auto-open")) {
                    g.classList.remove("open", "settled");
                    g.removeAttribute("data-auto-open");
                }
            });
            showNone(total);
        };
        chips("svc", function (f) { stateFilter = f; apply(); });
        if (search) search.addEventListener("input", apply);

        if (location.hash.indexOf("#svc-") === 0) {
            var g = document.getElementById(location.hash.slice(1));
            if (g) {
                if (!g.classList.contains("open")) g.querySelector(".fold-head").click();
                g.classList.add("sys-flash");
                g.scrollIntoView({ block: "start", behavior: "smooth" });
            }
        }
    }
})();
