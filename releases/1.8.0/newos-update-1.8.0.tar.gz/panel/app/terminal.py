"""
NewOS Panel - Sistema > Terminal (como o do Cockpit).

O navegador desenha o terminal (xterm.js); aqui ficam os terminais
abertos. Cada um e um pseudoterminal (pty) ligado ao helper
newos-terminal (sudo), que abre um shell de root fora do sandbox do
painel. Sem WebSocket: a saida vai por streaming HTTP (Server-Sent
Events) e o teclado por POST, o que passa pelo nginx sem configuracao
especial e nao precisa de biblioteca nova.

    - so administradores, depois de confirmar a senha (e o MFA)
    - no maximo 3 terminais por usuario
    - terminal sem digitacao pelo tempo de sessao inativa e fechado
    - sair (logout) fecha os terminais da pessoa
"""

from __future__ import annotations

import asyncio
import fcntl
import logging
import os
import pty
import secrets
import struct
import subprocess
import termios
import time
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger("newos.panel.terminal")
HELPER = "/usr/local/sbin/newos-terminal"
MAX_PER_USER = 3
SCROLLBACK = 64 * 1024            # o que ja saiu, para quem reconecta


@dataclass
class Term:
    id: str
    owner: str
    proc: subprocess.Popen
    fd: int
    created: float = field(default_factory=time.time)
    last_input: float = field(default_factory=time.time)
    history: bytearray = field(default_factory=bytearray)
    waiters: list[asyncio.Queue] = field(default_factory=list)
    closed: bool = False


_TERMS: dict[str, Term] = {}


def _set_size(fd: int, cols: int, rows: int) -> None:
    cols = max(20, min(500, int(cols)))
    rows = max(5, min(200, int(rows)))
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


def _child_setup() -> None:
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)       # o pty vira o terminal de controle


def _on_output(t: Term) -> None:
    try:
        data = os.read(t.fd, 65536)
    except OSError:
        data = b""
    if not data:
        _finish(t)
        return
    t.history += data
    if len(t.history) > SCROLLBACK:
        del t.history[:len(t.history) - SCROLLBACK]
    for q in list(t.waiters):
        q.put_nowait(data)


def _finish(t: Term) -> None:
    if t.closed:
        return
    t.closed = True
    loop = asyncio.get_event_loop()
    try:
        loop.remove_reader(t.fd)
    except (ValueError, OSError):
        pass
    try:
        os.close(t.fd)                 # o shell recebe o "desligar" (SIGHUP) e sai
    except OSError:
        pass
    for q in list(t.waiters):
        q.put_nowait(None)
    log.info("Terminal %s de %s fechado", t.id, t.owner)


def open_term(owner: str, cols: int, rows: int) -> Term:
    mine = [t for t in _TERMS.values() if t.owner == owner and not t.closed]
    if len(mine) >= MAX_PER_USER:
        raise RuntimeError(f"Ja ha {MAX_PER_USER} terminais abertos: feche um antes.")
    master, slave = pty.openpty()
    _set_size(master, cols, rows)
    try:
        proc = subprocess.Popen(["sudo", "-n", HELPER, owner], stdin=slave, stdout=slave, stderr=slave,
                                preexec_fn=_child_setup, close_fds=True,
                                env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "TERM": "xterm-256color"})
    finally:
        os.close(slave)
    os.set_blocking(master, False)
    t = Term(id=secrets.token_hex(12), owner=owner, proc=proc, fd=master)
    _TERMS[t.id] = t
    asyncio.get_event_loop().add_reader(master, _on_output, t)
    log.info("Terminal %s aberto por %s", t.id, owner)
    return t


def get(tid: str, owner: str) -> Term | None:
    t = _TERMS.get(tid)
    return t if t and t.owner == owner else None


def write(t: Term, data: bytes) -> None:
    if t.closed:
        return
    t.last_input = time.time()
    view = memoryview(data)
    while view:
        try:
            n = os.write(t.fd, view)
            view = view[n:]
        except BlockingIOError:
            time.sleep(0.01)


def resize(t: Term, cols: int, rows: int) -> None:
    if not t.closed:
        _set_size(t.fd, cols, rows)


def close(t: Term) -> None:
    _finish(t)
    _TERMS.pop(t.id, None)


def close_user(owner: str) -> int:
    n = 0
    for t in [t for t in _TERMS.values() if t.owner == owner]:
        close(t)
        n += 1
    return n


def reap(idle_seconds: int) -> None:
    """Fecha terminais sem digitacao pelo tempo de sessao inativa e limpa os encerrados."""
    now = time.time()
    for t in list(_TERMS.values()):
        if not t.closed and now - t.last_input > idle_seconds:
            log.info("Terminal %s de %s fechado por inatividade", t.id, t.owner)
            close(t)
        elif t.closed and t.proc.poll() is not None:
            _TERMS.pop(t.id, None)


def listing(owner: str) -> list[dict[str, Any]]:
    return [{"id": t.id, "since": int(t.created), "closed": t.closed}
            for t in _TERMS.values() if t.owner == owner]
