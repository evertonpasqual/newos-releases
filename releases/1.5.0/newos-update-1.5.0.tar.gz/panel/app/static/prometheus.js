/* =====================================================================
   NewOS Panel - telas do Prometheus
   ---------------------------------------------------------------------
   - versoes instaladas x mais nova (GitHub), com botao de atualizar
   - "Testar" de cada alvo (resposta numa faixa no topo)
   - remote_write: "Outro destino" acrescenta uma linha
   ===================================================================== */
(function () {
    "use strict";

    function esc(t) {
        var d = document.createElement("div");
        d.textContent = t == null ? "" : String(t);
        return d.innerHTML;
    }
    var NAMES = { prometheus: "Prometheus", node: "node_exporter", snmp: "snmp_exporter",
                  alertmanager: "Alertmanager", pve: "pve-exporter", vmware: "vmware_exporter" };

    /* ---------------- versoes ---------------------------------------- */
    var vt = document.getElementById("prom-versions");
    if (vt) {
        fetch("/api/prometheus/versoes", { credentials: "same-origin" })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                var body = vt.querySelector("tbody");
                if (!d.ok) { body.innerHTML = '<tr><td colspan="4" class="empty">' + esc(d.message) + "</td></tr>"; return; }
                var rows = Object.keys(NAMES).filter(function (k) { return d.versions[k] && d.versions[k].installed; })
                    .map(function (k, i) {
                        var v = d.versions[k], newer = v.latest && v.latest !== v.installed;
                        var btn = newer && k !== "alertmanager"
                            ? '<form method="post" action="/monitoramento/prometheus/atualizar/' + k + '" data-busy><button class="btn btn-sm" type="submit"><i class="bi bi-arrow-up-circle"></i> Atualizar</button></form>'
                            : (k === "pve" || k === "vmware"
                                ? '<form method="post" action="/monitoramento/prometheus/atualizar/' + k + '" data-busy><button class="btn btn-ghost btn-sm" type="submit" title="Atualiza pelo PyPI"><i class="bi bi-arrow-repeat"></i></button></form>'
                                : '<span class="badge badge-up mini">em dia</span>');
                        return '<tr style="--r:' + i + '"><td class="strong">' + NAMES[k] + '</td><td class="mono">' + esc(v.installed) +
                            '</td><td class="mono">' + esc(v.latest || "PyPI") + "</td><td class=\"actions\">" + btn + "</td></tr>";
                    });
                body.innerHTML = rows.join("") || '<tr><td colspan="4" class="empty">Nada instalado ainda.</td></tr>';
                body.querySelectorAll("form[data-busy]").forEach(function (f) {
                    f.addEventListener("submit", function () {
                        var w = document.getElementById("work-prometheus");
                        if (w) w.classList.add("show");
                        f.querySelector("button").disabled = true;
                    });
                });
            })
            .catch(function () { vt.querySelector("tbody").innerHTML = '<tr><td colspan="4" class="empty">Sem acesso ao GitHub agora.</td></tr>'; });
    }

    /* ---------------- testes ----------------------------------------- */
    var banner = document.getElementById("prom-test");
    document.querySelectorAll("[data-prom-test]").forEach(function (b) {
        b.addEventListener("click", function () {
            if (!banner) return;
            banner.hidden = false;
            banner.className = "prom-test card run";
            banner.querySelector(".ico").innerHTML = '<i class="bi bi-arrow-repeat"></i>';
            banner.querySelector(".msg").textContent = "testando " + b.getAttribute("data-target") + "…";
            banner.scrollIntoView({ block: "nearest", behavior: "smooth" });
            b.disabled = true;
            var q = "kind=" + encodeURIComponent(b.getAttribute("data-prom-test")) +
                    "&target=" + encodeURIComponent(b.getAttribute("data-target")) +
                    "&extra=" + encodeURIComponent(b.getAttribute("data-extra") || "");
            fetch("/api/prometheus/teste?" + q, { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    banner.className = "prom-test card " + (d.online ? "ok" : "fail");
                    banner.querySelector(".ico").innerHTML = '<i class="bi ' + (d.online ? "bi-check-circle-fill" : "bi-x-circle-fill") + '"></i>';
                    banner.querySelector(".msg").textContent = d.message || (d.online ? "ok" : "falhou");
                })
                .catch(function (e) { banner.className = "prom-test card fail"; banner.querySelector(".msg").textContent = e.message; })
                .then(function () { b.disabled = false; });
        });
    });

    /* ---------------- alertas ---------------------------------------- */
    var auto = document.querySelector("[data-auto-toggle]");
    if (auto) {
        auto.addEventListener("change", function () {
            document.querySelectorAll('.prom-alert-mods input[name="modules"]').forEach(function (c) {
                c.disabled = auto.checked;
            });
        });
    }
    var at = document.querySelector("[data-alert-test]");
    if (at && banner) {
        at.addEventListener("click", function () {
            banner.hidden = false;
            banner.className = "prom-test card run";
            banner.querySelector(".ico").innerHTML = '<i class="bi bi-arrow-repeat"></i>';
            banner.querySelector(".msg").textContent = "validando o bot e enviando o alerta de teste…";
            at.disabled = true;
            fetch("/api/prometheus/alertas/teste", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    banner.className = "prom-test card " + (d.online ? "ok" : "fail");
                    banner.querySelector(".ico").innerHTML = '<i class="bi ' + (d.online ? "bi-send-check" : "bi-x-circle-fill") + '"></i>';
                    banner.querySelector(".msg").textContent = d.message || "";
                })
                .catch(function (e) { banner.className = "prom-test card fail"; banner.querySelector(".msg").textContent = e.message; })
                .then(function () { at.disabled = false; });
        });
    }

    /* ---------------- remote_write: mais um destino ------------------ */
    var add = document.querySelector("[data-rw-add]");
    if (add) {
        add.addEventListener("click", function () {
            var list = document.getElementById("rw-list");
            var rows = list.querySelectorAll(".prom-rw");
            var row = rows[rows.length - 1].cloneNode(true);
            row.querySelectorAll("input").forEach(function (i) {
                if (i.type === "checkbox") { i.checked = false; i.value = String(rows.length); }
                else { i.value = ""; i.placeholder = i.name === "password" ? "" : i.placeholder; }
            });
            row.style.setProperty("--r", rows.length);
            list.appendChild(row);
            row.querySelector('input[name="url"]').focus();
        });
    }
})();
