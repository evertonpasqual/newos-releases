/* =====================================================================
   NewOS Panel - menu lateral
   ---------------------------------------------------------------------
   - clique no titulo do grupo: fixa aberto / fecha (lembrado no
     navegador); o mouse por cima abre so de passagem (CSS :hover)
   - o grupo da pagina atual ja vem aberto do servidor
   - entrada escalonada dos itens 1x por sessao
   ===================================================================== */
(function () {
    "use strict";

    var nav = document.querySelector(".nav");
    if (!nav) return;
    var KEY = "newos.nav.open";

    function load() {
        try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; }
    }
    function save(list) {
        try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* sem storage: so nesta pagina */ }
    }

    var pinned = load();
    nav.querySelectorAll(".nav-group[data-group]").forEach(function (g) {
        var id = g.getAttribute("data-group");
        var btn = g.querySelector(".nav-group-title");
        function set(open) {
            g.classList.toggle("open", open);
            btn.setAttribute("aria-expanded", open ? "true" : "false");
        }
        if (pinned.indexOf(id) !== -1) set(true);

        btn.addEventListener("click", function () {
            var open = !g.classList.contains("open");
            set(open);
            var list = load().filter(function (x) { return x !== id; });
            if (open) list.push(id);
            save(list);
            // fechado com o mouse ainda em cima: o :hover o manteria aberto
            if (!open) {
                g.classList.add("nav-shut");
                g.addEventListener("mouseleave", function off() {
                    g.classList.remove("nav-shut");
                    g.removeEventListener("mouseleave", off);
                });
            }
        });
    });

    // ---------------------------------------------------------------- abrir pelo mouse
    // So abre quando o mouse PARA sobre o titulo do grupo (intencao) e nunca
    // enquanto a lista rola: rolando, nada abre nem fecha, o conteudo fica
    // parado sob o cursor. O grupo aberto assim fica aberto enquanto o mouse
    // estiver no menu; abrir outro fecha o anterior so se ele estiver ABAIXO
    // (fechar um de cima puxaria a lista para cima). Sair do menu fecha tudo.
    var root = document.documentElement;
    var side = nav.closest(".sidebar") || nav;
    var INTENT = 170, QUIET = 380, LEAVE = 420;
    var lastScroll = 0, intent = 0, leaving = 0;
    function mini() { return root.classList.contains("nav-mini"); }
    function hovs() { return Array.prototype.slice.call(nav.querySelectorAll(".nav-group.hov")); }
    function openHov(g) {
        if (g.classList.contains("hov") || g.classList.contains("open")) return;
        var top = g.getBoundingClientRect().top;
        hovs().forEach(function (o) { if (o.getBoundingClientRect().top > top) o.classList.remove("hov"); });
        g.classList.add("hov");
    }
    function arm(g) {
        clearTimeout(intent);
        if (mini() || g.classList.contains("nav-shut")) return;
        intent = setTimeout(function try_() {
            var quiet = Date.now() - lastScroll;
            if (quiet < QUIET) { intent = setTimeout(try_, QUIET - quiet + 20); return; }
            if (g.matches(":hover")) openHov(g);
        }, INTENT);
    }
    nav.querySelectorAll(".nav-group[data-group]").forEach(function (g) {
        var t = g.querySelector(".nav-group-title");
        t.addEventListener("mousemove", function () { if (!g.classList.contains("hov")) arm(g); });
        t.addEventListener("mouseleave", function () { clearTimeout(intent); });
    });
    nav.addEventListener("scroll", function () { lastScroll = Date.now(); clearTimeout(intent); }, { passive: true });
    nav.addEventListener("wheel", function () { lastScroll = Date.now(); clearTimeout(intent); }, { passive: true });
    side.addEventListener("mouseenter", function () { clearTimeout(leaving); });
    side.addEventListener("mouseleave", function () {
        clearTimeout(intent);
        clearTimeout(leaving);
        leaving = setTimeout(function () { hovs().forEach(function (o) { o.classList.remove("hov"); }); }, LEAVE);
    });
    // clicar no titulo fixa/solta: o estado "de passagem" sai de cena
    nav.addEventListener("click", function (e) {
        var g = e.target.closest(".nav-group-title") && e.target.closest(".nav-group");
        if (g) g.classList.remove("hov");
    });
    new MutationObserver(function () { if (mini()) hovs().forEach(function (o) { o.classList.remove("hov"); }); })
        .observe(root, { attributes: true, attributeFilter: ["class"] });

    try {
        if (!sessionStorage.getItem("newos.nav.intro")) {
            Array.prototype.forEach.call(nav.children, function (el, i) { el.style.setProperty("--n", i); });
            nav.classList.add("nav-intro");
            sessionStorage.setItem("newos.nav.intro", "1");
        }
    } catch (e) { /* sem storage: sem animacao de entrada */ }

    // Liga as transicoes so depois do 1o quadro (estado lembrado sem "pulo").
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { nav.classList.add("nav-ready"); });
    });
})();

/* Botao "Copiar" (data-copy="texto"): codigos de recuperacao etc. */
document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-copy]");
    if (!b) return;
    var text = b.getAttribute("data-copy");
    var done = function () {
        var old = b.innerHTML;
        b.innerHTML = '<i class="bi bi-check2"></i> Copiado';
        setTimeout(function () { b.innerHTML = old; }, 1800);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done);
    } else {
        var t = document.createElement("textarea");
        t.value = text; document.body.appendChild(t); t.select();
        try { document.execCommand("copy"); done(); } catch (err) { /* sem permissao */ }
        t.remove();
    }
});

/* =====================================================================
   Sessao inativa: conta o tempo sem uso; 60 s antes do fim avisa com
   contagem e "Continuar"; no fim leva ao login. Mexer na tela (mouse,
   teclado, toque) avisa o servidor no maximo 1x por minuto.
   ===================================================================== */
(function () {
    "use strict";
    var limit = parseInt(document.body.getAttribute("data-idle"), 10);
    if (!limit) return;
    var WARN = Math.min(60, Math.floor(limit / 3));
    var last = Date.now(), lastPing = Date.now(), dirty = false, box = null, num = null;

    function ping() {
        lastPing = Date.now(); dirty = false;
        fetch("/api/sessao/ativo", { method: "POST", credentials: "same-origin" })
            .then(function (r) { if (r.status === 401) window.location = "/login?motivo=inatividade"; })
            .catch(function () { /* sem rede agora: tenta no proximo movimento */ });
    }
    function used() {
        last = Date.now(); dirty = true;
        if (box) { box.remove(); box = null; ping(); }
        else if (Date.now() - lastPing > 60000) ping();
    }
    ["mousemove", "mousedown", "keydown", "touchstart", "wheel"].forEach(function (ev) {
        document.addEventListener(ev, used, { passive: true });
    });
    // formularios e links ja renovam no servidor: so zera o relogio local
    document.addEventListener("submit", function () { last = Date.now(); lastPing = Date.now(); });

    function warn(left) {
        if (!box) {
            box = document.createElement("div");
            box.className = "idle-warn";
            box.setAttribute("role", "alertdialog");
            box.innerHTML = '<div class="idle-card"><i class="bi bi-hourglass-split"></i>' +
                '<div><strong>Sua sessão vai expirar</strong><span>Por segurança, o painel desconecta em <b class="idle-n"></b> s sem uso.</span></div>' +
                '<button type="button" class="btn btn-sm">Continuar conectado</button></div>';
            document.body.appendChild(box);
            box.querySelector("button").addEventListener("click", function () { used(); });
            num = box.querySelector(".idle-n");
        }
        num.textContent = left;
    }
    var asking = false;
    function server(then) {          // outra aba pode estar em uso: o servidor decide
        if (asking) return;
        asking = true;
        fetch("/api/sessao", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.status === 401 ? { left: 0 } : r.json(); })
            .then(function (d) { asking = false; then(d.left || 0); })
            .catch(function () { asking = false; });
    }
    setInterval(function () {
        var idle = Math.floor((Date.now() - last) / 1000);
        var left = limit - idle;
        if (left <= WARN && !box) {
            server(function (srv) {
                if (srv > WARN) { last = Date.now() - (limit - srv) * 1000; }   // usada em outra aba
                else if (srv <= 0) { window.location = "/login?motivo=inatividade"; }
                else { last = Date.now() - (limit - srv) * 1000; warn(srv); }
            });
            return;
        }
        if (box) {
            if (left <= 0) {
                server(function (srv) {
                    if (srv > 0) { box.remove(); box = null; last = Date.now() - (limit - srv) * 1000; }
                    else { window.location = "/logout?motivo=inatividade"; }
                });
                return;
            }
            warn(left);
        } else if (dirty && Date.now() - lastPing > 60000) ping();
    }, 1000);
})();

/* Repositorio offline (data-ofl-sync="grupo"): baixa de novo os pacotes dos hosts
   e acompanha ate terminar. */
document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-ofl-sync]");
    if (!b) return;
    var group = b.getAttribute("data-ofl-sync");
    var box = b.closest("[data-ofl]"), when = box && box.querySelector("[data-ofl-when]");
    b.disabled = true;
    if (when) when.innerHTML = '<span class="ofl-busy"><i class="bi bi-arrow-repeat"></i> baixando…</span>';
    fetch("/api/pacotes-offline/atualizar", {method: "POST", headers: {"Content-Type": "application/json"},
                                             body: JSON.stringify({group: group})})
        .then(function (r) { return r.json(); })
        .then(function (d) {
            if (!d.ok) { if (when) when.textContent = d.message || "Falhou."; b.disabled = false; return; }
            var tries = 0;
            (function poll() {
                setTimeout(function () {
                    fetch("/api/pacotes-offline").then(function (r) { return r.json(); }).then(function (s) {
                        var g = (s.groups || {})[group] || {};
                        if (g.running && ++tries < 120) return poll();
                        location.reload();
                    }).catch(function () { if (++tries < 120) poll(); });
                }, 3000);
            })();
        })
        .catch(function () { if (when) when.textContent = "Sem resposta do painel."; b.disabled = false; });
});
