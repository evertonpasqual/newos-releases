/* =====================================================================
   NewOS Panel - Sistema > Servidor (2.23): atualizacoes do Debian e energia
   ===================================================================== */
(function () {
    "use strict";
    var root = document.getElementById("os-cards");
    if (!root) return;
    var admin = root.getAttribute("data-admin") === "1";
    var $ = function (id) { return document.getElementById(id); };
    var timer = null, lastState = "";

    function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
    function ago(ts) {
        if (!ts) return "nunca";
        var s = Math.max(0, Math.floor(Date.now() / 1000) - ts);
        if (s < 90) return "agora há pouco";
        if (s < 3600) return "há " + Math.round(s / 60) + " min";
        if (s < 86400) return "há " + Math.round(s / 3600) + " h";
        return "há " + Math.round(s / 86400) + " d";
    }
    function dur(a, b) { var s = Math.max(0, (b || Math.floor(Date.now() / 1000)) - a); return Math.floor(s / 60) + " min " + (s % 60) + " s"; }
    function toast(msg, kind) {
        var t = document.createElement("div");
        t.className = "dk-toast " + (kind || "ok");
        t.textContent = msg;
        document.body.appendChild(t);
        setTimeout(function () { t.remove(); }, kind === "erro" ? 9000 : 5000);
    }
    function post(url, body) {
        return fetch(url, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
            .then(function (r) { return r.json().catch(function () { return { ok: false, message: "Resposta inválida (HTTP " + r.status + ")." }; }); });
    }

    // ------------------------------------------------------------ estado
    function paint(d) {
        var job = d.job || {}, running = job.state === "running";
        $("os-last").textContent = "última busca " + ago(d.last_update);
        if (!running) {
            $("os-count").textContent = d.count;
            $("os-count-label").textContent = d.count === 1 ? "pacote com versão nova" : (d.count ? "pacotes com versão nova" : "tudo em dia");
            $("os-sum").classList.toggle("is-clean", !d.count);
            $("os-chips").innerHTML = (d.security ? '<span class="os-chip sec"><i class="bi bi-shield-exclamation"></i> ' + d.security + " de segurança</span>" : "") +
                (d.count ? '<span class="os-chip">' + (d.count - d.security) + " outros</span>" : '<span class="os-chip ok"><i class="bi bi-check2-circle"></i> sem pendências</span>') +
                (d.kernel ? '<span class="os-chip" title="kernel em uso"><i class="bi bi-cpu"></i> ' + esc(d.kernel) + "</span>" : "");
            var tb = $("os-list"), pk = d.packages || [];
            tb.innerHTML = pk.slice(0, 400).map(function (p) {
                return "<tr><td><span class=\"mono\">" + esc(p.name) + "</span></td><td class=\"mono nic-sub\">" + esc(p.old) + "</td><td class=\"mono\">" + esc(p.new) +
                    "</td><td>" + (p.security ? '<span class="os-chip sec small">segurança</span>' : "") + "</td></tr>";
            }).join("");
            $("os-list-n").textContent = pk.length;
            $("os-list-box").hidden = !pk.length;
        }
        var rb = d.reboot || {};
        $("os-reboot").hidden = !rb.needed;
        $("os-reboot-pk").textContent = rb.packages && rb.packages.length ? " (" + rb.packages.slice(0, 6).join(", ") + (rb.packages.length > 6 ? "…" : "") + ")" : "";
        $("os-run").hidden = !running;
        root.querySelectorAll("[data-os-run], [data-os-plan]").forEach(function (b) { b.disabled = running; });
        if (running) {
            $("os-run-text").textContent = job.text ? job.text.charAt(0).toUpperCase() + job.text.slice(1) : "Em andamento";
            $("os-run-time").textContent = "· " + dur(job.started);
        }
        if (job.state) {
            $("os-log-box").hidden = false;
            $("os-log-state").textContent = "· " + (running ? "em andamento" : (job.state === "done" ? "concluída " : "falhou ") + ago(job.ended));
            var pre = $("os-log"), stick = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 30;
            pre.textContent = d.log || "";
            if (stick) pre.scrollTop = pre.scrollHeight;
            if (running) $("os-log-box").open = true;
        }
        if (lastState === "running" && !running && job.state) {
            toast(job.message || (job.state === "done" ? "Concluído." : "Falhou."), job.state === "done" ? "ok" : "erro");
        }
        lastState = job.state || "";
        clearTimeout(timer);
        timer = setTimeout(load, running ? 2500 : 60000);
    }
    function load() {
        fetch("/api/sistema/os", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.json(); })
            .then(function (d) { if (d && d.ok) paint(d); else { $("os-last").textContent = (d && d.message) || "sem resposta"; timer = setTimeout(load, 30000); } })
            .catch(function () { timer = setTimeout(load, 15000); });
    }
    load();

    function run(acao, remover) {
        return post("/api/sistema/os/executar", { acao: acao, remover: !!remover }).then(function (d) {
            if (!d.ok) { toast(d.message || "Falhou.", "erro"); return; }
            toast(d.message || "Começou.");
            lastState = "running";
            load();
        });
    }
    root.querySelectorAll("[data-os-run]").forEach(function (b) {
        b.addEventListener("click", function () { b.disabled = true; run(b.getAttribute("data-os-run")); });
    });

    // ------------------------------------------------------------ plano (o que vai mudar)
    var dlg = $("os-plan"), planAction = "";
    function list(title, items, cls) {
        if (!items.length) return "";
        return '<div class="os-plan-grp ' + (cls || "") + '"><b>' + title + " (" + items.length + ")</b><div class=\"os-plan-pk\">" +
            items.slice(0, 120).map(function (p) { return '<span class="mono">' + esc(p.name) + "</span>"; }).join("") +
            (items.length > 120 ? "<span>…</span>" : "") + "</div></div>";
    }
    root.querySelectorAll("[data-os-plan]").forEach(function (b) {
        b.addEventListener("click", function () {
            planAction = b.getAttribute("data-os-plan");
            $("os-plan-title").textContent = planAction === "upgrade" ? "Instalar atualizações (apt upgrade)" : "Atualização completa (apt dist-upgrade)";
            $("os-plan-body").innerHTML = '<p class="card-text"><span class="os-spin"><i class="bi bi-arrow-repeat"></i></span> Conferindo o que vai mudar (pela última lista baixada)…</p>';
            $("os-plan-rm").hidden = true; $("os-plan-rm-ok").checked = false; $("os-plan-go").disabled = true;
            dlg.showModal();
            post("/api/sistema/os/plano", { acao: planAction }).then(function (d) {
                if (!d.ok) { $("os-plan-body").innerHTML = '<div class="dk-msgs bad"><b>Não deu para conferir</b><div>' + esc(d.message) + "</div></div>"; return; }
                var total = d.upgrade.length + d.install.length;
                var html = total || d.remove.length ? "" : '<p class="card-text"><i class="bi bi-check2-circle"></i> Nada para instalar com a lista atual. Use <b>Buscar atualizações</b> antes, se faz tempo.</p>';
                html += list("Atualiza", d.upgrade) + list("Instala (novos)", d.install) + list("Remove", d.remove, "bad");
                if (d.kept && d.kept.length) html += '<p class="hint">Ficam para a <b>Atualização completa</b>: ' + d.kept.map(esc).join(", ") + "</p>";
                html += '<p class="hint">A lista é a da última busca; ao começar, o NewOS busca de novo antes de instalar.</p>';
                $("os-plan-body").innerHTML = html;
                $("os-plan-rm").hidden = !d.remove.length;
                $("os-plan-go").disabled = !!d.remove.length;
            });
        });
    });
    $("os-plan-rm-ok").addEventListener("change", function () { $("os-plan-go").disabled = !this.checked; });
    $("os-plan-go").addEventListener("click", function () {
        $("os-plan-go").disabled = true;
        run(planAction, $("os-plan-rm-ok").checked).then(function () { dlg.close(); });
    });

    // ------------------------------------------------------------ energia
    var pdlg = $("os-power"), pAction = "";
    var PTEXT = {
        reboot: ["Reiniciar o servidor?", "Reiniciar", "O servidor reinicia em 5 segundos. Coletas, backups e o painel param por alguns minutos e voltam sozinhos."],
        poweroff: ["Desligar o servidor?", "Desligar", "O servidor desliga em 5 segundos e NÃO volta sozinho: só ligando pelo hipervisor, console ou botão da máquina. Coletas e backups param até lá."]
    };
    root.querySelectorAll("[data-power]").forEach(function (b) {
        b.addEventListener("click", function () {
            pAction = b.getAttribute("data-power");
            $("os-power-title").textContent = PTEXT[pAction][0];
            $("os-power-text").textContent = PTEXT[pAction][2];
            $("os-power-go").querySelector("span").textContent = PTEXT[pAction][1];
            $("os-power-go").className = "btn btn-sm" + (pAction === "poweroff" ? " btn-danger" : "");
            $("os-power-pw").value = "";
            pdlg.showModal();
            setTimeout(function () { $("os-power-pw").focus(); }, 50);
        });
    });
    function goPower() {
        var pw = $("os-power-pw").value;
        if (!pw) { $("os-power-pw").focus(); return; }
        $("os-power-go").disabled = true;
        post("/api/sistema/energia", { acao: pAction, senha: pw }).then(function (d) {
            $("os-power-go").disabled = false;
            if (!d.ok) { toast(d.message || "Falhou.", "erro"); return; }
            pdlg.close();
            var ov = $("os-overlay");
            $("os-ov-title").textContent = pAction === "reboot" ? "Reiniciando…" : "Desligando…";
            $("os-ov-text").textContent = pAction === "reboot" ? "A tela volta sozinha quando o servidor responder." : "Pode fechar esta tela. O servidor só volta ligando pela máquina.";
            ov.hidden = false;
            if (pAction !== "reboot") return;
            var wentDown = false, t0 = Date.now();
            (function probe() {
                fetch("/healthz", { cache: "no-store" }).then(function (r) {
                    if (r.ok && wentDown) { location.href = "/login"; return; }
                    if (!r.ok) wentDown = true;
                    setTimeout(probe, 3000);
                }).catch(function () { wentDown = true; setTimeout(probe, 3000); });
                if (Date.now() - t0 > 60000) wentDown = true;   // reinicio rapido: depois de 1 min aceita a primeira resposta
            })();
        });
    }
    $("os-power-go").addEventListener("click", goPower);
    $("os-power-pw").addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); goPower(); } });

    document.querySelectorAll("#os-plan [data-close], #os-power [data-close]").forEach(function (b) {
        b.addEventListener("click", function () { b.closest("dialog").close(); });
    });
})();
