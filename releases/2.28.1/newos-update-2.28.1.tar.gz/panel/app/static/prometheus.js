/* =====================================================================
   NewOS Panel - telas do Prometheus
   ---------------------------------------------------------------------
   - versoes instaladas x mais nova (GitHub), com botao de atualizar
   - "Testar" de cada alvo (resposta numa faixa no topo)
   - remote_write: "Outro destino" acrescenta uma linha
   ===================================================================== */
(function () {
    "use strict";

    function esc(t) {
        var d = document.createElement("div");
        d.textContent = t == null ? "" : String(t);
        return d.innerHTML;
    }
    var NAMES = { prometheus: "Prometheus", node: "node_exporter", snmp: "snmp_exporter",
                  alertmanager: "Alertmanager", pve: "pve-exporter", vmware: "vmware_exporter" };

    /* ---------------- versoes ---------------------------------------- */
    var vt = document.getElementById("prom-versions");
    if (vt) {
        fetch("/api/prometheus/versoes", { credentials: "same-origin" })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                var body = vt.querySelector("tbody");
                if (!d.ok) { body.innerHTML = '<tr><td colspan="4" class="empty">' + esc(d.message) + "</td></tr>"; return; }
                var rows = Object.keys(NAMES).filter(function (k) { return d.versions[k] && d.versions[k].installed; })
                    .map(function (k, i) {
                        var v = d.versions[k], newer = v.latest && v.latest !== v.installed;
                        var btn = newer && k !== "alertmanager"
                            ? '<form method="post" action="/monitoramento/prometheus/atualizar/' + k + '" data-busy><button class="btn btn-sm" type="submit"><i class="bi bi-arrow-up-circle"></i> Atualizar</button></form>'
                            : (k === "pve" || k === "vmware"
                                ? '<form method="post" action="/monitoramento/prometheus/atualizar/' + k + '" data-busy><button class="btn btn-ghost btn-sm" type="submit" title="Atualiza pelo PyPI"><i class="bi bi-arrow-repeat"></i></button></form>'
                                : '<span class="badge badge-up mini">em dia</span>');
                        return '<tr style="--r:' + i + '"><td class="strong">' + NAMES[k] + '</td><td class="mono">' + esc(v.installed) +
                            '</td><td class="mono">' + esc(v.latest || "PyPI") + "</td><td class=\"actions\">" + btn + "</td></tr>";
                    });
                body.innerHTML = rows.join("") || '<tr><td colspan="4" class="empty">Nada instalado ainda.</td></tr>';
                body.querySelectorAll("form[data-busy]").forEach(function (f) {
                    f.addEventListener("submit", function () {
                        var w = document.getElementById("work-prometheus");
                        if (w) w.classList.add("show");
                        f.querySelector("button").disabled = true;
                    });
                });
            })
            .catch(function () { vt.querySelector("tbody").innerHTML = '<tr><td colspan="4" class="empty">Sem acesso ao GitHub agora.</td></tr>'; });
    }

    /* ---------------- testes ----------------------------------------- */
    var banner = document.getElementById("prom-test");
    document.querySelectorAll("[data-prom-test]").forEach(function (b) {
        b.addEventListener("click", function () {
            if (!banner) return;
            banner.hidden = false;
            banner.className = "prom-test card run";
            banner.querySelector(".ico").innerHTML = '<i class="bi bi-arrow-repeat"></i>';
            banner.querySelector(".msg").textContent = "testando " + b.getAttribute("data-target") + "…";
            banner.scrollIntoView({ block: "nearest", behavior: "smooth" });
            b.disabled = true;
            var q = "kind=" + encodeURIComponent(b.getAttribute("data-prom-test")) +
                    "&target=" + encodeURIComponent(b.getAttribute("data-target")) +
                    "&extra=" + encodeURIComponent(b.getAttribute("data-extra") || "");
            fetch("/api/prometheus/teste?" + q, { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    banner.className = "prom-test card " + (d.online ? "ok" : "fail");
                    banner.querySelector(".ico").innerHTML = '<i class="bi ' + (d.online ? "bi-check-circle-fill" : "bi-x-circle-fill") + '"></i>';
                    banner.querySelector(".msg").textContent = d.message || (d.online ? "ok" : "falhou");
                })
                .catch(function (e) { banner.className = "prom-test card fail"; banner.querySelector(".msg").textContent = e.message; })
                .then(function () { b.disabled = false; });
        });
    });

    /* ---------------- alertas ---------------------------------------- */
    var auto = document.querySelector("[data-auto-toggle]");
    if (auto) {
        auto.addEventListener("change", function () {
            document.querySelectorAll('.prom-alert-mods input[name="modules"]').forEach(function (c) {
                c.disabled = auto.checked;
            });
        });
    }
    var at = document.querySelector("[data-alert-test]");
    if (at && banner) {
        at.addEventListener("click", function () {
            banner.hidden = false;
            banner.className = "prom-test card run";
            banner.querySelector(".ico").innerHTML = '<i class="bi bi-arrow-repeat"></i>';
            banner.querySelector(".msg").textContent = "validando o bot e enviando o alerta de teste…";
            at.disabled = true;
            fetch("/api/prometheus/alertas/teste", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    banner.className = "prom-test card " + (d.online ? "ok" : "fail");
                    banner.querySelector(".ico").innerHTML = '<i class="bi ' + (d.online ? "bi-send-check" : "bi-x-circle-fill") + '"></i>';
                    banner.querySelector(".msg").textContent = d.message || "";
                })
                .catch(function (e) { banner.className = "prom-test card fail"; banner.querySelector(".msg").textContent = e.message; })
                .then(function () { at.disabled = false; });
        });
    }

    /* ---------------- remote_write: mais um destino ------------------ */
    var add = document.querySelector("[data-rw-add]");
    if (add) {
        add.addEventListener("click", function () {
            var list = document.getElementById("rw-list");
            var rows = list.querySelectorAll(".prom-rw");
            var row = rows[rows.length - 1].cloneNode(true);
            row.querySelectorAll("input").forEach(function (i) {
                if (i.type === "checkbox") { i.checked = false; i.value = String(rows.length); }
                else { i.value = ""; i.placeholder = i.name === "password" ? "" : i.placeholder; }
            });
            row.style.setProperty("--r", rows.length);
            list.appendChild(row);
            row.querySelector('input[name="url"]').focus();
        });
    }
})();

/* ---------------- Alvos: filtro de hosts por cluster ---------------- */
(function () {
    "use strict";
    var bar = document.querySelector("[data-prom-filter]");
    if (!bar) return;
    var rows = document.querySelectorAll(".prom-hosts tbody tr[data-cluster]");
    bar.addEventListener("click", function (e) {
        var b = e.target.closest("[data-f]");
        if (!b) return;
        bar.querySelectorAll("[data-f]").forEach(function (x) { x.classList.toggle("on", x === b); });
        var f = b.getAttribute("data-f"), i = 0;
        rows.forEach(function (r) {
            var show = f === "*" || r.getAttribute("data-cluster") === f;
            r.hidden = !show;
            if (show) { r.style.setProperty("--r", Math.min(i++, 12)); r.classList.remove("prom-in"); void r.offsetWidth; r.classList.add("prom-in"); }
        });
    });
})();

/* ---------------- Alvos: remover varios hosts de uma vez ------------- */
(function () {
    "use strict";
    var form = document.querySelector("[data-prom-bulk]");
    var all = document.querySelector("[data-prom-all]");
    if (!form || !all) return;
    var boxes = Array.prototype.slice.call(document.querySelectorAll('input[name="addresses"][form="hosts-bulk"]'));
    function visible(b) { return !b.closest("tr").hidden; }
    function sync() {
        var vis = boxes.filter(visible), n = boxes.filter(function (b) { return b.checked && visible(b); }).length;
        form.hidden = n === 0;
        form.querySelectorAll("[data-n]").forEach(function (x) { x.textContent = n; });
        all.checked = n > 0 && n === vis.length;
        all.indeterminate = n > 0 && n < vis.length;
    }
    all.addEventListener("change", function () {
        boxes.forEach(function (b) { b.checked = all.checked && visible(b); });
        sync();
    });
    boxes.forEach(function (b) { b.addEventListener("change", sync); });
    var bar = document.querySelector("[data-prom-filter]");
    if (bar) bar.addEventListener("click", function () {
        setTimeout(function () { boxes.forEach(function (b) { if (!visible(b)) b.checked = false; }); sync(); }, 0);
    });
    // 2.27: editar em massa (cluster e jobs): os campos so valem quando o modo nao e "manter"
    form.querySelectorAll("[data-bulk-mode]").forEach(function (sel) {
        function upd() {
            var tgt = form.querySelector('[data-bulk-for="' + sel.getAttribute("data-bulk-mode") + '"]');
            if (!tgt) return;
            if (tgt.tagName === "SELECT") tgt.disabled = sel.value === "keep";
            else tgt.hidden = sel.value === "keep";
        }
        sel.addEventListener("change", upd);
        upd();
    });
    form.addEventListener("submit", function (e) {
        var n = boxes.filter(function (b) { return b.checked && visible(b); }).length;
        if (e.submitter && e.submitter.hasAttribute("data-bulk-edit")) {
            var cm = form.querySelector('[name="cluster_mode"]').value, jm = form.querySelector('[name="jobs_mode"]').value;
            var picked = form.querySelectorAll('input[name="jobs"]:checked').length;
            var why = !n ? "Nenhum host selecionado." : (cm === "keep" && jm === "keep") ? "Escolha o que mudar: o cluster, os jobs ou os dois."
                : (jm !== "keep" && !picked) ? "Marque os jobs." : "";
            if (why) { window.alert(why); e.preventDefault(); e.stopImmediatePropagation(); }
            return;
        }
        if (!n || !window.confirm("Remover " + n + " host(s) do Prometheus? Os programas nos hosts não são tocados.")) {
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true);
    sync();
})();

/* ---------------- Importar: arquivo escolhido ou colado ------------- */
(function () {
    "use strict";
    document.querySelectorAll("[data-imp]").forEach(function (box) {
        var file = box.querySelector("input[type=file]");
        var text = box.querySelector("textarea");
        var label = box.querySelector("[data-imp-name]");
        function mark(name) {
            box.classList.toggle("has-file", !!name);
            if (label) label.textContent = name || label.getAttribute("data-empty");
        }
        file.addEventListener("change", function () {
            var f = file.files && file.files[0];
            mark(f ? f.name + " (" + Math.max(1, Math.round(f.size / 1024)) + " KiB)" : "");
            if (f) text.value = "";
        });
        text.addEventListener("input", function () {
            if (text.value.trim()) { file.value = ""; mark("colado (" + text.value.split("\n").length + " linhas)"); }
            else mark("");
        });
        ["dragenter", "dragover"].forEach(function (ev) {
            box.addEventListener(ev, function (e) { e.preventDefault(); box.classList.add("drag"); });
        });
        ["dragleave", "drop"].forEach(function (ev) {
            box.addEventListener(ev, function () { box.classList.remove("drag"); });
        });
        box.addEventListener("drop", function (e) {
            e.preventDefault();
            if (e.dataTransfer && e.dataTransfer.files.length) {
                file.files = e.dataTransfer.files;
                file.dispatchEvent(new Event("change"));
            }
        });
    });
})();

/* 2.18 - padrao de nomes NewFront: CLUSTER-CLIENTE, PVE-CLIENTE, CEPH-CLIENTE (maiusculas).
   O nome se preenche pelo cliente enquanto o analista nao digitar outro. */
(function () {
    "use strict";
    function slug(s) {
        return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase()
            .replace(/[^A-Z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    }
    document.querySelectorAll("input.nf-upper").forEach(function (inp) {
        inp.addEventListener("input", function () {
            var p = inp.selectionStart, up = inp.value.toUpperCase();
            if (up !== inp.value) { inp.value = up; try { inp.setSelectionRange(p, p); } catch (e) { /* tipo sem cursor */ } }
        });
    });
    document.querySelectorAll("input[data-nf-name]").forEach(function (inp) {
        var form = inp.form, prefix = inp.getAttribute("data-nf-name");
        if (!form) return;
        var last = inp.value;                           // so troca o que ainda e sugestao nossa
        function cliente() {
            var c = form.querySelector('input[name="cliente"]');
            if (c) return c.value;
            var sel = form.querySelector('select[name="cluster"]');
            var opt = sel && sel.options[sel.selectedIndex];
            return opt ? (opt.getAttribute("data-cliente") || "") : "";
        }
        function suggest() {
            var c = slug(cliente());
            if (!c || (inp.value && inp.value !== last)) return;
            inp.value = last = prefix + c;
        }
        form.addEventListener("input", function (e) { if (e.target.name === "cliente") suggest(); });
        form.addEventListener("change", function (e) { if (e.target.name === "cluster") suggest(); });
    });
})();
