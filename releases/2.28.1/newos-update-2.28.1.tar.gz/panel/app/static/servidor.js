/* =====================================================================
   NewOS Panel - Sistema > Servidor (2.28)
   ---------------------------------------------------------------------
   - Abas: Atualizações e energia | Segurança | Identidade e /etc/hosts.
     O endereço (#cofre, #grub, #hosts, #wazuh...) abre a aba certa e
     rola até o cartão; os cartões do topo também levam direto.
   - Wazuh: enquanto o agente instala, a tela confere a cada 5 s e
     recarrega quando terminar.
   ===================================================================== */
(function () {
    "use strict";
    var tabs = document.getElementById("srv-tabs");
    if (!tabs) return;
    var panes = Array.prototype.slice.call(document.querySelectorAll(".srv-pane"));
    var buttons = Array.prototype.slice.call(tabs.querySelectorAll("button[data-tab]"));
    var KEY = "newos.servidor.aba";

    function show(name) {
        if (!panes.some(function (p) { return p.getAttribute("data-pane") === name; })) name = buttons[0].getAttribute("data-tab");
        panes.forEach(function (p) { p.hidden = p.getAttribute("data-pane") !== name; });
        buttons.forEach(function (b) {
            var on = b.getAttribute("data-tab") === name;
            b.classList.toggle("on", on);
            b.setAttribute("aria-selected", on ? "true" : "false");
        });
        try { sessionStorage.setItem(KEY, name); } catch (e) { /* sem storage: tudo bem */ }
        return name;
    }

    // "#cofre" -> aba que contem o cartao; "#seguranca" -> a propria aba
    function fromHash() {
        var id = decodeURIComponent((location.hash || "").slice(1));
        if (!id) return null;
        if (panes.some(function (p) { return p.getAttribute("data-pane") === id; })) return { pane: id };
        var el = document.getElementById(id);
        var pane = el && el.closest(".srv-pane");
        return pane ? { pane: pane.getAttribute("data-pane"), el: el } : null;
    }

    function openHash(scroll) {
        var h = fromHash();
        if (!h) return false;
        show(h.pane);
        if (scroll && h.el) setTimeout(function () { h.el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60);
        return true;
    }

    buttons.forEach(function (b) {
        b.addEventListener("click", function () {
            var name = show(b.getAttribute("data-tab"));
            if (history.replaceState) history.replaceState(null, "", "#" + name);
        });
    });
    window.addEventListener("hashchange", function () { openHash(true); });

    if (!openHash(true)) {
        var last = null;
        try { last = sessionStorage.getItem(KEY); } catch (e) { last = null; }
        show(last || buttons[0].getAttribute("data-tab"));
    }

    /* ---------------- Wazuh: acompanha a instalacao ------------------ */
    var wz = document.getElementById("wazuh");
    if (wz && wz.getAttribute("data-wz-running") === "1") {
        var tries = 0;
        var timer = setInterval(function () {
            tries += 1;
            if (tries > 240) { clearInterval(timer); return; }       // 20 min: desiste de conferir
            fetch("/api/sistema/wazuh", { credentials: "same-origin" })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (d) {
                    if (d && d.job && d.job.state !== "running") {
                        clearInterval(timer);
                        location.hash = "wazuh";
                        location.reload();
                    }
                })
                .catch(function () { /* o painel pode estar reiniciando: tenta de novo */ });
        }, 5000);
    }
})();
