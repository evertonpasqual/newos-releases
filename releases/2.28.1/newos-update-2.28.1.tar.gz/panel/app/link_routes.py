"""
NewOS Panel - NewOS Manager: ativacao obrigatoria e estado do agente.

Servidor instalado pela ISO (marca /etc/newos/activation-required): depois
do login, todo o painel leva a /ativacao ate:
    1. colar a chave gerada no NewOS Manager (o agente newos-link ativa)
    2. trocar a senha padrao do admin (se ainda for a padrao) pela senha que o
       NewOS gera (21 caracteres; 2.21: nao da para digitar outra)
So administradores ativam. Servidores atualizados (sem a marca) entram no
Manager como pendentes e nada trava aqui.

Suspenso ou desativado pelo Manager (o agente newos-link cria
/etc/newos/suspended.json ou /etc/newos/decommissioned): TODO o painel,
inclusive o login, leva a /suspenso, que so informa. Reativar e so pelo
Manager (ou, suspenso, "newos-link resume" como root no SSH).

    GET  /ativacao              passo atual
    POST /ativacao/chave        ativa com a chave
    POST /ativacao/senha        troca a senha padrao e libera o painel
    POST /sistema/manager/verificar   um sinal agora (Sistema > Servidor)
    GET  /suspenso              aviso de servidor suspenso / desativado
    GET/POST /recuperar-senha   2.22: "Esqueci a senha" (usuario + duplo fator) -> pedido ao Manager
    GET  /recuperar-senha/aguardando  espera o administrador do Manager autorizar
    GET  /api/recuperar-senha   situacao do pedido (a tela pergunta a cada 4 s)
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, mfa, terminal_routes

log = logging.getLogger("newos.panel.link")
HELPER = "/usr/local/sbin/newos-link"
REQUIRED = "/etc/newos/activation-required"
STATUS = "/etc/newos/link-status.json"
NEWOS_CONF = "/etc/newos/newos.conf"
SUSPENDED = "/etc/newos/suspended.json"
DECOMMISSIONED = "/etc/newos/decommissioned"
LOCK_OPEN = ("/suspenso", "/static", "/healthz", "/favicon")
OPEN_PATHS = ("/ativacao", "/login", "/logout", "/static", "/healthz", "/api/tema", "/favicon")
STATUS_TEXT = {"active": "ativo", "pending": "pendente de aprovação", "revoked": "revogado",
               "awaiting-key": "aguardando a chave de ativação", "waiting-firstboot": "aguardando o 1º boot",
               "off": "desligado", "none": "ainda sem contato"}


class LinkError(Exception):
    pass


def required() -> bool:
    return os.path.exists(REQUIRED)


def locked() -> str:
    """'' | 'suspended' | 'decommissioned' (ordem do NewOS Manager)."""
    if os.path.exists(DECOMMISSIONED):
        return "decommissioned"
    return "suspended" if os.path.exists(SUSPENDED) else ""


def link_status() -> dict[str, Any]:
    try:
        with open(STATUS, encoding="utf-8") as fh:
            st = json.load(fh)
    except (OSError, ValueError):
        st = {}
    st.setdefault("status", "none")
    st["required"] = required()
    st["text"] = STATUS_TEXT.get(st["status"], st["status"])
    return st


def helper(args: list[str], payload: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=90, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise LinkError(f"Nao foi possivel executar o agente: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise LinkError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def _default_password() -> str:
    val = "admin"
    try:
        with open(NEWOS_CONF, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("PANEL_ADMIN_PASSWORD="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return val


def still_default(user_id: int) -> bool:
    row = db.query_one("SELECT password_hash FROM users WHERE id = %s", (user_id,))
    return bool(row) and auth.verify_password(_default_password(), row["password_hash"])


def install_gate(app: FastAPI) -> None:
    """Registrar ANTES do SessionMiddleware (para a sessao ja estar pronta aqui)."""

    @app.middleware("http")
    async def activation_gate(request: Request, call_next):
        path = request.url.path
        if locked() and not path.startswith(LOCK_OPEN):
            if path.startswith("/api/"):
                return JSONResponse({"ok": False, "message": "Servidor suspenso pelo NewOS Manager."},
                                    status_code=423)
            return RedirectResponse("/suspenso", status_code=303)
        if not required() or path.startswith(OPEN_PATHS) or not request.session.get("user"):
            return await call_next(request)
        if path.startswith("/api/"):
            return JSONResponse({"ok": False, "message": "Ative este servidor no NewOS Manager."}, status_code=423)
        return RedirectResponse("/ativacao", status_code=303)


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    @app.get("/suspenso", response_class=HTMLResponse)
    async def locked_page(request: Request):
        mode = locked()
        if not mode:
            return redirect("/")
        since = None
        try:
            with open(SUSPENDED, encoding="utf-8") as fh:
                since = json.load(fh).get("since")
        except (OSError, ValueError):
            pass
        resp = render(request, "locked.html", mode=mode, st=link_status(), since=since)
        resp.status_code = 423
        return resp

    @app.get("/ativacao", response_class=HTMLResponse)
    async def activation_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not required():
            return redirect("/dashboard")
        st = link_status()
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        step = "senha" if st["status"] == "active" else "chave"
        new_pw = ""
        if request.query_params.get("voltar"):
            request.session.pop("act_copied", None)
        if step == "senha" and request.session.get("act_copied") and request.session.get("act_pw"):
            # 2.24: passo 3 - duplo fator (obrigatorio) e cofre
            row = await run_in_threadpool(db.query_one, "SELECT mfa_enabled, mfa_secret FROM users WHERE id = %s", (user["id"],)) or {}
            if row.get("mfa_enabled"):
                secret, qr = row.get("mfa_secret") or "", ""
            else:
                secret = request.session.get("act_mfa") or mfa.new_secret()
                request.session["act_mfa"] = secret
                qr = mfa.qr_svg(mfa.uri(secret, user["username"]))
            return render(request, "activation.html", st=st, admin=admin, step="mfa", qr=qr, pretty=mfa.pretty(secret),
                          has_mfa=bool(row.get("mfa_enabled")))
        if step == "senha":
            # 2.21: a senha nova nao e digitada: o NewOS gera (21 caracteres) e so mostra para copiar.
            # Fica na sessao (assinada) ate o "Trocar e entrar", entao nao da para trocar por outra.
            if request.query_params.get("nova") or not request.session.get("act_pw"):
                request.session["act_pw"] = auth.generate_password()
            new_pw = request.session["act_pw"]
        return render(request, "activation.html", st=st, admin=admin, step=step, new_pw=new_pw)

    @app.post("/ativacao/chave", response_class=HTMLResponse)
    async def activation_key(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            flash(request, "erro", "Só um administrador ativa o servidor.")
            return redirect("/ativacao")
        form = await request.form()
        ip = auth.client_ip(request)
        try:
            res = await run_in_threadpool(helper, ["activate"], {"key": str(form.get("key", ""))})
        except LinkError as exc:
            db.log_audit(user["username"], "ativacao", f"chave recusada: {exc}"[:200], ip)
            flash(request, "erro", str(exc))
            return redirect("/ativacao")
        db.log_audit(user["username"], "ativacao", f"ativado no Manager (cliente {res.get('client') or '-'})", ip)
        if not await run_in_threadpool(still_default, user["id"]):
            try:
                await run_in_threadpool(helper, ["finish"])
            except LinkError as exc:
                flash(request, "erro", str(exc))
                return redirect("/ativacao")
            flash(request, "ok", "Servidor ativado no NewOS Manager.")
            return redirect("/dashboard")
        flash(request, "ok", "Chave aceita. Agora troque a senha padrão para liberar o painel.")
        return redirect("/ativacao")

    @app.post("/ativacao/senha", response_class=HTMLResponse)
    async def activation_password(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if link_status()["status"] != "active":
            return redirect("/ativacao")
        form = await request.form()
        pw = str(request.session.get("act_pw") or "")
        if not pw:
            flash(request, "erro", "A senha gerada expirou. Copie a nova senha abaixo.")
            return redirect("/ativacao")
        if not form.get("copiei"):
            flash(request, "erro", "Copie e guarde a senha antes de continuar (marque a confirmação).")
            return redirect("/ativacao")
        request.session["act_copied"] = 1          # 2.24: a troca acontece no passo 3 (duplo fator + cofre)
        return redirect("/ativacao")

    @app.post("/ativacao/mfa", response_class=HTMLResponse)
    async def activation_mfa(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if link_status()["status"] != "active":
            return redirect("/ativacao")
        pw = str(request.session.get("act_pw") or "")
        if not pw or not request.session.get("act_copied"):
            return redirect("/ativacao")
        form = await request.form()
        row = await run_in_threadpool(db.query_one, "SELECT mfa_enabled, mfa_secret FROM users WHERE id = %s", (user["id"],)) or {}
        step = None
        if row.get("mfa_enabled"):
            secret = row.get("mfa_secret") or ""
        else:
            secret = str(request.session.get("act_mfa") or "")
            step = mfa.check(secret, str(form.get("code", ""))) if secret else None
            if step is None:
                flash(request, "erro", "Código inválido: escaneie o QR code e digite o código atual do app.")
                return redirect("/ativacao")
        from . import cofre_routes
        try:
            res = await run_in_threadpool(cofre_routes.rotate_and_register, user["id"], user["username"], pw, secret, step)
        except Exception as exc:  # noqa: BLE001
            flash(request, "erro", f"Não consegui trocar a senha: {exc}")
            return redirect("/ativacao")
        try:
            await run_in_threadpool(helper, ["finish"])
        except LinkError as exc:
            flash(request, "erro", str(exc))
            return redirect("/ativacao")
        for k in ("act_pw", "act_copied", "act_mfa"):
            request.session.pop(k, None)
        ip = auth.client_ip(request)
        db.log_audit(user["username"], "ativacao", "senha padrao trocada pela senha gerada (21 caracteres), duplo fator "
                     + ("ligado" if step is not None else "ja ligado") + "; cofre: "
                     + (((res.get("vault") or {}).get("state") or "?") if res.get("vault") else f"nao enviado ({res['warn']})"), ip)
        return render(request, "activation.html", st=link_status(), admin=True, step="fim", res=res)

    @app.post("/sistema/manager/verificar", response_class=HTMLResponse)
    async def manager_check(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        try:
            st = await run_in_threadpool(helper, ["once"])
            if st.get("last_error"):
                flash(request, "erro", f"NewOS Manager: {st['last_error']}")
            else:
                flash(request, "ok", f"NewOS Manager: {STATUS_TEXT.get(st.get('status'), st.get('status'))}.")
        except LinkError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/servidor#manager")

    # ---------------------------------------------------------------- 2.22: recuperar a senha
    RESET_TEXT = {"pending": "Aguardando um administrador do NewOS Manager autorizar.",
                  "applied": "Senha trocada. Peça a senha nova a quem autorizou no NewOS Manager.",
                  "denied": "O pedido foi recusado no NewOS Manager.",
                  "expired": "O pedido expirou (15 minutos) sem autorização. Faça outro, se precisar.",
                  "cancelled": "Este pedido foi substituído por um mais novo.",
                  "failed": "O Manager autorizou, mas a senha não pôde ser gravada aqui. Faça outro pedido.",
                  "none": "Pedido não encontrado. Faça outro, se precisar."}

    def reset_available() -> bool:
        return link_status().get("status") == "active" and not locked()

    @app.get("/recuperar-senha", response_class=HTMLResponse)
    async def reset_form(request: Request):
        if auth.current_user(request):
            return redirect("/dashboard")
        return render(request, "reset_password.html", step="form", available=reset_available())

    @app.post("/recuperar-senha", response_class=HTMLResponse)
    async def reset_submit(request: Request):
        if auth.current_user(request):
            return redirect("/dashboard")
        form = await request.form()
        username, code = str(form.get("username", "")).strip()[:64], str(form.get("code", ""))
        ip = auth.client_ip(request)
        available = reset_available()

        def again(error: str):
            return render(request, "reset_password.html", step="form", available=available, error=error, username=username)

        wait = auth.is_locked_out(ip)
        if wait:
            return again(f"Muitas tentativas. Tente novamente em {wait} segundos.")
        if not available:
            return again("Este servidor não está ligado ao NewOS Manager: a recuperação não está disponível.")
        row = await run_in_threadpool(db.query_one, "SELECT id, username, is_active, mfa_enabled, mfa_secret, mfa_last_step "
                                      "FROM users WHERE username = %s LIMIT 1", (username,))
        step = None
        if row and row.get("is_active") and row.get("mfa_enabled"):
            step = mfa.check(row.get("mfa_secret") or "", code, row.get("mfa_last_step"))
        if step is None:
            auth.register_failure(ip)
            log.warning("Recuperacao de senha negada para %r vindo de %s", username, ip)
            db.log_audit(username or "?", "senha", "recuperacao de senha: usuario ou codigo invalido", ip)
            return again("Usuário ou código inválido. A recuperação exige a verificação em duas etapas ligada.")
        await run_in_threadpool(db.execute, "UPDATE users SET mfa_last_step = %s WHERE id = %s", (step, row["id"]))
        auth.clear_failures(ip)
        try:
            res = await run_in_threadpool(helper, ["reset-request"], {"user": row["username"], "ip": ip})
        except LinkError as exc:
            return again(str(exc))
        request.session["pwreset"] = {"id": res["id"], "user": row["username"], "exp": int(res.get("expires") or 0)}
        db.log_audit(row["username"], "senha", f"pediu recuperacao de senha ao NewOS Manager (pedido {res['id']})", ip)
        return redirect("/recuperar-senha/aguardando")

    @app.get("/recuperar-senha/aguardando", response_class=HTMLResponse)
    async def reset_wait(request: Request):
        p = request.session.get("pwreset")
        if not isinstance(p, dict):
            return redirect("/recuperar-senha")
        return render(request, "reset_password.html", step="wait", req=p, text=RESET_TEXT["pending"])

    @app.get("/api/recuperar-senha")
    async def reset_poll(request: Request):
        p = request.session.get("pwreset")
        if not isinstance(p, dict):
            return JSONResponse({"ok": False, "status": "none", "text": RESET_TEXT["none"]}, status_code=404)
        try:
            res = await run_in_threadpool(helper, ["reset-check"], {"id": p["id"]})
        except LinkError as exc:
            return {"ok": True, "status": "pending", "text": f"Sem contato com o Manager agora ({exc}). Tentando de novo…"}
        st = res.get("status") or "none"
        if st != "pending":
            request.session.pop("pwreset", None)
            if st == "applied":
                db.log_audit(p["user"], "senha", f"senha trocada pela recuperacao (autorizado por {res.get('by') or '?'} "
                             "no NewOS Manager)", auth.client_ip(request))
        return {"ok": True, "status": st, "text": RESET_TEXT.get(st, RESET_TEXT["none"]), "left": res.get("left")}

