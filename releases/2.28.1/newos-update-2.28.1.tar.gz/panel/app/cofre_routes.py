"""
NewOS Panel - cofre (Vaultwarden) pelo NewOS Manager (2.24).

O NewOS nunca fala com o cofre: manda ao Manager (pelo agente newos-link) a
senha nova e o segredo do duplo fator, e o Manager grava o item na colecao
NewOS-PROXYs com o hostname deste servidor e os IPs dele.

Troca em duas fases (a senha nunca se perde):
    1. vault-prepare  o Manager guarda (cifrado) e responde
    2. a senha (e o duplo fator) mudam AQUI
    3. vault-confirm  o Manager grava no cofre
Se o passo 1 falhar (cofre nao configurado, Manager fora), a troca segue e a
tela avisa: da para cadastrar depois em Sistema > Servidor.

    GET  /sistema/servidor/cofre    "Cadastrar no cofre" (gera senha nova para o admin)
    POST /sistema/servidor/cofre
"""

from __future__ import annotations

import logging
import socket
import time
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, link_routes, mfa, terminal_routes

log = logging.getLogger("newos.panel.cofre")
DEFAULT_HOSTNAMES = {"newos", "localhost", "debian", ""}
STATE_TEXT = {"feito": "no cofre", "pendente": "na fila do Manager para o cofre", "erro": "o Manager não conseguiu gravar no cofre",
              "aguardando-hostname": "vai para o cofre assim que o hostname for definido", "aguardando-newos": "aguardando"}


def default_hostname() -> bool:
    return socket.gethostname().split(".")[0].strip().lower() in DEFAULT_HOSTNAMES


def admin_username() -> str:
    val = "admin"
    try:
        with open(link_routes.NEWOS_CONF, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("PANEL_ADMIN_USER="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'") or "admin"
    except OSError:
        pass
    return val


def vault_status() -> dict[str, Any]:
    st = link_routes.link_status()
    v = st.get("vault") if isinstance(st.get("vault"), dict) else {}
    v = dict(v or {})
    v["linked"] = st.get("status") == "active"
    v["text"] = STATE_TEXT.get(v.get("state") or "", "ainda não cadastrado")
    return v


def mfa_row(user_id: int) -> dict[str, Any]:
    return db.query_one("SELECT id, username, mfa_enabled, mfa_secret, mfa_last_step FROM users WHERE id = %s", (user_id,)) or {}


def unix_same_password(password: str) -> tuple[list[str], list[str]]:
    """2.25: a mesma senha do admin vale para o root e o usuario do NewOS (newfront),
    console e SSH: o item do cofre serve para os tres. Devolve (trocados, falhos)."""
    from . import system_routes
    done, bad = [], []
    try:
        names = [u["user"] for u in system_routes.helper(["unix-users"]).get("users", []) if not u.get("locked")]
    except Exception as exc:  # noqa: BLE001
        log.error("contas Linux: %s", exc)
        return [], ["root"]
    for name in names:
        try:
            system_routes.helper(["unix-password"], {"user": name, "password": password})
            done.append(name)
        except Exception as exc:  # noqa: BLE001
            log.error("senha do %s (Linux) nao trocada: %s", name, exc)
            bad.append(name)
    return done, bad


def rotate_and_register(user_id: int, username: str, password: str, secret: str, new_mfa_step: int | None) -> dict[str, Any]:
    """Troca a senha do painel e, a mesma, do root e do newfront (2.25); liga o duplo fator,
    se new_mfa_step, e manda ao cofre pelo Manager.
    Devolve {codes, vault, warn}. Levanta excecao se a troca local falhar (nada muda)."""
    jid, warn = None, ""
    try:
        jid = link_routes.helper(["vault-prepare"], {"user": username, "password": password, "totp": secret}).get("id")
    except link_routes.LinkError as exc:
        warn = str(exc)
    try:
        auth.change_password(user_id, password)
        codes = mfa.enable(user_id, secret, new_mfa_step) if new_mfa_step is not None else None
    except Exception as exc:
        if jid:
            try:
                link_routes.helper(["vault-confirm"], {"id": jid, "ok": False, "message": "a troca falhou no NewOS"})
            except link_routes.LinkError:
                pass
        raise exc
    unix, bad = unix_same_password(password)
    if bad:
        warn = (warn + "; " if warn else "") + "não troquei a senha de " + ", ".join(bad) + " (Linux): troque em Usuários › contas Linux"
    vault = None
    if jid:
        try:
            vault = link_routes.helper(["vault-confirm"], {"id": jid, "ok": True, "unix": unix})
        except link_routes.LinkError as exc:
            warn = f"a senha foi trocada, mas o Manager não confirmou o cofre: {exc}"
    wazuh = ""
    if vault:
        vault["text"] = STATE_TEXT.get(vault.get("state") or "", vault.get("state") or "")
        wazuh = start_wazuh()
    return {"codes": codes, "vault": vault, "warn": warn, "unix": unix, "wazuh": wazuh}


def start_wazuh() -> str:
    """2.28: cadastrado no cofre -> instala o agente Wazuh (so se ainda nao tiver; em segundo plano)."""
    from . import system_routes
    res = system_routes.os_helper(["wazuh", "install", "--auto"], 60)
    if res.get("ok"):
        if res.get("skipped"):
            return ""
        log.info("cofre: instalando o agente Wazuh")
        return "Instalando o agente Wazuh: acompanhe em Sistema › Servidor › Segurança."
    msg = res.get("message") or "falhou"
    log.warning("cofre: agente Wazuh nao iniciado: %s", msg)
    return "" if "não está configurado" in msg else f"O agente Wazuh não foi instalado: {msg}"


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    async def guard(request: Request):
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            flash(request, "erro", "Só administradores cadastram no cofre.")
            return None, redirect("/sistema/servidor#cofre")
        return user, None

    def blockers(v: dict[str, Any]) -> str:
        if not v.get("linked"):
            return "Este servidor precisa estar ativo no NewOS Manager."
        if default_hostname():
            return "Defina o hostname deste servidor (PROXY-CLIENTE) em Identidade, logo abaixo, antes: o item do cofre leva o nome dele."
        if v.get("configured") is False:
            return "O cofre ainda não está configurado no NewOS Manager (Configurações › Integrações › Cofre)."
        return ""

    @app.get("/sistema/servidor/cofre", response_class=HTMLResponse)
    async def vault_page(request: Request):
        user, bounce = await guard(request)
        if bounce:
            return bounce
        target = await run_in_threadpool(db.query_one, "SELECT id, username, mfa_enabled FROM users WHERE username = %s AND is_active = 1",
                                         (admin_username(),))
        if not target:
            flash(request, "erro", f"A conta {admin_username()} não existe ou está desativada.")
            return redirect("/sistema/servidor#cofre")
        v = await run_in_threadpool(vault_status)
        secret = ""
        if not target.get("mfa_enabled"):
            secret = request.session.get("cofre_mfa") or mfa.new_secret()
            request.session["cofre_mfa"] = secret
        return render(request, "cofre.html", active="servidor", target=target, v=v, why=blockers(v), secret=secret,
                      qr=mfa.qr_svg(mfa.uri(secret, target["username"])) if secret else "", pretty=mfa.pretty(secret) if secret else "",
                      host=socket.gethostname().split(".")[0])

    @app.post("/sistema/servidor/cofre", response_class=HTMLResponse)
    async def vault_submit(request: Request):
        user, bounce = await guard(request)
        if bounce:
            return bounce
        form = await request.form()
        v = await run_in_threadpool(vault_status)
        why = blockers(v)
        if why:
            flash(request, "erro", why)
            return redirect("/sistema/servidor/cofre")
        if not form.get("confirmo"):
            flash(request, "erro", "Marque a confirmação: a senha do admin vai mudar.")
            return redirect("/sistema/servidor/cofre")
        target = await run_in_threadpool(mfa_row, (await run_in_threadpool(
            db.query_one, "SELECT id FROM users WHERE username = %s AND is_active = 1", (admin_username(),)) or {}).get("id") or 0)
        if not target:
            return redirect("/sistema/servidor#cofre")
        step = None
        if target.get("mfa_enabled"):
            secret = target.get("mfa_secret") or ""
        else:
            secret = request.session.get("cofre_mfa") or ""
            step = mfa.check(secret, str(form.get("code", ""))) if secret else None
            if step is None:
                flash(request, "erro", "Código do duplo fator inválido: escaneie o QR code e digite o código atual.")
                return redirect("/sistema/servidor/cofre")
        pw = auth.generate_password()
        ip = auth.client_ip(request)
        try:
            res = await run_in_threadpool(rotate_and_register, target["id"], target["username"], pw, secret, step)
        except Exception as exc:  # noqa: BLE001
            log.error("Cadastrar no cofre falhou: %s", exc)
            flash(request, "erro", f"Nada mudou: {exc}")
            return redirect("/sistema/servidor/cofre")
        request.session.pop("cofre_mfa", None)
        db.log_audit(user["username"], "senha", f"cofre: senha nova do {target['username']} gerada e enviada ao NewOS Manager"
                     + (" (duplo fator ligado)" if step is not None else "") + (f"; aviso: {res['warn']}" if res["warn"] else ""), ip)
        if res.get("wazuh"):
            db.log_audit(user["username"], "sistema", "cofre: " + res["wazuh"], ip)
        resp = render(request, "cofre.html", active="servidor", done=True, pw=pw, res=res, target=target,
                      host=socket.gethostname().split(".")[0], v=await run_in_threadpool(vault_status), why="")
        resp.headers["Cache-Control"] = "no-store"
        return resp
