#!/usr/bin/env bash
# =====================================================================
#  Modulo Docker - instalacao (newos-modctl install docker)
#  docker.io do Debian + a configuracao que protege o NewOS (newos-docker setup):
#  teto de recursos (newos-docker.slice), logs com rotacao, rede propria e o
#  FORWARD devolvido ao firewall do NewOS.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="docker"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

[[ -x /usr/local/sbin/newos-docker ]] || mod_die "Helper newos-docker ausente: atualize o NewOS." 2
if ! pkg_installed docker.io; then
    apt_ensure_lists
    apt_install docker.io
fi
# a configuracao vai antes de o Docker subir de verdade (rede propria desde o primeiro start)
NEWOS_DOCKER_UNCONFINED=1 /usr/local/sbin/newos-docker setup >/dev/null || mod_die "Nao consegui configurar o Docker (veja /var/log/newos-docker.log)."
systemctl enable docker.socket >/dev/null 2>&1 || true
svc_enable_start docker || mod_die "O Docker nao subiu." 2
NEWOS_DOCKER_UNCONFINED=1 /usr/local/sbin/newos-docker setup >/dev/null || true
mod_info "Docker $(docker --version 2>/dev/null | sed 's/^Docker version //; s/,.*//') pronto. Veja em Docker > Containers."
