"""
NewOS Panel - contas de acesso web.

CRUD das contas que entram no painel. Todas ficam na tabela `users` do
MariaDB, com senha em hash bcrypt.

Regras de seguranca aplicadas aqui:
  - nunca e possivel ficar sem nenhum administrador ativo
  - ninguem consegue excluir ou desativar a propria conta
  - o nome de usuario e validado e normalizado (minusculo, sem espaco)
"""

from __future__ import annotations

import logging
import re
from typing import Any

from . import auth, db

log = logging.getLogger("newos.panel.users")

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,31}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

MIN_PASSWORD_LEN = 6


class UserError(RuntimeError):
    """Erro de validacao tratado e mostrado ao administrador."""


# =====================================================================
#  Validacao
# =====================================================================

def validate_username(username: str) -> str:
    username = (username or "").strip().lower()
    if not USERNAME_RE.match(username):
        raise UserError(
            "Usuario invalido. Use de 2 a 32 caracteres: letras minusculas, "
            "numeros, ponto, hifen ou underscore, comecando por letra ou numero."
        )
    return username


def validate_password(password: str, confirm: str = None) -> str:
    password = password or ""
    if len(password) < MIN_PASSWORD_LEN:
        raise UserError(f"A senha precisa ter ao menos {MIN_PASSWORD_LEN} caracteres.")
    if confirm is not None and password != confirm:
        raise UserError("A confirmacao nao confere com a senha.")
    return password


def validate_email(email: str) -> str:
    email = (email or "").strip()
    if email and not EMAIL_RE.match(email):
        raise UserError(f"E-mail invalido: {email!r}")
    return email


# =====================================================================
#  Consultas
# =====================================================================

def list_users() -> list[dict[str, Any]]:
    return db.query_all(
        "SELECT id, username, full_name, email, is_active, is_admin, "
        "       must_change_password, last_login, created_at "
        "FROM users ORDER BY username"
    )


def get_user(user_id: int) -> dict[str, Any] | None:
    return db.query_one(
        "SELECT id, username, full_name, email, is_active, is_admin, "
        "       must_change_password, last_login, created_at "
        "FROM users WHERE id = %s",
        (user_id,),
    )


def count_active_admins(exclude_id: int | None = None) -> int:
    if exclude_id is None:
        row = db.query_one(
            "SELECT COUNT(*) AS n FROM users WHERE is_active = 1 AND is_admin = 1"
        )
    else:
        row = db.query_one(
            "SELECT COUNT(*) AS n FROM users "
            "WHERE is_active = 1 AND is_admin = 1 AND id <> %s",
            (exclude_id,),
        )
    return int((row or {}).get("n", 0))


def _guard_last_admin(user_id: int, action: str) -> None:
    """
    Impede que a ultima conta administrativa ativa seja perdida.

    Sem isso, um clique desatento tranca todo mundo para fora do painel e
    so o console fisico resolve.
    """
    user = get_user(user_id)
    if not user:
        raise UserError("Usuario nao encontrado.")
    if not (user["is_admin"] and user["is_active"]):
        return
    if count_active_admins(exclude_id=user_id) == 0:
        raise UserError(
            f"Nao e possivel {action}: esta e a unica conta de administrador "
            f"ativa. Crie ou reative outro administrador antes."
        )


# =====================================================================
#  Escrita
# =====================================================================

def create_user(username: str, password: str, confirm: str, full_name: str = "",
                email: str = "", is_admin: bool = True, is_active: bool = True,
                must_change: bool = False) -> int:
    username = validate_username(username)
    validate_password(password, confirm)
    email = validate_email(email)

    if db.query_one("SELECT id FROM users WHERE username = %s", (username,)):
        raise UserError(f"O usuario '{username}' ja existe.")

    db.execute(
        "INSERT INTO users "
        "(username, password_hash, full_name, email, is_active, is_admin, "
        " must_change_password) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s)",
        (username, auth.hash_password(password), (full_name or "").strip()[:128],
         email or None, 1 if is_active else 0, 1 if is_admin else 0,
         1 if must_change else 0),
    )

    row = db.query_one("SELECT id FROM users WHERE username = %s", (username,))
    new_id = int((row or {}).get("id", 0))
    log.info("Usuario criado: %s (id=%s)", username, new_id)
    return new_id


def update_user(user_id: int, full_name: str = "", email: str = "",
                is_admin: bool = True, is_active: bool = True,
                must_change: bool = False,
                current_user_id: int | None = None) -> None:
    user = get_user(user_id)
    if not user:
        raise UserError("Usuario nao encontrado.")

    if current_user_id == user_id and not is_active:
        raise UserError("Voce nao pode desativar a sua propria conta.")
    if current_user_id == user_id and not is_admin:
        raise UserError("Voce nao pode remover o seu proprio acesso de administrador.")

    # Se esta tirando privilegio/atividade, confere se sobra algum admin.
    if user["is_admin"] and user["is_active"] and (not is_admin or not is_active):
        if count_active_admins(exclude_id=user_id) == 0:
            raise UserError(
                "Nao e possivel: esta e a unica conta de administrador ativa."
            )

    email = validate_email(email)

    db.execute(
        "UPDATE users SET full_name = %s, email = %s, is_active = %s, "
        "       is_admin = %s, must_change_password = %s "
        "WHERE id = %s",
        ((full_name or "").strip()[:128], email or None,
         1 if is_active else 0, 1 if is_admin else 0,
         1 if must_change else 0, user_id),
    )
    log.info("Usuario atualizado: %s (id=%s)", user["username"], user_id)


def set_password(user_id: int, password: str, confirm: str,
                 must_change: bool = False) -> None:
    user = get_user(user_id)
    if not user:
        raise UserError("Usuario nao encontrado.")

    validate_password(password, confirm)

    db.execute(
        "UPDATE users SET password_hash = %s, must_change_password = %s "
        "WHERE id = %s",
        (auth.hash_password(password), 1 if must_change else 0, user_id),
    )
    log.info("Senha redefinida para %s (id=%s)", user["username"], user_id)


def toggle_active(user_id: int, current_user_id: int | None = None) -> bool:
    user = get_user(user_id)
    if not user:
        raise UserError("Usuario nao encontrado.")
    if current_user_id == user_id:
        raise UserError("Voce nao pode desativar a sua propria conta.")

    new_state = 0 if user["is_active"] else 1
    if new_state == 0:
        _guard_last_admin(user_id, "desativar")

    db.execute("UPDATE users SET is_active = %s WHERE id = %s", (new_state, user_id))
    log.info("Usuario %s %s", user["username"], "ativado" if new_state else "desativado")
    return bool(new_state)


def delete_user(user_id: int, current_user_id: int | None = None) -> str:
    user = get_user(user_id)
    if not user:
        raise UserError("Usuario nao encontrado.")
    if current_user_id == user_id:
        raise UserError("Voce nao pode excluir a sua propria conta.")

    _guard_last_admin(user_id, "excluir")

    db.execute("DELETE FROM users WHERE id = %s", (user_id,))
    log.info("Usuario excluido: %s (id=%s)", user["username"], user_id)
    return user["username"]
