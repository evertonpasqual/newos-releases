-- =====================================================================
--  NewOS Panel - esquema do banco de dados (MariaDB)
-- ---------------------------------------------------------------------
--  Aplicado uma unica vez, no PRIMEIRO BOOT do servidor, por
--  /usr/local/lib/newos/firstboot.d/20-panel-database.sh
--
--  Nao pode rodar durante o build da ISO porque o MariaDB precisa
--  estar em execucao, e dentro do chroot nenhum servico sobe.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Usuarios do painel
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username             VARCHAR(64)  NOT NULL,
    password_hash        VARCHAR(255) NOT NULL,     -- bcrypt
    full_name            VARCHAR(128) DEFAULT NULL,
    email                VARCHAR(190) DEFAULT NULL,
    is_active            TINYINT(1)   NOT NULL DEFAULT 1,
    is_admin             TINYINT(1)   NOT NULL DEFAULT 1,
    must_change_password TINYINT(1)   NOT NULL DEFAULT 0,
    last_login           DATETIME     DEFAULT NULL,
    created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                      ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Trilha de auditoria: quem mudou o que, e de onde
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    username   VARCHAR(64)  NOT NULL,
    action     VARCHAR(64)  NOT NULL,    -- login, logout, rede, vlan, senha
    detail     TEXT         DEFAULT NULL,
    source_ip  VARCHAR(45)  DEFAULT NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_audit_created (created_at),
    KEY idx_audit_user (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Configuracoes livres do painel (chave/valor)
--  Reservado para a fase 3. Ja criado para nao precisar de migracao.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
    setting_key   VARCHAR(64)  NOT NULL,
    setting_value TEXT         DEFAULT NULL,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO settings (setting_key, setting_value)
VALUES ('schema_version', '1');

-- ---------------------------------------------------------------------
-- Modulos: software opcional que o administrador liga e desliga pela web
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS modules (
    module_key   VARCHAR(48)  NOT NULL,
    installed    TINYINT(1)   NOT NULL DEFAULT 0,  -- pacotes ja instalados
    enabled      TINYINT(1)   NOT NULL DEFAULT 0,  -- modulo ligado
    version      VARCHAR(32)  DEFAULT NULL,
    last_error   TEXT         DEFAULT NULL,
    installed_at DATETIME     DEFAULT NULL,
    updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (module_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Componentes de um modulo (ex.: zabbix -> agent2, proxy)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS module_components (
    module_key    VARCHAR(48) NOT NULL,
    component_key VARCHAR(48) NOT NULL,
    enabled       TINYINT(1)  NOT NULL DEFAULT 0,
    updated_at    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (module_key, component_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- v3: tema da interface por usuario (identidade NewIO: claro / escuro)
--   ADD COLUMN IF NOT EXISTS: seguro de reaplicar em bancos ja criados.
-- ---------------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS theme VARCHAR(8) NOT NULL DEFAULT 'light'
    AFTER must_change_password;

UPDATE settings SET setting_value = '3' WHERE setting_key = 'schema_version';
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES ('schema_version', '3');

-- ---------------------------------------------------------------------
-- v4: modulo Backup - restauracoes para baixar pelo navegador
--   O Bareos restaura numa area temporaria do servidor; quando termina,
--   o painel empacota em ZIP. O token vence (padrao 24 h) e o ZIP some.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backup_restores (
    token         CHAR(32)     NOT NULL,
    jobid         INT UNSIGNED NOT NULL,          -- backup de origem
    restore_jobid INT UNSIGNED DEFAULT NULL,      -- job de restauracao
    client        VARCHAR(128) NOT NULL,
    label         VARCHAR(255) NOT NULL DEFAULT '',
    status        VARCHAR(16)  NOT NULL DEFAULT 'restoring',
    message       VARCHAR(255) DEFAULT NULL,
    files         INT UNSIGNED DEFAULT NULL,
    size          BIGINT UNSIGNED DEFAULT NULL,
    created_by    VARCHAR(64)  NOT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at    DATETIME     NOT NULL,
    PRIMARY KEY (token),
    KEY idx_backup_restores_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Selecao de arquivos/pastas de uma restauracao em andamento (por sessao).
-- Fica no banco e nao no cookie: o cookie de sessao tem ~4 KB.
CREATE TABLE IF NOT EXISTS backup_selections (
    sel_id     CHAR(32)    NOT NULL,
    username   VARCHAR(64) NOT NULL,
    data       MEDIUMTEXT  NOT NULL,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sel_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE settings SET setting_value = '4' WHERE setting_key = 'schema_version';
