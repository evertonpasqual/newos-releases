"""
NewOS Panel - aplicacao FastAPI.

Servido pelo uvicorn em 127.0.0.1:8081 e publicado pelo nginx na porta
configurada em PANEL_HTTP_PORT (81 por padrao).

Rotas:
    GET  /                      -> redireciona
    GET  /login   POST /login   -> autenticacao
    GET  /logout
    GET  /dashboard             -> CPU, memoria, disco
    GET  /api/stats             -> JSON consumido pelo dashboard

    Configuracoes > Network
    GET/POST /configuracoes/network/rede    -> IP, mascara, gateway, DNS
    GET      /configuracoes/network/vlan    -> VLANs 802.1Q
        POST /configuracoes/network/vlan/{criar,remover}
    GET      /configuracoes/network/rotas   -> rotas estaticas
        POST /configuracoes/network/rotas/{adicionar,remover}

    Usuarios > Contas
    GET      /usuarios/contas               -> lista
    GET/POST /usuarios/contas/nova          -> criar
    GET/POST /usuarios/contas/{id}          -> editar
        POST /usuarios/contas/{id}/{senha,alternar,excluir}

    GET/POST /minha-conta       -> trocar a propria senha
"""

from __future__ import annotations

import json
import logging
import socket
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from markupsafe import Markup
from starlette.concurrency import run_in_threadpool
from starlette.middleware.sessions import SessionMiddleware
from starlette.status import HTTP_303_SEE_OTHER

from . import auth, backup_routes, benchmark_routes, db, monitoring_routes, system_routes, sysbackup_routes, firewall_routes, terminal, terminal_routes, traffic_routes, updates, updates_routes, metrics, mfa, modules, netcfg, storage, users
from .config import get_settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("newos.panel")

settings = get_settings()
BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title=f"{settings.os_name} Panel",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.session_secret,
    max_age=settings.session_max_age,
    same_site="lax",
    https_only=False,          # a fase 1 e HTTP puro, como combinado
    session_cookie="newos_panel",
)

app.mount(
    "/static",
    StaticFiles(directory=str(BASE_DIR / "static")),
    name="static",
)

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def _asset_version() -> str:
    """
    Versao dos arquivos estaticos, usada como ?v= nas URLs.

    O nginx manda o navegador guardar /static/ por 1 hora. Sem isto, depois
    de uma atualizacao do painel (update-panel.sh, sem ISO) o navegador
    misturava HTML novo com CSS antigo. A versao muda sempre que qualquer
    arquivo de static/ muda.
    """
    newest = 0.0
    for path in (BASE_DIR / "static").rglob("*"):
        if path.is_file():
            newest = max(newest, path.stat().st_mtime)
    return str(int(newest))


ASSET_VERSION = _asset_version()
templates.env.filters["human_bytes"] = metrics.human_bytes
templates.env.filters["num"] = metrics.num


def _fmt_ts(value: Any, fmt: str = "%d/%m/%Y %H:%M") -> str:
    """Timestamp (segundos) -> data local; vazio vira travessao."""
    if not value:
        return "—"
    try:
        return datetime.fromtimestamp(float(value)).strftime(fmt)
    except (TypeError, ValueError, OSError):
        return "—"


def _fmt_duration(value: Any) -> str:
    """Segundos -> '2 h 05 min', '3 min 12 s', '40 s'."""
    if value is None or value == "":
        return "—"
    s = int(float(value))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h} h {m:02d} min"
    if m:
        return f"{m} min {sec:02d} s"
    return f"{sec} s"


templates.env.filters["ts"] = _fmt_ts
templates.env.filters["dur"] = _fmt_duration
templates.env.filters["md"] = lambda t: Markup(updates.md_to_html(t))


# =====================================================================
#  Helpers
# =====================================================================

def render(request: Request, template: str, **context: Any) -> HTMLResponse:
    """Renderiza um template ja com o contexto comum a todas as paginas."""
    user = auth.current_user(request)
    base = {
        "request": request,
        "user": user,
        # Tema do usuario (claro/escuro), lido da sessao: ver /api/tema.
        "theme": (user or {}).get("theme", "light"),
        "hostname": socket.gethostname(),
        "v": ASSET_VERSION,
        "os_name": settings.os_name,
        "os_version": settings.os_version,
        "vendor": settings.vendor,
        "color_bg": settings.color_bg,
        "color_accent": settings.color_accent,
        "flash": request.session.pop("flash", None),
        "allow_network_config": settings.allow_network_config,
        "panel_port": settings.http_port,
        # Secoes de menu contribuidas pelos modulos LIGADOS.
        # Falha aqui nao pode derrubar a pagina inteira.
        "nav_modules": _safe_nav_modules(),
        # Alteracao de rede aguardando confirmacao (faixa no topo).
        "net_pending": netcfg.pending() if user else None,
        "fw_pending": firewall_routes.pending() if user else None,
        # Sessao inativa: o navegador avisa um minuto antes de encerrar.
        "idle_seconds": auth.idle_minutes() * 60 if user else 0,
        # Versao nova no repositorio de releases (faixa no topo).
        "update_info": updates.cached() if user else {},
    }
    base.update(context)
    return templates.TemplateResponse(template, base)


def _safe_nav_modules() -> list[dict[str, Any]]:
    """Menu dos modulos. Se o banco cair, o painel continua navegavel."""
    try:
        return modules.active_menu()
    except Exception as exc:  # noqa: BLE001
        log.warning("Nao foi possivel montar o menu dos modulos: %s", exc)
        return []


def flash(request: Request, kind: str, message: str) -> None:
    """Mensagem exibida uma unica vez na proxima pagina. kind: ok|erro|aviso"""
    request.session["flash"] = {"kind": kind, "message": message}


def require_login(request: Request) -> dict[str, Any] | None:
    return auth.current_user(request)


def redirect(url: str) -> RedirectResponse:
    return RedirectResponse(url=url, status_code=HTTP_303_SEE_OTHER)


# Sistema > Servidor (hostname, dominio, /etc/hosts).
system_routes.register(app, render=lambda *a, **k: render(*a, **k),
                       flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))

# Sistema > Terminal (como o do Cockpit; so administradores).
terminal_routes.register(app, render=lambda *a, **k: render(*a, **k),
                         flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))
benchmark_routes.register(app, render=lambda *a, **k: render(*a, **k),
                         flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))
traffic_routes.register(app, render=lambda *a, **k: render(*a, **k),
                         flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))

# Modulo Firewall (nftables).
firewall_routes.register(app, render=lambda *a, **k: render(*a, **k),
                         flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))

# Sistema > Backup e restauracao (do proprio NewOS).
sysbackup_routes.register(app, render=lambda *a, **k: render(*a, **k),
                          flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))

# Sistema > Atualizacoes (versao nova sem ISO, pacote assinado).
updates_routes.register(app, render=lambda *a, **k: render(*a, **k),
                        flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))

# Telas do modulo Backup (Bareos): so respondem com o modulo ligado.
backup_routes.register(app, render=lambda *a, **k: render(*a, **k),
                       flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))


# =====================================================================
#  Autenticacao
# =====================================================================

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    if require_login(request):
        return redirect("/dashboard")
    return redirect("/login")


@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    if require_login(request):
        return redirect("/dashboard")
    expired = request.session.pop("expired", None) or request.query_params.get("motivo") == "inatividade"
    return render(request, "login.html", notice=(
        f"Sessão encerrada por inatividade ({auth.idle_minutes()} min sem uso). Entre de novo." if expired else None))


@app.get("/api/sessao")
async def api_session_left(request: Request):
    """Quanto falta (sem renovar): outra aba pode estar sendo usada."""
    if not auth.current_user(request):
        return JSONResponse({"ok": False, "expired": True}, status_code=401)
    left = auth.idle_minutes() * 60 - (int(time.time()) - int(request.session.get("seen") or time.time()))
    return {"ok": True, "left": max(0, left)}


@app.post("/api/sessao/ativo")
async def api_session_alive(request: Request):
    """O navegador avisa que a pessoa esta usando a tela (mouse, teclado)."""
    if not auth.current_user(request):
        return JSONResponse({"ok": False, "expired": True}, status_code=401)
    return {"ok": True, "idle": auth.idle_minutes() * 60}


@app.post("/usuarios/sessao", response_class=HTMLResponse)
async def users_session_policy(request: Request, minutos: str = Form("15")):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        m = await run_in_threadpool(auth.set_idle_minutes, int(minutos))
        db.log_audit(user["username"], "sessao", f"Sessao inativa expira em {m} min", auth.client_ip(request))
        flash(request, "ok", f"Sessões sem uso por {m} minutos são encerradas.")
    except ValueError:
        flash(request, "erro", "Informe os minutos.")
    return redirect("/usuarios/contas#sessao")


@app.post("/login", response_class=HTMLResponse)
async def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    ip = auth.client_ip(request)

    locked = auth.is_locked_out(ip)
    if locked:
        return render(
            request, "login.html",
            error=f"Muitas tentativas. Tente novamente em {locked} segundos.",
        )

    try:
        user = auth.authenticate(username.strip(), password)
    except db.DatabaseUnavailable as exc:
        log.error("Login indisponivel: %s", exc)
        return render(
            request, "login.html",
            error="Banco de dados indisponivel. Verifique o servico mariadb.",
        )

    if not user:
        auth.register_failure(ip)
        log.warning("Login negado para %r vindo de %s", username, ip)
        return render(request, "login.html", error="Usuario ou senha invalidos.")

    auth.clear_failures(ip)
    # Verificacao em duas etapas: a senha certa so leva ao codigo do app.
    if mfa.status(user["id"])["enabled"]:
        request.session["mfa_pending"] = {"id": user["id"], "username": user["username"],
                                          "full_name": user.get("full_name") or user["username"],
                                          "ts": int(time.time())}
        return redirect("/login/mfa")
    request.session["seen"] = int(time.time())
    request.session["user"] = {
        "id": user["id"],
        "username": user["username"],
        "full_name": user.get("full_name") or user["username"],
        "theme": auth.get_theme(user["id"]),
    }
    db.log_audit(user["username"], "login", "Login efetuado", ip)
    log.info("Login de %s a partir de %s", user["username"], ip)
    return redirect("/dashboard")


MFA_LOGIN_TTL = 300      # segundos para digitar o codigo depois da senha


def _mfa_pending(request: Request) -> dict[str, Any] | None:
    p = request.session.get("mfa_pending")
    if not isinstance(p, dict) or int(time.time()) - int(p.get("ts", 0)) > MFA_LOGIN_TTL:
        request.session.pop("mfa_pending", None)
        return None
    return p


@app.get("/login/mfa", response_class=HTMLResponse)
async def login_mfa_form(request: Request):
    p = _mfa_pending(request)
    if not p:
        return redirect("/login")
    return render(request, "login_mfa.html", pending_user=p["username"])


@app.post("/login/mfa", response_class=HTMLResponse)
async def login_mfa_submit(request: Request, code: str = Form("")):
    p = _mfa_pending(request)
    if not p:
        return render(request, "login.html", error="Tempo esgotado: entre de novo com usuario e senha.")
    ip = auth.client_ip(request)
    locked = auth.is_locked_out(ip)
    if locked:
        return render(request, "login_mfa.html", pending_user=p["username"],
                      error=f"Muitas tentativas. Tente novamente em {locked} segundos.")
    how = await run_in_threadpool(mfa.verify_user, p["id"], code)
    if not how:
        auth.register_failure(ip)
        log.warning("Codigo MFA errado para %r vindo de %s", p["username"], ip)
        return render(request, "login_mfa.html", pending_user=p["username"], error="Codigo invalido ou ja usado.")
    auth.clear_failures(ip)
    request.session.pop("mfa_pending", None)
    request.session["seen"] = int(time.time())
    request.session["user"] = {"id": p["id"], "username": p["username"], "full_name": p["full_name"],
                               "theme": auth.get_theme(p["id"])}
    db.log_audit(p["username"], "login", "Login efetuado (com MFA" + (": codigo de recuperacao" if how == "recuperacao" else "") + ")", ip)
    if how == "recuperacao":
        left = mfa.status(p["id"])["recovery_left"]
        flash(request, "aviso", f"Voce entrou com um codigo de recuperacao (restam {left}). "
                                "Se perdeu o celular, desative e ative o MFA de novo em Minha conta.")
    return redirect("/dashboard")


@app.get("/logout")
async def logout(request: Request):
    tsid = request.session.get("tsid", "")
    user = auth.current_user(request)
    if user:
        db.log_audit(user["username"], "logout", "Sessao encerrada",
                     auth.client_ip(request))
    terminal.close_session(tsid)        # fecha os terminais deste navegador (os outros seguem)
    request.session.clear()
    if request.query_params.get("motivo") == "inatividade":
        return redirect("/login?motivo=inatividade")
    return redirect("/login")


# =====================================================================
#  Tema (claro / escuro) do usuario logado
# =====================================================================

@app.post("/api/tema")
async def api_theme(request: Request):
    """Grava o tema escolhido no interruptor da barra superior."""
    user = require_login(request)
    if not user:
        return JSONResponse({"ok": False, "message": "nao autenticado"},
                            status_code=401)

    body = await request.json()
    theme = "dark" if body.get("tema") == "dark" else "light"

    auth.set_theme(user["id"], theme)
    user["theme"] = theme
    request.session["user"] = user
    return JSONResponse({"ok": True, "tema": theme})


# =====================================================================
#  Dashboard
# =====================================================================

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    if not require_login(request):
        return redirect("/login")

    db_ok, db_version = db.healthcheck()

    # Nome e funcao de cada interface (Network > Interfaces). Se o helper
    # de rede falhar, o dashboard continua, so sem os nomes.
    net_names = {}
    for name, cfg in netcfg.state().get("interfaces", {}).items():
        net_names[name] = {"alias": cfg.get("alias", ""), "role": cfg.get("role", ""),
                           "role_label": netcfg.ROLES.get(cfg.get("role", ""), "")}

    return render(
        request, "dashboard.html",
        stats=metrics.collect_all(),
        disks=storage.disks(),
        net_names=net_names,
        db_ok=db_ok,
        db_version=db_version,
    )


@app.get("/api/stats")
async def api_stats(request: Request):
    if not require_login(request):
        return JSONResponse({"error": "nao autenticado"}, status_code=401)
    return JSONResponse(metrics.collect_all())


# =====================================================================
#  Armazenamento
# =====================================================================

@app.get("/armazenamento", response_class=HTMLResponse)
async def storage_page(request: Request):
    if not require_login(request):
        return redirect("/login")
    return render(request, "storage.html", st=storage.overview(), tree=storage.flatten)


STORAGE_ACTIONS = {"disk-init", "part-create", "part-delete", "part-grow", "format", "wipe",
                   "vg-create", "vg-extend", "vg-remove", "lv-create", "lv-extend", "lv-remove",
                   "zpool-create", "zpool-destroy", "zfs-create", "zfs-destroy",
                   "mount", "umount", "zfs-mount", "zfs-umount"}


@app.post("/armazenamento/{action}", response_class=HTMLResponse)
async def storage_action(request: Request, action: str):
    """
    Operacao de disco. Pode demorar (formatar um disco grande, LVM): roda
    numa thread para nao travar o painel inteiro enquanto isso.
    """
    user = require_login(request)
    if not user:
        return redirect("/login")
    if action not in STORAGE_ACTIONS:
        flash(request, "erro", "Operacao de disco desconhecida.")
        return redirect("/armazenamento")
    raw = await request.form()
    form: dict[str, Any] = {k: str(v) for k, v in raw.items() if k != "devices"}
    form["devices"] = [str(v) for v in raw.getlist("devices")]
    try:
        result = await run_in_threadpool(storage.act, action, form)
        detail = result.get("message", "")
        db.log_audit(user["username"], "disco", f"{action}: {detail}", auth.client_ip(request))
        log.info("Disco (%s) por %s: %s", action, user["username"], detail)
        flash(request, "ok", detail)
    except storage.StorageError as exc:
        flash(request, "erro", str(exc))
        log.warning("Falha em disco (%s): %s", action, exc)
    except KeyError as exc:
        flash(request, "erro", f"Campo obrigatorio ausente: {exc}")
    return redirect("/armazenamento")


# =====================================================================
#  Configuracoes -> Network
#
#  Toda alteracao vai para o helper com --safe: ela vale na hora, mas
#  precisa ser CONFIRMADA em ate 2 minutos (faixa no topo de todas as
#  paginas). Se o acesso cair -- IP errado, bond na placa errada -- a
#  rede volta sozinha ao que era.
# =====================================================================

NET_BASE = "/configuracoes/network"


def _net_done(request: Request, user: dict[str, Any], kind: str,
              result: dict[str, Any], back: str) -> RedirectResponse:
    """Registra a alteracao e avisa que ela precisa de confirmacao."""
    detail = result.get("message", "")
    db.log_audit(user["username"], kind, detail, auth.client_ip(request))
    log.info("Rede (%s) por %s: %s", kind, user["username"], detail)
    if result.get("pending"):
        flash(request, "aviso",
              f"Aplicado: {detail}. Confira se esta tudo certo e clique em "
              f"Confirmar na faixa acima. Sem confirmacao em "
              f"{result.get('seconds', 120)} segundos, a configuracao anterior volta sozinha.")
    else:
        flash(request, "ok", detail)
    return redirect(back)


def _net_fail(request: Request, exc: Exception, back: str) -> RedirectResponse:
    flash(request, "erro", str(exc))
    log.warning("Falha na rede: %s", exc)
    return redirect(back)


async def _form(request: Request) -> dict[str, str]:
    form = await request.form()
    return {k: str(v) for k, v in form.items()}


@app.get(f"{NET_BASE}/rede", response_class=HTMLResponse)
async def network_interfaces(request: Request):
    """Lista de todas as interfaces (fisicas, bonds e VLANs)."""
    if not require_login(request):
        return redirect("/login")
    return render(request, "settings_network.html", net=netcfg.overview())


@app.get(f"{NET_BASE}/interface/{{name}}", response_class=HTMLResponse)
async def network_interface_form(request: Request, name: str):
    if not require_login(request):
        return redirect("/login")
    net = netcfg.overview()
    nic = net["by_name"].get(name)
    if not nic:
        flash(request, "erro", f"A interface {name} nao existe.")
        return redirect(f"{NET_BASE}/rede")
    if nic["member_of"]:
        flash(request, "aviso", f"{name} faz parte do {nic['member_of']}: "
                                f"o endereco e configurado no bond.")
        return redirect(f"{NET_BASE}/bond?editar={nic['member_of']}")
    return render(request, "settings_interface.html", net=net, nic=nic,
                  roles=netcfg.ROLES)


@app.post(f"{NET_BASE}/interface/{{name}}", response_class=HTMLResponse)
async def network_interface_save(request: Request, name: str):
    user = require_login(request)
    if not user:
        return redirect("/login")
    back = f"{NET_BASE}/interface/{name}"
    form = await _form(request)
    form["name"] = name
    try:
        if form.get("kind") == "vlan":
            nic = netcfg.overview()["by_name"].get(name) or {}
            vlan = nic.get("vlan") or {}
            form.update({"parent": vlan.get("parent", ""), "vlan_id": str(vlan.get("id", ""))})
            result = netcfg.set_vlan(form)
        else:
            result = netcfg.set_interface(form)
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, back)
    return _net_done(request, user, "rede", result, f"{NET_BASE}/rede")


@app.post(f"{NET_BASE}/interface/{{name}}/remover", response_class=HTMLResponse)
async def network_interface_delete(request: Request, name: str):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.delete_interface(name)
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, f"{NET_BASE}/rede")
    return _net_done(request, user, "rede", result, f"{NET_BASE}/rede")


# --- Bonds -----------------------------------------------------------

@app.get(f"{NET_BASE}/bond", response_class=HTMLResponse)
async def network_bonds(request: Request, editar: str = ""):
    if not require_login(request):
        return redirect("/login")
    net = netcfg.overview()
    editing = net["by_name"].get(editar) if editar else None
    if editing and editing["kind"] != "bond":
        editing = None
    used = {b["name"] for b in net["bonds"]}
    next_name = next(f"bond{i}" for i in range(0, 1000) if f"bond{i}" not in used)
    return render(request, "settings_bond.html", net=net, editing=editing,
                  next_name=next_name, bond_modes=netcfg.BOND_MODES,
                  hash_policies=netcfg.HASH_POLICIES, roles=netcfg.ROLES)


@app.post(f"{NET_BASE}/bond", response_class=HTMLResponse)
async def network_bond_save(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    raw = await request.form()
    members = [str(v) for v in raw.getlist("members")]
    form = {k: str(v) for k, v in raw.items() if k != "members"}
    back = f"{NET_BASE}/bond" + (f"?editar={form.get('name')}" if form.get("editing") else "")
    try:
        result = netcfg.set_bond(form, members)
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, back)
    return _net_done(request, user, "bond", result, f"{NET_BASE}/bond")


# --- VLANs -----------------------------------------------------------

@app.get(f"{NET_BASE}/vlan", response_class=HTMLResponse)
async def network_vlans(request: Request):
    if not require_login(request):
        return redirect("/login")
    return render(request, "settings_vlan.html", net=netcfg.overview(),
                  roles=netcfg.ROLES)


@app.post(f"{NET_BASE}/vlan/criar", response_class=HTMLResponse)
async def network_vlan_create(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.set_vlan(await _form(request))
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, f"{NET_BASE}/vlan")
    return _net_done(request, user, "vlan", result, f"{NET_BASE}/vlan")


@app.post(f"{NET_BASE}/vlan/remover", response_class=HTMLResponse)
async def network_vlan_delete(request: Request, name: str = Form(...)):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.delete_interface(name)
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, f"{NET_BASE}/vlan")
    return _net_done(request, user, "vlan", result, f"{NET_BASE}/vlan")


# --- Rotas -----------------------------------------------------------

@app.get(f"{NET_BASE}/rotas", response_class=HTMLResponse)
async def network_routes(request: Request):
    if not require_login(request):
        return redirect("/login")
    return render(request, "settings_routes.html", net=netcfg.overview())


@app.post(f"{NET_BASE}/rotas/adicionar", response_class=HTMLResponse)
async def network_route_add(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.add_route(await _form(request))
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, f"{NET_BASE}/rotas")
    return _net_done(request, user, "rota", result, f"{NET_BASE}/rotas")


@app.post(f"{NET_BASE}/rotas/remover", response_class=HTMLResponse)
async def network_route_delete(request: Request, destination: str = Form(...)):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.delete_route(destination)
    except netcfg.NetworkError as exc:
        return _net_fail(request, exc, f"{NET_BASE}/rotas")
    return _net_done(request, user, "rota", result, f"{NET_BASE}/rotas")


# --- Confirmar / desfazer -------------------------------------------

@app.post(f"{NET_BASE}/confirmar", response_class=HTMLResponse)
async def network_confirm(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    back = request.headers.get("referer") or f"{NET_BASE}/rede"
    try:
        result = netcfg.confirm()
        db.log_audit(user["username"], "rede", "alteracao confirmada", auth.client_ip(request))
        flash(request, "ok", result.get("message", "Configuracao confirmada."))
    except netcfg.NetworkError as exc:
        flash(request, "erro", str(exc))
    return redirect(back)


@app.post(f"{NET_BASE}/desfazer", response_class=HTMLResponse)
async def network_undo(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    try:
        result = netcfg.rollback()
        db.log_audit(user["username"], "rede", "alteracao desfeita", auth.client_ip(request))
        flash(request, "ok", result.get("message", "Configuracao anterior restaurada."))
    except netcfg.NetworkError as exc:
        flash(request, "erro", str(exc))
    return redirect(f"{NET_BASE}/rede")


@app.get("/api/network/pending")
async def api_network_pending(request: Request):
    """Contagem regressiva da faixa de confirmacao (consultada pelo JS)."""
    if not require_login(request):
        return JSONResponse({"error": "nao autenticado"}, status_code=401)
    return JSONResponse(netcfg.pending() or {"pending": False})


# =====================================================================
#  Usuarios -> Contas
# =====================================================================

@app.get("/usuarios/contas", response_class=HTMLResponse)
async def users_list(request: Request):
    if not require_login(request):
        return redirect("/login")
    try:
        rows = users.list_users()
    except db.DatabaseUnavailable as exc:
        flash(request, "erro", f"Banco indisponivel: {exc}")
        rows = []
    me = auth.current_user(request)
    admin = await run_in_threadpool(terminal_routes.is_admin, me) if me else False
    unix: list[dict] = []
    if admin:
        try:
            unix = (await run_in_threadpool(system_routes.helper, ["unix-users"])).get("users", [])
        except system_routes.SystemError_ as exc:
            flash(request, "erro", str(exc))
    return render(request, "users_list.html", users=rows, idle_minutes=auth.idle_minutes(),
                  admin=admin, unix=unix)


@app.post("/usuarios/linux/senha", response_class=HTMLResponse)
async def unix_password(request: Request):
    """Senha do root e do usuario do NewOS (console e SSH): so administrador,
    confirmando a propria senha do painel."""
    me = auth.current_user(request)
    if not me:
        return redirect("/login")
    back = "/usuarios/contas#linux"
    if not await run_in_threadpool(terminal_routes.is_admin, me):
        flash(request, "erro", "Só administradores trocam a senha das contas do Linux.")
        return redirect(back)
    f = await request.form()
    ip = auth.client_ip(request)
    if auth.is_locked_out(ip):
        flash(request, "erro", "Muitas tentativas. Aguarde alguns minutos.")
        return redirect(back)
    if not await run_in_threadpool(auth.authenticate, me["username"], str(f.get("current", ""))):
        auth.register_failure(ip)
        flash(request, "erro", "Sua senha do painel não confere.")
        return redirect(back)
    auth.clear_failures(ip)
    name, pw, pw2 = str(f.get("user", "")), str(f.get("password", "")), str(f.get("password2", ""))
    if pw != pw2:
        flash(request, "erro", "As duas senhas não são iguais.")
        return redirect(back)
    try:
        res = await run_in_threadpool(system_routes.helper, ["unix-password"], {"user": name, "password": pw})
        db.log_audit(me["username"], "usuario", f"trocou a senha do usuario Linux {name}", ip)
        flash(request, "ok", res["message"])
    except system_routes.SystemError_ as exc:
        flash(request, "erro", str(exc))
    return redirect(back)


@app.get("/usuarios/contas/nova", response_class=HTMLResponse)
async def user_new_form(request: Request):
    if not require_login(request):
        return redirect("/login")
    return render(request, "user_form.html", is_new=True, edit_user=None)


@app.post("/usuarios/contas/nova", response_class=HTMLResponse)
async def user_new_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    confirm: str = Form(...),
    full_name: str = Form(""),
    email: str = Form(""),
    is_admin: str = Form(""),
    is_active: str = Form(""),
    must_change: str = Form(""),
):
    me = require_login(request)
    if not me:
        return redirect("/login")

    try:
        users.create_user(
            username, password, confirm, full_name, email,
            is_admin=bool(is_admin), is_active=bool(is_active),
            must_change=bool(must_change),
        )
        db.log_audit(me["username"], "usuario", f"criou {username}",
                     auth.client_ip(request))
        flash(request, "ok", f"Conta '{username}' criada.")
        return redirect("/usuarios/contas")
    except users.UserError as exc:
        flash(request, "erro", str(exc))
        return redirect("/usuarios/contas/nova")


@app.get("/usuarios/contas/{user_id}", response_class=HTMLResponse)
async def user_edit_form(request: Request, user_id: int):
    if not require_login(request):
        return redirect("/login")

    row = users.get_user(user_id)
    if not row:
        flash(request, "erro", "Conta nao encontrada.")
        return redirect("/usuarios/contas")

    return render(request, "user_form.html", is_new=False, edit_user=row)


@app.post("/usuarios/contas/{user_id}", response_class=HTMLResponse)
async def user_edit_submit(
    request: Request,
    user_id: int,
    full_name: str = Form(""),
    email: str = Form(""),
    is_admin: str = Form(""),
    is_active: str = Form(""),
    must_change: str = Form(""),
):
    me = require_login(request)
    if not me:
        return redirect("/login")

    try:
        users.update_user(
            user_id, full_name, email,
            is_admin=bool(is_admin), is_active=bool(is_active),
            must_change=bool(must_change), current_user_id=me["id"],
        )
        db.log_audit(me["username"], "usuario", f"editou id={user_id}",
                     auth.client_ip(request))
        flash(request, "ok", "Conta atualizada.")
    except users.UserError as exc:
        flash(request, "erro", str(exc))

    return redirect(f"/usuarios/contas/{user_id}")


@app.post("/usuarios/contas/{user_id}/senha", response_class=HTMLResponse)
async def user_set_password(
    request: Request,
    user_id: int,
    password: str = Form(...),
    confirm: str = Form(...),
    must_change: str = Form(""),
):
    me = require_login(request)
    if not me:
        return redirect("/login")

    try:
        users.set_password(user_id, password, confirm, bool(must_change))
        db.log_audit(me["username"], "usuario", f"redefiniu senha id={user_id}",
                     auth.client_ip(request))
        flash(request, "ok", "Senha redefinida.")
    except users.UserError as exc:
        flash(request, "erro", str(exc))

    return redirect(f"/usuarios/contas/{user_id}")


@app.post("/usuarios/contas/{user_id}/alternar", response_class=HTMLResponse)
async def user_toggle(request: Request, user_id: int):
    me = require_login(request)
    if not me:
        return redirect("/login")

    try:
        now_active = users.toggle_active(user_id, current_user_id=me["id"])
        db.log_audit(me["username"], "usuario",
                     f"{'ativou' if now_active else 'desativou'} id={user_id}",
                     auth.client_ip(request))
        flash(request, "ok", f"Conta {'ativada' if now_active else 'desativada'}.")
    except users.UserError as exc:
        flash(request, "erro", str(exc))

    return redirect("/usuarios/contas")


@app.post("/usuarios/contas/{user_id}/mfa-desativar", response_class=HTMLResponse)
async def users_mfa_reset(request: Request, user_id: int):
    user = require_login(request)
    if not user:
        return redirect("/login")
    target = users.get_user(user_id)
    if not target:
        return redirect("/usuarios/contas")
    await run_in_threadpool(mfa.disable, user_id)
    db.log_audit(user["username"], "mfa", f"Desativou o MFA de {target['username']}", auth.client_ip(request))
    flash(request, "aviso", f"MFA de {target['username']} desativado: no proximo login ele entra so com a senha "
                            "e pode ativar de novo em Minha conta.")
    return redirect(f"/usuarios/contas/{user_id}")


@app.post("/usuarios/contas/{user_id}/excluir", response_class=HTMLResponse)
async def user_delete(request: Request, user_id: int):
    me = require_login(request)
    if not me:
        return redirect("/login")

    try:
        username = users.delete_user(user_id, current_user_id=me["id"])
        db.log_audit(me["username"], "usuario", f"excluiu {username}",
                     auth.client_ip(request))
        flash(request, "ok", f"Conta '{username}' excluida.")
    except users.UserError as exc:
        flash(request, "erro", str(exc))

    return redirect("/usuarios/contas")


# =====================================================================
#  Minha conta
# =====================================================================

@app.get("/minha-conta", response_class=HTMLResponse)
async def account_form(request: Request):
    user = require_login(request)
    if not user:
        return redirect("/login")
    st = await run_in_threadpool(mfa.status, user["id"])
    setup = None
    secret = request.session.get("mfa_setup")
    if secret and not st["enabled"]:
        u = mfa.uri(secret, user["username"])
        setup = {"qr": mfa.qr_svg(u), "secret": mfa.pretty(secret), "uri": u}
    codes = request.session.pop("mfa_codes", None)
    return render(request, "my_account.html", mfa_st=st, mfa_setup=setup, mfa_codes=codes)


@app.post("/minha-conta/mfa/{acao}", response_class=HTMLResponse)
async def account_mfa(request: Request, acao: str):
    user = require_login(request)
    if not user:
        return redirect("/login")
    form = await request.form()
    code, password = str(form.get("code", "")), str(form.get("password", ""))
    st = await run_in_threadpool(mfa.status, user["id"])
    ip = auth.client_ip(request)
    if acao == "iniciar" and not st["enabled"]:
        request.session["mfa_setup"] = mfa.new_secret()
    elif acao == "cancelar":
        request.session.pop("mfa_setup", None)
    elif acao == "ativar" and not st["enabled"]:
        secret = request.session.get("mfa_setup")
        step = mfa.check(secret, code) if secret else None
        if step is None:
            flash(request, "erro", "Codigo nao confere. Confira a hora do celular e digite o codigo atual do app.")
        else:
            codes = await run_in_threadpool(mfa.enable, user["id"], secret, step)
            request.session.pop("mfa_setup", None)
            request.session["mfa_codes"] = codes
            db.log_audit(user["username"], "mfa", "Verificacao em duas etapas ativada", ip)
            flash(request, "ok", "Verificacao em duas etapas ativada. Guarde os codigos de recuperacao abaixo.")
    elif acao in ("desativar", "recuperacao") and st["enabled"]:
        if not await run_in_threadpool(auth.authenticate, user["username"], password):
            flash(request, "erro", "Senha incorreta.")
        elif not await run_in_threadpool(mfa.verify_user, user["id"], code):
            flash(request, "erro", "Codigo invalido ou ja usado.")
        elif acao == "desativar":
            await run_in_threadpool(mfa.disable, user["id"])
            db.log_audit(user["username"], "mfa", "Verificacao em duas etapas desativada", ip)
            flash(request, "aviso", "Verificacao em duas etapas desativada.")
        else:
            request.session["mfa_codes"] = await run_in_threadpool(mfa.regenerate_recovery, user["id"])
            db.log_audit(user["username"], "mfa", "Novos codigos de recuperacao", ip)
            flash(request, "ok", "Novos codigos de recuperacao gerados (os antigos deixaram de valer).")
    return redirect("/minha-conta#mfa")


@app.post("/minha-conta", response_class=HTMLResponse)
async def account_submit(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
):
    user = require_login(request)
    if not user:
        return redirect("/login")

    if not auth.authenticate(user["username"], current_password):
        flash(request, "erro", "A senha atual esta incorreta.")
    elif new_password != confirm_password:
        flash(request, "erro", "A confirmacao nao confere com a nova senha.")
    elif len(new_password) < 6:
        flash(request, "erro", "A nova senha precisa ter ao menos 6 caracteres.")
    else:
        auth.change_password(user["id"], new_password)
        db.log_audit(user["username"], "senha", "Senha alterada",
                     auth.client_ip(request))
        flash(request, "ok", "Senha alterada com sucesso.")

    return redirect("/minha-conta")


# =====================================================================
#  Modulos
# =====================================================================

@app.get("/modulos", response_class=HTMLResponse)
async def modules_page(request: Request):
    if not require_login(request):
        return redirect("/login")

    try:
        items = modules.list_modules()
    except Exception as exc:  # noqa: BLE001
        flash(request, "erro", f"Nao foi possivel listar os modulos: {exc}")
        items = []

    return render(request, "modules.html",
                  modules=items, apt=modules.apt_health())


@app.post("/api/modules/{module_key}")
async def api_module_toggle(request: Request, module_key: str):
    """Liga ou desliga um modulo. Consumido pelo interruptor da tela."""
    user = require_login(request)
    if not user:
        return JSONResponse({"ok": False, "message": "nao autenticado"},
                            status_code=401)

    body = await request.json()
    want = bool(body.get("enabled"))

    try:
        # Instalar um modulo pode levar minutos (o ZFS compila um modulo do
        # kernel). Numa thread: o painel continua respondendo aos outros.
        if want:
            msg = await run_in_threadpool(modules.enable_module, module_key)
        else:
            msg = await run_in_threadpool(modules.disable_module, module_key)

        db.log_audit(user["username"], "modulo",
                     f"{'ligou' if want else 'desligou'} {module_key}",
                     auth.client_ip(request))
        log.info("Modulo %s %s por %s", module_key,
                 "ligado" if want else "desligado", user["username"])
        return JSONResponse({"ok": True, "message": msg})

    except modules.ModuleError as exc:
        log.warning("Falha no modulo %s: %s", module_key, exc)
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)


@app.post("/api/modules/{module_key}/components/{component_key}")
async def api_component_toggle(request: Request, module_key: str,
                               component_key: str):
    user = require_login(request)
    if not user:
        return JSONResponse({"ok": False, "message": "nao autenticado"},
                            status_code=401)

    body = await request.json()
    want = bool(body.get("enabled"))

    try:
        msg = await run_in_threadpool(modules.set_component, module_key, component_key, want)
        db.log_audit(user["username"], "modulo",
                     f"{'ligou' if want else 'desligou'} {module_key}/{component_key}",
                     auth.client_ip(request))
        return JSONResponse({"ok": True, "message": msg})
    except modules.ModuleError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)


@app.post("/api/apt-repair")
async def api_apt_repair(request: Request):
    """
    Destrava o APT. Um pacote meio-instalado impede QUALQUER instalacao
    no servidor, entao este botao existe para o administrador nao
    precisar do console fisico so por causa disso.
    """
    user = require_login(request)
    if not user:
        return JSONResponse({"ok": False, "message": "nao autenticado"},
                            status_code=401)
    try:
        msg = await run_in_threadpool(modules.apt_repair)
        db.log_audit(user["username"], "apt", "reparo do APT",
                     auth.client_ip(request))
        log.info("APT reparado por %s", user["username"])
        return JSONResponse({"ok": True, "message": msg})
    except modules.ModuleError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)


# =====================================================================
#  Servicos
# =====================================================================

@app.get("/servicos", response_class=HTMLResponse)
async def services_page(request: Request):
    if not require_login(request):
        return redirect("/login")

    try:
        items = modules.list_services()
    except Exception as exc:  # noqa: BLE001
        flash(request, "erro", f"Nao foi possivel listar os servicos: {exc}")
        items = []

    return render(request, "services.html", services=items)


@app.post("/api/servicos/log")
async def api_services_log(request: Request):
    """Log ao vivo dos servicos (journal), a partir do ultimo cursor visto."""
    if not require_login(request):
        return JSONResponse({"ok": False}, status_code=401)
    try:
        body = await request.json()
    except ValueError:
        return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)

    def tail() -> dict[str, Any]:
        proc = subprocess.run(["sudo", "-n", "/usr/local/sbin/newos-journal", "tail"],
                              input=json.dumps({"units": body.get("units") or [], "cursor": body.get("cursor") or "",
                                                "prio": body.get("prio", 7), "lines": body.get("lines", 150)}),
                              capture_output=True, text=True, timeout=40, check=False)
        if proc.returncode != 0:
            return {"ok": False, "message": (proc.stderr.strip().splitlines() or ["falhou"])[-1].removeprefix("ERRO: ")}
        return json.loads(proc.stdout)
    return await run_in_threadpool(tail)


@app.post("/api/services/{service_name}")
async def api_service_action(request: Request, service_name: str):
    user = require_login(request)
    if not user:
        return JSONResponse({"ok": False, "message": "nao autenticado"},
                            status_code=401)

    body = await request.json()
    action = str(body.get("action", ""))

    try:
        msg = await run_in_threadpool(modules.service_action, action, service_name)
        db.log_audit(user["username"], "servico", f"{action} {service_name}",
                     auth.client_ip(request))
        log.info("Servico %s: %s por %s", service_name, action, user["username"])
        return JSONResponse({"ok": True, "message": msg})
    except modules.ModuleError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)


# =====================================================================
#  Monitoramento (Zabbix; Prometheus): ver monitoring_routes.py
# =====================================================================

monitoring_routes.register(app, render=lambda *a, **k: render(*a, **k),
                           flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))
monitoring_routes.register_prometheus(app, render=lambda *a, **k: render(*a, **k),
                                      flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))
monitoring_routes.register_prometheus_alerts(app, render=lambda *a, **k: render(*a, **k),
                                             flash=lambda *a: flash(*a), redirect=lambda u: redirect(u))


# =====================================================================
#  auth_request do nginx
# =====================================================================

@app.get("/api/authcheck")
async def api_authcheck(request: Request):
    """
    Endpoint consultado pelo nginx (auth_request) antes de servir o
    Adminer. Devolve 200 se a sessao do painel e valida, 401 se nao.

    E assim que o Adminer fica atras do mesmo login do painel, sem
    precisar de porta extra exposta na rede.
    """
    if require_login(request):
        return JSONResponse({"ok": True})
    return JSONResponse({"ok": False}, status_code=401)


# =====================================================================
#  Compatibilidade: URLs antigas continuam funcionando
# =====================================================================

@app.get("/configuracoes/rede")
async def _old_rede():
    return redirect("/configuracoes/network/rede")


@app.get("/configuracoes/vlan")
async def _old_vlan():
    return redirect("/configuracoes/network/vlan")


@app.get("/configuracoes/conta")
async def _old_conta():
    return redirect("/minha-conta")


# =====================================================================
#  Saude do servico (usado pelo nginx e por monitoramento)
# =====================================================================

@app.get("/healthz")
async def healthz():
    ok, detail = db.healthcheck()
    return JSONResponse(
        {"status": "ok" if ok else "degraded", "database": detail},
        status_code=200 if ok else 503,
    )
