/* =====================================================================
   NewOS Panel - Troubleshooting
   formulario -> POST /api/troubleshooting/iniciar -> acompanha ao vivo
   Toda saida vem de hosts da rede: sempre escapada (esc).
   ===================================================================== */
(function () {
    "use strict";

    function $(s, el) { return (el || document).querySelector(s); }
    function $$(s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); }
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function num(n, dec) {
        if (n == null || isNaN(n)) return "—";
        return Number(n).toLocaleString("pt-BR", { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 });
    }
    function api(url, body) {
        var o = { credentials: "same-origin", cache: "no-store", headers: {} };
        if (body !== undefined) { o.method = "POST"; o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
        return fetch(url, o).then(function (r) {
            if (r.status === 401) { location.href = "/login"; throw new Error("sessao"); }
            return r.json();
        });
    }
    function badge(cls, txt) { return '<span class="badge ' + cls + ' mini">' + esc(txt) + "</span>"; }
    function table(head, rows, empty) {
        if (!rows.length) return '<div class="empty">' + esc(empty) + "</div>";
        return '<div class="ts-scroll"><table class="data"><thead><tr>' + head.map(function (h) { return "<th>" + esc(h) + "</th>"; }).join("") +
            "</tr></thead><tbody>" + rows.join("") + "</tbody></table></div>";
    }
    function tiles(items) {
        return '<div class="ts-tiles">' + items.map(function (i) {
            return '<div class="ts-tile"><span>' + esc(i[0]) + "</span><strong>" + esc(i[1]) + "</strong></div>";
        }).join("") + "</div>";
    }

    var LABEL = { dns: "DNS", ping: "Ping", rota: "Rota (MTR)", portas: "Portas abertas", descoberta: "Descoberta de rede", interfaces: "Saúde das interfaces" };
    var render = {
        dns: function (r) {
            var html = r.diverge ? '<div class="alert alert-aviso"><span class="ico"><i class="bi bi-exclamation-triangle"></i></span><span>Os servidores responderam diferente. Em sites com CDN isso pode ser normal; em nomes internos, confira a zona.</span></div>' : "";
            return html + table(["Servidor", "Situação", "Tempo", "Respostas"], r.servers.map(function (s) {
                var ok = s.status === "NOERROR";
                var ans = s.answers.length ? s.answers.map(function (a) { return '<div class="mono">' + esc(a.type) + " " + esc(a.value) + ' <span class="nic-sub">TTL ' + esc(a.ttl) + "</span></div>"; }).join("") : '<span class="nic-sub">sem registros</span>';
                return '<tr><td class="mono">' + esc(s.server) + (s.default ? ' <span class="nic-sub">(deste servidor)</span>' : "") + "</td><td>" + badge(ok ? "badge-up" : "badge-err", s.status) + "</td><td>" + (s.ms == null ? "—" : esc(s.ms) + " ms") + "</td><td>" + ans + "</td></tr>";
            }), "Sem resposta.");
        },
        ping: function (r) {
            return tiles([["Enviados", num(r.sent)], ["Recebidos", num(r.received)], ["Perda", r.loss == null ? "—" : num(r.loss, 1) + "%"], ["Mínimo", r.min == null ? "—" : num(r.min, 1) + " ms"], ["Média", r.avg == null ? "—" : num(r.avg, 1) + " ms"], ["Máximo", r.max == null ? "—" : num(r.max, 1) + " ms"]]);
        },
        rota: function (r) {
            var last = r.hubs.length - 1;
            var html = table(["Salto", "Host", "Perda", "Enviados", "Último", "Média", "Melhor", "Pior"], r.hubs.map(function (h) {
                var cls = h.loss > 0 ? "badge-warn" : "badge-up";
                return "<tr><td>" + esc(h.hop) + '</td><td class="mono">' + esc(h.host) + "</td><td>" + badge(cls, num(h.loss, 1) + "%") + "</td><td>" + esc(h.sent) + "</td><td>" + num(h.last, 1) + "</td><td>" + num(h.avg, 1) + "</td><td>" + num(h.best, 1) + "</td><td>" + num(h.worst, 1) + "</td></tr>";
            }), "Nenhum salto respondeu.");
            if (last >= 0) html += '<p class="hint">Perda só num salto do meio, sem perda no destino, costuma ser o roteador limitando respostas, e não um problema real.</p>';
            return html;
        },
        portas: function (r) {
            return tiles([["Host", r.address || r.target], ["Abertas", num(r.ports.length)], ["Fechadas", num(r.closed)], ["Filtradas", num(r.filtered)]]) +
                table(["Porta", "Situação", "Serviço", "Versão"], r.ports.map(function (p) {
                    return '<tr><td class="mono">' + esc(p.port) + "/" + esc(p.proto) + "</td><td>" + badge("badge-up", p.state === "open" ? "aberta" : p.state) + "</td><td>" + esc(p.service) + "</td><td>" + esc(p.version) + "</td></tr>";
                }), "Nenhuma porta aberta nas portas verificadas.");
        },
        descoberta: function (r) {
            var html = tiles([["Faixa", r.cidr], ["Encontrados", num(r.hosts.length)], ["Endereços", num(r.total)], ["Via", r.local ? r.iface + " (rede local)" : "roteada"]]);
            if (!r.local) html += '<div class="alert alert-aviso"><span class="ico"><i class="bi bi-info-circle"></i></span><span>Esta faixa é roteada: MAC e fabricante não aparecem, e hosts que não respondem a ping ficam de fora.</span></div>';
            return html + table(["IP", "MAC", "Fabricante", "Nome"], r.hosts.map(function (h) {
                return '<tr><td class="mono">' + esc(h.ip) + (h.self ? ' <span class="nic-sub">(este servidor)</span>' : "") + '</td><td class="mono">' + esc(h.mac || "—") + "</td><td>" + esc(h.vendor || "—") + '</td><td class="mono">' + esc(h.name || "—") + "</td></tr>";
            }), "Nenhum host respondeu nessa faixa.");
        },
        interfaces: function (r) {
            return table(["Interface", "Link", "Velocidade", "Duplex", "Erros (RX/TX)", "Descartes (RX/TX)", "Observações"], r.ifaces.map(function (i) {
                var cls = i.level === "erro" ? "badge-err" : i.level === "aviso" ? "badge-warn" : "badge-up";
                var notes = i.notes.length ? i.notes.map(esc).join("<br>") : '<span class="nic-sub">sem observações</span>';
                var grow = Object.keys(i.growing);
                if (grow.length) notes += '<div class="mono nic-sub">' + grow.map(function (k) { return esc(k) + " +" + esc(i.growing[k]); }).join(", ") + "</div>";
                return '<tr><td class="mono">' + esc(i.name) + '<div class="nic-sub">' + esc(i.driver || (i.physical ? "física" : "virtual")) + "</div></td><td>" + badge(cls, i.up ? "ativo" : "sem link") + "</td><td>" + (i.speed ? num(i.speed) + " Mb/s" : "—") + "</td><td>" + esc(i.duplex && i.duplex !== "Unknown" ? i.duplex : "—") + "</td><td>" + num(i.errors.rx_errors) + " / " + num(i.errors.tx_errors) + "</td><td>" + num(i.errors.rx_dropped) + " / " + num(i.errors.tx_dropped) + "</td><td>" + notes + "</td></tr>";
            }), "Nenhuma interface encontrada.");
        }
    };

    /* ---------------- abas e campos condicionais -------------------- */
    $$("#ts-tabs button").forEach(function (b) {
        b.addEventListener("click", function () {
            $$("#ts-tabs button").forEach(function (x) { x.classList.toggle("on", x === b); });
            $$("[data-ts-form]").forEach(function (f) { f.hidden = f.getAttribute("data-ts-form") !== b.getAttribute("data-tab"); });
        });
    });
    var pingForm = $('[data-ts-form="ping"]'), portForm = $('[data-ts-form="portas"]'), discForm = $('[data-ts-form="descoberta"]');
    pingForm.elements.tool.addEventListener("change", function () { $(".ts-size", pingForm).hidden = this.value !== "ping"; });
    portForm.elements.profile.addEventListener("change", function () {
        var list = this.value === "lista";
        $(".ts-ports", portForm).hidden = !list;
        portForm.elements.ports.required = list;
    });
    $$("[data-cidr]", discForm).forEach(function (b) { b.addEventListener("click", function () { discForm.elements.cidr.value = b.getAttribute("data-cidr"); }); });

    /* ---------------- execucao -------------------------------------- */
    var box = $("#ts-run"), timer = null, current = null;
    function setState(html) { $("#ts-state").innerHTML = html; }
    function poll() {
        if (!current) return;
        var id = current;
        api("/api/troubleshooting/job/" + id).then(function (j) {
            if (id !== current) return;
            if (!j.ok) { setState(badge("badge-err", "falhou")); $("#ts-result").innerHTML = '<div class="empty">' + esc(j.message) + "</div>"; $("#ts-stop").hidden = true; return; }
            $("#ts-title").innerHTML = '<i class="bi bi-terminal"></i> ' + esc(LABEL[j.tool] || j.tool) + ' <span class="nic-sub mono">' + esc(j.target) + "</span>";
            var raw = $("#ts-raw"), follow = raw.scrollTop + raw.clientHeight >= raw.scrollHeight - 30;
            raw.textContent = j.output || "";
            if (follow) raw.scrollTop = raw.scrollHeight;
            if (j.state === "running") {
                setState('<span class="tr-live"><span class="live-dot"></span> rodando</span>');
                $("#ts-stop").hidden = false;
                $("#ts-raw-box").open = true;
                $("#ts-result").innerHTML = "";
                timer = setTimeout(poll, 1000);
                return;
            }
            $("#ts-stop").hidden = true;
            if (j.state === "done") {
                setState(badge("badge-up", "concluído"));
                $("#ts-raw-box").open = false;
                $("#ts-result").innerHTML = render[j.tool](j.result);
            } else if (j.state === "stopped") {
                setState(badge("badge-down", "interrompido"));
                $("#ts-result").innerHTML = "";
            } else {
                setState(badge("badge-err", "falhou"));
                $("#ts-result").innerHTML = '<div class="alert alert-erro"><span class="ico"><i class="bi bi-x-circle"></i></span><span>' + esc(j.error) + "</span></div>";
            }
        }).catch(function () { if (id === current) timer = setTimeout(poll, 3000); });
    }
    function open(id) {
        clearTimeout(timer);
        current = id;
        box.hidden = false;
        $("#ts-result").innerHTML = "";
        $("#ts-raw").textContent = "";
        setState("");
        box.scrollIntoView({ behavior: "smooth", block: "start" });
        poll();
    }
    $$("[data-ts-form]").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var kind = form.getAttribute("data-ts-form"), body = { tool: kind };
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name) return;
                body[el.name] = el.type === "checkbox" ? el.checked : el.value;
            });
            var btn = $("button[type=submit]", form);
            btn.disabled = true;
            api("/api/troubleshooting/iniciar", body).then(function (r) {
                btn.disabled = false;
                if (r.ok) { open(r.id); return; }
                box.hidden = false;
                current = null;
                clearTimeout(timer);
                $("#ts-stop").hidden = true;
                $("#ts-title").innerHTML = '<i class="bi bi-terminal"></i> Resultado';
                setState(badge("badge-err", "recusado"));
                $("#ts-raw").textContent = "";
                $("#ts-result").innerHTML = '<div class="alert alert-erro"><span class="ico"><i class="bi bi-x-circle"></i></span><span>' + esc(r.message) + "</span></div>";
            }).catch(function () { btn.disabled = false; });
        });
    });
    $("#ts-stop").addEventListener("click", function () {
        if (!current) return;
        api("/api/troubleshooting/job/" + current + "/parar", {}).then(function () { clearTimeout(timer); poll(); });
    });
    $$("[data-ts-open]").forEach(function (b) { b.addEventListener("click", function () { open(b.getAttribute("data-ts-open")); }); });
})();
