#!/usr/bin/env bash
# =====================================================================
#  Modulo NBackup - instalacao
#  Chamado por: newos-modctl install nbackup   (root, precisa de internet)
#  Netmiko (SSH nos equipamentos), cryptography (credenciais cifradas) e
#  git (historico), todos do repositorio oficial do Debian.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="nbackup"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

[[ -x /usr/local/sbin/newos-nbackup ]] || mod_die "Helper newos-nbackup ausente: atualize o NewOS." 2
apt_require_healthy
apt_ensure_lists
pkg_require_available python3-netmiko python3-cryptography git
mod_info "Instalando Netmiko, cryptography e git..."
apt_install python3-netmiko python3-cryptography git
python3 -c 'import netmiko, cryptography' || mod_die "Netmiko nao carregou depois da instalacao." 2
/usr/local/sbin/newos-nbackup init >/dev/null || mod_die "Nao consegui preparar o NBackup." 2
mod_info "Pronto. Defina o diretorio em NBackup > Ajustes e cadastre os equipamentos."
