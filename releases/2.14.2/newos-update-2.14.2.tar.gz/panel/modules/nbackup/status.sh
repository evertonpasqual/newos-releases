#!/usr/bin/env bash
set -Eeuo pipefail
inst=no
if dpkg-query -W -f='${db:Status-Status}' python3-netmiko 2>/dev/null | grep -qx installed && [[ -x /usr/local/sbin/newos-nbackup ]]; then
    inst=yes
fi
printf 'installed=%s\n' "${inst}"
printf 'active=%s\n' "$([[ "$(systemctl is-enabled newos-nbackup.timer 2>/dev/null)" == enabled ]] && echo yes || echo no)"
