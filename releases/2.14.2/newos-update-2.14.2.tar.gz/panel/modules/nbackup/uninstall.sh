#!/usr/bin/env bash
# =====================================================================
#  Modulo NBackup - desligar: para o agendamento. Equipamentos,
#  credenciais (/etc/newos/nbackup.*) e o historico ficam.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="nbackup"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"
[[ -x /usr/local/sbin/newos-nbackup ]] && /usr/local/sbin/newos-nbackup disable >/dev/null || true
mod_info "NBackup desligado. Configuracao e historico mantidos."
