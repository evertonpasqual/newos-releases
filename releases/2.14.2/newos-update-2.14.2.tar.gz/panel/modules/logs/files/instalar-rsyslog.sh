#!/bin/bash
# =====================================================================================================
#  instalar-rsyslog.sh — manda os logs deste servidor Linux para o NewOS (módulo Logs > Graylog)
#
#  bash instalar-rsyslog.sh instalar [--udp] [--porta 514]   instala o rsyslog (pelo NewOS, sem internet)
#                                                            e encaminha tudo para o NewOS
#  bash instalar-rsyslog.sh status                           o que está configurado e a fila
#  bash instalar-rsyslog.sh testar                           manda uma mensagem de teste
#  bash instalar-rsyslog.sh remover                          tira só o encaminhamento (o rsyslog fica)
#
#  Baixado do painel do NewOS (curl .../dl/instalar-rsyslog.sh), o script já vem com o endereço dele em
#  NEWOS_URL: o rsyslog vem do repositório offline do NewOS (Debian 12/13 e Proxmox 8/9). Em outro
#  sistema, usa o apt do próprio host. Pode rodar quantas vezes quiser.
#
#  Padrão: TCP (com fila em disco enquanto o NewOS não responde). --udp para equipamentos/redes que
#  só aceitam UDP.
# =====================================================================================================
set -euo pipefail

NEWOS_URL=""        # preenchido pelo NewOS quando o script é baixado do painel (ou --newos URL)
CONF=/etc/rsyslog.d/90-newos.conf
JCONF=/etc/systemd/journald.conf.d/90-newos-syslog.conf
MODO=""; PROTO=tcp; PORTA=514

uso() { sed -n '3,9p' "$0" | sed 's/^#  //'; exit 1; }
ok()   { echo "    ✔ $*"; }
info() { echo "    • $*"; }
aviso(){ echo "    ⚠ $*"; }
etapa(){ echo; echo "==> $*"; }

# pacote .deb pelo repositório offline do NewOS (Debian 12/13 = Proxmox 8/9): só o que falta no host.
# Tudo com limite de tempo e registrado em $LOGF (o apt do Proxmox pode estar ocupado: espera o lock).
LOGF=/var/log/newos-instalar.log
apt_newos() {   # pacotes...
  [[ -n "$NEWOS_URL" ]] || return 2
  local suite d rc
  suite=$(. /etc/os-release 2>/dev/null; echo "${VERSION_CODENAME:-}")
  case "$suite" in bookworm|trixie) ;;
    *) aviso "este host é ${suite:-desconhecido}: o NewOS tem pacotes para Debian 12/13 (Proxmox 8/9)"; return 2 ;;
  esac
  d=$(mktemp -d); mkdir -p "$d/lists/partial"
  echo "deb [trusted=yes] $NEWOS_URL/dl/apt/$suite ./" >"$d/sources.list"
  local o=(-o "Dir::Etc::SourceList=$d/sources.list" -o Dir::Etc::SourceParts=/dev/null -o "Dir::State::Lists=$d/lists"
           -o Dir::Cache::pkgcache= -o Dir::Cache::srcpkgcache= -o APT::Install-Recommends=0 -o Acquire::Languages=none
           -o APT::Sandbox::User=root -o Acquire::http::Timeout=20 -o DPkg::Lock::Timeout=180
           -o Dpkg::Options::=--force-confold)
  info "baixando do NewOS ($suite): $* (até 2 min)"
  rc=0
  { echo "== $(date '+%F %T') apt_newos $suite $*"
    timeout 180 apt-get "${o[@]}" update \
      && DEBIAN_FRONTEND=noninteractive timeout 900 apt-get "${o[@]}" -y install "$@"; } >>"$LOGF" 2>&1 || rc=1
  rm -rf "$d"
  if [[ $rc -ne 0 ]]; then
    aviso "não instalou pelo NewOS. Últimas linhas de $LOGF:"
    tail -n 6 "$LOGF" | sed 's/^/        /'
  fi
  return $rc
}

# reinicia o rsyslog sem travar: um rsyslog preso (ex.: modulo TLS ausente) nao para no SIGTERM
reiniciar_rsyslog() {
  if timeout 25 systemctl restart rsyslog 2>/dev/null; then return 0; fi
  aviso "o rsyslog não reiniciou em 25 s: encerrando à força (systemctl kill -s KILL)"
  systemctl kill -s KILL rsyslog 2>/dev/null || true
  sleep 2
  systemctl reset-failed rsyslog 2>/dev/null || true
  timeout 25 systemctl start rsyslog 2>/dev/null
}

# confere de verdade: TCP estabelecido com o NewOS e sem erro de driver no journal
conferir() {
  local i est=0 err
  if [[ "$PROTO" == "udp" ]] || ! grep -q 'protocol="tcp"' "$CONF" 2>/dev/null; then
    info "UDP não tem conexão para conferir: veja no NewOS (Monitoramento › Logs › Quem está mandando)"; return 0
  fi
  for i in 1 2 3 4 5 6 7 8 9 10; do
    if ss -Htn state established "( dport = :$PORTA )" 2>/dev/null | grep -q "$ALVO:$PORTA"; then est=1; break; fi
    sleep 1
  done
  err=$(journalctl -u rsyslog --since "-2min" --no-pager -o cat 2>/dev/null | grep -iE "lmnsd|netstream|omfwd|suspended|error" | tail -n 3 || true)
  if [[ $est -eq 1 ]]; then
    ok "conectado ao NewOS ($ALVO:$PORTA/tcp): os logs estão chegando"
    return 0
  fi
  aviso "o rsyslog NÃO conectou ao NewOS em $ALVO:$PORTA/tcp"
  [[ -n "$err" ]] && echo "$err" | sed 's/^/        /'
  if grep -qi "gtls" <<<"$err"; then
    info "há um driver TLS global (DefaultNetstreamDriver gtls) neste host: o encaminhamento já usa StreamDriver=\"ptcp\"; rode instalar de novo se o $CONF for antigo"
  fi
  info "teste a porta: timeout 3 bash -c '</dev/tcp/$ALVO/$PORTA' && echo aberta"
  info "firewall do NewOS: a porta $PORTA/tcp precisa aceitar este servidor"
  return 1
}

[[ $# -ge 1 ]] || uso
MODO=$1; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --udp)   PROTO=udp ;;
    --tcp)   PROTO=tcp ;;
    --porta) PORTA=${2:-}; shift ;;
    --newos) NEWOS_URL=${2:-}; shift ;;
    *)       echo "opção desconhecida: $1"; uso ;;
  esac
  shift
done
case "$MODO" in instalar|status|testar|remover) ;; *) uso ;; esac
[[ $EUID -eq 0 ]] || { echo "Rode como root."; exit 1; }
[[ "$PORTA" =~ ^[0-9]{1,5}$ ]] || { echo "Porta inválida: $PORTA"; exit 1; }

# o destino é o próprio NewOS (o endereço que entregou o script, sem a porta do painel)
ALVO=$(sed -E 's#^https?://##; s#/.*$##; s#^\[([^]]+)\].*#\1#; s#:[0-9]+$##' <<<"$NEWOS_URL")
[[ -n "$ALVO" || "$MODO" == "status" || "$MODO" == "remover" || "$MODO" == "testar" ]] || { echo "ERRO: sem o endereço do NewOS. Use --newos http://IP-DO-NEWOS"; exit 1; }

if [[ "$MODO" == "remover" ]]; then
  etapa "removendo o encaminhamento para o NewOS"
  rm -f "$CONF"
  reiniciar_rsyslog || true
  ok "pronto: o rsyslog continua instalado, só não manda mais nada ao NewOS"; exit 0
fi

if [[ "$MODO" == "status" ]]; then
  etapa "rsyslog"
  if command -v rsyslogd >/dev/null; then ok "instalado ($(rsyslogd -v 2>/dev/null | head -1 | awk '{print $2}' | tr -d ,))"; else aviso "não instalado"; fi
  systemctl is-active --quiet rsyslog && ok "serviço ativo" || aviso "serviço parado"
  if [[ -f "$CONF" ]]; then ok "encaminhando: $(grep -o 'target="[^"]*" port="[^"]*" protocol="[^"]*"' "$CONF" | tr -d '"')"
  else aviso "sem encaminhamento para o NewOS ($CONF não existe)"; fi
  Q=$(ls -1 /var/spool/rsyslog/newos_fwd* 2>/dev/null | wc -l || true)
  [[ "${Q:-0}" -gt 0 ]] && aviso "fila em disco com $Q arquivo(s): o NewOS não está recebendo" || ok "sem fila acumulada"
  exit 0
fi

if [[ "$MODO" == "testar" ]]; then
  [[ -f "$CONF" ]] || { aviso "sem encaminhamento para o NewOS ($CONF não existe): rode instalar"; exit 1; }
  ALVO=$(grep -o 'target="[^"]*"' "$CONF" | head -1 | cut -d'"' -f2); PORTA=$(grep -o 'port="[^"]*"' "$CONF" | head -1 | cut -d'"' -f2)
  grep -q 'protocol="udp"' "$CONF" && PROTO=udp
  logger -t newos-teste -p user.notice "Teste do NewOS: logs de $(hostname) chegando ($(date '+%F %T'))"
  info "mensagem de teste enviada (no Graylog: newos-teste)"
  conferir; exit $?
fi

# =============================================================================================== instalar
etapa "rsyslog"
if command -v rsyslogd >/dev/null; then
  ok "já instalado"
elif apt_newos rsyslog; then
  ok "instalado pelo NewOS ($NEWOS_URL)"
else
  info "tentando o apt do próprio host (precisa de internet; até 5 min)"
  DEBIAN_FRONTEND=noninteractive timeout 300 apt-get -o Acquire::http::Timeout=10 -o Acquire::Retries=0 \
    -o DPkg::Lock::Timeout=120 install -y -qq rsyslog >>"$LOGF" 2>&1 \
    || { echo "ERRO: não consegui instalar o rsyslog (sem NewOS e sem repositório apt)."; exit 1; }
  ok "instalado pelo apt do host"
fi

etapa "journal -> rsyslog"
mkdir -p "$(dirname "$JCONF")"
printf '# Gerado pelo instalar-rsyslog.sh do NewOS: o journal entrega tudo ao rsyslog\n[Journal]\nForwardToSyslog=yes\n' >"$JCONF"
systemctl restart systemd-journald 2>/dev/null || true
ok "ForwardToSyslog=yes"

etapa "encaminhamento para o NewOS ($ALVO:$PORTA/$PROTO)"
{
  echo "# Gerado pelo instalar-rsyslog.sh do NewOS em $(date '+%F %T'). Para tirar: bash instalar-rsyslog.sh remover"
  echo "# Tudo que este servidor registra vai para o NewOS, que repassa ao Graylog com o nome do cliente."
  if [[ "$PROTO" == "tcp" ]]; then
    # StreamDriver ptcp explicito: um "DefaultNetstreamDriver gtls" global (de outra config) sem o
    # rsyslog-gnutls deixaria este encaminhamento parado
    echo "*.* action(type=\"omfwd\" target=\"$ALVO\" port=\"$PORTA\" protocol=\"tcp\" StreamDriver=\"ptcp\""
    echo "           action.resumeRetryCount=\"-1\" action.resumeInterval=\"10\""
    echo "           queue.type=\"LinkedList\" queue.filename=\"newos_fwd\" queue.maxDiskSpace=\"512m\""
    echo "           queue.saveOnShutdown=\"on\")"
  else
    echo "*.* action(type=\"omfwd\" target=\"$ALVO\" port=\"$PORTA\" protocol=\"udp\")"
  fi
} >"$CONF.novo"
mkdir -p /var/spool/rsyslog
rm -f "$CONF.anterior"; [[ -f "$CONF" ]] && cp -a "$CONF" "$CONF.anterior"
mv "$CONF.novo" "$CONF"
if rsyslogd -N1 >/dev/null 2>&1; then
  rm -f "$CONF.anterior"
  systemctl enable rsyslog >/dev/null 2>&1 || true
  reiniciar_rsyslog || { echo "ERRO: o rsyslog não voltou. Veja: journalctl -u rsyslog -n 30"; exit 1; }
  ok "configurado em $CONF"
else
  if [[ -f "$CONF.anterior" ]]; then mv "$CONF.anterior" "$CONF"; else rm -f "$CONF"; fi
  echo "ERRO: o rsyslog recusou a configuração (rsyslogd -N1); a anterior foi mantida."; exit 1
fi

etapa "teste"
logger -t newos-teste -p user.notice "Teste do NewOS: logs de $(hostname) chegando ($(date '+%F %T'))"
info "mensagem de teste enviada"
if conferir; then
  info "No NewOS: Monitoramento › Logs › Quem está mandando mostra este servidor em alguns segundos."
else
  exit 2
fi
