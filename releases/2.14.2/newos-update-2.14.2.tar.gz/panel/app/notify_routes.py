"""
NewOS Panel - Sistema > Notificacoes (avisos por e-mail).

    GET  /sistema/notificacoes          conta SMTP, destinatarios, modo, categorias, historico
    POST /sistema/notificacoes          salva (acao=testar: salva e manda um e-mail de teste)

Tudo pelo helper newos-notify (sudo). A senha do e-mail vai uma vez para o
helper, que cifra e guarda; nunca volta para a tela. So administradores.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, terminal_routes

log = logging.getLogger("newos.panel.notify")
HELPER = "/usr/local/sbin/newos-notify"


class NotifyError(RuntimeError):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 90) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise NotifyError(f"Não foi possível executar o newos-notify: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise NotifyError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not terminal_routes.is_admin(user):
            flash(request, "erro", "Só administradores configuram as notificações.")
            return None, redirect("/dashboard")
        return user, None

    @app.get("/sistema/notificacoes", response_class=HTMLResponse)
    async def notify_page(request: Request):
        user, bounce = await run_in_threadpool(guard, request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(helper, ["status"])
        except NotifyError as exc:
            st = {"conf": {}, "categories": {}, "history": [], "queue": 0, "open": [], "error": str(exc)}
        return render(request, "notifications.html", active="notificacoes", st=st)

    @app.post("/sistema/notificacoes", response_class=HTMLResponse)
    async def notify_save(request: Request):
        user, bounce = await run_in_threadpool(guard, request)
        if bounce:
            return bounce
        f = await request.form()
        payload: dict[str, Any] = {k: str(f.get(k) or "") for k in ("host", "port", "security", "user", "password", "sender",
                                                                      "sender_name", "recipients", "mode", "disk_warn", "disk_crit",
                                                                      "panel_url")}
        payload.update(enabled=bool(f.get("enabled")), verify=not bool(f.get("insecure")), clear_password=bool(f.get("clear_password")),
                       categories={k[4:]: True for k in f.keys() if k.startswith("cat_") and f.get(k)})
        try:
            res = await run_in_threadpool(helper, ["save"], payload)
            db.log_audit(user["username"], "notificacoes",
                         f"Notificacoes: {payload['host']}:{payload['port']}, modo {payload['mode']}, para {payload['recipients'][:120]}",
                         auth.client_ip(request))
            flash(request, "ok", res.get("message", "Salvo."))
            if f.get("acao") == "testar":
                res = await run_in_threadpool(helper, ["test"], None, 60)
                db.log_audit(user["username"], "notificacoes", "E-mail de teste enviado", auth.client_ip(request))
                flash(request, "ok", res.get("message", "E-mail de teste enviado."))
        except NotifyError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/notificacoes")
