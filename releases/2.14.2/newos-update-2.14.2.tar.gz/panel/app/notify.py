"""
NewOS Panel - avisos por e-mail disparados pelo proprio painel (login).

So enfileira: o newos-notify (root, via sudo) decide se manda, conforme o
modo e as categorias de Sistema > Notificacoes. Nunca trava o pedido.
"""

from __future__ import annotations

import json
import logging
import subprocess
import threading
from typing import Any

log = logging.getLogger("newos.panel.notify")
HELPER = "/usr/local/sbin/newos-notify"


def _send(event: dict[str, Any]) -> None:
    try:
        subprocess.run(["sudo", "-n", HELPER, "send"], input=json.dumps(event), text=True, capture_output=True,
                       timeout=15, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning("Aviso por e-mail nao enfileirado: %s", exc)


def emit(event: dict[str, Any]) -> None:
    """Em segundo plano: o login nao espera o sudo."""
    threading.Thread(target=_send, args=(event,), daemon=True).start()


def login_blocked(ip: str, attempts: int) -> None:
    emit({"cat": "seguranca", "level": "aviso", "key": f"login-bloqueado:{ip}", "title": f"Tentativas de login erradas de {ip}",
          "text": f"{attempts} tentativas de login erradas seguidas vindas de {ip}. O painel bloqueou esse endereço por alguns minutos.",
          "details": {"Origem": ip, "Tentativas": str(attempts)}, "link": "/usuarios/contas"})


def admin_login(username: str, ip: str, how: str) -> None:
    emit({"cat": "seguranca", "level": "info", "key": f"login:{username}:{ip}", "title": f"Login de {username} no painel",
          "text": f"{username} entrou no painel vindo de {ip} ({how}).", "details": {"Usuário": username, "Origem": ip}})
