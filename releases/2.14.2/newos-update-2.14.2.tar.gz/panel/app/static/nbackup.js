/* NewOS - NBackup: cadastro do equipamento (campos conforme fabricante e metodo). */
(function () {
    "use strict";
    document.querySelectorAll(".nbk-form").forEach(function (form) {
        var vendor = form.querySelector(".nbk-vendor"), method = form.querySelector(".nbk-method"),
            port = form.querySelector(".nbk-port"), isNew = !form.querySelector("input[name=id]").value;
        function opt() { return vendor.options[vendor.selectedIndex] || {}; }
        function sync(changedVendor) {
            var o = opt(), methods = ((o.dataset && o.dataset.methods) || "ssh").split(",");
            Array.prototype.forEach.call(method.options, function (m) { m.disabled = methods.indexOf(m.value) < 0; });
            if (methods.indexOf(method.value) < 0) { method.value = methods[0]; }
            if (changedVendor && isNew && o.dataset) {
                if (changedVendor === "vendor") { method.value = methods[0]; }
                port.value = method.value === "api" ? 443 : 22;
            }
            var api = method.value === "api";
            form.querySelectorAll(".nbk-ssh").forEach(function (el) { el.hidden = api; });
            form.querySelectorAll(".nbk-api").forEach(function (el) { el.hidden = !api; });
            form.querySelectorAll(".nbk-enable").forEach(function (el) { el.hidden = !(o.dataset && o.dataset.enable === "1"); });
            form.querySelectorAll(".nbk-howto").forEach(function (el) { el.hidden = el.dataset.vendor !== vendor.value; });
        }
        vendor.addEventListener("change", function () { sync("vendor"); });
        method.addEventListener("change", function () { sync("method"); });
        sync(false);
    });
})();
