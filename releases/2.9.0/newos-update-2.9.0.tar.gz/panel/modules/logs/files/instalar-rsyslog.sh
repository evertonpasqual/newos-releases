#!/bin/bash
# =====================================================================================================
#  instalar-rsyslog.sh — manda os logs deste servidor Linux para o NewOS (módulo Logs > Graylog)
#
#  bash instalar-rsyslog.sh instalar [--udp] [--porta 514]   instala o rsyslog (pelo NewOS, sem internet)
#                                                            e encaminha tudo para o NewOS
#  bash instalar-rsyslog.sh status                           o que está configurado e a fila
#  bash instalar-rsyslog.sh testar                           manda uma mensagem de teste
#  bash instalar-rsyslog.sh remover                          tira só o encaminhamento (o rsyslog fica)
#
#  Baixado do painel do NewOS (curl .../dl/instalar-rsyslog.sh), o script já vem com o endereço dele em
#  NEWOS_URL: o rsyslog vem do repositório offline do NewOS (Debian 12/13 e Proxmox 8/9). Em outro
#  sistema, usa o apt do próprio host. Pode rodar quantas vezes quiser.
#
#  Padrão: TCP (com fila em disco enquanto o NewOS não responde). --udp para equipamentos/redes que
#  só aceitam UDP.
# =====================================================================================================
set -euo pipefail

NEWOS_URL=""        # preenchido pelo NewOS quando o script é baixado do painel (ou --newos URL)
CONF=/etc/rsyslog.d/90-newos.conf
JCONF=/etc/systemd/journald.conf.d/90-newos-syslog.conf
MODO=""; PROTO=tcp; PORTA=514

uso() { sed -n '3,9p' "$0" | sed 's/^#  //'; exit 1; }
ok()   { echo "    ✔ $*"; }
info() { echo "    • $*"; }
aviso(){ echo "    ⚠ $*"; }
etapa(){ echo; echo "==> $*"; }

# pacote .deb pelo repositório offline do NewOS (Debian 12/13): só o que falta no host
apt_newos() {   # pacotes...
  [[ -n "$NEWOS_URL" ]] || return 2
  local suite d rc
  suite=$(. /etc/os-release 2>/dev/null; echo "${VERSION_CODENAME:-}")
  case "$suite" in bookworm|trixie) ;; *) return 2 ;; esac
  d=$(mktemp -d); mkdir -p "$d/lists/partial"
  echo "deb [trusted=yes] $NEWOS_URL/dl/apt/$suite ./" >"$d/sources.list"
  local o=(-o "Dir::Etc::SourceList=$d/sources.list" -o Dir::Etc::SourceParts=/dev/null -o "Dir::State::Lists=$d/lists"
           -o Dir::Cache::pkgcache= -o Dir::Cache::srcpkgcache= -o APT::Install-Recommends=0 -o Acquire::Languages=none
           -o APT::Sandbox::User=root)
  rc=0
  timeout 120 apt-get "${o[@]}" -qq update >/dev/null 2>&1 \
    && DEBIAN_FRONTEND=noninteractive timeout 600 apt-get "${o[@]}" -y -qq install "$@" >/dev/null 2>&1 || rc=1
  rm -rf "$d"; return $rc
}

[[ $# -ge 1 ]] || uso
MODO=$1; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --udp)   PROTO=udp ;;
    --tcp)   PROTO=tcp ;;
    --porta) PORTA=${2:-}; shift ;;
    --newos) NEWOS_URL=${2:-}; shift ;;
    *)       echo "opção desconhecida: $1"; uso ;;
  esac
  shift
done
case "$MODO" in instalar|status|testar|remover) ;; *) uso ;; esac
[[ $EUID -eq 0 ]] || { echo "Rode como root."; exit 1; }
[[ "$PORTA" =~ ^[0-9]{1,5}$ ]] || { echo "Porta inválida: $PORTA"; exit 1; }

# o destino é o próprio NewOS (o endereço que entregou o script, sem a porta do painel)
ALVO=$(sed -E 's#^https?://##; s#/.*$##; s#^\[([^]]+)\].*#\1#; s#:[0-9]+$##' <<<"$NEWOS_URL")
[[ -n "$ALVO" || "$MODO" == "status" || "$MODO" == "remover" ]] || { echo "ERRO: sem o endereço do NewOS. Use --newos http://IP-DO-NEWOS"; exit 1; }

if [[ "$MODO" == "remover" ]]; then
  etapa "removendo o encaminhamento para o NewOS"
  rm -f "$CONF"
  systemctl restart rsyslog 2>/dev/null || true
  ok "pronto: o rsyslog continua instalado, só não manda mais nada ao NewOS"; exit 0
fi

if [[ "$MODO" == "status" ]]; then
  etapa "rsyslog"
  if command -v rsyslogd >/dev/null; then ok "instalado ($(rsyslogd -v 2>/dev/null | head -1 | awk '{print $2}' | tr -d ,))"; else aviso "não instalado"; fi
  systemctl is-active --quiet rsyslog && ok "serviço ativo" || aviso "serviço parado"
  if [[ -f "$CONF" ]]; then ok "encaminhando: $(grep -o 'target="[^"]*" port="[^"]*" protocol="[^"]*"' "$CONF" | tr -d '"')"
  else aviso "sem encaminhamento para o NewOS ($CONF não existe)"; fi
  Q=$(ls -1 /var/spool/rsyslog/newos_fwd* 2>/dev/null | wc -l || true)
  [[ "${Q:-0}" -gt 0 ]] && aviso "fila em disco com $Q arquivo(s): o NewOS não está recebendo" || ok "sem fila acumulada"
  exit 0
fi

if [[ "$MODO" == "testar" ]]; then
  logger -t newos-teste -p user.notice "Teste do NewOS: logs de $(hostname) chegando ($(date '+%F %T'))"
  ok "mensagem enviada. No NewOS: Monitoramento › Logs › Fontes (e no Graylog: newos-teste)"; exit 0
fi

# =============================================================================================== instalar
etapa "rsyslog"
if command -v rsyslogd >/dev/null; then
  ok "já instalado"
elif apt_newos rsyslog; then
  ok "instalado pelo NewOS ($NEWOS_URL)"
else
  info "o NewOS não entregou (sistema não é Debian 12/13?): tentando o apt do host"
  DEBIAN_FRONTEND=noninteractive timeout 300 apt-get install -y -qq rsyslog >/dev/null 2>&1 \
    || { echo "ERRO: não consegui instalar o rsyslog (sem NewOS e sem repositório apt)."; exit 1; }
  ok "instalado pelo apt do host"
fi

etapa "journal -> rsyslog"
mkdir -p "$(dirname "$JCONF")"
printf '# Gerado pelo instalar-rsyslog.sh do NewOS: o journal entrega tudo ao rsyslog\n[Journal]\nForwardToSyslog=yes\n' >"$JCONF"
systemctl restart systemd-journald 2>/dev/null || true
ok "ForwardToSyslog=yes"

etapa "encaminhamento para o NewOS ($ALVO:$PORTA/$PROTO)"
{
  echo "# Gerado pelo instalar-rsyslog.sh do NewOS em $(date '+%F %T'). Para tirar: bash instalar-rsyslog.sh remover"
  echo "# Tudo que este servidor registra vai para o NewOS, que repassa ao Graylog com o nome do cliente."
  if [[ "$PROTO" == "tcp" ]]; then
    echo "*.* action(type=\"omfwd\" target=\"$ALVO\" port=\"$PORTA\" protocol=\"tcp\""
    echo "           action.resumeRetryCount=\"-1\" action.resumeInterval=\"10\""
    echo "           queue.type=\"LinkedList\" queue.filename=\"newos_fwd\" queue.maxDiskSpace=\"512m\""
    echo "           queue.saveOnShutdown=\"on\")"
  else
    echo "*.* action(type=\"omfwd\" target=\"$ALVO\" port=\"$PORTA\" protocol=\"udp\")"
  fi
} >"$CONF.novo"
mkdir -p /var/spool/rsyslog
rm -f "$CONF.anterior"; [[ -f "$CONF" ]] && cp -a "$CONF" "$CONF.anterior"
mv "$CONF.novo" "$CONF"
if rsyslogd -N1 >/dev/null 2>&1; then
  rm -f "$CONF.anterior"
  systemctl enable rsyslog >/dev/null 2>&1 || true
  systemctl restart rsyslog
  ok "configurado em $CONF"
else
  if [[ -f "$CONF.anterior" ]]; then mv "$CONF.anterior" "$CONF"; else rm -f "$CONF"; fi
  echo "ERRO: o rsyslog recusou a configuração (rsyslogd -N1); a anterior foi mantida."; exit 1
fi

etapa "teste"
logger -t newos-teste -p user.notice "Teste do NewOS: logs de $(hostname) chegando ($(date '+%F %T'))"
ok "mensagem de teste enviada"
info "No NewOS: Monitoramento › Logs › Fontes mostra este servidor em alguns segundos."
info "Firewall do NewOS: a porta $PORTA/$PROTO precisa aceitar este servidor (o módulo Logs libera as redes privadas)."
