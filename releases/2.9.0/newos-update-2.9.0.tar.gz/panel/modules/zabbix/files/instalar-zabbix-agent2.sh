#!/bin/bash
# =====================================================================================================
#  instalar-zabbix-agent2.sh — Zabbix Agent 2 num host, falando com o Zabbix Proxy do NewOS
#
#  bash instalar-zabbix-agent2.sh instalar [--hostname NOME] [--metadata TEXTO]
#        instala/atualiza o zabbix-agent2 pelo NewOS (sem internet no host) e aponta para o proxy
#  bash instalar-zabbix-agent2.sh status       versão, serviço e para onde aponta
#  bash instalar-zabbix-agent2.sh remover      desinstala o zabbix-agent2
#
#  Baixado do painel do NewOS (curl .../dl/instalar-zabbix-agent2.sh), o script já vem com o endereço
#  dele em NEWOS_URL: o pacote vem do repositório offline do NewOS (Debian 12/13 e Proxmox 8/9), da
#  mesma série do Zabbix do NewOS. Em outro sistema, usa o apt do próprio host.
#
#  --hostname  nome do host no Zabbix (padrão: o hostname desta máquina). Tem que ser IGUAL ao
#              cadastrado no Zabbix (ou use autorregistro com --metadata).
#  Pode rodar quantas vezes quiser: mantém o resto do zabbix_agent2.conf.
# =====================================================================================================
set -euo pipefail

NEWOS_URL=""        # preenchido pelo NewOS quando o script é baixado do painel (ou --newos URL)
CONF=/etc/zabbix/zabbix_agent2.conf
MODO=""; NOME=""; META=""

uso() { sed -n '3,9p' "$0" | sed 's/^#  //'; exit 1; }
ok()   { echo "    ✔ $*"; }
info() { echo "    • $*"; }
aviso(){ echo "    ⚠ $*"; }
etapa(){ echo; echo "==> $*"; }

# pacote .deb pelo repositório offline do NewOS (Debian 12/13): só o que falta no host
apt_newos() {   # pacotes...
  [[ -n "$NEWOS_URL" ]] || return 2
  local suite d rc
  suite=$(. /etc/os-release 2>/dev/null; echo "${VERSION_CODENAME:-}")
  case "$suite" in bookworm|trixie) ;; *) return 2 ;; esac
  d=$(mktemp -d); mkdir -p "$d/lists/partial"
  echo "deb [trusted=yes] $NEWOS_URL/dl/apt/$suite ./" >"$d/sources.list"
  local o=(-o "Dir::Etc::SourceList=$d/sources.list" -o Dir::Etc::SourceParts=/dev/null -o "Dir::State::Lists=$d/lists"
           -o Dir::Cache::pkgcache= -o Dir::Cache::srcpkgcache= -o APT::Install-Recommends=0 -o Acquire::Languages=none
           -o APT::Sandbox::User=root)
  rc=0
  timeout 120 apt-get "${o[@]}" -qq update >/dev/null 2>&1 \
    && DEBIAN_FRONTEND=noninteractive timeout 600 apt-get "${o[@]}" -y -qq \
         -o Dpkg::Options::=--force-confold install "$@" >/dev/null 2>&1 || rc=1
  rm -rf "$d"; return $rc
}

# chave=valor no zabbix_agent2.conf (troca a linha ativa ou a comentada; senão acrescenta)
ajustar() {   # chave valor
  local k="$1" v="$2"
  if grep -qE "^$k=" "$CONF"; then sed -i "s|^$k=.*|$k=$v|" "$CONF"
  elif grep -qE "^# *$k=" "$CONF"; then sed -i "0,/^# *$k=.*/s||$k=$v|" "$CONF"
  else echo "$k=$v" >>"$CONF"; fi
}

[[ $# -ge 1 ]] || uso
MODO=$1; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --hostname) NOME=${2:-}; shift ;;
    --metadata) META=${2:-}; shift ;;
    --newos)    NEWOS_URL=${2:-}; shift ;;
    *)          echo "opção desconhecida: $1"; uso ;;
  esac
  shift
done
case "$MODO" in instalar|status|remover) ;; *) uso ;; esac
[[ $EUID -eq 0 ]] || { echo "Rode como root."; exit 1; }
[[ -z "$NOME" || "$NOME" =~ ^[A-Za-z0-9._\ -]{1,128}$ ]] || { echo "Nome inválido: $NOME"; exit 1; }
[[ -z "$META" || "$META" =~ ^[A-Za-z0-9._:,\ -]{1,255}$ ]] || { echo "Metadata inválida: $META"; exit 1; }

# o proxy é o próprio NewOS (o endereço que entregou o script, sem a porta do painel)
PROXY=$(sed -E 's#^https?://##; s#/.*$##; s#^\[([^]]+)\].*#\1#; s#:[0-9]+$##' <<<"$NEWOS_URL")

if [[ "$MODO" == "status" ]]; then
  etapa "zabbix-agent2"
  V=$(dpkg-query -W -f='${Version}' zabbix-agent2 2>/dev/null || true)
  [[ -n "$V" ]] && ok "instalado ($V)" || { aviso "não instalado"; exit 0; }
  systemctl is-active --quiet zabbix-agent2 && ok "serviço ativo" || aviso "serviço parado"
  for k in Server ServerActive Hostname HostMetadata; do
    l=$(grep -E "^$k=" "$CONF" 2>/dev/null | tail -1 || true); [[ -n "$l" ]] && info "$l"
  done
  exit 0
fi

if [[ "$MODO" == "remover" ]]; then
  etapa "removendo o zabbix-agent2"
  systemctl disable --now zabbix-agent2 >/dev/null 2>&1 || true
  DEBIAN_FRONTEND=noninteractive apt-get purge -y -qq zabbix-agent2 >/dev/null 2>&1 || true
  ok "removido"; exit 0
fi

[[ -n "$PROXY" ]] || { echo "ERRO: sem o endereço do NewOS. Use --newos http://IP-DO-NEWOS"; exit 1; }

# =============================================================================================== instalar
etapa "zabbix-agent2"
ANTES=$(dpkg-query -W -f='${Version}' zabbix-agent2 2>/dev/null || true)
if apt_newos zabbix-agent2; then
  ok "pelo NewOS ($NEWOS_URL): $(dpkg-query -W -f='${Version}' zabbix-agent2)${ANTES:+ (antes: $ANTES)}"
elif [[ -n "$ANTES" ]]; then
  aviso "o NewOS não entregou o pacote; fica a versão instalada ($ANTES)"
else
  info "o NewOS não entregou (sistema não é Debian 12/13?): tentando o apt do host"
  DEBIAN_FRONTEND=noninteractive timeout 300 apt-get install -y -qq zabbix-agent2 >/dev/null 2>&1 \
    || { echo "ERRO: não consegui instalar o zabbix-agent2 (sem NewOS e sem repositório Zabbix no host)."; exit 1; }
  ok "instalado pelo apt do host"
fi
[[ -f "$CONF" ]] || { echo "ERRO: $CONF não existe depois da instalação."; exit 1; }

etapa "configuração ($CONF)"
[[ -f "$CONF.newos-original" ]] || cp -a "$CONF" "$CONF.newos-original"
NOME=${NOME:-$(hostname)}
ajustar Server "$PROXY"
ajustar ServerActive "$PROXY"
ajustar Hostname "$NOME"
[[ -n "$META" ]] && ajustar HostMetadata "$META"
ok "Server e ServerActive = $PROXY (Zabbix Proxy do NewOS)"
ok "Hostname = $NOME"
[[ -n "$META" ]] && ok "HostMetadata = $META (autorregistro)"

systemctl enable zabbix-agent2 >/dev/null 2>&1 || true
systemctl restart zabbix-agent2
sleep 2
if systemctl is-active --quiet zabbix-agent2; then ok "serviço ativo (porta 10050)"
else echo "ERRO: o zabbix-agent2 não subiu. Veja: journalctl -u zabbix-agent2 -n 30"; exit 1; fi

etapa "próximos passos"
info "No Zabbix: cadastre o host '$NOME' monitorado pelo proxy deste NewOS (interface agente: IP deste host, porta 10050)."
info "Firewall do NewOS: o proxy precisa alcançar este host na 10050 e receber na 10051 (checks ativos)."
