#!/usr/bin/env bash
# =====================================================================
#  NewOS Panel - update-panel.sh
# ---------------------------------------------------------------------
#  Atualiza SOMENTE o painel web em um servidor ja instalado.
#  Nao mexe no sistema operacional, no disco, nem no banco de dados
#  (o esquema e reaplicado, mas ele e idempotente).
#
#  Rode a partir do diretorio que contem a pasta "panel/":
#
#      sudo ./update-panel.sh
#
#  Opcoes:
#      --no-deps      nao roda o pip (mais rapido, se nada mudou)
#      --no-restart   nao reinicia os servicos ao final
#      --dry-run      mostra o que faria, sem alterar nada
#
#  Em caso de erro, o painel anterior fica preservado em
#      /opt/newos-panel.bak-<data>
#  e o script tenta voltar sozinho.
# =====================================================================
set -Eeuo pipefail

SRC_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
CONFIG="/etc/newos/newos.conf"

DO_DEPS=1
DO_RESTART=1
DRY_RUN=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-deps)    DO_DEPS=0 ;;
        --no-restart) DO_RESTART=0 ;;
        --dry-run)    DRY_RUN=1 ;;
        -h|--help)    sed -n '3,22p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) printf 'Opcao desconhecida: %s\n' "$1" >&2; exit 1 ;;
    esac
    shift
done

if [[ -t 1 ]]; then
    R=$'\033[31m'; G=$'\033[32m'; Y=$'\033[33m'; B=$'\033[1m'; N=$'\033[0m'
else
    R=''; G=''; Y=''; B=''; N=''
fi
info() { printf '%s[ .. ]%s %s\n' "${B}" "${N}" "$*"; }
ok()   { printf '%s[ OK ]%s %s\n' "${G}" "${N}" "$*"; }
warn() { printf '%s[AVISO]%s %s\n' "${Y}" "${N}" "$*"; }
# ATENCAO: "exit" NAO dispara o trap ERR. Por isso o die chama o
# rollback por conta propria depois que o backup existe (antes, as
# mensagens "revertendo" nao revertiam nada).
ROLLBACK_ARMED=0
die()  {
    printf '%s[ERRO]%s %s\n' "${R}" "${N}" "$*" >&2
    [[ "${ROLLBACK_ARMED}" -eq 1 ]] && rollback
    exit 1
}

[[ "${EUID}" -eq 0 ]] || die "Rode como root: sudo $0"
[[ -f "${CONFIG}" ]] || die "${CONFIG} nao encontrado. Este servidor e um NewOS?"

# Onde estao os arquivos novos.
PANEL_SRC="${SRC_DIR}/panel"
[[ -d "${PANEL_SRC}/app" ]] || PANEL_SRC="${SRC_DIR}"
[[ -f "${PANEL_SRC}/app/main.py" ]] || \
    die "Nao encontrei app/main.py. Rode este script de dentro do pacote extraido."

# shellcheck source=/dev/null
source "${CONFIG}"
: "${PANEL_INSTALL_DIR:=/opt/newos-panel}"
: "${PANEL_SYSTEM_USER:=newospanel}"
: "${PANEL_HTTP_PORT:=81}"
: "${PANEL_BIND_HOST:=127.0.0.1}"
: "${PANEL_BIND_PORT:=8081}"
: "${PANEL_DB_NAME:=newos_panel}"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="${PANEL_INSTALL_DIR}.bak-${STAMP}"

printf '\n%s=====================================================%s\n' "${B}" "${N}"
printf ' NewOS Panel - atualizacao do painel web\n'
printf '%s=====================================================%s\n\n' "${B}" "${N}"
printf '  Origem...: %s\n' "${PANEL_SRC}"
printf '  Destino..: %s\n' "${PANEL_INSTALL_DIR}"
printf '  Backup...: %s\n' "${BACKUP}"
printf '  Porta....: %s\n\n' "${PANEL_HTTP_PORT}"

if [[ "${DRY_RUN}" -eq 1 ]]; then
    warn "--dry-run: nada sera alterado."
    printf '\n  Arquivos que seriam copiados:\n'
    ( cd "${PANEL_SRC}" && find app bin sql systemd nginx sudoers modules \
        requirements.txt -type f 2>/dev/null | sed 's/^/    /' )
    exit 0
fi

# ---------------------------------------------------------------------
# 1. Backup
# ---------------------------------------------------------------------
if [[ -d "${PANEL_INSTALL_DIR}" ]]; then
    info "Guardando a versao atual em ${BACKUP}..."
    cp -a "${PANEL_INSTALL_DIR}" "${BACKUP}"
    ok "Backup criado."
else
    warn "${PANEL_INSTALL_DIR} nao existe; instalacao nova."
    install -d -m 0755 "${PANEL_INSTALL_DIR}"
fi

rollback() {
    warn "Revertendo para a versao anterior..."
    if [[ -d "${BACKUP}" ]]; then
        rm -rf "${PANEL_INSTALL_DIR}"
        mv "${BACKUP}" "${PANEL_INSTALL_DIR}"
        systemctl restart newos-panel 2>/dev/null || true
        warn "Revertido. O painel voltou para a versao anterior."
    fi
}
trap 'rollback' ERR
ROLLBACK_ARMED=1

# ---------------------------------------------------------------------
# 2. Codigo
#    O venv NAO e tocado aqui (fica fora do rsync); as dependencias sao
#    tratadas no passo 3.
# ---------------------------------------------------------------------
info "Copiando o codigo do painel..."

# Ficam de fora do rsync (e do --delete), porque nascem no BUILD:
#   static/logo.png, static/logo-light.png  -> logos tratados do branding
#   static/vendor/                          -> fonte e icones (newos-panel-assets)
rsync -a --delete \
      --exclude 'venv' \
      --exclude '__pycache__' \
      --exclude '*.pyc' \
      --exclude '/static/logo.png' \
      --exclude '/static/logo-light.png' \
      --exclude '/static/vendor/' \
      "${PANEL_SRC}/app/"  "${PANEL_INSTALL_DIR}/app/"

for d in bin sql systemd nginx sudoers modules keys; do
    [[ -d "${PANEL_SRC}/${d}" ]] && \
        rsync -a "${PANEL_SRC}/${d}/" "${PANEL_INSTALL_DIR}/${d}/"
done
[[ -f "${PANEL_SRC}/requirements.txt" ]] && \
    cp -f "${PANEL_SRC}/requirements.txt" "${PANEL_INSTALL_DIR}/"
[[ -f "${PANEL_SRC}/update-panel.sh" ]] && \
    cp -f "${PANEL_SRC}/update-panel.sh" "${PANEL_INSTALL_DIR}/"

# Servidores instalados antes da identidade NewIO nao tem o logo do tema
# claro. Usa o que vier no pacote (o deploy-panel.sh manda o original de
# branding/); sem ele, o branco como reserva ate a proxima ISO.
if [[ ! -f "${PANEL_INSTALL_DIR}/app/static/logo-light.png" ]]; then
    for cand in "${PANEL_SRC}/app/static/logo-light.png" \
                "${PANEL_INSTALL_DIR}/app/static/logo.png"; do
        if [[ -f "${cand}" ]]; then
            cp "${cand}" "${PANEL_INSTALL_DIR}/app/static/logo-light.png"
            break
        fi
    done
fi

ok "Codigo atualizado."

# Fonte e icones da identidade (pacotes do Debian). Os templates novos
# podem usar icones novos, entao isto roda a cada atualizacao.
info "Preparando fonte e icones do painel..."
MISSING_PKGS=()
for pkg in fonts-inter-variable bootstrap-icons cloud-guest-utils; do
    dpkg-query -W -f='${db:Status-Status}' "${pkg}" 2>/dev/null | grep -qx installed || \
        MISSING_PKGS+=("${pkg}")
done
if ((${#MISSING_PKGS[@]} > 0)); then
    # Um NewOS recem-instalado nao tem indices do APT (o build apaga
    # /var/lib/apt/lists): sem o update, "pacote nao encontrado".
    info "Instalando ${MISSING_PKGS[*]}..."
    apt-get update -qq >/dev/null 2>&1 || warn "apt-get update falhou (sem internet?)."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "${MISSING_PKGS[@]}" >/dev/null || \
        warn "Nao foi possivel instalar ${MISSING_PKGS[*]}."
fi
bash "${PANEL_SRC}/bin/newos-panel-assets" "${PANEL_INSTALL_DIR}" || \
    die "newos-panel-assets falhou; revertendo."

# ---------------------------------------------------------------------
# 3. Dependencias Python
# ---------------------------------------------------------------------
VENV_PY="${PANEL_INSTALL_DIR}/venv/bin/python"

if [[ ! -x "${VENV_PY}" ]]; then
    info "Virtualenv ausente; criando..."
    python3 -m venv --system-site-packages "${PANEL_INSTALL_DIR}/venv"
    DO_DEPS=1
fi

if [[ "${DO_DEPS}" -eq 1 ]]; then
    info "Instalando/atualizando as dependencias Python..."
    if "${PANEL_INSTALL_DIR}/venv/bin/pip" install --no-cache-dir -q \
            -r "${PANEL_INSTALL_DIR}/requirements.txt"; then
        ok "Dependencias em dia."
    else
        warn "pip falhou (sem internet?). Seguindo com o que ja estava instalado."
    fi
else
    info "--no-deps: pulando o pip."
fi

# ---------------------------------------------------------------------
# 4. Verificacao real: o app importa?
# ---------------------------------------------------------------------
info "Verificando se o app carrega..."
if ( cd "${PANEL_INSTALL_DIR}" && \
     NEWOS_CONF="${CONFIG}" "${VENV_PY}" -c 'import app.main' ); then
    ok "app.main importou sem erro."
else
    die "O app novo nao importa. Nada foi ativado; revertendo."
fi

# ---------------------------------------------------------------------
# 5. Integracao (systemd, sudoers, nginx, helper)
# ---------------------------------------------------------------------
render() {
    sed -e "s|@PANEL_INSTALL_DIR@|${PANEL_INSTALL_DIR}|g" \
        -e "s|@PANEL_SYSTEM_USER@|${PANEL_SYSTEM_USER}|g" \
        -e "s|@PANEL_HTTP_PORT@|${PANEL_HTTP_PORT}|g" \
        -e "s|@PANEL_BIND_HOST@|${PANEL_BIND_HOST}|g" \
        -e "s|@PANEL_BIND_PORT@|${PANEL_BIND_PORT}|g" \
        -e "s|@IPV6_PREFIX@|${IPV6_PREFIX}|g" \
        "$1" >"$2"
}

if [[ -e /proc/net/if_inet6 ]]; then IPV6_PREFIX=""; else IPV6_PREFIX="# "; fi

# --- helper privilegiado -------------------------------------------
if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-netapply" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-netapply" \
                    /usr/local/sbin/newos-netapply
    ok "Helper de rede atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-storage" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-storage" \
                    /usr/local/sbin/newos-storage
    ok "Helper de discos atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-backup" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-backup" \
                    /usr/local/sbin/newos-backup
    ok "Helper de backup atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-system" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-system" /usr/local/sbin/newos-system
    ok "Helper de sistema atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-ntp" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-ntp" /usr/local/sbin/newos-ntp
    ok "Hora certa: $(/usr/local/sbin/newos-ntp apply 2>/dev/null || echo 'nao ajustada')"
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-terminal" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-terminal" /usr/local/sbin/newos-terminal
    ok "Terminal do painel atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-firewall" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-firewall" /usr/local/sbin/newos-firewall
    ok "Helper do firewall atualizado."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-sysbackup" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-sysbackup" /usr/local/sbin/newos-sysbackup
    install -d -m 0700 /var/lib/newos-sysbackup
    for u in newos-sysbackup.service newos-sysbackup.timer; do
        install -m 0644 "${PANEL_INSTALL_DIR}/systemd/${u}" "/etc/systemd/system/${u}"
    done
    systemctl daemon-reload
    ok "Backup do sistema: helper e agendador atualizados."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-update" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-update" /usr/local/sbin/newos-update
    install -d -m 0755 /var/lib/newos-update
    for u in newos-update-check.service newos-update-check.timer; do
        install -m 0644 "${PANEL_INSTALL_DIR}/systemd/${u}" "/etc/systemd/system/${u}"
    done
    systemctl daemon-reload
    systemctl enable --now newos-update-check.timer >/dev/null 2>&1 || true
    ok "Atualizacoes automaticas: verificacao diaria ativa."
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-prometheus" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-prometheus" \
                    /usr/local/sbin/newos-prometheus
    ok "Helper do Prometheus atualizado."
    # Prometheus ja instalado: regera os arquivos com o helper novo (no modo
    # manual o prometheus.yml do administrador fica intacto). O promtool
    # valida antes; se recusar, nada muda e a atualizacao segue.
    if [[ -x /usr/local/bin/prometheus && -f /etc/newos/prometheus.json ]]; then
        if /usr/local/sbin/newos-prometheus render >/dev/null 2>&1; then
            ok "Configuracao do Prometheus regerada."
        else
            warn "Prometheus: configuracao nao regerada (veja Monitoramento > Prometheus)."
        fi
    fi
fi

if [[ -f "${PANEL_INSTALL_DIR}/bin/newos-modctl" ]]; then
    install -m 0755 "${PANEL_INSTALL_DIR}/bin/newos-modctl" \
                    /usr/local/sbin/newos-modctl
    ok "Helper de modulos atualizado."
fi

# O site do painel faz include deste diretorio; precisa existir.
mkdir -p /etc/nginx/newos-modules
touch /etc/nginx/newos-modules/.keep

# --- unidade systemd ------------------------------------------------
if [[ -f "${PANEL_INSTALL_DIR}/systemd/newos-panel.service" ]]; then
    render "${PANEL_INSTALL_DIR}/systemd/newos-panel.service" \
           /etc/systemd/system/newos-panel.service
    chmod 0644 /etc/systemd/system/newos-panel.service
    systemctl daemon-reload
    ok "newos-panel.service atualizado."
fi

# --- sudoers --------------------------------------------------------
if [[ -f "${PANEL_INSTALL_DIR}/sudoers/newos-panel.in" ]]; then
    render "${PANEL_INSTALL_DIR}/sudoers/newos-panel.in" /tmp/newos-panel.sudoers
    if visudo -c -f /tmp/newos-panel.sudoers >/dev/null 2>&1; then
        install -m 0440 -o root -g root /tmp/newos-panel.sudoers \
                        /etc/sudoers.d/newos-panel
        ok "sudoers atualizado e validado."
    else
        warn "sudoers gerado e invalido; mantendo o anterior."
    fi
    rm -f /tmp/newos-panel.sudoers
fi

# --- nginx ----------------------------------------------------------
if [[ -f "${PANEL_INSTALL_DIR}/nginx/newos-panel.conf.in" ]]; then
    render "${PANEL_INSTALL_DIR}/nginx/newos-panel.conf.in" \
           /etc/nginx/sites-available/newos-panel
    ln -sf /etc/nginx/sites-available/newos-panel \
           /etc/nginx/sites-enabled/newos-panel
    if nginx -t >/dev/null 2>&1; then
        ok "nginx validado."
    else
        warn "nginx -t reprovou; veja: nginx -t"
    fi
fi

# ---------------------------------------------------------------------
# 6. Esquema do banco (idempotente)
# ---------------------------------------------------------------------
MYSQL="mariadb"; command -v mariadb >/dev/null 2>&1 || MYSQL="mysql"
if [[ -f "${PANEL_INSTALL_DIR}/sql/schema.sql" ]] && \
   "${MYSQL}" -e "USE \`${PANEL_DB_NAME}\`" >/dev/null 2>&1; then
    info "Reaplicando o esquema (CREATE TABLE IF NOT EXISTS)..."
    if "${MYSQL}" "${PANEL_DB_NAME}" <"${PANEL_INSTALL_DIR}/sql/schema.sql"; then
        ok "Esquema em dia."
    else
        warn "Nao foi possivel reaplicar o esquema."
    fi
fi

# ---------------------------------------------------------------------
# 7. Permissoes
# ---------------------------------------------------------------------
chown -R root:root "${PANEL_INSTALL_DIR}"
[[ -d "${PANEL_INSTALL_DIR}/venv" ]] && \
    chown -R "${PANEL_SYSTEM_USER}:${PANEL_SYSTEM_USER}" "${PANEL_INSTALL_DIR}/venv"
find "${PANEL_INSTALL_DIR}" -type d -exec chmod 0755 {} +
find "${PANEL_INSTALL_DIR}" -type f -exec chmod 0644 {} +
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-netapply" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-modctl" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-panel-assets" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-storage" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-backup" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-prometheus" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-update" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-system" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-sysbackup" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/bin/newos-firewall" 2>/dev/null || true
find "${PANEL_INSTALL_DIR}/modules" -name '*.sh' -exec chmod 0755 {} + 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/update-panel.sh" 2>/dev/null || true
chmod 0755 "${PANEL_INSTALL_DIR}/venv/bin/"* 2>/dev/null || true

trap - ERR
ROLLBACK_ARMED=0

# ---------------------------------------------------------------------
# 7.1 Versao do sistema
#     O pacote do deploy-panel.sh traz RELEASE com a versao do produto.
#     Atualizamos onde o servidor "diz" a versao dele: release, painel,
#     newos.conf e os-release (o que aparece no login e no "cat").
# ---------------------------------------------------------------------
if [[ -f "${PANEL_SRC}/RELEASE" ]]; then
    NEW_VERSION="$(sed -n 's/^NEWOS_VERSION="\([^"]*\)".*/\1/p' "${PANEL_SRC}/RELEASE")"
    NEW_SOURCE="$(sed -n 's/^NEWOS_SOURCE="\([^"]*\)".*/\1/p' "${PANEL_SRC}/RELEASE")"
    if [[ "${NEW_VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        OLD_VERSION="${NEWOS_VERSION:-?}"
        cat >/etc/newos/release <<EOF
# ${NEWOS_NAME:-NewOS} - versao instalada (nao edite: gerado pelo build e pelas atualizacoes)
NEWOS_VERSION="${NEW_VERSION}"
NEWOS_SOURCE="${NEW_SOURCE}"
NEWOS_INSTALLED_FROM="update"
NEWOS_UPDATED="$(date -Is)"
EOF
        chmod 0644 /etc/newos/release
        for f in /etc/newos/newos.conf /etc/newos/panel.env; do
            [[ -f "${f}" ]] && sed -i "s/^NEWOS_VERSION=.*/NEWOS_VERSION=\"${NEW_VERSION}\"/" "${f}"
        done
        [[ -f /usr/lib/os-release ]] && \
            sed -i "s/^VERSION_ID=.*/VERSION_ID=\"${NEW_VERSION}\"/" /usr/lib/os-release
        # Troca o texto da versao antiga so se ela for uma versao de
        # verdade (ex.: v1.0.0 ou 1.0.0) -- nunca um padrao generico.
        if [[ "${OLD_VERSION}" =~ ^v?[0-9]+\.[0-9]+\.[0-9]+$ && "${OLD_VERSION}" != "${NEW_VERSION}" ]]; then
            sed -i "s/${OLD_VERSION//./\\.}/${NEW_VERSION}/g" \
                /usr/lib/os-release /etc/issue /etc/motd /etc/lsb-release 2>/dev/null || true
        fi
        ok "Versao do sistema: ${OLD_VERSION} -> ${NEW_VERSION} (${NEW_SOURCE})."
    else
        warn "RELEASE com versao invalida (${NEW_VERSION}); versao do sistema mantida."
    fi
fi

# ---------------------------------------------------------------------
# 8. Reiniciar
# ---------------------------------------------------------------------
if [[ "${DO_RESTART}" -eq 1 ]]; then
    info "Reiniciando os servicos..."
    systemctl restart newos-panel
    systemctl reload nginx 2>/dev/null || systemctl restart nginx 2>/dev/null || true

    sleep 2
    HEALTH=0
    for _ in $(seq 1 20); do
        if curl -fsS --max-time 3 \
             "http://${PANEL_BIND_HOST}:${PANEL_BIND_PORT}/healthz" >/dev/null 2>&1; then
            HEALTH=1; break
        fi
        sleep 1
    done

    if [[ "${HEALTH}" -eq 1 ]]; then
        ok "Painel respondendo."
    else
        warn "O painel nao respondeu ao /healthz."
        warn "Diagnostique com: journalctl -u newos-panel -n 40 --no-pager"
        warn "Para voltar a versao anterior:"
        warn "    systemctl stop newos-panel"
        warn "    rm -rf ${PANEL_INSTALL_DIR} && mv ${BACKUP} ${PANEL_INSTALL_DIR}"
        warn "    systemctl start newos-panel"
        exit 1
    fi
else
    info "--no-restart: reinicie voce mesmo com 'systemctl restart newos-panel'."
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
printf '\n%s  Painel atualizado.%s\n' "${G}" "${N}"
printf '  Acesse: http://%s:%s\n' "${IP:-<ip-do-servidor>}" "${PANEL_HTTP_PORT}"
printf '  Backup da versao anterior: %s\n' "${BACKUP}"
printf '  (pode apagar quando tiver certeza de que esta tudo bem)\n\n'
