#!/usr/bin/env bash
set -Eeuo pipefail
printf 'installed=%s\n' "$(dpkg-query -W -f='${Status}' rsyslog-gnutls 2>/dev/null | grep -q 'ok installed' && echo yes || echo no)"
printf 'active=%s\n' "$([[ -f /etc/rsyslog.d/60-newos-logs.conf ]] && systemctl is-active -q rsyslog.service && echo yes || echo no)"
