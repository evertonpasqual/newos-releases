#!/usr/bin/env bash
# =====================================================================
#  Modulo Logs (Graylog) - desligar
#  Para de receber e de enviar (o rsyslog do sistema continua). A copia
#  local e o certificado ficam; a fila ainda nao enviada e descartada.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="logs"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

/usr/local/sbin/newos-logs disable >/dev/null 2>&1 || true
systemctl disable --now newos-logs-clean.timer >/dev/null 2>&1 || true
rm -f /etc/systemd/system/newos-logs-clean.service /etc/systemd/system/newos-logs-clean.timer
systemctl daemon-reload
rm -f /var/spool/rsyslog/newos_graylog*
mod_info "Logs desligado. Copia local guardada em /var/log/newos-logs."
