#!/usr/bin/env bash
# Estado do modulo Firewall, em pares chave=valor.
set -Eeuo pipefail
printf 'installed=%s\n' "$(command -v nft >/dev/null 2>&1 && echo yes || echo no)"
printf 'active=%s\n' "$(nft list table inet newos >/dev/null 2>&1 && echo yes || echo no)"
