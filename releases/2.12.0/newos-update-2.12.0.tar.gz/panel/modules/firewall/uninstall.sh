#!/usr/bin/env bash
# =====================================================================
#  Modulo Firewall - remocao: tira as regras do NewOS (tudo liberado).
#  A configuracao fica guardada em /etc/newos/firewall.json: religar
#  volta como estava.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="firewall"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

/usr/local/sbin/newos-firewall disable >/dev/null || true
if [[ -f /etc/nftables.conf.newos-orig ]]; then
    cp -f /etc/nftables.conf.newos-orig /etc/nftables.conf
else
    printf '#!/usr/sbin/nft -f\nflush ruleset\n' >/etc/nftables.conf
fi
mod_info "Firewall desligado: tudo liberado. A configuracao ficou guardada para religar."
