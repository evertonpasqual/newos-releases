#!/usr/bin/env bash
# =====================================================================
#  Modulo Firewall - instalacao
#  Chamado por: newos-modctl install firewall
#  nftables do Debian; na 1a vez libera as portas que ja estavam em uso
#  (nada para de funcionar ao ligar) e passa a bloquear o resto.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="firewall"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

if ! command -v nft >/dev/null 2>&1; then
    apt_require_healthy
    apt_ensure_lists
    mod_info "Instalando o nftables..."
    apt_install nftables
fi
modprobe nf_tables 2>/dev/null || true
mod_info "Ligando o firewall (o que ja estava em uso continua liberado)..."
/usr/local/sbin/newos-firewall install-defaults | sed -n 's/.*"message": "\([^"]*\)".*/[firewall] \1/p'
mod_info "Pronto. Ajuste em Firewall > Regras; o registro do que foi bloqueado fica em Firewall > Visao geral."
