#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - remocao
# ---------------------------------------------------------------------
#  Para os servicos e remove os pacotes do Zabbix.
#  NAO apaga o banco do proxy: perder dados nunca deve ser efeito
#  colateral de desligar um botao.
# =====================================================================
set -Eeuo pipefail

echo "[zabbix] Parando os servicos..."
systemctl disable --now zabbix-agent2 2>/dev/null || true
systemctl disable --now zabbix-proxy  2>/dev/null || true

echo "[zabbix] Removendo os pacotes..."
apt-get purge -y 'zabbix-agent2*' zabbix-proxy-mysql zabbix-sql-scripts 2>/dev/null || true
apt-get autoremove -y 2>/dev/null || true

echo "[zabbix] Modulo removido."
echo "[zabbix] Preservados de proposito:"
echo "[zabbix]   - banco zabbix_proxy   (apagar: mariadb -e 'DROP DATABASE zabbix_proxy;')"
echo "[zabbix]   - /etc/newos/zabbix-proxy.env"
echo "[zabbix]   - repositorio zabbix-release"
