#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - liga/desliga um componente
# ---------------------------------------------------------------------
#  Uso: component.sh <agent2|proxy> <enable|disable>
#  Chamado por: newos-modctl component zabbix <comp> <acao>
# =====================================================================
set -Eeuo pipefail

# MOD_TAG e lido pelas funcoes de log do modlib.sh.
# shellcheck disable=SC2034
MOD_TAG="zabbix"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"
# shellcheck source=lib.sh
source "$(cd "$(dirname "$0")" && pwd)/lib.sh"

COMPONENT="${1:?uso: component.sh <agent2|proxy> <enable|disable>}"
ACTION="${2:?uso: component.sh <agent2|proxy> <enable|disable>}"

ZBX_ENV="/etc/newos/zabbix-proxy.env"
PROXY_DB="zabbix_proxy"
PROXY_DB_USER="zabbix"

MYSQL="mariadb"; MYSQLADMIN="mariadb-admin"
if ! command -v mariadb >/dev/null 2>&1; then MYSQL="mysql"; MYSQLADMIN="mysqladmin"; fi

# =====================================================================
#  AGENT 2
# =====================================================================
enable_agent2() {
    echo "[zabbix] Instalando o Zabbix Agent 2..."
    apt_require_healthy
    # Sem isto o apt instalaria o zabbix-agent2 7.0 do proprio Debian.
    pkg_from_origin zabbix-agent2 repo.zabbix.com || \
        mod_die "O repositorio oficial da Zabbix nao esta ativo. Desligue e ligue o modulo de novo." 2

    # -----------------------------------------------------------------
    #  ATENCAO -- BUG JA CORRIGIDO, NAO REINTRODUZA
    #
    #  A versao anterior fazia, alem disto:
    #
    #     plugins=$(apt-cache --names-only search '^zabbix-agent2-plugin-')
    #     apt-get install -y ${plugins}
    #
    #  ou seja, instalava TODOS os plugins do repositorio -- postgresql,
    #  mongodb, mssql, ember-plus... O Agent 2 carrega cada plugin
    #  declarado em /etc/zabbix/zabbix_agent2.d/plugins.d/*.conf no
    #  arranque; se UM deles nao carrega, o agente encerra sozinho logo
    #  depois de subir. Era exatamente o sintoma: o log mostrava
    #  "Zabbix Agent2 hostname: [...]" e, poucos segundos depois,
    #  "Zabbix Agent 2 stopped".
    #
    #  O procedimento oficial instala SO o zabbix-agent2. E o que
    #  fazemos agora. Quem quiser um plugin especifico instala a mao.
    # -----------------------------------------------------------------
    apt_install zabbix-agent2

    agent2_set_defaults

    if svc_enable_start zabbix-agent2; then
        mod_info "Agent 2 ativo na porta 10050."
        return 0
    fi

    # -----------------------------------------------------------------
    #  Auto-reparo: se este servidor ainda tem plugins instalados por
    #  uma versao antiga deste script, eles sao a causa mais provavel.
    #  Removemos e tentamos uma unica vez mais.
    # -----------------------------------------------------------------
    local plugins
    plugins="$({ dpkg-query -W -f='${Package} ${db:Status-Status}\n' 'zabbix-agent2-plugin-*' 2>/dev/null || true; } | \
               awk '$2 == "installed" {print $1}' | tr '\n' ' ')"

    if [[ -n "${plugins// /}" ]]; then
        mod_warn "O agente nao subiu e ha plugins instalados:${plugins:+ ${plugins}}"
        mod_warn "Plugins sao a causa mais comum disso. Removendo e tentando de novo."
        # shellcheck disable=SC2086
        apt-get purge -y ${plugins} 2>&1 | tail -6 | sed 's/^/[zabbix]   /' || true

        if svc_enable_start zabbix-agent2; then
            mod_info "Agent 2 subiu depois de remover os plugins."
            mod_info "Plugins removidos:${plugins:+ ${plugins}}"
            mod_info "Se precisar de algum, instale um por vez e reinicie o agente."
            return 0
        fi
    fi

    mod_die "O Zabbix Agent 2 foi instalado mas nao subiu. Veja o motivo acima." 2
}

# ---------------------------------------------------------------------
# agent2_set_defaults
#   Ajusta o Hostname para o nome desta maquina quando ele ainda esta no
#   valor de fabrica.
#
#   ATENCAO (bug ja corrigido): antes isto era um
#       grep -qE '^\s*Hostname\s*=\s*Zabbix server\s*$' && sed -i ...
#   que so pegava a grafia exata "Hostname=Zabbix server". Qualquer
#   espaco a mais, ou a diretiva ausente (o agente usa o default interno
#   "Zabbix server" nesse caso), passava batido -- e o agente continuava
#   se anunciando como "Zabbix server", como apareceu no log real.
#   Agora a decisao e feita em Python, sobre o valor ja normalizado.
# ---------------------------------------------------------------------
agent2_set_defaults() {
    local conf="/etc/zabbix/zabbix_agent2.conf"
    [[ -f "${conf}" ]] || { mod_warn "${conf} nao existe."; return 0; }

    python3 - "${conf}" "$(hostname)" <<'PY'
import re, sys

path, machine = sys.argv[1], sys.argv[2]
DEFAULTS = {"", "Zabbix server", "Zabbix Agent", "Zabbix agent"}

with open(path, encoding="utf-8", errors="replace") as fh:
    lines = fh.read().splitlines()

current, index = None, None
for i, line in enumerate(lines):
    m = re.match(r"^\s*Hostname\s*=\s*(.*?)\s*$", line)
    if m:
        current, index = m.group(1), i        # fica com a ultima ocorrencia

if current is not None and current not in DEFAULTS:
    print(f"[zabbix] Hostname ja configurado: {current}")
    raise SystemExit(0)

if index is None:
    lines.append("")
    lines.append("### NewOS")
    lines.append(f"Hostname={machine}")
else:
    lines[index] = f"Hostname={machine}"

with open(path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(lines) + "\n")
print(f"[zabbix] Hostname do agente definido como {machine}.")
PY

    chown root:zabbix "${conf}" 2>/dev/null || true
    chmod 0640 "${conf}" 2>/dev/null || true
}

disable_agent2() {
    echo "[zabbix] Parando o Zabbix Agent 2..."
    systemctl disable --now zabbix-agent2 2>/dev/null || true
    echo "[zabbix] Agent 2 parado. Os pacotes continuam instalados."
}

# =====================================================================
#  PROXY
# =====================================================================
enable_proxy() {
    echo "[zabbix] Instalando o Zabbix Proxy (MySQL)..."
    apt_require_healthy
    pkg_from_origin zabbix-proxy-mysql repo.zabbix.com || \
        mod_die "O repositorio oficial da Zabbix nao esta ativo. Desligue e ligue o modulo de novo." 2
    apt_install zabbix-proxy-mysql zabbix-sql-scripts

    # --- MariaDB de pe? ----------------------------------------------
    systemctl is-active --quiet mariadb || systemctl start mariadb
    local ready=0
    for _ in $(seq 1 30); do
        if "${MYSQLADMIN}" ping >/dev/null 2>&1; then
            ready=1; break
        fi
        sleep 1
    done
    [[ "${ready}" -eq 1 ]] || { echo "[zabbix] ERRO: MariaDB nao respondeu." >&2; exit 1; }

    # --- Senha do banco ----------------------------------------------
    # Sorteada uma vez e reaproveitada nas proximas ativacoes, senao o
    # zabbix_proxy.conf ficaria com uma senha que nao confere mais.
    local db_pass=""
    if [[ -f "${ZBX_ENV}" ]]; then
        # shellcheck source=/dev/null
        source "${ZBX_ENV}"
        db_pass="${ZBX_PROXY_DB_PASSWORD:-}"
    fi
    if [[ -z "${db_pass}" ]]; then
        db_pass="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"
        umask 077
        cat >"${ZBX_ENV}" <<EOF
# NewOS - credenciais do banco do Zabbix Proxy
# Gerado em $(date -Is). Nao versione este arquivo.
ZBX_PROXY_DB_NAME="${PROXY_DB}"
ZBX_PROXY_DB_USER="${PROXY_DB_USER}"
ZBX_PROXY_DB_PASSWORD="${db_pass}"
EOF
        chmod 0600 "${ZBX_ENV}"
        umask 022
        echo "[zabbix] Senha do banco sorteada e guardada em ${ZBX_ENV}"
    fi

    # --- Banco e usuario ---------------------------------------------
    echo "[zabbix] Criando o banco ${PROXY_DB}..."
    ${MYSQL} <<SQL
CREATE DATABASE IF NOT EXISTS \`${PROXY_DB}\`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
CREATE USER IF NOT EXISTS '${PROXY_DB_USER}'@'localhost' IDENTIFIED BY '${db_pass}';
ALTER USER '${PROXY_DB_USER}'@'localhost' IDENTIFIED BY '${db_pass}';
GRANT ALL PRIVILEGES ON \`${PROXY_DB}\`.* TO '${PROXY_DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL

    # --- Esquema (so na primeira vez) --------------------------------
    local tables
    tables="$(${MYSQL} -N -B "${PROXY_DB}" -e 'SHOW TABLES;' 2>/dev/null | wc -l)"

    if [[ "${tables}" -lt 5 ]]; then
        # ATENCAO (bug ja corrigido): no Zabbix 7.4 o esquema vem SEM
        # compressao, em /usr/share/zabbix/sql-scripts/mysql/proxy.sql --
        # e o procedimento oficial usa "cat ... | mysql". A versao
        # anterior deste script so procurava proxy.sql.gz (caminho das
        # versoes antigas) e abortava com "nao achei o proxy.sql.gz".
        # Agora procuramos as duas formas, nos tres caminhos conhecidos.
        local schema=""
        for cand in /usr/share/zabbix/sql-scripts/mysql/proxy.sql \
                    /usr/share/zabbix/sql-scripts/mysql/proxy.sql.gz \
                    /usr/share/zabbix-sql-scripts/mysql/proxy.sql \
                    /usr/share/zabbix-sql-scripts/mysql/proxy.sql.gz \
                    /usr/share/doc/zabbix-sql-scripts/mysql/proxy.sql \
                    /usr/share/doc/zabbix-sql-scripts/mysql/proxy.sql.gz; do
            [[ -f "${cand}" ]] && { schema="${cand}"; break; }
        done
        if [[ -z "${schema}" ]]; then
            schema="$(find /usr/share -path '*mysql*' \
                        \( -name 'proxy.sql' -o -name 'proxy.sql.gz' \) \
                        2>/dev/null | head -1)"
        fi

        if [[ -z "${schema}" ]]; then
            echo "[zabbix] ERRO: nao achei o proxy.sql do zabbix-sql-scripts." >&2
            echo "[zabbix] Conteudo instalado pelo pacote:" >&2
            dpkg -L zabbix-sql-scripts 2>/dev/null | grep -i 'sql' | \
                head -20 | sed 's/^/[zabbix]   /' >&2 || \
                echo "[zabbix]   (o pacote zabbix-sql-scripts nao esta instalado)" >&2
            exit 1
        fi

        echo "[zabbix] Importando o esquema de ${schema}..."
        # Exigido pelo procedimento oficial: sem isto o MariaDB recusa
        # criar as funcoes do esquema quando o log binario esta ligado.
        ${MYSQL} -e "SET GLOBAL log_bin_trust_function_creators = 1;" 2>/dev/null || true

        # O arquivo pode vir comprimido ou nao.
        local reader="cat"
        [[ "${schema}" == *.gz ]] && reader="zcat"

        if ! "${reader}" "${schema}" | ${MYSQL} --default-character-set=utf8mb4 \
                -u"${PROXY_DB_USER}" -p"${db_pass}" "${PROXY_DB}"; then
            ${MYSQL} -e "SET GLOBAL log_bin_trust_function_creators = 0;" 2>/dev/null || true
            echo "[zabbix] ERRO: falha ao importar o esquema do proxy." >&2
            exit 1
        fi

        ${MYSQL} -e "SET GLOBAL log_bin_trust_function_creators = 0;" 2>/dev/null || true
        echo "[zabbix] Esquema importado."
    else
        echo "[zabbix] O banco ja tem ${tables} tabelas; esquema preservado."
    fi

    # --- Configuracao -------------------------------------------------
    local conf="/etc/zabbix/zabbix_proxy.conf"
    if [[ -f "${conf}" ]]; then
        python3 - "${conf}" "${PROXY_DB}" "${PROXY_DB_USER}" "${db_pass}" <<'PY'
import re, sys
path, db, user, pwd = sys.argv[1:5]
values = {"DBName": db, "DBUser": user, "DBPassword": pwd}
with open(path, encoding="utf-8", errors="replace") as fh:
    lines = fh.read().splitlines()
seen = set()
out = []
for line in lines:
    m = re.match(r"^\s*(\w+)\s*=", line)
    if m and m.group(1) in values:
        out.append(f"{m.group(1)}={values[m.group(1)]}")
        seen.add(m.group(1))
    else:
        out.append(line)
missing = [k for k in values if k not in seen]
if missing:
    out.append("")
    out.append("### NewOS")
    out += [f"{k}={values[k]}" for k in missing]
with open(path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
PY
        chown root:zabbix "${conf}" 2>/dev/null || true
        chmod 0640 "${conf}" 2>/dev/null || true

        # Hostname padrao = hostname da maquina.
        if grep -qE '^\s*Hostname\s*=\s*Zabbix proxy\s*$' "${conf}"; then
            sed -i "s/^\s*Hostname\s*=.*/Hostname=$(hostname)/" "${conf}"
        fi
        echo "[zabbix] zabbix_proxy.conf ajustado."
        zbx_tune_proxy "${conf}"
    fi

    svc_enable_start zabbix-proxy || \
        mod_die "O Zabbix Proxy foi instalado mas nao subiu. Veja o motivo acima." 2
    mod_info "Proxy ativo na porta 10051."
    echo "[zabbix] Cadastre este proxy no Zabbix Server com o Hostname configurado."
}

disable_proxy() {
    echo "[zabbix] Parando o Zabbix Proxy..."
    systemctl disable --now zabbix-proxy 2>/dev/null || true
    echo "[zabbix] Proxy parado."
    echo "[zabbix] O banco ${PROXY_DB} foi PRESERVADO de proposito."
    echo "[zabbix] Para apagar mesmo: mariadb -e 'DROP DATABASE ${PROXY_DB};'"
}

# =====================================================================
#  MAIN
# =====================================================================
case "${COMPONENT}:${ACTION}" in
    agent2:enable)  enable_agent2  ;;
    agent2:disable) disable_agent2 ;;
    proxy:enable)   enable_proxy   ;;
    proxy:disable)  disable_proxy  ;;
    *) echo "Componente ou acao invalidos: ${COMPONENT}:${ACTION}" >&2; exit 1 ;;
esac
