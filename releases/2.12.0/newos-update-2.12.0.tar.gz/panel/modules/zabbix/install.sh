#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - instalacao do repositorio oficial
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl install zabbix
#  Roda como root. Precisa de internet.
#
#  Procedimento oficial da Zabbix para 7.4 / Debian 13 / MySQL:
#      https://www.zabbix.com/download
#
#  Aqui so preparamos o repositorio. Os pacotes de cada componente sao
#  instalados quando o botao daquele componente e ligado.
#
#  ---------------------------------------------------------------------
#  HISTORICO (nao repita estes erros)
#
#  1) A versao anterior usava "dpkg -s zabbix-release" para decidir se
#     ja estava instalado. Esse comando retorna 0 TAMBEM quando o pacote
#     esta meio-instalado. Resultado: numa segunda tentativa o script
#     pulava a instalacao e reportava sucesso com o repositorio ausente.
#     Agora usamos pkg_installed(), que exige Status-Status=installed.
#
#  2) Um zabbix-release meio-instalado TRAVA O APT INTEIRO: como esse
#     pacote nao vem de nenhum repositorio (ele e quem ADICIONA o
#     repositorio), o apt nao consegue reinstala-lo e passa a recusar
#     qualquer operacao -- inclusive a de outros modulos. Por isso agora
#     checamos a saude do APT antes e limpamos o estado quebrado.
# =====================================================================
set -Eeuo pipefail

# MOD_TAG e lido pelas funcoes de log do modlib.sh.
# shellcheck disable=SC2034
MOD_TAG="zabbix"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

# shellcheck source=lib.sh
source "${NEWOS_MODULE_DIR:-$(dirname "$0")}/lib.sh"
ZBX_VERSION="$(zbx_version)"            # escolhida no painel (padrao 7.4)
ZBX_URL="$(zbx_release_url "${ZBX_VERSION}")"
ZBX_DEB="$(basename "${ZBX_URL}")"

mod_info "Preparando o repositorio oficial Zabbix ${ZBX_VERSION}..."

# ---------------------------------------------------------------------
# 1. O APT deste servidor esta saudavel?
# ---------------------------------------------------------------------
apt_require_healthy
apt_ensure_lists

# ---------------------------------------------------------------------
# 2. Ja esta instalado DE VERDADE e o repositorio responde?
# ---------------------------------------------------------------------
# NAO basta "pkg_exists zabbix-agent2": o Debian tem um zabbix-agent2
# proprio (7.0). Exigimos que o candidato venha de repo.zabbix.com.
if pkg_installed zabbix-release && pkg_from_origin zabbix-agent2 repo.zabbix.com && \
   [[ "$(zbx_repo_installed)" == "${ZBX_VERSION}" ]]; then
    mod_info "Repositorio Zabbix ja configurado; atualizando os indices."
    apt-get update -qq || mod_die "apt-get update falhou." 2
    mod_info "Repositorio pronto."
    exit 0
fi

# ---------------------------------------------------------------------
# 3. Limpa restos de uma tentativa anterior
# ---------------------------------------------------------------------
apt_cleanup_broken zabbix-release

# Repositorio de OUTRA versao: sai antes de entrar o da versao escolhida.
if pkg_installed zabbix-release && [[ "$(zbx_repo_installed)" != "${ZBX_VERSION}" ]]; then
    mod_info "Trocando o repositorio $(zbx_repo_installed) pelo ${ZBX_VERSION}..."
    dpkg --purge zabbix-release >/dev/null 2>&1 || dpkg --purge --force-all zabbix-release >/dev/null 2>&1 || true
    rm -f /etc/apt/sources.list.d/zabbix*.sources \
          /etc/apt/sources.list.d/zabbix*.list 2>/dev/null || true
fi

# Sem zabbix-release instalado, NENHUMA fonte zabbix pode sobrar: o pacote
# de cada versao cria arquivos com nomes diferentes (o da 8.0 cria
# zabbix-unstable.sources, zabbix-tools.sources...). Uma fonte de outra
# versao esquecida faz o APT continuar oferecendo os pacotes dela.
if ! pkg_installed zabbix-release; then
    rm -f /etc/apt/sources.list.d/zabbix*.sources \
          /etc/apt/sources.list.d/zabbix*.list 2>/dev/null || true
fi

# ---------------------------------------------------------------------
# 4. Internet
# ---------------------------------------------------------------------
if ! have_internet "${ZBX_URL}"; then
    mod_err "Nao consegui alcancar repo.zabbix.com."
    mod_err "Este modulo precisa de internet para instalar."
    mod_err "Confira no console do servidor:"
    mod_err "    ping -c1 repo.zabbix.com"
    mod_err "    curl -I ${ZBX_URL}"
    exit 2
fi

# ---------------------------------------------------------------------
# 5. Baixa, valida e instala o pacote de repositorio
# ---------------------------------------------------------------------
TMP="$(mktemp -d)"
trap 'rm -rf "${TMP}"' EXIT

download_verified "${ZBX_URL}" "${TMP}/${ZBX_DEB}" 2048
dpkg_install_deb "${TMP}/${ZBX_DEB}"

pkg_installed zabbix-release || \
    mod_die "O zabbix-release nao ficou instalado corretamente." 2

# ---------------------------------------------------------------------
# 6. Atualiza os indices
# ---------------------------------------------------------------------
mod_info "Atualizando os indices do APT..."
if ! apt-get update -qq; then
    mod_err "apt-get update falhou depois de adicionar o repositorio."
    mod_err "Removendo o zabbix-release para nao deixar o APT travado."
    dpkg --purge --force-all zabbix-release >/dev/null 2>&1 || true
    rm -f /etc/apt/sources.list.d/zabbix.sources \
          /etc/apt/sources.list.d/zabbix.list 2>/dev/null || true
    apt-get update -qq >/dev/null 2>&1 || true
    exit 2
fi

# ---------------------------------------------------------------------
# 7. Os pacotes ficaram mesmo visiveis?
# ---------------------------------------------------------------------
MISSING=""
for p in zabbix-agent2 zabbix-proxy-mysql zabbix-sql-scripts; do
    pkg_from_origin "${p}" repo.zabbix.com || MISSING+=" ${p}"
done

if [[ -n "${MISSING}" ]]; then
    mod_err "Os pacotes nao apareceram no APT:${MISSING}"
    mod_err "Conteudo de /etc/apt/sources.list.d/:"
    ls -1 /etc/apt/sources.list.d/ 2>/dev/null | sed 's/^/[zabbix]   /' >&2 || true
    mod_err "Removendo o zabbix-release para nao deixar o APT travado."
    dpkg --purge --force-all zabbix-release >/dev/null 2>&1 || true
    apt-get update -qq >/dev/null 2>&1 || true
    exit 2
fi

mod_info "Repositorio Zabbix ${ZBX_VERSION} pronto."
# Hosts sem internet: o zabbix-agent2 desta serie fica guardado aqui (baixa em segundo plano)
/usr/local/sbin/newos-pkgrepo sync zabbix >/dev/null 2>&1 || true
mod_info "Agora ligue o Agent 2 e/ou o Proxy nos botoes deste modulo."
