#!/usr/bin/env bash
# Estado do modulo Zabbix, em pares chave=valor.
set -Eeuo pipefail
printf 'repository=%s\n' "$(dpkg -s zabbix-release >/dev/null 2>&1 && echo yes || echo no)"
printf 'agent2_installed=%s\n' "$(dpkg -s zabbix-agent2 >/dev/null 2>&1 && echo yes || echo no)"
printf 'agent2_active=%s\n' "$(systemctl is-active zabbix-agent2 2>/dev/null || echo inactive)"
printf 'proxy_installed=%s\n' "$(dpkg -s zabbix-proxy-mysql >/dev/null 2>&1 && echo yes || echo no)"
printf 'proxy_active=%s\n' "$(systemctl is-active zabbix-proxy 2>/dev/null || echo inactive)"
MYSQL="mariadb"; command -v mariadb >/dev/null 2>&1 || MYSQL="mysql"
printf 'proxy_db=%s\n' "$(${MYSQL} -e 'USE zabbix_proxy' >/dev/null 2>&1 && echo yes || echo no)"
