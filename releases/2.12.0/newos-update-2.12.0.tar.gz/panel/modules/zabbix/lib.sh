#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - versao do repositorio oficial
# ---------------------------------------------------------------------
#  A versao escolhida no painel fica em /etc/newos/zabbix.version
#  (padrao 7.4). Sempre do repositorio oficial da Zabbix:
#      https://www.zabbix.com/download
#  O 7.0 LTS usa o caminho antigo (sem "release/"); 7.4 e 8.0, o novo.
# =====================================================================
# shellcheck disable=SC2034
ZBX_VERSION_FILE="/etc/newos/zabbix.version"
ZBX_VERSIONS="7.0 7.4 8.0"

zbx_version() {
    local v
    v=""
    [[ -r "${ZBX_VERSION_FILE}" ]] && v="$(tr -d ' \n' <"${ZBX_VERSION_FILE}")"
    [[ " ${ZBX_VERSIONS} " == *" ${v} "* ]] || v="7.4"
    printf '%s' "${v}"
}

zbx_release_url() {
    local v="$1" path="release/debian"
    [[ "${v}" == "7.0" ]] && path="debian"
    printf 'https://repo.zabbix.com/zabbix/%s/%s/pool/main/z/zabbix-release/zabbix-release_latest_%s+debian13_all.deb' \
        "${v}" "${path}" "${v}"
}

# Versao do repositorio instalado agora ("7.4"), lida do zabbix-release.
zbx_repo_installed() {
    { dpkg-query -W -f='${Version}' zabbix-release 2>/dev/null || true; } | sed -nE 's/^([0-9]+:)?([0-9]+\.[0-9]+).*/\2/p'
}

# ---------------------------------------------------------------------
# Perfil do Proxy: ja sai otimizado para ~50 hosts (agentes, SNMP, ping,
# descoberta) e VMware, com o Server central da NewFront. Aplicado so na
# PRIMEIRA instalacao (marca em /etc/newos/zabbix-proxy.tuned): o que o
# administrador mudar depois e preservado. "Aplicar o perfil otimizado"
# no painel grava de novo (action.sh tune-proxy).
# ---------------------------------------------------------------------
ZBX_PROXY_SERVER_DEFAULT="mon.newfront.cloud"
ZBX_PROXY_TUNED="/etc/newos/zabbix-proxy.tuned"
ZBX_PROXY_PROFILE=(
    "ProxyConfigFrequency=60"        # busca a configuracao a cada 1 min
    "DataSenderFrequency=1"
    "StartPollers=10"                # agentes passivos e checks simples
    "StartPollersUnreachable=3"
    "StartPingers=4"                 # ICMP
    "StartDiscoverers=5"
    "StartHTTPPollers=2"
    "StartPreprocessors=8"
    "StartDBSyncers=4"
    "StartVMwareCollectors=4"        # vCenter/ESXi
    "VMwareFrequency=60"
    "VMwarePerfFrequency=60"
    "VMwareCacheSize=64M"
    "VMwareTimeout=30"
    "CacheSize=128M"                 # configuracao (hosts, itens)
    "HistoryCacheSize=64M"
    "HistoryIndexCacheSize=16M"
    "Timeout=10"
    "ProxyOfflineBuffer=24"          # 1 dia de dados se o Server cair
    "ProxyBufferMode=hybrid"         # fila em memoria, banco so se encher
    "ProxyMemoryBufferSize=64M"
    "LogSlowQueries=3000"
)

# zbx_tune_proxy <conf> [force] -> aplica o perfil (e o Server padrao se
# ainda estiver no 127.0.0.1 do pacote); valida com zabbix_proxy -T e
# volta o arquivo anterior se o Zabbix recusar.
zbx_tune_proxy() {
    local conf="$1" force="${2:-}"
    [[ -f "${conf}" ]] || return 0
    [[ -f "${ZBX_PROXY_TUNED}" && "${force}" != force ]] && return 0
    cp -f "${conf}" "${conf}.pre-tune"
    python3 - "${conf}" "${ZBX_PROXY_SERVER_DEFAULT}" "${ZBX_PROXY_PROFILE[@]%%#*}" <<'PY'
import re, sys
path, server, *pairs = sys.argv[1:]
values = dict(p.strip().split("=", 1) for p in pairs if "=" in p)
with open(path, encoding="utf-8", errors="replace") as fh:
    lines = fh.read().splitlines()
cur = {}
for ln in lines:
    m = re.match(r"^\s*(\w+)\s*=\s*(.*)$", ln)
    if m:
        cur[m.group(1)] = m.group(2).strip()
if cur.get("Server", "") in ("", "127.0.0.1", "localhost"):
    values["Server"] = server
seen, out = set(), []
for ln in lines:
    m = re.match(r"^\s*(\w+)\s*=", ln)
    if m and m.group(1) in values:
        if m.group(1) not in seen:
            out.append(f"{m.group(1)}={values[m.group(1)]}")
            seen.add(m.group(1))
        continue
    out.append(ln)
rest = [k for k in values if k not in seen]
if rest:
    out += ["", "### NewOS: perfil otimizado (~50 hosts + VMware)"] + [f"{k}={values[k]}" for k in rest]
with open(path, "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
PY
    if command -v zabbix_proxy >/dev/null 2>&1 && ! zabbix_proxy -T -c "${conf}" >/dev/null 2>&1; then
        echo "[zabbix] AVISO: o Zabbix recusou o perfil otimizado; mantida a configuracao anterior." >&2
        zabbix_proxy -T -c "${conf}" 2>&1 | tail -3 | sed 's/^/[zabbix]   /' >&2 || true
        cp -f "${conf}.pre-tune" "${conf}"
        return 0
    fi
    : >"${ZBX_PROXY_TUNED}"
    echo "[zabbix] Perfil otimizado aplicado (~50 hosts + VMware; Server $(grep -oP '^\s*Server\s*=\s*\K.*' "${conf}" | tail -1))."
}
