#!/usr/bin/env bash
# =====================================================================
#  Modulo Zabbix - acoes do painel
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl action zabbix <acao> [arg]
#
#    info                     estado em chave=valor (versoes, servicos...)
#    set-version <7.0|7.4|8.0> troca o repositorio oficial e leva junto o
#                             que estiver instalado (agent e/ou proxy)
#    log  <agent2|proxy>      ultimas linhas do log
#    test <agent2|proxy>      este servidor alcanca o(s) Server(s)?
#    tune-proxy               grava de novo o perfil otimizado do proxy
# =====================================================================
set -Eeuo pipefail

# shellcheck disable=SC2034
MOD_TAG="zabbix"
DIR="${NEWOS_MODULE_DIR:-$(cd "$(dirname "$0")" && pwd)}"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"
# shellcheck source=lib.sh
source "${DIR}/lib.sh"

ACTION="${1:?uso: action.sh <info|set-version|log|test> [arg]}"
shift || true

# Pacote nao instalado: dpkg-query sai com erro e, com pipefail, derrubaria
# o script (era o erro ao trocar a versao antes de ligar agent/proxy).
pkgver() { { dpkg-query -W -f='${db:Status-Status} ${Version}' "$1" 2>/dev/null || true; } | awk '$1=="installed"{print $2}'; }
candidate() { LC_ALL=C apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/{print $2}'; }
# Versao mais nova de um pacote DENTRO do repositorio da serie escolhida
# (repo.zabbix.com/zabbix/<serie>/). Necessario para descer de versao: o
# apt nunca rebaixa sozinho, e a 8.0 usa epoch 2 ("2:8.0..."), que vence
# qualquer 7.x na comparacao.
series_version() {
    local pkg="$1" serie="$2"
    local out
    out="$(LC_ALL=C apt-cache madison "${pkg}" 2>/dev/null || true)"
    # Le tudo antes (sem "exit" no awk: SIGPIPE + pipefail derrubaria o script).
    awk -F'|' -v s="/zabbix/${serie}/" '!f && $3 ~ s {gsub(/ /, "", $2); print $2; f=1}' <<<"${out}"
}
conf_of() { case "$1" in agent2) echo /etc/zabbix/zabbix_agent2.conf ;; proxy) echo /etc/zabbix/zabbix_proxy.conf ;; *) mod_die "Componente invalido: $1" ;; esac; }
svc_of()  { case "$1" in agent2) echo zabbix-agent2 ;; proxy) echo zabbix-proxy ;; esac; }
conf_val() { grep -oP "^\s*$2\s*=\s*\K.*$" "$1" 2>/dev/null | tail -1 || true; }

case "${ACTION}" in
info)
    printf 'version=%s\n' "$(zbx_version)"
    printf 'repo=%s\n' "$(zbx_repo_installed)"
    printf 'versions=%s\n' "${ZBX_VERSIONS}"
    for c in agent2 proxy; do
        pkg=zabbix-agent2; [[ "${c}" == proxy ]] && pkg=zabbix-proxy-mysql
        printf '%s_pkg=%s\n' "${c}" "$(pkgver "${pkg}")"
        printf '%s_candidate=%s\n' "${c}" "$(candidate "${pkg}")"
        printf '%s_active=%s\n' "${c}" "$(systemctl is-active "$(svc_of "${c}")" 2>/dev/null || true)"
        printf '%s_since=%s\n' "${c}" "$(systemctl show -p ActiveEnterTimestamp --value "$(svc_of "${c}")" 2>/dev/null || true)"
        printf '%s_mem=%s\n' "${c}" "$(systemctl show -p MemoryCurrent --value "$(svc_of "${c}")" 2>/dev/null || true)"
    done
    MYSQL="mariadb"; command -v mariadb >/dev/null 2>&1 || MYSQL="mysql"
    printf 'proxy_db_bytes=%s\n' "$(${MYSQL} -N -B -e "SELECT COALESCE(SUM(data_length+index_length),0) FROM information_schema.tables WHERE table_schema='zabbix_proxy'" 2>/dev/null || echo 0)"
    printf 'agent2_plugins=%s\n' "$({ dpkg-query -W -f='${Package} ${db:Status-Status}\n' 'zabbix-agent2-plugin-*' 2>/dev/null || true; } | awk '$2=="installed"{printf "%s ", $1}')"
    ;;

set-version)
    v="${1:-}"
    [[ " ${ZBX_VERSIONS} " == *" ${v} "* ]] || mod_die "Versao invalida: '${v}'. Use: ${ZBX_VERSIONS}"
    old="$(zbx_version)"
    agent_was="$(pkgver zabbix-agent2)"; proxy_was="$(pkgver zabbix-proxy-mysql)"
    install -d -m 0755 /etc/newos
    printf '%s\n' "${v}" >"${ZBX_VERSION_FILE}"
    if ! bash "${DIR}/install.sh"; then
        printf '%s\n' "${old}" >"${ZBX_VERSION_FILE}"
        bash "${DIR}/install.sh" >/dev/null 2>&1 || true
        mod_die "Nao consegui ativar o repositorio ${v}; voltei para o ${old}." 2
    fi
    # Leva junto o que ja estava instalado (sobe ou desce de versao).
    if [[ -n "${agent_was}" ]]; then
        target="$(series_version zabbix-agent2 "${v}")"
        [[ -n "${target}" ]] || mod_die "O repositorio ${v} nao oferece o zabbix-agent2." 2
        mod_info "Zabbix Agent 2: ${agent_was} -> ${target}"
        # Versao exata: descendo, "apt install pacote" diria "ja e o mais novo".
        apt_install --allow-downgrades "zabbix-agent2=${target}"
        systemctl restart zabbix-agent2 || true
    fi
    if [[ -n "${proxy_was}" ]]; then
        target="$(series_version zabbix-proxy-mysql "${v}")"
        if [[ -n "${target}" ]] && dpkg --compare-versions "${target}" lt "${proxy_was}"; then
            # O proxy so atualiza o banco PARA CIMA. Descendo, o banco (que
            # e so a fila do proxy) e recriado do zero.
            mod_warn "Descendo de versao: o banco do proxy (fila temporaria) sera recriado."
            systemctl stop zabbix-proxy 2>/dev/null || true
            M="mariadb"; command -v mariadb >/dev/null 2>&1 || M="mysql"
            ${M} -e 'DROP DATABASE IF EXISTS zabbix_proxy' || true
        fi
        target="$(series_version zabbix-proxy-mysql "${v}")"
        scripts="$(series_version zabbix-sql-scripts "${v}")"
        [[ -n "${target}" && -n "${scripts}" ]] || mod_die "O repositorio ${v} nao oferece o zabbix-proxy-mysql." 2
        mod_info "Zabbix Proxy: ${proxy_was} -> ${target}"
        apt_install --allow-downgrades "zabbix-proxy-mysql=${target}" "zabbix-sql-scripts=${scripts}"
        bash "${DIR}/component.sh" proxy enable
    fi
    mod_info "Zabbix ${v} ativo (repositorio oficial)."
    ;;

tune-proxy)
    conf=/etc/zabbix/zabbix_proxy.conf
    [[ -f "${conf}" ]] || mod_die "O Zabbix Proxy nao esta instalado."
    zbx_tune_proxy "${conf}" force
    if systemctl is-active --quiet zabbix-proxy; then
        systemctl restart zabbix-proxy
        sleep 2
        systemctl is-active --quiet zabbix-proxy || { cp -f "${conf}.pre-tune" "${conf}"; systemctl restart zabbix-proxy || true
            mod_die "O proxy nao subiu com o perfil; voltei a configuracao anterior." 2; }
    fi
    mod_info "Proxy reiniciado com o perfil otimizado."
    ;;

log)
    c="${1:-agent2}"; svc="$(svc_of "${c}")"; [[ -n "${svc}" ]] || mod_die "Componente invalido."
    f="/var/log/zabbix/zabbix_agent2.log"; [[ "${c}" == proxy ]] && f="/var/log/zabbix/zabbix_proxy.log"
    if [[ -s "${f}" ]]; then tail -n 80 "${f}"; else journalctl -u "${svc}" -n 80 --no-pager -o short-iso 2>&1 || true; fi
    ;;

test)
    c="${1:-agent2}"; conf="$(conf_of "${c}")"
    [[ -f "${conf}" ]] || mod_die "${conf} nao existe: o componente esta instalado?"
    targets="$(conf_val "${conf}" Server)"
    [[ "${c}" == agent2 ]] && targets="${targets},$(conf_val "${conf}" ServerActive)"
    seen=" "
    for t in ${targets//[,;]/ }; do
        [[ -z "${t}" || "${seen}" == *" ${t} "* ]] && continue
        seen+="${t} "
        host="${t%%:*}"; port="10051"; [[ "${t}" == *:* ]] && port="${t##*:}"
        [[ "${host}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]] && { printf 'skip %s rede autorizada (so para checagens passivas)\n' "${t}"; continue; }
        if timeout 5 bash -c "exec 3<>/dev/tcp/${host}/${port}" 2>/dev/null; then
            printf 'ok %s:%s conectou\n' "${host}" "${port}"
        else
            printf 'fail %s:%s sem resposta (rede, firewall ou porta)\n' "${host}" "${port}"
        fi
    done
    if [[ "${c}" == agent2 ]]; then
        lp="$(conf_val "${conf}" ListenPort)"; lp="${lp:-10050}"
        if ss -ltn "sport = :${lp}" 2>/dev/null | grep -q LISTEN; then printf 'ok local:%s agente escutando\n' "${lp}"
        else printf 'fail local:%s agente nao esta escutando\n' "${lp}"; fi
    fi
    ;;

*) mod_die "Acao desconhecida: ${ACTION}" ;;
esac
