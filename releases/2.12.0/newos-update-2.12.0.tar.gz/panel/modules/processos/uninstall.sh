#!/usr/bin/env bash
# =====================================================================
#  Modulo Processos - desligar (so tira a tela; o helper fica)
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="processos"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"
rm -rf /run/newos-top
mod_info "Processos desligado."
