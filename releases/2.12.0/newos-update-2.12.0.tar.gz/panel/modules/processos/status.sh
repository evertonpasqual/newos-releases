#!/usr/bin/env bash
set -Eeuo pipefail
printf 'installed=%s\n' "$([[ -x /usr/local/sbin/newos-top ]] && echo yes || echo no)"
printf 'active=%s\n' "$([[ -x /usr/local/sbin/newos-top ]] && echo yes || echo no)"
