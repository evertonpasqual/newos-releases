#!/usr/bin/env bash
# =====================================================================
#  Modulo Processos - instalacao
#  Chamado por: newos-modctl install processos
#  Nada a instalar: o helper newos-top le o /proc (vem com o painel).
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="processos"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

[[ -x /usr/local/sbin/newos-top ]] || mod_die "Helper newos-top ausente: atualize o NewOS." 2
mod_info "Pronto. Veja em Sistema > Processos."
