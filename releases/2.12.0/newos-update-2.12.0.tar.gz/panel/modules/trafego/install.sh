#!/usr/bin/env bash
# =====================================================================
#  Modulo Trafego ao vivo - instalacao
#  Chamado por: newos-modctl install trafego
#  iptraf-ng + conntrack; liga a contagem de bytes por conexao e garante
#  que o kernel acompanhe as conexoes mesmo com o Firewall desligado
#  (uma tabela nftables minima, so de leitura, que usa o conntrack).
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="trafego"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

missing=()
for p in iptraf-ng conntrack nftables; do
    pkg_installed "${p}" || missing+=("${p}")
done
if ((${#missing[@]} > 0)); then
    apt_require_healthy
    apt_ensure_lists
    mod_info "Instalando ${missing[*]}..."
    apt_install "${missing[@]}"
fi

printf 'nf_conntrack\n' >/etc/modules-load.d/newos-trafego.conf
printf '# NewOS (Trafego ao vivo): bytes por conexao no conntrack\nnet.netfilter.nf_conntrack_acct = 1\n' \
    >/etc/sysctl.d/90-newos-trafego.conf
modprobe nf_conntrack 2>/dev/null || true

install -d -m 0755 /etc/newos
cat >/etc/newos/trafego.nft <<'NFT'
# NewOS (Trafego ao vivo): faz o kernel acompanhar as conexoes (conntrack)
# mesmo sem o Firewall. Nao filtra nada: so conta.
destroy table inet newos_trafego
table inet newos_trafego {
    chain pre {
        type filter hook prerouting priority -160; policy accept;
        ct state new counter
    }
    chain out {
        type filter hook output priority -160; policy accept;
        ct state new counter
    }
}
NFT
cat >/etc/systemd/system/newos-trafego.service <<'UNIT'
[Unit]
Description=NewOS: acompanhamento de conexoes (Trafego ao vivo)
After=nftables.service network-pre.target
Wants=network-pre.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStartPre=-/usr/sbin/modprobe nf_conntrack
ExecStartPre=-/usr/sbin/sysctl -q -w net.netfilter.nf_conntrack_acct=1
ExecStart=/usr/sbin/nft -f /etc/newos/trafego.nft
ExecStop=-/usr/sbin/nft destroy table inet newos_trafego

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
svc_enable_start newos-trafego
mod_info "Pronto. Veja em Configuracoes > Network > Trafego ao vivo."
