#!/usr/bin/env bash
set -Eeuo pipefail
printf 'installed=%s\n' "$(command -v iptraf-ng >/dev/null 2>&1 && command -v conntrack >/dev/null 2>&1 && echo yes || echo no)"
printf 'active=%s\n' "$(systemctl is-active newos-trafego.service 2>/dev/null || echo inactive)"
printf 'acct=%s\n' "$(cat /proc/sys/net/netfilter/nf_conntrack_acct 2>/dev/null || echo 0)"
