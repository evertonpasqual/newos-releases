#!/usr/bin/env bash
# =====================================================================
#  Modulo Trafego ao vivo - desligar
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="trafego"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

systemctl disable --now newos-trafego.service >/dev/null 2>&1 || true
nft destroy table inet newos_trafego 2>/dev/null || true
rm -f /etc/systemd/system/newos-trafego.service /etc/newos/trafego.nft \
      /etc/sysctl.d/90-newos-trafego.conf /etc/modules-load.d/newos-trafego.conf
systemctl daemon-reload
mod_info "Trafego ao vivo desligado (o iptraf-ng continua instalado)."
