#!/usr/bin/env bash
# =====================================================================
#  Modulo Prometheus - desligar
#  Para os servicos. Mantem programas, configuracao (/etc/prometheus,
#  /etc/newos/prometheus.json) e dados (/var/lib/prometheus): religar
#  volta exatamente como estava.
# =====================================================================
set -Eeuo pipefail
for s in prometheus node_exporter prometheus-pve-exporter snmp_exporter vmware_exporter alertmanager; do
    systemctl disable --now "${s}" >/dev/null 2>&1 || true
done
echo "[prometheus] Servicos parados. Configuracao e dados preservados."
