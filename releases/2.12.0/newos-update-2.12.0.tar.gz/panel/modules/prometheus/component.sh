#!/usr/bin/env bash
# =====================================================================
#  Modulo Prometheus - componentes (exporters)
#  Chamado por: newos-modctl component prometheus <node|pve|snmp|vmware> <enable|disable>
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="prometheus"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

COMP="${1:?uso: component.sh <node|pve|snmp|vmware|alertmanager> <enable|disable>}"
ACTION="${2:?uso: component.sh <componente> <enable|disable>}"
case "${COMP}" in node|pve|snmp|vmware|alertmanager) ;; *) mod_die "Componente invalido: ${COMP}" ;; esac
export NEWOS_MODULE_DIR="${NEWOS_MODULE_DIR:-$(cd "$(dirname "$0")" && pwd)}"

case "${ACTION}" in
    enable)
        mod_info "Instalando ${COMP} (versao oficial mais nova)..."
        /usr/local/sbin/newos-prometheus install "${COMP}" | sed -n 's/.*"message": "\([^"]*\)".*/[prometheus] \1/p'
        ;;
    disable)
        /usr/local/sbin/newos-prometheus remove "${COMP}" | sed -n 's/.*"message": "\([^"]*\)".*/[prometheus] \1/p'
        ;;
    *) mod_die "Acao invalida: ${ACTION}" ;;
esac
