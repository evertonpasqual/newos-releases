#!/usr/bin/env bash
# Estado do modulo Prometheus, em pares chave=valor.
set -Eeuo pipefail
printf 'installed=%s\n' "$([[ -x /usr/local/bin/prometheus ]] && echo yes || echo no)"
for s in prometheus node_exporter prometheus-pve-exporter snmp_exporter vmware_exporter alertmanager; do
    printf '%s=%s\n' "${s}" "$(systemctl is-active "${s}" 2>/dev/null || true)"
done
