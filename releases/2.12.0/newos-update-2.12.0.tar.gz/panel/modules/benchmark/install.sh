#!/usr/bin/env bash
# =====================================================================
#  Modulo Benchmark - instalacao
#  Chamado por: newos-modctl install benchmark
#  fio (disco), iperf3 (rede) e speedtest-cli (internet), do Debian.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="benchmark"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

missing=()
for p in fio iperf3 speedtest-cli; do
    pkg_installed "${p}" || missing+=("${p}")
done
if ((${#missing[@]} > 0)); then
    apt_require_healthy
    apt_ensure_lists
    # o iperf3 pergunta se deve subir como servico: nao (o painel liga quando pedir)
    echo "iperf3 iperf3/start_daemon boolean false" | debconf-set-selections 2>/dev/null || true
    mod_info "Instalando ${missing[*]}..."
    apt_install "${missing[@]}"
fi
systemctl disable --now iperf3.service >/dev/null 2>&1 || true
install -d -m 0755 /var/lib/newos/bench
mod_info "Pronto. Os testes ficam em Ferramentas > Benchmark."
