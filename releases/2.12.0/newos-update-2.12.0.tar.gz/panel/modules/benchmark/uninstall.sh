#!/usr/bin/env bash
# =====================================================================
#  Modulo Benchmark - desligar
#  Para o teste em andamento e o servidor iperf3. O historico e os
#  relatorios ficam guardados em /var/lib/newos/bench.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="benchmark"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

for u in $(systemctl list-units 'newos-bench-*' --no-legend --plain 2>/dev/null | awk '{print $1}'); do
    systemctl stop "${u}" 2>/dev/null || true
done
echo '{"action": "stop"}' | /usr/local/sbin/newos-bench iperf-server >/dev/null 2>&1 || true
mod_info "Benchmark desligado. Historico e relatorios guardados em /var/lib/newos/bench."
