#!/usr/bin/env bash
set -Eeuo pipefail
printf 'installed=%s\n' "$(command -v fio >/dev/null 2>&1 && command -v iperf3 >/dev/null 2>&1 && echo yes || echo no)"
printf 'active=%s\n' "$(command -v fio >/dev/null 2>&1 && echo yes || echo no)"
