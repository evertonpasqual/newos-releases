#!/usr/bin/env bash
# =====================================================================
#  NewOS - biblioteca comum dos modulos
#  Caminho: /opt/newos-panel/modules/_lib/modlib.sh
# ---------------------------------------------------------------------
#  Carregada pelos install.sh/component.sh dos modulos:
#
#      source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"
#
#  O diretorio comeca com "_" de proposito: o newos-modctl so aceita
#  chaves de modulo que casem com ^[a-z0-9], entao "_lib" nunca sera
#  confundido com um modulo.
# =====================================================================
# shellcheck shell=bash

[[ -n "${NEWOS_MODLIB_LOADED:-}" ]] && return 0
NEWOS_MODLIB_LOADED=1

export DEBIAN_FRONTEND=noninteractive

# ---------------------------------------------------------------------
# Idioma fixo para as ferramentas do APT.
#
# O pkg_exists le a saida do apt-cache, que e traduzida. Depender de
# duas grafias ("Candidate:" / "Candidato:") e fragil e ja produziu
# expressoes regulares com precedencia errada. Com LC_ALL=C a saida e
# sempre em ingles e a leitura fica com um caso so.
# ---------------------------------------------------------------------
export LC_ALL=C
export LANGUAGE=C

mod_info() { printf '[%s] %s\n' "${MOD_TAG:-modulo}" "$*"; }
mod_warn() { printf '[%s] AVISO: %s\n' "${MOD_TAG:-modulo}" "$*" >&2; }
mod_err()  { printf '[%s] ERRO: %s\n'  "${MOD_TAG:-modulo}" "$*" >&2; }
# Imprime so o $1: o $2 e o codigo de saida, nao faz parte da mensagem.
mod_die()  { mod_err "$1"; exit "${2:-1}"; }

# ---------------------------------------------------------------------
# pkg_installed <pacote>
#   Verdadeiro SOMENTE se o pacote esta realmente instalado e
#   configurado.
#
#   ATENCAO: nao use "dpkg -s" para isso. Ele retorna 0 tambem quando o
#   pacote esta em 'half-installed', 'unpacked' ou 'reinstreq' -- ou
#   seja, QUEBRADO. Foi exatamente esse engano que fez o modulo Zabbix
#   pular a instalacao e reportar sucesso com o repositorio ausente.
# ---------------------------------------------------------------------
pkg_installed() {
    local status
    status="$(dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null || true)"
    [[ "${status}" == "installed" ]]
}

# ---------------------------------------------------------------------
# pkg_broken <pacote>
#   Verdadeiro se o dpkg conhece o pacote mas ele NAO esta 'installed'.
# ---------------------------------------------------------------------
pkg_broken() {
    local status
    status="$(dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null || true)"
    [[ -n "${status}" && "${status}" != "installed" && \
       "${status}" != "config-files" && "${status}" != "not-installed" ]]
}

# ---------------------------------------------------------------------
# pkg_exists <pacote>
#   O pacote esta visivel em algum repositorio configurado?
#
#   Usamos "apt-cache policy" com LC_ALL=C (veja o comentario no topo do
#   arquivo) e conferimos que existe um candidato diferente de "(none)".
#   Se ainda houver duvida, "apt-cache show" confirma.
# ---------------------------------------------------------------------
pkg_exists() {
    local pol
    pol="$(LC_ALL=C apt-cache policy "$1" 2>/dev/null || true)"

    if grep -qE '^[[:space:]]*Candidate:' <<<"${pol}" && \
       ! grep -qE '^[[:space:]]*Candidate:[[:space:]]*\(none\)' <<<"${pol}"; then
        return 0
    fi

    # Segunda opiniao: pacote real presente em algum indice.
    LC_ALL=C apt-cache show "$1" 2>/dev/null | grep -q '^Package:'
}

# ---------------------------------------------------------------------
# pkg_from_origin <pacote> <trecho-da-url>
#   O candidato do pacote vem MESMO do repositorio esperado?
#
#   ATENCAO (bug ja corrigido): o modulo Zabbix testava so
#   "pkg_exists zabbix-agent2" para decidir que o repositorio oficial ja
#   estava configurado. Mas o proprio Debian tem um zabbix-agent2 (7.0),
#   entao o teste passava com o repositorio da Zabbix AUSENTE e o
#   servidor acabava instalando a versao do Debian em vez da 7.4.
# ---------------------------------------------------------------------
pkg_from_origin() {
    # Sem "apt-cache | grep -q": com muitas versoes na tabela o grep sai
    # cedo, o apt-cache leva SIGPIPE e o pipefail vira o acerto em falha.
    local out
    out="$(LC_ALL=C apt-cache policy "$1" 2>/dev/null || true)"
    grep -qF -- "$2" <<<"${out}"
}

# ---------------------------------------------------------------------
# apt_lists_empty
#   O /var/lib/apt/lists esta sem indices?
#
#   ISSO E O ESTADO NORMAL DE UM NewOS RECEM-INSTALADO: o hook
#   0900-cleanup.chroot apaga /var/lib/apt/lists/* para a ISO nao
#   carregar indices velhos. Enquanto ninguem rodar "apt-get update",
#   o APT nao conhece NENHUM pacote -- e qualquer pkg_exists da falso.
# ---------------------------------------------------------------------
apt_lists_empty() {
    ! compgen -G "/var/lib/apt/lists/*_Packages*" >/dev/null 2>&1 && \
    ! compgen -G "/var/lib/apt/lists/*_Packages" >/dev/null 2>&1
}

# ---------------------------------------------------------------------
# apt_ensure_lists
#   Garante que o APT tem indices utilizaveis. Falha ALTO se nao
#   conseguir: seguir sem indices so produz o erro enganoso
#   "pacote nao encontrado no repositorio".
# ---------------------------------------------------------------------
apt_ensure_lists() {
    local out rc=0

    if ! apt_lists_empty; then
        # Ja ha indices. Atualiza, mas sem drama se a rede oscilar.
        apt-get update -qq >/dev/null 2>&1 || \
            mod_warn "apt-get update falhou; usando os indices ja existentes."
        return 0
    fi

    mod_info "O APT ainda nao tem indices; rodando apt-get update..."
    out="$(apt-get update 2>&1)" || rc=$?

    if (( rc != 0 )) || apt_lists_empty; then
        mod_err "Nao foi possivel baixar os indices do APT."
        printf '%s\n' "${out}" | tail -15 | sed "s/^/[${MOD_TAG:-modulo}]   /" >&2
        mod_err ""
        mod_err "Repositorios configurados neste servidor:"
        {
            cat /etc/apt/sources.list 2>/dev/null
            cat /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources 2>/dev/null
        } | grep -vE '^\s*(#|$)' | sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
        mod_err ""
        mod_err "Confira no console do servidor:"
        mod_err "    ping -c1 deb.debian.org"
        mod_err "    sudo apt-get update"
        exit 2
    fi

    mod_info "Indices do APT prontos."
}

# ---------------------------------------------------------------------
# pkg_require_available <pacote...>
#   Aborta com diagnostico util se algum pacote nao aparecer no APT.
# ---------------------------------------------------------------------
pkg_require_available() {
    local missing="" p
    for p in "$@"; do
        pkg_exists "${p}" || missing+=" ${p}"
    done
    [[ -z "${missing}" ]] && return 0

    mod_err "Pacotes ausentes nos repositorios:${missing}"
    mod_err "Repositorios ativos:"
    {
        cat /etc/apt/sources.list 2>/dev/null
        cat /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources 2>/dev/null
    } | grep -vE '^\s*(#|$)' | sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
    exit 2
}

# ---------------------------------------------------------------------
# svc_enable_start <servico>
#   Habilita, (re)inicia e CONFERE que o servico ficou de pe.
#
#   "systemctl restart" retorna 0 mesmo quando a unidade sobe e morre em
#   seguida (Result=exit-code com Restart=no). Sem conferir, o painel
#   dizia "ligado" com o servico caido -- foi assim que o Zabbix
#   apareceu como ativo sem nunca ter subido. Se falhar, imprimimos o
#   motivo real do journal, que e a informacao que resolve o problema.
# ---------------------------------------------------------------------
svc_enable_start() {
    local svc="$1" state sub _i

    systemctl enable "${svc}" >/dev/null 2>&1 || \
        mod_warn "systemctl enable ${svc} retornou erro."

    if ! systemctl restart "${svc}"; then
        mod_err "systemctl restart ${svc} falhou."
        svc_dump_failure "${svc}"
        return 1
    fi

    # Ate 15 segundos: alguns servicos morrem 2-3 segundos depois de
    # subir (plugin que nao carrega, banco que recusa a senha...), e um
    # servico com Restart=on-failure fica em "auto-restart" no meio.
    for _i in $(seq 1 15); do
        sleep 1
        state="$(systemctl is-active "${svc}" 2>/dev/null || true)"
        sub="$(systemctl show -p SubState --value "${svc}" 2>/dev/null || true)"

        # auto-restart = ja morreu pelo menos uma vez. Nao adianta esperar.
        if [[ "${sub}" == "auto-restart" || "${sub}" == "failed" ]]; then
            mod_err "O servico ${svc} subiu e caiu (SubState=${sub})."
            svc_dump_failure "${svc}"
            return 1
        fi
        [[ "${state}" == "activating" ]] && continue
        [[ "${state}" == "active" ]] || break
    done

    state="$(systemctl is-active "${svc}" 2>/dev/null || true)"
    if [[ "${state}" != "active" ]]; then
        mod_err "O servico ${svc} nao ficou ativo (estado: ${state:-desconhecido})."
        svc_dump_failure "${svc}"
        return 1
    fi

    mod_info "Servico ${svc} ativo e habilitado no boot."
}

# ---------------------------------------------------------------------
# svc_dump_failure <servico>
#   Mostra o porque de um servico nao subir: status + journal + o log
#   do proprio Zabbix, que costuma ter a mensagem util.
# ---------------------------------------------------------------------
svc_dump_failure() {
    local svc="$1" f
    mod_err "--- resumo da unidade ---"
    systemctl show "${svc}" \
        -p ActiveState -p SubState -p Result -p ExecMainStatus \
        -p ExecMainCode -p NRestarts -p StatusText 2>/dev/null | \
        sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
    mod_err "--- systemctl status ${svc} ---"
    systemctl status "${svc}" --no-pager -l 2>&1 | tail -15 | \
        sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
    mod_err "--- journalctl -u ${svc} ---"
    journalctl -u "${svc}" --no-pager -n 25 2>&1 | \
        sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
    for f in "/var/log/zabbix/${svc}.log" \
             "/var/log/zabbix/${svc//-/_}.log"; do
        if [[ -f "${f}" ]]; then
            mod_err "--- ${f} ---"
            tail -20 "${f}" | sed "s/^/[${MOD_TAG:-modulo}]   /" >&2 || true
        fi
    done
}

# ---------------------------------------------------------------------
# apt_healthy
#   O APT consegue operar? Um unico pacote em estado quebrado trava
#   TODAS as instalacoes do sistema, entao vale conferir antes.
# ---------------------------------------------------------------------
apt_healthy() {
    apt-get --simulate --quiet install -y ca-certificates >/dev/null 2>&1
}

# ---------------------------------------------------------------------
# apt_require_healthy
#   Aborta com instrucao clara se o APT estiver travado.
# ---------------------------------------------------------------------
apt_require_healthy() {
    apt_healthy && return 0

    local broken
    broken="$(dpkg-query -W -f='${Package} ${db:Status-Status}\n' 2>/dev/null | \
              awk '$2 != "installed" && $2 != "not-installed" && $2 != "config-files" {print $1}' | \
              tr '\n' ' ')"

    mod_err "O APT deste servidor esta travado e nenhuma instalacao vai funcionar."
    [[ -n "${broken}" ]] && mod_err "Pacotes em estado quebrado:${broken:+ ${broken}}"
    mod_err ""
    mod_err "Para destravar, rode no console do servidor:"
    [[ -n "${broken}" ]] && \
        mod_err "    sudo dpkg --purge --force-all ${broken}"
    mod_err "    sudo apt-get update && sudo apt-get -f install"
    exit 2
}

# ---------------------------------------------------------------------
# apt_cleanup_broken <pacote...>
#   Remove a forca pacotes que ficaram meio-instalados. Usado antes de
#   uma reinstalacao, para nao herdar o estado ruim da tentativa
#   anterior.
# ---------------------------------------------------------------------
apt_cleanup_broken() {
    local pkg
    for pkg in "$@"; do
        if pkg_broken "${pkg}"; then
            mod_warn "O pacote ${pkg} esta em estado quebrado; limpando antes de seguir."
            dpkg --purge --force-all "${pkg}" >/dev/null 2>&1 || true
        fi
    done
}

# ---------------------------------------------------------------------
# have_internet <url>
# ---------------------------------------------------------------------
have_internet() {
    curl -fsS --max-time 20 -o /dev/null "$1" 2>/dev/null || \
    curl -fsSI --max-time 20 -o /dev/null "$1" 2>/dev/null
}

# ---------------------------------------------------------------------
# apt_install <pacote...>
#   Instala mostrando so o essencial, e falhando com mensagem util.
# ---------------------------------------------------------------------
apt_install() {
    mod_info "Instalando: $*"
    if ! apt-get install -y -o Dpkg::Options::=--force-confold "$@" 2>&1 | \
            tail -12 | sed "s/^/[${MOD_TAG:-modulo}]   /"; then
        mod_die "Falha ao instalar: $*" 2
    fi
}

# ---------------------------------------------------------------------
# download_verified <url> <destino> [tamanho-minimo-bytes]
#   Baixa e confere que o arquivo nao veio truncado. Um .deb pela metade
#   e o caminho mais curto para deixar o dpkg em estado quebrado.
# ---------------------------------------------------------------------
download_verified() {
    local url="$1" dest="$2" minsize="${3:-1024}"

    mod_info "Baixando $(basename "${url}")..."
    if ! curl -fsSL --max-time 300 --retry 2 -o "${dest}" "${url}"; then
        mod_die "Falha ao baixar ${url}" 2
    fi

    local size
    size="$(stat -c%s "${dest}" 2>/dev/null || echo 0)"
    if (( size < minsize )); then
        rm -f "${dest}"
        mod_die "O download veio incompleto (${size} bytes). Rede instavel?" 2
    fi

    mod_info "Baixado: ${size} bytes."
}

# ---------------------------------------------------------------------
# download_try <url> <destino> [tamanho-minimo]
#   Igual ao download_verified, mas RETORNA 1 em vez de abortar. Use
#   quando houver um segundo endereco para tentar.
# ---------------------------------------------------------------------
download_try() {
    local url="$1" dest="$2" minsize="${3:-1024}" size

    curl -fsSL --max-time 300 --retry 2 -o "${dest}" "${url}" 2>/dev/null || return 1

    size="$(stat -c%s "${dest}" 2>/dev/null || echo 0)"
    if (( size < minsize )); then
        rm -f "${dest}"
        return 1
    fi
    mod_info "Baixado de ${url}: ${size} bytes."
    return 0
}

# ---------------------------------------------------------------------
# apt_broken_packages
#   Imprime os pacotes em estado quebrado, separados por espaco.
# ---------------------------------------------------------------------
apt_broken_packages() {
    dpkg-query -W -f='${Package} ${db:Status-Status}\n' 2>/dev/null | \
        awk '$2 != "installed" && $2 != "not-installed" && $2 != "config-files" {print $1}' | \
        tr '\n' ' '
}

# ---------------------------------------------------------------------
# dpkg_install_deb <arquivo.deb>
#   Instala um .deb local com verificacao antes e reparo depois.
# ---------------------------------------------------------------------
dpkg_install_deb() {
    local deb="$1" name
    name="$(basename "${deb}")"

    # O arquivo e realmente um .deb valido?
    if ! dpkg-deb --info "${deb}" >/dev/null 2>&1; then
        rm -f "${deb}"
        mod_die "O arquivo ${name} nao e um pacote .deb valido (download corrompido)." 2
    fi

    mod_info "Instalando ${name}..."
    if ! dpkg -i "${deb}" 2>&1 | sed "s/^/[${MOD_TAG:-modulo}]   /"; then
        mod_warn "dpkg -i retornou erro; tentando resolver dependencias..."
        apt-get -f install -y >/dev/null 2>&1 || true

        local pkgname
        pkgname="$(dpkg-deb -f "${deb}" Package 2>/dev/null || true)"
        if [[ -n "${pkgname}" ]] && ! pkg_installed "${pkgname}"; then
            apt_cleanup_broken "${pkgname}"
            mod_die "Nao foi possivel instalar ${name}." 2
        fi
    fi
}
