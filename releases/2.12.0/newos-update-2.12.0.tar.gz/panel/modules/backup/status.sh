#!/usr/bin/env bash
# Estado do modulo Backup, em pares chave=valor.
set -Eeuo pipefail
printf 'installed=%s\n' "$(command -v bareos-dir >/dev/null 2>&1 && echo yes || echo no)"
for s in bareos-director bareos-storage bareos-filedaemon postgresql; do
    printf '%s=%s\n' "${s}" "$(systemctl is-active "${s}" 2>/dev/null || true)"
done
printf 'version=%s\n' "$(dpkg-query -W -f='${Version}' bareos-director 2>/dev/null || echo none)"
