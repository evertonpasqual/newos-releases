#!/usr/bin/env bash
# =====================================================================
#  Modulo Backup - remocao
# ---------------------------------------------------------------------
#  Remove os PROGRAMAS. Mantem tudo o que e dado: /etc/bareos (rotinas,
#  clientes, destinos), o catalogo no PostgreSQL e os volumes gravados.
#  Religar o modulo volta exatamente de onde parou.
#  Recusa enquanto houver backup ou restauracao em andamento.
# =====================================================================
set -Eeuo pipefail

if command -v bconsole >/dev/null 2>&1; then
    running="$(printf 'list jobs jobstatus=R\n' | timeout 20 bconsole 2>/dev/null | grep -cE '^\| +[0-9]+ ' || true)"
    if [[ "${running:-0}" -gt 0 ]]; then
        echo "[backup] ERRO: ha ${running} job(s) em execucao. Espere terminar ou cancele em Backups > Historico." >&2
        exit 2
    fi
fi

echo "[backup] Parando o Bareos..."
systemctl disable --now bareos-director bareos-storage bareos-filedaemon >/dev/null 2>&1 || true
echo "[backup] Removendo os programas (configuracao, catalogo e volumes ficam)..."
apt-get remove -y bareos-director bareos-storage bareos-filedaemon bareos-bconsole \
    bareos-storage-dplcompat bareos-database-postgresql 2>&1 | tail -3 || true
echo "[backup] Removido. O PostgreSQL continua instalado (guarda o catalogo)."
