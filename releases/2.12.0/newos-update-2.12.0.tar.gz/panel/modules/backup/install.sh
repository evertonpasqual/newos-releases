#!/usr/bin/env bash
# =====================================================================
#  Modulo Backup - instalacao do Bareos 25 (repositorio oficial)
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl install backup   (root, precisa de internet)
#
#  - repositorio download.bareos.org/current/Debian_13 (builds da
#    comunidade; o Debian 13 nao traz mais o Bareos)
#  - catalogo no PostgreSQL LOCAL, criado pelo dbconfig sem perguntas
#  - Director, Storage Daemon e File Daemon desta maquina
#  - S3 pelo backend dplcompat (usa o s3cmd por baixo)
#  - o Storage padrao "File" passa a anunciar o IP do servidor (com o
#    hostname, clientes que nao resolvem o nome falham sem erro claro)
# =====================================================================
set -Eeuo pipefail

# shellcheck disable=SC2034
MOD_TAG="backup"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

BAREOS_URL="https://download.bareos.org/current/Debian_13"
KEYRING="/etc/apt/keyrings/bareos.gpg"
SOURCES="/etc/apt/sources.list.d/bareos.sources"
PKGS=(postgresql bareos-director bareos-storage bareos-filedaemon bareos-bconsole
      bareos-database-postgresql bareos-storage-dplcompat s3cmd)

apt_require_healthy
apt_ensure_lists

# ---------------------------------------------------------------------
# 1. Repositorio oficial
# ---------------------------------------------------------------------
if ! pkg_from_origin bareos-director download.bareos.org; then
    have_internet "${BAREOS_URL}/" || mod_die "Sem acesso a ${BAREOS_URL}: o Bareos vem de download.bareos.org." 2
    mod_info "Adicionando o repositorio oficial do Bareos (${BAREOS_URL})..."
    install -d -m 0755 /etc/apt/keyrings
    if ! curl -fsSL --max-time 60 "${BAREOS_URL}/bareos-keyring.gpg" -o "${KEYRING}.tmp"; then
        rm -f "${KEYRING}.tmp"
        mod_die "Nao consegui baixar a chave do repositorio (${BAREOS_URL}/bareos-keyring.gpg)." 2
    fi
    # A chave vem binaria (.gpg); se vier em texto, converte.
    if grep -q "BEGIN PGP" "${KEYRING}.tmp" 2>/dev/null; then
        gpg --dearmor <"${KEYRING}.tmp" >"${KEYRING}"
        rm -f "${KEYRING}.tmp"
    else
        mv "${KEYRING}.tmp" "${KEYRING}"
    fi
    chmod 0644 "${KEYRING}"
    cat >"${SOURCES}" <<SRC
Types: deb
URIs: ${BAREOS_URL}
Suites: /
Architectures: amd64
Signed-By: ${KEYRING}
SRC
    if ! apt-get update -qq >/dev/null 2>&1; then
        rm -f "${SOURCES}"
        mod_die "apt-get update falhou depois de adicionar o repositorio do Bareos." 2
    fi
fi
pkg_require_available "${PKGS[@]}"

# ---------------------------------------------------------------------
# 2. Pacotes (o dbconfig cria o banco bareos no PostgreSQL local)
# ---------------------------------------------------------------------
debconf-set-selections <<'DEB'
bareos-database-common bareos-database-common/dbconfig-install boolean true
bareos-database-common bareos-database-common/database-type select pgsql
bareos-database-common bareos-database-common/pgsql/method select Unix socket
DEB
mod_info "Instalando PostgreSQL e Bareos (Director, Storage, File Daemon, S3)..."
apt_install "${PKGS[@]}"

# ---------------------------------------------------------------------
# 3. Ajustes do NewOS
# ---------------------------------------------------------------------
# 0755 na raiz (o painel precisa atravessar ate downloads/); cada area
# fica fechada: restores so para o bareos, downloads so para o painel.
PANEL_GROUP="$(. /etc/newos/newos.conf 2>/dev/null; echo "${PANEL_SYSTEM_USER:-newospanel}")"
install -d -m 0755 -o root -g root /var/lib/newos-backup
install -d -m 0750 -o bareos -g bareos /var/lib/newos-backup/restores
install -d -m 0750 -o root -g "${PANEL_GROUP}" /var/lib/newos-backup/downloads

# O Storage "File" (padrao) anuncia o hostname; clientes remotos precisam
# do IP. O helper sabe calcular o IP principal e reescrever com seguranca.
/usr/local/sbin/newos-backup setup-defaults >/dev/null 2>&1 || \
    mod_warn "Nao consegui ajustar o endereco do Storage padrao; ajuste em Backups > Destinos."

for svc in postgresql bareos-director bareos-storage bareos-filedaemon; do
    svc_enable_start "${svc}" || mod_die "O servico ${svc} nao subiu." 2
done

# O Director precisa estar respondendo pelo bconsole.
for _ in $(seq 1 20); do
    if printf 'status director\n' | timeout 15 bconsole 2>/dev/null | grep -q "Version:"; then
        mod_info "Bareos pronto: $(printf 'version\n' | timeout 15 bconsole 2>/dev/null | grep -o 'Version: [^ ]*' | head -1)"
        mod_info "Abra Backups > Visao geral no menu."
        exit 0
    fi
    sleep 2
done
mod_die "O Director nao respondeu ao bconsole. Veja: journalctl -u bareos-director" 2
