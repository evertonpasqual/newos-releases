#!/usr/bin/env bash
# Estado do modulo ZFS, em pares chave=valor.
set -Eeuo pipefail
printf 'installed=%s\n' "$(command -v zpool >/dev/null 2>&1 && echo yes || echo no)"
printf 'kernel_module=%s\n' "$(cat /sys/module/zfs/version 2>/dev/null || echo none)"
printf 'pools=%s\n' "$(zpool list -H -o name 2>/dev/null | wc -l)"
