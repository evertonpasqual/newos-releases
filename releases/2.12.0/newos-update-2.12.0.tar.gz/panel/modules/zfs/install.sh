#!/usr/bin/env bash
# =====================================================================
#  Modulo ZFS - instalacao
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl install zfs   (root, precisa de internet)
#
#  O ZFS nao vem no kernel do Debian (licenca CDDL): o zfs-dkms compila
#  o modulo AQUI, contra os headers do kernel em uso. O meta-pacote
#  linux-headers-amd64 garante os headers dos kernels futuros, e o DKMS
#  recompila sozinho a cada atualizacao de kernel.
# =====================================================================
set -Eeuo pipefail

# shellcheck disable=SC2034
MOD_TAG="zfs"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

apt_require_healthy
apt_ensure_lists

KVER="$(uname -r)"
pkg_require_available zfs-dkms zfsutils-linux linux-headers-amd64

# O zfs-dkms mostra um aviso de licenca pelo debconf: ja respondido.
echo "zfs-dkms zfs-dkms/note-incompatible-licenses note" | debconf-set-selections

mod_info "Instalando headers do kernel ${KVER} e o OpenZFS (compila o modulo; leva alguns minutos)..."
apt_install "linux-headers-${KVER}" linux-headers-amd64 zfs-dkms zfsutils-linux

if ! modprobe zfs 2>/dev/null; then
    mod_err "O modulo zfs nao carregou. Saida do DKMS:"
    dkms status 2>&1 | sed 's/^/[zfs]   /' >&2 || true
    exit 2
fi
mod_info "Modulo do kernel carregado: $(cat /sys/module/zfs/version 2>/dev/null || echo '?')"

systemctl enable --now zfs-zed.service >/dev/null 2>&1 || \
    mod_warn "zfs-zed (monitor de eventos) nao subiu; o ZFS funciona sem ele."
for unit in zfs-import-cache.service zfs-mount.service zfs.target; do
    systemctl enable "${unit}" >/dev/null 2>&1 || true
done

mod_info "ZFS pronto. Crie pools em Armazenamento > Discos."
