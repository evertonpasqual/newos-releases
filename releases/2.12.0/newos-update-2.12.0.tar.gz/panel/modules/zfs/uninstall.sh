#!/usr/bin/env bash
# =====================================================================
#  Modulo ZFS - remocao
# ---------------------------------------------------------------------
#  Desligar NUNCA pode apagar dados: com pools ativos a remocao e
#  recusada (sem o ZFS os dados ficariam inacessiveis ate reinstalar).
# =====================================================================
set -Eeuo pipefail

if command -v zpool >/dev/null 2>&1; then
    pools="$(zpool list -H -o name 2>/dev/null | tr '\n' ' ')"
    if [[ -n "${pools// /}" ]]; then
        echo "[zfs] ERRO: ha pools ZFS ativos: ${pools}" >&2
        echo "[zfs] Exporte (zpool export <pool>) ou destrua os pools antes de desligar o modulo." >&2
        exit 2
    fi
fi

echo "[zfs] Removendo os pacotes do ZFS..."
systemctl disable --now zfs-zed.service >/dev/null 2>&1 || true
modprobe -r zfs 2>/dev/null || true
apt-get purge -y zfs-dkms zfsutils-linux 2>&1 | tail -3 || true
apt-get autoremove -y >/dev/null 2>&1 || true
echo "[zfs] ZFS removido. Os headers do kernel foram mantidos."
