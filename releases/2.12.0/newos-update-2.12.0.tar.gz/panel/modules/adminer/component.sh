#!/usr/bin/env bash
# O modulo Adminer nao tem componentes; existe para a interface uniforme.
set -Eeuo pipefail
echo "[adminer] Este modulo nao possui componentes."
exit 0
