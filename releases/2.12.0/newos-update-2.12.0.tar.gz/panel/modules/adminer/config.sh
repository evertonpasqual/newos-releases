#!/usr/bin/env bash
# O modulo Adminer nao tem configuracao pela web.
set -Eeuo pipefail
[[ "${1:-}" == "show" ]] && exit 0
echo "[adminer] Este modulo nao possui configuracao."
exit 0
