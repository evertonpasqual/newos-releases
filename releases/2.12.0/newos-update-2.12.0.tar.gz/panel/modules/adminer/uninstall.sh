#!/usr/bin/env bash
# =====================================================================
#  Modulo Adminer - remocao
# ---------------------------------------------------------------------
#  Tira o Adminer do ar. NAO remove o php-fpm nem toca no banco: outro
#  modulo pode estar usando o PHP, e apagar dados nunca deve ser efeito
#  colateral de desligar um botao.
# =====================================================================
set -Eeuo pipefail

NGINX_SNIPPET_DIR="/etc/nginx/newos-modules"
WEBROOT="/var/www/newos-adminer"

echo "[adminer] Removendo o trecho do nginx..."
rm -f "${NGINX_SNIPPET_DIR}/adminer.conf"

if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
    echo "[adminer] nginx recarregado."
else
    echo "[adminer] AVISO: nginx -t reprovou apos a remocao." >&2
fi

rm -rf "${WEBROOT}"

echo "[adminer] Fora do ar."
echo "[adminer] Os pacotes (adminer, php-fpm) continuam instalados de proposito:"
echo "[adminer] outro modulo pode depender do PHP. Para remover mesmo:"
echo "[adminer]     apt-get purge adminer"
