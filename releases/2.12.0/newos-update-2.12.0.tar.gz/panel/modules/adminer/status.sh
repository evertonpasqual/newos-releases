#!/usr/bin/env bash
# Estado do modulo Adminer, em pares chave=valor.
set -Eeuo pipefail
SNIPPET="/etc/nginx/newos-modules/adminer.conf"
printf 'packages=%s\n' "$(dpkg -s adminer >/dev/null 2>&1 && echo yes || echo no)"
printf 'nginx_snippet=%s\n' "$([[ -f "${SNIPPET}" ]] && echo yes || echo no)"
printf 'php_fpm=%s\n' "$(systemctl list-units 'php*-fpm.service' --state=running --no-legend 2>/dev/null | grep -qc . && echo running || echo stopped)"
printf 'url=/adminer/\n'
