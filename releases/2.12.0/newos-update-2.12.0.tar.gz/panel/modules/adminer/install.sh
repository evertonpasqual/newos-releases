#!/usr/bin/env bash
# =====================================================================
#  Modulo Adminer - instalacao
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl install adminer
#  Roda como root.
#
#  Publica o Adminer em http://<ip>:<porta-do-painel>/adminer/
#  protegido pelo mesmo login do painel (auth_request no nginx).
#
#  ---------------------------------------------------------------------
#  DE ONDE VEM O ADMINER
#
#  O Adminer e um unico arquivo PHP. Tentamos, nesta ordem:
#
#    1. o pacote "adminer" do Debian, se existir no repositorio
#    2. o download oficial https://www.adminer.org/latest-mysql.php
#
#  O caminho 2 existe porque o pacote foi removido de algumas versoes do
#  Debian, e porque o proprio projeto distribui assim. Nao dependemos de
#  um pacote que pode nao estar la.
# =====================================================================
set -Eeuo pipefail

# MOD_TAG e lido pelas funcoes de log do modlib.sh.
# shellcheck disable=SC2034
MOD_TAG="adminer"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

WEBROOT="/var/www/newos-adminer"
NGINX_SNIPPET_DIR="/etc/nginx/newos-modules"
ADMINER_URL_MYSQL="https://www.adminer.org/latest-mysql.php"
ADMINER_URL_FULL="https://www.adminer.org/latest.php"

# ---------------------------------------------------------------------
# 1. O APT esta saudavel?
# ---------------------------------------------------------------------
apt_require_healthy

# ---------------------------------------------------------------------
# 2. PHP-FPM (obrigatorio de qualquer jeito)
# ---------------------------------------------------------------------
#  ATENCAO (bug ja corrigido): antes o "apt-get update" aqui era
#  opcional (|| mod_warn). Num NewOS recem-instalado o
#  /var/lib/apt/lists esta VAZIO de proposito, entao sem indices o
#  apt-cache nao conhece pacote nenhum e o modulo dizia
#  "php-fpm nao encontrado no repositorio" -- quando na verdade o
#  problema era nunca ter baixado os indices. Agora e obrigatorio.
apt_ensure_lists

PHP_PKGS=""
for p in php-fpm php-mysql php-mbstring; do
    if pkg_exists "${p}"; then
        PHP_PKGS+=" ${p}"
    else
        mod_warn "Pacote ${p} nao encontrado no repositorio."
    fi
done

if [[ -z "${PHP_PKGS}" ]]; then
    # Fallback: versao explicita, se o meta-pacote nao existir.
    for v in 8.4 8.3 8.2; do
        if pkg_exists "php${v}-fpm"; then
            PHP_PKGS=" php${v}-fpm php${v}-mysql php${v}-mbstring"
            mod_info "Usando PHP ${v} explicitamente."
            break
        fi
    done
fi

if [[ -z "${PHP_PKGS}" ]]; then
    mod_err "Nao encontrei PHP-FPM nos repositorios deste servidor."
    mod_err "Diagnostico (apt-cache policy php-fpm):"
    LC_ALL=C apt-cache policy php-fpm 2>&1 | sed 's/^/[adminer]   /' >&2 || true
    mod_err "Repositorios ativos:"
    {
        cat /etc/apt/sources.list 2>/dev/null
        cat /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources 2>/dev/null
    } | grep -vE '^\s*(#|$)' | sed 's/^/[adminer]   /' >&2 || true
    exit 2
fi

# shellcheck disable=SC2086  # queremos a lista separada em argumentos
apt_install ${PHP_PKGS}

# ---------------------------------------------------------------------
# 3. O Adminer em si
# ---------------------------------------------------------------------
install -d -m 0755 "${WEBROOT}"
ADMINER_SRC=""

if pkg_exists adminer; then
    mod_info "Pacote 'adminer' disponivel no Debian; instalando."
    apt_install adminer

    for cand in /usr/share/adminer/adminer.php \
                /usr/share/adminer/adminer/index.php \
                /usr/share/adminer/index.php; do
        [[ -f "${cand}" ]] && { ADMINER_SRC="${cand}"; break; }
    done
    [[ -z "${ADMINER_SRC}" ]] && \
        ADMINER_SRC="$(find /usr/share/adminer -name '*.php' -type f 2>/dev/null | head -1)"
fi

if [[ -n "${ADMINER_SRC}" ]]; then
    mod_info "Adminer do Debian em: ${ADMINER_SRC}"
    # Um require de uma linha: o "apt upgrade" continua atualizando.
    cat >"${WEBROOT}/index.php" <<PHPEOF
<?php
/**
 * NewOS - ponto de entrada do Adminer (pacote Debian).
 * Carrega o arquivo do pacote para que o apt continue atualizando.
 */
require '${ADMINER_SRC}';
PHPEOF
else
    mod_info "Pacote Debian indisponivel; baixando o Adminer oficial."

    if ! have_internet "${ADMINER_URL_MYSQL}"; then
        mod_die "Sem acesso a adminer.org e sem o pacote no Debian. Verifique a internet do servidor." 2
    fi

    if ! download_try "${ADMINER_URL_MYSQL}" "${WEBROOT}/index.php" 100000; then
        mod_warn "latest-mysql.php falhou; tentando latest.php."
        download_verified "${ADMINER_URL_FULL}" "${WEBROOT}/index.php" 100000
    fi

    # Confere que veio PHP mesmo, e nao uma pagina de erro.
    if ! head -c 32 "${WEBROOT}/index.php" | grep -q '<?php'; then
        rm -f "${WEBROOT}/index.php"
        mod_die "O arquivo baixado nao parece ser o Adminer." 2
    fi
    mod_info "Adminer oficial instalado em ${WEBROOT}/index.php"
fi

chown -R www-data:www-data "${WEBROOT}"
chmod 0644 "${WEBROOT}/index.php"

# ---------------------------------------------------------------------
# 4. Socket do PHP-FPM
# ---------------------------------------------------------------------
PHP_UNIT="$(systemctl list-unit-files 'php*-fpm.service' --no-legend 2>/dev/null | awk '{print $1}' | head -1)"
if [[ -n "${PHP_UNIT}" ]]; then
    systemctl enable --now "${PHP_UNIT}" >/dev/null 2>&1 || true
    mod_info "${PHP_UNIT} ativo."
fi

PHP_SOCK=""
for _ in $(seq 1 10); do
    PHP_SOCK="$(find /run/php -maxdepth 1 -name 'php*-fpm.sock' 2>/dev/null | sort | tail -1)"
    [[ -n "${PHP_SOCK}" ]] && break
    sleep 1
done

if [[ -z "${PHP_SOCK}" ]]; then
    PHP_VER="$(find /etc/php -maxdepth 1 -mindepth 1 -type d -printf '%f\n' 2>/dev/null | sort -V | tail -1)"
    [[ -n "${PHP_VER}" ]] || mod_die "PHP-FPM instalado mas sem socket nem configuracao." 2
    PHP_SOCK="/run/php/php${PHP_VER}-fpm.sock"
    mod_warn "Socket ainda nao criado; assumindo ${PHP_SOCK}."
fi

mod_info "Socket PHP-FPM: ${PHP_SOCK}"

# ---------------------------------------------------------------------
# 5. Trecho do nginx
#
#    auth_request manda cada requisicao para /_authcheck, que o painel
#    responde 200 (sessao valida) ou 401. O Adminer fica atras do mesmo
#    login do painel, sem porta extra exposta na rede.
# ---------------------------------------------------------------------
install -d -m 0755 "${NGINX_SNIPPET_DIR}"

FASTCGI_SNIPPET="snippets/fastcgi-php.conf"
[[ -f /etc/nginx/snippets/fastcgi-php.conf ]] || FASTCGI_SNIPPET="fastcgi.conf"

cat >"${NGINX_SNIPPET_DIR}/adminer.conf" <<NGINXEOF
# NewOS - modulo adminer (gerado por install.sh, nao edite a mao)

location = /adminer {
    return 301 /adminer/;
}

location ^~ /adminer/ {
    # So passa quem ja esta logado no painel.
    auth_request /_authcheck;
    error_page 401 403 = @newos_login;

    alias ${WEBROOT}/;
    index index.php;

    location ~ ^/adminer/.*\.php\$ {
        auth_request /_authcheck;
        error_page 401 403 = @newos_login;
        include ${FASTCGI_SNIPPET};
        fastcgi_pass unix:${PHP_SOCK};
        fastcgi_param SCRIPT_FILENAME ${WEBROOT}/index.php;
        fastcgi_param DOCUMENT_ROOT ${WEBROOT};
    }

    location ~ ^/adminer/\$ {
        auth_request /_authcheck;
        error_page 401 403 = @newos_login;
        include ${FASTCGI_SNIPPET};
        fastcgi_pass unix:${PHP_SOCK};
        fastcgi_param SCRIPT_FILENAME ${WEBROOT}/index.php;
        fastcgi_param DOCUMENT_ROOT ${WEBROOT};
    }
}
NGINXEOF

chmod 0644 "${NGINX_SNIPPET_DIR}/adminer.conf"

# ---------------------------------------------------------------------
# 6. Valida e recarrega
# ---------------------------------------------------------------------
if nginx -t 2>&1 | sed 's/^/[adminer]   /'; then
    systemctl reload nginx
    mod_info "nginx recarregado."
else
    mod_err "nginx -t reprovou. Removendo o trecho para nao derrubar o painel."
    rm -f "${NGINX_SNIPPET_DIR}/adminer.conf"
    nginx -t >/dev/null 2>&1 && systemctl reload nginx || true
    exit 2
fi

mod_info "Instalado. Acesse /adminer/ no mesmo endereco do painel."
mod_info "Use as credenciais do MariaDB (servidor: localhost)."
