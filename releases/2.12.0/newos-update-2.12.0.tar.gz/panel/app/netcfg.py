"""
NewOS Panel - rede: interfaces, bonds, VLANs e rotas.

O painel NUNCA mexe na rede diretamente. Ele le o estado e pede as
alteracoes ao helper privilegiado /usr/local/sbin/newos-netapply (via
sudo), que valida TUDO e escreve os arquivos do systemd-networkd.

Aqui ficam so:
  - a leitura do estado configurado (network.json, pelo helper) e do que
    o kernel tem de fato (ip -json), juntos numa visao para as telas
  - a traducao dos formularios para o JSON que o helper espera

Toda alteracao feita pelo painel usa --safe: se nao for confirmada em
2 minutos (porque o acesso caiu), a rede volta sozinha ao que era.
"""

from __future__ import annotations

import ipaddress
import json
import logging
import subprocess
import time
from pathlib import Path
from typing import Any

from .config import get_settings

log = logging.getLogger("newos.panel.netcfg")

PENDING_FILE = Path("/etc/newos/network.pending")

ROLES = {
    "": "",
    "wan": "WAN",
    "lan": "LAN",
    "mgmt": "Gerência",
    "dmz": "DMZ",
}

BOND_MODES = {
    "active-backup": "Ativo/reserva (active-backup): redundância, funciona em qualquer switch",
    "802.3ad": "LACP (802.3ad): soma de banda, exige LACP no switch",
    "balance-alb": "Balanceamento adaptativo (balance-alb): sem configurar o switch",
    "balance-tlb": "Balanceamento de saída (balance-tlb)",
    "balance-xor": "XOR (balance-xor): exige port-channel estático no switch",
    "balance-rr": "Round-robin (balance-rr)",
    "broadcast": "Broadcast: envia por todas as placas",
}

HASH_POLICIES = ("layer3+4", "layer2+3", "layer2", "encap2+3", "encap3+4")


class NetworkError(RuntimeError):
    """Erro de validacao ou de aplicacao, mostrado ao administrador."""


# =====================================================================
#  Helper privilegiado
# =====================================================================

def _helper(args: list[str], payload: dict[str, Any] | None = None,
            timeout: int = 90) -> dict[str, Any]:
    settings = get_settings()
    cmd = ["sudo", "-n", settings.netapply_bin, *args]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=False,
            input=json.dumps(payload) if payload is not None else None,
        )
    except subprocess.TimeoutExpired as exc:
        raise NetworkError("O helper de rede demorou demais para responder.") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise NetworkError(f"Nao foi possivel executar o helper de rede: {exc}") from exc

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        raise NetworkError(detail.removeprefix("ERRO: ") or
                           f"O helper de rede retornou o codigo {proc.returncode}.")
    try:
        return json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        return {"ok": True, "message": (proc.stdout or "").strip()}


def _change(args: list[str], payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Alteracao feita pelo painel: sempre com rollback automatico."""
    if not get_settings().allow_network_config:
        raise NetworkError(
            "A alteracao de rede pelo painel esta desativada "
            "(PANEL_ALLOW_NETWORK_CONFIG=no em /etc/newos/newos.conf)."
        )
    return _helper([*args, "--safe"], payload)


# =====================================================================
#  Leitura
# =====================================================================

def state() -> dict[str, Any]:
    try:
        return _helper(["state"])
    except NetworkError as exc:
        log.error("Estado da rede indisponivel: %s", exc)
        return {"interfaces": {}, "routes": [], "effective_metrics": {},
                "physical": [], "members": {}, "error": str(exc)}


def pending() -> dict[str, Any] | None:
    """Alteracao aguardando confirmacao (lido direto: o arquivo e 0644)."""
    try:
        data = json.loads(PENDING_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    data["remaining"] = max(0, int(data.get("deadline", 0)) - int(time.time()))
    return data


def _read_sys(name: str, attr: str) -> str:
    try:
        return Path(f"/sys/class/net/{name}/{attr}").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def live() -> dict[str, dict[str, Any]]:
    """O que o kernel tem agora, por interface."""
    try:
        out = subprocess.run(["ip", "-json", "-d", "addr", "show"],
                             capture_output=True, text=True, timeout=10, check=True).stdout
        items = json.loads(out)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        log.error("Falha ao listar interfaces: %s", exc)
        return {}

    protected = get_settings().protected_interfaces
    result: dict[str, dict[str, Any]] = {}
    for item in items:
        name = item.get("ifname", "")
        if not name or name == "lo" or name in protected:
            continue
        info_kind = (item.get("linkinfo") or {}).get("info_kind", "")
        if info_kind not in ("", "bond", "vlan"):
            continue          # bridges, tuneis, veth...: fora do escopo
        if not info_kind and not Path(f"/sys/class/net/{name}/device").exists():
            continue          # virtuais sem tipo conhecido
        speed = _read_sys(name, "speed")
        addrs = [f"{a['local']}/{a['prefixlen']}" for a in item.get("addr_info", [])
                 if a.get("family") == "inet"]
        result[name] = {
            "name": name,
            "kind": {"bond": "bond", "vlan": "vlan"}.get(info_kind, "ethernet"),
            "up": "UP" in item.get("flags", []),
            "carrier": _read_sys(name, "carrier") == "1",
            "operstate": item.get("operstate", "UNKNOWN"),
            "mac": item.get("address", ""),
            "mtu": item.get("mtu", 0),
            "speed": int(speed) if speed.isdigit() and int(speed) > 0 else None,
            "master": item.get("master", ""),
            "addresses": addrs,
        }
    return result


def kernel_routes() -> list[dict[str, Any]]:
    """Rotas realmente ativas no kernel (inclui as que nao sao do painel)."""
    try:
        out = subprocess.run(["ip", "-json", "-4", "route", "show"],
                             capture_output=True, text=True, timeout=10, check=True).stdout
        raw = json.loads(out)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        log.warning("Nao foi possivel listar as rotas do kernel: %s", exc)
        return []
    routes = []
    for item in raw:
        dst = item.get("dst", "")
        if dst == "default":
            dst = "0.0.0.0/0"
        elif dst and "/" not in dst:
            dst = f"{dst}/32"
        routes.append({
            "destination": dst,
            "gateway": item.get("gateway", ""),
            "device": item.get("dev", ""),
            "metric": str(item.get("metric", "") or ""),
            "protocol": item.get("protocol", ""),
            "scope": item.get("scope", ""),
        })
    return routes


def overview() -> dict[str, Any]:
    """
    Visao unica para as telas: cada interface com o que foi CONFIGURADO
    (intencao) e o que o kernel TEM (realidade), lado a lado.
    """
    st = state()
    lv = live()
    kroutes = kernel_routes()
    metrics = st.get("effective_metrics", {})
    members = st.get("members", {})
    cfgs = st.get("interfaces", {})

    live_gw = {r["device"]: r["gateway"] for r in kroutes
               if r["destination"] == "0.0.0.0/0" and r.get("gateway")}

    rows: list[dict[str, Any]] = []
    for name in set(lv) | set(cfgs):
        cfg = cfgs.get(name, {})
        real = lv.get(name, {})
        row = {
            "name": name,
            "kind": cfg.get("kind") or real.get("kind", "ethernet"),
            "configured": bool(cfg),
            "alias": cfg.get("alias", ""),
            "role": cfg.get("role", ""),
            "role_label": ROLES.get(cfg.get("role", ""), ""),
            "mode": cfg.get("mode", "none") if cfg else "",
            "addresses": cfg.get("addresses", []),
            "gateway": cfg.get("gateway", ""),
            "metric": cfg.get("metric"),
            "effective_metric": metrics.get(name),
            "dns": cfg.get("dns", []),
            "domains": cfg.get("domains", []),
            "mtu": cfg.get("mtu"),
            "bond": cfg.get("bond"),
            "vlan": cfg.get("vlan"),
            "member_of": members.get(name, ""),
            "exists": bool(real),
            "up": real.get("up", False),
            "carrier": real.get("carrier", False),
            "operstate": real.get("operstate", "AUSENTE"),
            "mac": real.get("mac", ""),
            "speed": real.get("speed"),
            "live_addresses": real.get("addresses", []),
            "live_gateway": live_gw.get(name, ""),
        }
        first = (row["addresses"] or [""])[0]
        row["form_address"] = first.split("/")[0] if first else ""
        row["form_netmask"] = (str(ipaddress.IPv4Interface(first).netmask)
                               if first else "255.255.255.0")
        row["form_extra"] = "\n".join(row["addresses"][1:])
        rows.append(row)

    # Fisicas primeiro, depois bonds, depois VLANs; dentro, por nome.
    order = {"ethernet": 0, "bond": 1, "vlan": 2}
    rows.sort(key=lambda r: (order.get(r["kind"], 9), r["name"]))

    return {
        "interfaces": rows,
        "by_name": {r["name"]: r for r in rows},
        "bonds": [r for r in rows if r["kind"] == "bond"],
        "vlans": [r for r in rows if r["kind"] == "vlan"],
        "free_physical": [r for r in rows if r["kind"] == "ethernet" and not r["member_of"]],
        "vlan_parents": [r for r in rows
                         if r["kind"] in ("ethernet", "bond") and not r["member_of"]],
        "configured": [r for r in rows if r["configured"] and not r["member_of"]],
        "routes": st.get("routes", []),
        "kernel_routes": kroutes,
        "gateways": sorted(metrics.items(), key=lambda x: x[1]),
        "error": st.get("error", ""),
    }


# =====================================================================
#  Formularios -> helper
# =====================================================================

def netmask_to_prefix(netmask: str) -> int:
    netmask = (netmask or "").strip()
    if netmask.isdigit():
        prefix = int(netmask)
        if 1 <= prefix <= 32:
            return prefix
    try:
        return ipaddress.IPv4Network(f"0.0.0.0/{netmask}").prefixlen
    except ValueError as exc:
        raise NetworkError(f"Mascara invalida: '{netmask}'. Use 255.255.255.0 ou 24.") from exc


def addressing_from_form(form: dict[str, str]) -> dict[str, Any]:
    """Campos de enderecamento comuns as telas de interface, bond e VLAN."""
    mode = form.get("mode", "none")
    data: dict[str, Any] = {
        "alias": form.get("alias", ""),
        "role": form.get("role", ""),
        "mode": mode,
        "mtu": form.get("mtu", ""),
        "metric": form.get("metric", ""),
        "dns": [form.get("dns1", ""), form.get("dns2", "")],
        "domains": form.get("domains", ""),
    }
    if mode == "static":
        address = (form.get("address") or "").strip()
        if not address:
            raise NetworkError("Informe o endereco IP.")
        if "/" not in address:
            address = f"{address}/{netmask_to_prefix(form.get('netmask', ''))}"
        extra = (form.get("extra_addresses") or "").split()
        data["addresses"] = [address, *extra]
        data["gateway"] = form.get("gateway", "")
    return data


def set_interface(form: dict[str, str]) -> dict[str, Any]:
    payload = addressing_from_form(form)
    payload["name"] = form.get("name", "")
    return _change(["set-interface"], payload)


def set_bond(form: dict[str, str], members: list[str]) -> dict[str, Any]:
    payload = addressing_from_form(form)
    payload.update({
        "name": form.get("name", ""),
        "members": members,
        "bond_mode": form.get("bond_mode", "active-backup"),
        "primary": form.get("primary", ""),
        "lacp_rate": form.get("lacp_rate", "fast"),
        "hash_policy": form.get("hash_policy", "layer3+4"),
    })
    return _change(["set-bond"], payload)


def set_vlan(form: dict[str, str]) -> dict[str, Any]:
    payload = addressing_from_form(form)
    payload.update({"parent": form.get("parent", ""), "id": form.get("vlan_id", "")})
    return _change(["set-vlan"], payload)


def delete_interface(name: str) -> dict[str, Any]:
    return _change(["delete-interface", name])


def add_route(form: dict[str, str]) -> dict[str, Any]:
    return _change(["add-route"], {
        "destination": form.get("destination", ""),
        "gateway": form.get("gateway", ""),
        "interface": form.get("interface", ""),
        "metric": form.get("metric", ""),
    })


def delete_route(destination: str) -> dict[str, Any]:
    return _change(["del-route", destination])


def confirm() -> dict[str, Any]:
    return _helper(["confirm"])


def rollback() -> dict[str, Any]:
    return _helper(["rollback"])
