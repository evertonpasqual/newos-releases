"""
NewOS Panel - acesso ao MariaDB.

Conexao por requisicao (o painel tem carga baixissima: um punhado de
usuarios administrativos). Simples e sem estado global para vazar.
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any, Iterator

import pymysql
from pymysql.cursors import DictCursor

from .config import get_settings

log = logging.getLogger("newos.panel.db")


class DatabaseUnavailable(RuntimeError):
    """O MariaDB nao respondeu. Tratado como erro amigavel na interface."""


@contextlib.contextmanager
def connection() -> Iterator[pymysql.connections.Connection]:
    """Abre uma conexao, garante commit/rollback e fecha ao sair."""
    settings = get_settings()
    try:
        conn = pymysql.connect(
            host=settings.db_host,
            port=settings.db_port,
            user=settings.db_user,
            password=settings.db_password,
            database=settings.db_name,
            charset="utf8mb4",
            cursorclass=DictCursor,
            autocommit=False,
            connect_timeout=5,
            read_timeout=10,
            write_timeout=10,
        )
    except pymysql.MySQLError as exc:
        log.error("Falha ao conectar no MariaDB: %s", exc)
        raise DatabaseUnavailable(str(exc)) from exc

    try:
        yield conn
        conn.commit()
    except Exception:
        with contextlib.suppress(Exception):
            conn.rollback()
        raise
    finally:
        with contextlib.suppress(Exception):
            conn.close()


def query_one(sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchone()


def query_all(sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return list(cur.fetchall())


def execute(sql: str, params: tuple[Any, ...] = ()) -> int:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount


def healthcheck() -> tuple[bool, str]:
    """Retorna (ok, mensagem) para exibir no dashboard."""
    try:
        with connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT VERSION() AS v")
            row = cur.fetchone()
        return True, (row or {}).get("v", "desconhecida")
    except DatabaseUnavailable as exc:
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001 - queremos reportar qualquer falha
        return False, str(exc)


def log_audit(user: str, action: str, detail: str, ip: str = "") -> None:
    """
    Grava uma linha na tabela de auditoria.

    Nunca levanta excecao: auditoria falhando nao pode derrubar a acao
    que o administrador pediu.
    """
    try:
        execute(
            "INSERT INTO audit_log (username, action, detail, source_ip) "
            "VALUES (%s, %s, %s, %s)",
            (user[:64], action[:64], detail[:1000], ip[:45]),
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("Nao foi possivel gravar auditoria: %s", exc)
