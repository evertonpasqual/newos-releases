"""
NewOS Panel - modulo Firewall (nftables).

    /firewall                 visao geral: estado, atividade ao vivo, portas em uso
    /firewall/regras          entrada (este servidor) e encaminhamento (entre redes)
    /firewall/nat             NAT (LAN sai pela WAN) e redirecionamento de portas
    /firewall/protecao        painel e SSH, protecoes, bloqueios
    /firewall/grupos          grupos de enderecos e de portas (GRUPO-SEDE...)
    GET  /api/firewall/mapa               regras + grupos + contadores (mapa animado)
    POST /firewall/aplicar/<secao>/<op>   toda alteracao (com volta automatica; a
                                          lista de bloqueio vale direto)
    POST /firewall/confirmar | /firewall/desfazer | /firewall/ligar | /firewall/desligar
    GET  /api/firewall/atividade          pacotes registrados + contadores (ao vivo)

O helper newos-firewall valida e aplica; cada alteracao feita aqui volta
sozinha em 2 minutos se nao for confirmada (o acesso pode ter caido).
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules

log = logging.getLogger("newos.panel.firewall")
HELPER = "/usr/local/sbin/newos-firewall"
PENDING = Path("/etc/newos/firewall.pending")
SECTIONS = {"rule", "admin", "protect", "block", "masq", "forward", "geo", "group", "ssh", "defaults"}
LISTS = ("admin_zones", "src_groups", "dst_groups", "ssh_groups")
OPS = {"save", "delete", "toggle", "up", "down"}
BACK = {"rule": "/firewall/regras", "admin": "/firewall/protecao", "protect": "/firewall/protecao",
        "block": "/firewall/protecao", "masq": "/firewall/nat", "forward": "/firewall/nat",
        "geo": "/firewall/protecao#pais", "group": "/firewall/grupos", "ssh": "/firewall/protecao#admin",
        "defaults": "/firewall/protecao#admin"}


# Atalhos da tela de bloqueio por pais (qualquer outro codigo ISO de 2 letras tambem vale)
COUNTRIES = {
    "BR": "Brasil", "AR": "Argentina", "UY": "Uruguai", "PY": "Paraguai", "CL": "Chile", "BO": "Bolívia",
    "PE": "Peru", "CO": "Colômbia", "VE": "Venezuela", "EC": "Equador", "MX": "México", "US": "Estados Unidos",
    "CA": "Canadá", "PT": "Portugal", "ES": "Espanha", "FR": "França", "DE": "Alemanha", "IT": "Itália",
    "GB": "Reino Unido", "NL": "Holanda", "IE": "Irlanda", "BE": "Bélgica", "CH": "Suíça", "SE": "Suécia",
    "FI": "Finlândia", "PL": "Polônia", "RO": "Romênia", "UA": "Ucrânia", "RU": "Rússia", "TR": "Turquia",
    "CN": "China", "HK": "Hong Kong", "TW": "Taiwan", "JP": "Japão", "KR": "Coreia do Sul", "KP": "Coreia do Norte",
    "IN": "Índia", "PK": "Paquistão", "BD": "Bangladesh", "VN": "Vietnã", "TH": "Tailândia", "ID": "Indonésia",
    "SG": "Singapura", "IR": "Irã", "IQ": "Iraque", "IL": "Israel", "AE": "Emirados Árabes", "SA": "Arábia Saudita",
    "EG": "Egito", "NG": "Nigéria", "ZA": "África do Sul", "AO": "Angola", "MZ": "Moçambique", "AU": "Austrália",
}


class FirewallError(Exception):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise FirewallError(f"Nao foi possivel executar o helper do firewall: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise FirewallError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def pending() -> dict[str, Any] | None:
    """Alteracao aguardando confirmacao (lido direto: o arquivo e 0644)."""
    try:
        p = json.loads(PENDING.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    import time
    p["remaining"] = max(0, int(p.get("deadline", 0)) - int(time.time()))
    return p


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not (modules.get_module("firewall") or {}).get("enabled"):
            flash(request, "aviso", "Ligue o módulo Firewall em Sistema > Módulos.")
            return None, redirect("/modulos")
        return user, None

    async def page(request: Request, template: str, active: str, extra: bool = False):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(helper, ["state"])
            cnt = await run_in_threadpool(helper, ["counters"])
            act = await run_in_threadpool(helper, ["activity", "3600"]) if extra else {"events": []}
        except FirewallError as exc:
            flash(request, "erro", str(exc))
            st, cnt, act = {"state": {}, "zones": {}, "ports": [], "zone_names": {}}, {"counters": {}}, {"events": []}
        warnings = request.session.pop("fw_warnings", None)
        return render(request, template, active=active, fw=st, cnt=cnt.get("counters", {}),
                      autoblock=cnt.get("autoblock", []), events=act.get("events", []), fw_warnings=warnings,
                      countries=COUNTRIES)

    @app.get("/firewall", response_class=HTMLResponse)
    async def fw_home(request: Request):
        return await page(request, "firewall_overview.html", "firewall", extra=True)

    @app.get("/firewall/regras", response_class=HTMLResponse)
    async def fw_rules(request: Request):
        return await page(request, "firewall_rules.html", "firewall-regras")

    @app.get("/firewall/nat", response_class=HTMLResponse)
    async def fw_nat(request: Request):
        return await page(request, "firewall_nat.html", "firewall-nat")

    @app.get("/firewall/grupos", response_class=HTMLResponse)
    async def fw_groups(request: Request):
        return await page(request, "firewall_groups.html", "firewall-grupos")

    # Mapa animado: o estado e os contadores juntos (a tela pede a cada poucos segundos)
    @app.get("/api/firewall/mapa")
    async def fw_map(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            st = await run_in_threadpool(helper, ["state"])
            cnt = await run_in_threadpool(helper, ["counters"])
        except FirewallError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=500)
        return {"ok": True, "state": st.get("state", {}), "ports": st.get("ports", []), "active": st.get("active"),
                "zone_names": st.get("zone_names", {}), "zones": st.get("zones", {}),
                "panel_port": st.get("panel_port", 81), "counters": cnt.get("counters", {}),
                "autoblock": len(cnt.get("autoblock", []))}

    @app.get("/firewall/protecao", response_class=HTMLResponse)
    async def fw_protect(request: Request):
        return await page(request, "firewall_protect.html", "firewall-protecao")

    def done(request: Request, user: dict[str, Any], res: dict[str, Any]) -> None:
        msg = res.get("message", "Feito")
        if res.get("pending"):
            msg += f". Confirme em até {res.get('seconds', 120)} s, senão volta sozinho."
        flash(request, "ok", msg)
        if res.get("warnings"):
            request.session["fw_warnings"] = [w[:200] for w in res["warnings"][:6]]
        db.log_audit(user["username"], "firewall", res.get("message", "")[:200], auth.client_ip(request))

    @app.post("/firewall/aplicar/{section}/{op}", response_class=HTMLResponse)
    async def fw_apply(request: Request, section: str, op: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if section not in SECTIONS or op not in OPS:
            return redirect("/firewall")
        raw = await request.form()
        data: dict[str, Any] = {k: str(raw.get(k)) for k in raw.keys()}
        for k in LISTS:
            if k in raw:
                data[k] = [str(v) for v in raw.getlist(k)]
        back = str(raw.get("back") or BACK[section])
        data["_client"] = auth.client_ip(request)      # o helper recusa bloquear quem esta usando o painel
        try:
            res = await run_in_threadpool(helper, ["apply", "--safe"], {"section": section, "op": op, "data": data},
                                          300 if section == "geo" else 120)
            if section == "block" and op == "save" and not res.get("pending"):
                res["message"] += " (já valendo; está em Firewall › Proteção › Lista de bloqueio)"
            done(request, user, res)
        except FirewallError as exc:
            flash(request, "erro", str(exc))
        return redirect(back if back.startswith("/firewall") else "/firewall")

    @app.post("/firewall/{acao}", response_class=HTMLResponse)
    async def fw_action(request: Request, acao: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        cmd = {"confirmar": ["confirm"], "desfazer": ["rollback"], "ligar": ["enable", "--safe"],
               "desligar": ["disable", "--safe"]}.get(acao)
        raw = await request.form()
        if acao == "desbloquear":
            cmd = ["unblock", str(raw.get("ip", ""))]
        if not cmd:
            return redirect("/firewall")
        try:
            res = await run_in_threadpool(helper, cmd)
            done(request, user, res)
        except FirewallError as exc:
            flash(request, "erro", str(exc))
        back = str(raw.get("back") or "/firewall")
        return redirect(back if back.startswith("/firewall") else "/firewall")

    @app.get("/api/firewall/atividade")
    async def fw_activity(request: Request, segundos: int = 3600):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            act = await run_in_threadpool(helper, ["activity", str(max(60, min(segundos, 86400)))])
            cnt = await run_in_threadpool(helper, ["counters"])
        except FirewallError as exc:
            return {"ok": False, "message": str(exc)}
        return {"ok": True, "events": act.get("events", [])[:80], "counters": cnt.get("counters", {}),
                "autoblock": cnt.get("autoblock", [])}

    @app.get("/api/firewall/pending")
    async def fw_pending(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        return pending() or {"pending": False}
