"""
NewOS Panel - Sistema > Servidor: hostname, dominio e /etc/hosts.

O helper newos-system faz as alteracoes (validadas, com copia do arquivo
anterior). Ao trocar o nome, o painel oferece levar o nome novo para o
Zabbix Agent e para o host local do Prometheus, quando eles usavam o
nome antigo.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, link_routes, modules, terminal_routes

log = logging.getLogger("newos.panel.system")
HELPER = "/usr/local/sbin/newos-system"


class SystemError_(Exception):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=120, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemError_(f"Nao foi possivel executar o helper: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise SystemError_((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def related(old: str) -> dict[str, bool]:
    """Onde o nome antigo aparece (para oferecer levar o nome novo junto)."""
    out = {"zabbix": False, "prometheus": False}
    zbx = modules.get_module("zabbix") or {}
    if zbx.get("enabled") and any(c["key"] == "agent2" and c["enabled"] for c in zbx.get("components", [])):
        out["zabbix"] = (modules.get_config("zabbix", "agent2").get("Hostname") or "") == old
    prom = modules.get_module("prometheus") or {}
    if prom.get("enabled"):
        try:
            from . import prometheus
            st = prometheus.state()
            out["prometheus"] = any(n.get("address") in ("localhost", "127.0.0.1") and n.get("name") == old
                                    for n in st.get("nodes", []))
        except Exception:  # noqa: BLE001
            pass
    return out


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    @app.get("/sistema/servidor", response_class=HTMLResponse)
    async def server_page(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        try:
            info = await run_in_threadpool(helper, ["show"])
        except SystemError_ as exc:
            flash(request, "erro", str(exc))
            info = {}
        rel = await run_in_threadpool(related, info.get("hostname", "")) if info else {}
        admin = await run_in_threadpool(terminal_routes.is_admin, auth.current_user(request))
        return render(request, "system_server.html", active="servidor", info=info, rel=rel, admin=admin,
                      link=link_routes.link_status())

    @app.post("/sistema/servidor/grub", response_class=HTMLResponse)
    async def server_grub(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            flash(request, "erro", "Só administradores mudam a senha do GRUB.")
            return redirect("/sistema/servidor#grub")
        f = await request.form()
        ip = auth.client_ip(request)
        if auth.is_locked_out(ip):
            flash(request, "erro", "Muitas tentativas. Aguarde alguns minutos.")
            return redirect("/sistema/servidor#grub")
        if not await run_in_threadpool(auth.authenticate, user["username"], str(f.get("current", ""))):
            auth.register_failure(ip)
            flash(request, "erro", "Sua senha do painel não confere.")
            return redirect("/sistema/servidor#grub")
        auth.clear_failures(ip)
        action = "off" if f.get("action") == "off" else "set"
        payload: dict[str, Any] = {"action": action}
        if action == "set":
            pw, pw2 = str(f.get("password", "")), str(f.get("password2", ""))
            if pw != pw2:
                flash(request, "erro", "As duas senhas do GRUB não são iguais.")
                return redirect("/sistema/servidor#grub")
            payload["password"] = pw
        try:
            res = await run_in_threadpool(helper, ["grub-password"], payload)
            db.log_audit(user["username"], "sistema",
                         "definiu a senha do GRUB" if action == "set" else "removeu a senha do GRUB", ip)
            flash(request, "ok", res["message"])
        except SystemError_ as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/servidor#grub")

    @app.post("/sistema/servidor/identidade", response_class=HTMLResponse)
    async def server_identity(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        f = await request.form()
        try:
            res = await run_in_threadpool(helper, ["set-identity"], {
                "hostname": str(f.get("hostname", "")), "domain": str(f.get("domain", "")),
                "self_ip": bool(f.get("self_ip"))})
        except SystemError_ as exc:
            flash(request, "erro", str(exc))
            return redirect("/sistema/servidor")
        msgs = [res["message"]]
        old, new = res.get("old_hostname", ""), res["hostname"]
        if old != new and f.get("sync_zabbix"):
            try:
                await run_in_threadpool(modules.set_config, "zabbix", "agent2", {"Hostname": new})
                msgs.append("Zabbix Agent agora se apresenta como " + new + " (ajuste o host no Zabbix Server).")
            except modules.ModuleError as exc:
                msgs.append(f"Zabbix Agent não foi ajustado: {exc}")
        if old != new and f.get("sync_prometheus"):
            try:
                from . import prometheus
                st = await run_in_threadpool(prometheus.state)
                me = next(n for n in st.get("nodes", []) if n.get("address") in ("localhost", "127.0.0.1")
                          and n.get("name") == old)
                await run_in_threadpool(prometheus.apply, "node", {"orig": me["address"],
                                                                   "address": me["address"], "name": new})
                msgs.append("Prometheus: este servidor aparece como " + new + ".")
            except Exception as exc:  # noqa: BLE001
                msgs.append(f"Prometheus não foi ajustado: {exc}")
        db.log_audit(user["username"], "sistema", f"identidade: {old} -> {res['fqdn']}", auth.client_ip(request))
        flash(request, "ok", " ".join(msgs))
        return redirect("/sistema/servidor")

    @app.post("/sistema/servidor/hosts", response_class=HTMLResponse)
    async def server_hosts(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        f = await request.form()
        ips, names, comments = f.getlist("ip"), f.getlist("names"), f.getlist("comment")
        entries = [{"ip": str(ips[i]), "names": str(names[i]) if i < len(names) else "",
                    "comment": str(comments[i]) if i < len(comments) else ""} for i in range(len(ips))]
        try:
            res = await run_in_threadpool(helper, ["set-hosts"], {"entries": entries})
            db.log_audit(user["username"], "sistema", "editou o /etc/hosts", auth.client_ip(request))
            flash(request, "ok", res["message"])
        except SystemError_ as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/servidor#hosts")
