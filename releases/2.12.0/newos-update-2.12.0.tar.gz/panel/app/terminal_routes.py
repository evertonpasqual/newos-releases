"""
NewOS Panel - Sistema > Terminal.

    GET  /sistema/terminal              pagina (pede a senha de novo antes)
    POST /sistema/terminal/acesso       senha (+ codigo do MFA) -> libera por 30 min
    POST /api/terminal/abrir            abre um terminal          -> {id}
    GET  /api/terminal/<id>/saida       saida ao vivo (Server-Sent Events)
    POST /api/terminal/<id>/entrada     o que foi digitado
    POST /api/terminal/<id>/tamanho     colunas x linhas
    POST /api/terminal/<id>/fechar

So administradores. Abrir e fechar vao para a auditoria.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import secrets
import time
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, mfa, terminal

log = logging.getLogger("newos.panel.terminal")
ACCESS_TTL = 30 * 60          # a senha confirmada vale 30 min para abrir terminais


def is_admin(user: dict[str, Any]) -> bool:
    try:
        row = db.query_one("SELECT is_admin, is_active FROM users WHERE id = %s", (user["id"],))
    except Exception:  # noqa: BLE001
        return False
    return bool(row and row["is_admin"] and row["is_active"])


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def access_ok(request: Request) -> bool:
        return time.time() - float(request.session.get("term_ok") or 0) < ACCESS_TTL

    @app.on_event("startup")
    async def _reaper() -> None:
        async def loop() -> None:
            while True:
                await asyncio.sleep(60)
                try:
                    terminal.reap(auth.idle_minutes() * 60)
                except Exception as exc:  # noqa: BLE001
                    log.warning("Limpeza dos terminais falhou: %s", exc)
        asyncio.get_event_loop().create_task(loop())

    @app.get("/sistema/terminal", response_class=HTMLResponse)
    async def term_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        admin = await run_in_threadpool(is_admin, user)
        st = await run_in_threadpool(mfa.status, user["id"]) if admin else {"enabled": False}
        app = request.query_params.get("app")
        app = app if app in terminal.APPS else "shell"
        return render(request, "system_terminal.html", active="terminal" if app == "shell" else "trafego",
                      admin=admin, app=app,
                      access=admin and access_ok(request), mfa_on=st["enabled"],
                      access_min=ACCESS_TTL // 60)

    @app.post("/sistema/terminal/acesso", response_class=HTMLResponse)
    async def term_access(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        back = "/sistema/terminal?app=iptraf" if request.query_params.get("app") == "iptraf" else "/sistema/terminal"
        if not await run_in_threadpool(is_admin, user):
            return redirect(back)
        form = await request.form()
        ip = auth.client_ip(request)
        if auth.is_locked_out(ip):
            flash(request, "erro", "Muitas tentativas. Aguarde alguns minutos.")
            return redirect(back)
        ok = await run_in_threadpool(auth.authenticate, user["username"], str(form.get("password", "")))
        st = await run_in_threadpool(mfa.status, user["id"])
        if ok and st["enabled"]:
            ok = bool(await run_in_threadpool(mfa.verify_user, user["id"], str(form.get("code", ""))))
        if not ok:
            auth.register_failure(ip)
            db.log_audit(user["username"], "terminal", "Acesso ao terminal negado (senha/codigo)", ip)
            flash(request, "erro", "Senha ou código incorreto.")
            return redirect(back)
        auth.clear_failures(ip)
        request.session["term_ok"] = time.time()
        db.log_audit(user["username"], "terminal", "Acesso administrativo ao terminal confirmado", ip)
        return redirect(back)

    async def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão encerrada."}, status_code=401)
        if not await run_in_threadpool(is_admin, user) or not access_ok(request):
            return None, JSONResponse({"ok": False, "message": "Confirme o acesso administrativo."},
                                      status_code=403)
        return user, None

    @app.post("/api/terminal/abrir")
    async def term_open(request: Request):
        user, bad = await guard(request)
        if bad:
            return bad
        try:
            body = await request.json()
        except ValueError:
            body = {}
        try:
            sid = request.session.get("tsid") or secrets.token_hex(8)
            request.session["tsid"] = sid
            app = body.get("app") if body.get("app") in terminal.APPS else "shell"
            t = terminal.open_term(user["username"], int(body.get("cols", 100)), int(body.get("rows", 30)), sid, app)
        except (RuntimeError, OSError) as exc:
            return {"ok": False, "message": str(exc)}
        db.log_audit(user["username"], "terminal",
                     "Terminal de root aberto" + (f" ({app})" if app != "shell" else ""), auth.client_ip(request))
        return {"ok": True, "id": t.id}

    @app.get("/api/terminal/{tid}/saida")
    async def term_output(request: Request, tid: str):
        user, bad = await guard(request)
        if bad:
            return bad
        t = terminal.get(tid, user["username"])
        if not t:
            return JSONResponse({"ok": False}, status_code=404)
        q: asyncio.Queue = asyncio.Queue()
        t.waiters.append(q)

        async def stream():
            try:
                if t.history:
                    yield f"data: {base64.b64encode(bytes(t.history)).decode()}\n\n"
                if t.closed:
                    yield "event: fim\ndata: x\n\n"
                    return
                while True:
                    try:
                        data = await asyncio.wait_for(q.get(), timeout=15)
                    except asyncio.TimeoutError:
                        if await request.is_disconnected():
                            return
                        yield ": ping\n\n"          # mantem a conexao (nginx/proxies)
                        continue
                    if data is None:
                        yield "event: fim\ndata: x\n\n"
                        return
                    chunks = [data]
                    while not q.empty():            # junta o que chegou junto
                        nxt = q.get_nowait()
                        if nxt is None:
                            q.put_nowait(None)
                            break
                        chunks.append(nxt)
                    yield f"data: {base64.b64encode(b''.join(chunks)).decode()}\n\n"
            finally:
                if q in t.waiters:
                    t.waiters.remove(q)

        return StreamingResponse(stream(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    @app.post("/api/terminal/{tid}/entrada")
    async def term_input(request: Request, tid: str):
        user, bad = await guard(request)
        if bad:
            return bad
        t = terminal.get(tid, user["username"])
        if not t or t.closed:
            return JSONResponse({"ok": False, "closed": True}, status_code=410)
        data = await request.body()
        if len(data) > 1_000_000:
            return JSONResponse({"ok": False}, status_code=413)
        terminal.write(t, data)
        return {"ok": True}

    @app.post("/api/terminal/{tid}/tamanho")
    async def term_resize(request: Request, tid: str):
        user, bad = await guard(request)
        if bad:
            return bad
        t = terminal.get(tid, user["username"])
        if t:
            body = await request.json()
            terminal.resize(t, int(body.get("cols", 100)), int(body.get("rows", 30)))
        return {"ok": True}

    @app.post("/api/terminal/{tid}/fechar")
    async def term_close(request: Request, tid: str):
        user = auth.current_user(request)
        if not user:
            return JSONResponse({"ok": False}, status_code=401)
        t = terminal.get(tid, user["username"])
        if t:
            terminal.close(t)
            db.log_audit(user["username"], "terminal", "Terminal de root fechado", auth.client_ip(request))
        return {"ok": True}
