"""
NewOS Panel - verificacao em duas etapas (MFA por TOTP, RFC 6238).

Funciona com qualquer app autenticador (Google Authenticator, Microsoft
Authenticator, Authy, 1Password, Bitwarden...): um codigo de 6 digitos que
muda a cada 30 s, calculado a partir de um segredo compartilhado no QR code.

    - o mesmo codigo nao vale duas vezes (guarda o ultimo passo usado)
    - aceita 30 s de diferenca de relogio para cada lado
    - 8 codigos de recuperacao de uso unico (guardados como hash) para
      quem perder o celular
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import socket
import struct
import time
import urllib.parse
from typing import Any

from . import db
from .qrcodegen import QrCode

STEP = 30
DIGITS = 6
WINDOW = 1          # passos aceitos antes/depois (relogio do celular adiantado/atrasado)


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def _code(secret: str, step: int) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", step), hashlib.sha1).digest()
    off = digest[-1] & 0x0F
    num = struct.unpack(">I", digest[off:off + 4])[0] & 0x7FFFFFFF
    return str(num % 10 ** DIGITS).zfill(DIGITS)


def check(secret: str, code: str, last_step: int | None = None) -> int | None:
    """Passo aceito (para guardar) ou None. Recusa codigo ja usado."""
    code = "".join(ch for ch in (code or "") if ch.isdigit())
    if len(code) != DIGITS or not secret:
        return None
    now = int(time.time()) // STEP
    for step in range(now - WINDOW, now + WINDOW + 1):
        if hmac.compare_digest(_code(secret, step), code):
            if last_step is not None and step <= last_step:
                return None
            return step
    return None


def uri(secret: str, username: str) -> str:
    issuer = f"NewOS {socket.gethostname()}"
    label = urllib.parse.quote(f"{issuer}:{username}")
    return (f"otpauth://totp/{label}?secret={secret}&issuer={urllib.parse.quote(issuer)}"
            f"&algorithm=SHA1&digits={DIGITS}&period={STEP}")


def qr_svg(text: str) -> str:
    """QR code em SVG (sem imagem externa nem JS)."""
    qr = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
    size, border = qr.get_size(), 3
    parts = [f"M{x + border},{y + border}h1v1h-1z"
             for y in range(size) for x in range(size) if qr.get_module(x, y)]
    dim = size + border * 2
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" class="mfa-qr" '
            f'shape-rendering="crispEdges" role="img" aria-label="QR code do autenticador">'
            f'<rect width="100%" height="100%" fill="#fff"/><path d="{" ".join(parts)}" fill="#0b1733"/></svg>')


def pretty(secret: str) -> str:
    return " ".join(secret[i:i + 4] for i in range(0, len(secret), 4))


# ---------------------------------------------------------------------
#  Codigos de recuperacao
# ---------------------------------------------------------------------

def _h(code: str) -> str:
    return hashlib.sha256(code.replace("-", "").lower().encode()).hexdigest()


def new_recovery() -> tuple[list[str], str]:
    codes = [f"{secrets.token_hex(2)}-{secrets.token_hex(2)}-{secrets.token_hex(2)}" for _ in range(8)]
    return codes, json.dumps([_h(c) for c in codes])


# ---------------------------------------------------------------------
#  Banco
# ---------------------------------------------------------------------

def status(user_id: int) -> dict[str, Any]:
    row = db.query_one("SELECT mfa_enabled, mfa_recovery, mfa_since FROM users WHERE id = %s", (user_id,)) or {}
    try:
        left = len(json.loads(row.get("mfa_recovery") or "[]"))
    except ValueError:
        left = 0
    return {"enabled": bool(row.get("mfa_enabled")), "recovery_left": left, "since": row.get("mfa_since")}


def enable(user_id: int, secret: str, step: int) -> list[str]:
    codes, stored = new_recovery()
    db.execute("UPDATE users SET mfa_secret = %s, mfa_enabled = 1, mfa_recovery = %s, mfa_last_step = %s, "
               "mfa_since = NOW() WHERE id = %s", (secret, stored, step, user_id))
    return codes


def disable(user_id: int) -> None:
    db.execute("UPDATE users SET mfa_secret = NULL, mfa_enabled = 0, mfa_recovery = NULL, "
               "mfa_last_step = NULL, mfa_since = NULL WHERE id = %s", (user_id,))


def regenerate_recovery(user_id: int) -> list[str]:
    codes, stored = new_recovery()
    db.execute("UPDATE users SET mfa_recovery = %s WHERE id = %s", (stored, user_id))
    return codes


def verify_user(user_id: int, code: str) -> str | None:
    """Confere o codigo do app OU um codigo de recuperacao. Retorna como entrou."""
    row = db.query_one("SELECT mfa_secret, mfa_enabled, mfa_recovery, mfa_last_step FROM users WHERE id = %s",
                       (user_id,))
    if not row or not row.get("mfa_enabled"):
        return None
    step = check(row["mfa_secret"], code, row.get("mfa_last_step"))
    if step is not None:
        db.execute("UPDATE users SET mfa_last_step = %s WHERE id = %s", (step, user_id))
        return "app"
    clean = (code or "").strip()
    if "-" in clean or len(clean) == 12:
        try:
            hashes = json.loads(row.get("mfa_recovery") or "[]")
        except ValueError:
            hashes = []
        h = _h(clean)
        if h in hashes:
            hashes.remove(h)
            db.execute("UPDATE users SET mfa_recovery = %s WHERE id = %s", (json.dumps(hashes), user_id))
            return "recuperacao"
    return None
