"""
NewOS Panel - modulo Logs (Monitoramento > Logs (Graylog)).

    /monitoramento/logs                 estado, destino, certificado, fila,
                                        fontes, ajustes e como apontar cada
                                        tipo de equipamento para este NewOS
    POST /monitoramento/logs/ajustes    portas, copia local, fila em disco
    POST /monitoramento/logs/certificado renova o certificado agora
    GET  /api/logs                      estado (atualiza a tela sozinha)
    POST /api/logs/teste                mensagem de teste + teste do TLS
    GET  /api/logs/fonte/<ip>           ultimas linhas recebidas de uma fonte

Tudo pelo helper newos-logs (sudo). O certificado vem do NewOS Manager
pelo agente newos-link; o painel nunca ve a chave privada.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules, monitoring_routes, offline

log = logging.getLogger("newos.panel.logs")
HELPER = "/usr/local/sbin/newos-logs"
IP_RE = re.compile(r"^[0-9A-Fa-f:.]{2,45}$")
STATES = {
    "ok": ("ok", "Enviando ao Graylog"),
    "queue": ("warn", "Guardando na fila (Graylog sem resposta)"),
    "no-cert": ("warn", "Aguardando o certificado do Manager"),
    "no-destination": ("warn", "Aguardando o destino do Manager"),
    "no-manager": ("err", "Este NewOS não está ativo no NewOS Manager"),
    "suspended": ("err", "Servidor suspenso: logs parados"),
    "off": ("muted", "Desligado"),
}


class LogsError(Exception):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise LogsError(f"Nao foi possivel executar o helper de logs: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise LogsError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("logs") or {}).get("enabled"))

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Logs (Graylog) em Sistema > Módulos.")
            return None, redirect("/modulos")
        return user, None

    def api_guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        if not enabled():
            return None, JSONResponse({"ok": False, "message": "Módulo desligado."}, status_code=409)
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "logs", what, auth.client_ip(request))
        log.info("Logs por %s: %s", user["username"], what)

    @app.get("/monitoramento/logs", response_class=HTMLResponse)
    async def logs_page(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            st = await run_in_threadpool(helper, ["status"])
        except LogsError as exc:
            st = {"ok": False, "state": "off", "message": str(exc), "settings": {}, "sources": [], "ips": [],
                  "cert": {}, "destination": {}, "stats": {}}
        here = (request.url.hostname or "")
        ips = st.get("ips") or []
        newos_ip = here if here in ips else (ips[0] if ips else here)
        hosts = await run_in_threadpool(monitoring_routes.panel_addresses, request)
        return render(request, "logs.html", active="logs", st=st, states=STATES, newos_ip=newos_ip,
                      panel_hosts=hosts, offline_rsyslog=offline.group_info("rsyslog"))

    @app.post("/monitoramento/logs/ajustes", response_class=HTMLResponse)
    async def logs_save(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        form = await request.form()
        body = {k: str(form.get(k) or "") for k in ("udp", "tcp", "port", "forward_local", "local_days", "buffer_gb")}
        try:
            res = await run_in_threadpool(helper, ["save"], body)
            audit(request, user, f"ajustes: {body}")
            flash(request, "ok", res.get("message", "Salvo."))
        except LogsError as exc:
            flash(request, "erro", str(exc))
        return redirect("/monitoramento/logs#ajustes")

    @app.post("/monitoramento/logs/certificado", response_class=HTMLResponse)
    async def logs_cert(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            res = await run_in_threadpool(helper, ["cert"], None, 180)
            audit(request, user, "renovou o certificado de logs")
            flash(request, "ok", res.get("message", "Certificado renovado."))
        except LogsError as exc:
            flash(request, "erro", f"Certificado não renovado: {exc}")
        return redirect("/monitoramento/logs")

    @app.get("/api/logs")
    async def logs_api(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        try:
            return await run_in_threadpool(helper, ["status"])
        except LogsError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=500)

    @app.post("/api/logs/teste")
    async def logs_test(request: Request):
        user, bad = api_guard(request)
        if bad:
            return bad
        try:
            res = await run_in_threadpool(helper, ["test"], None, 60)
        except LogsError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
        audit(request, user, f"teste: {res.get('tag', '')}")
        return res

    @app.get("/api/logs/fonte/{ip}")
    async def logs_source(request: Request, ip: str, n: int = 100):
        _, bad = api_guard(request)
        if bad:
            return bad
        if not IP_RE.match(ip):
            return JSONResponse({"ok": False, "message": "Fonte inválida."}, status_code=400)
        try:
            return await run_in_threadpool(helper, ["tail", ip, str(max(10, min(500, n)))])
        except LogsError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=404)
