"""
NewOS Panel - Sistema > Agendamentos.

    /sistema/agendamentos             o que roda sozinho: timers do systemd,
                                      cron e o agendador do Bareos, com a
                                      ultima execucao, o resultado e a proxima
    GET  /api/agendamentos            a mesma lista (a tela atualiza sozinha)
    GET  /api/agendamentos/log/<u>    ultimas linhas do journal
    GET  /api/agendamentos/calendario proximas execucoes de uma expressao
    POST /api/agendamentos/executar   {unit}            (admin)
    POST /api/agendamentos/ligar      {unit, on}        (admin)
    POST /api/agendamentos/tarefa     {id?, name, command, calendar, password}  (admin + senha)
    POST /api/agendamentos/apagar     {id, password}    (admin + senha)

Tarefas novas rodam como root: so administradores, e com a senha de novo
(como o Terminal). Tudo pelo helper newos-sched.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, mfa, terminal_routes

log = logging.getLogger("newos.panel.schedule")
HELPER = "/usr/local/sbin/newos-sched"


def helper(args: list[str], stdin: Any = None, timeout: int = 90) -> dict[str, Any]:
    data = None if stdin is None else json.dumps(stdin)
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], input=data, capture_output=True, text=True,
                              timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "message": str(exc)}
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        return {"ok": False, "message": (lines[-1] if lines else "falhou").removeprefix("ERRO: ")}
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "message": "Resposta inválida do newos-sched."}


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def api_user(request: Request, admin: bool = False) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        if admin and not terminal_routes.is_admin(user):
            return None, JSONResponse({"ok": False, "message": "Só administradores."}, status_code=403)
        return user, None

    def password_ok(user: dict[str, Any], password: str, code: str = "") -> bool:
        """Senha de novo (e o codigo do MFA, se a conta usa), como no Terminal."""
        if not auth.authenticate(user["username"], password):
            return False
        if mfa.status(user["id"])["enabled"]:
            return bool(mfa.verify_user(user["id"], code))
        return True

    def mfa_on(user: dict[str, Any]) -> bool:
        return bool(mfa.status(user["id"])["enabled"])

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "agendamentos", what, auth.client_ip(request))
        log.info("Agendamentos por %s: %s", user["username"], what)

    @app.get("/sistema/agendamentos", response_class=HTMLResponse)
    async def schedule_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        return render(request, "schedule.html", active="agendamentos", admin=admin,
                      need_code=await run_in_threadpool(mfa_on, user))

    @app.get("/api/agendamentos")
    async def schedule_list(request: Request):
        _, bad = api_user(request)
        if bad:
            return bad
        res = await run_in_threadpool(helper, ["list"])
        return res if res.get("ok") else JSONResponse(res, status_code=500)

    @app.get("/api/agendamentos/log/{unit}")
    async def schedule_log(request: Request, unit: str):
        _, bad = api_user(request)
        if bad:
            return bad
        return await run_in_threadpool(helper, ["log", unit])

    @app.get("/api/agendamentos/calendario")
    async def schedule_calendar(request: Request, q: str = ""):
        _, bad = api_user(request)
        if bad:
            return bad
        return await run_in_threadpool(helper, ["calendar", *q.split()[:12]], None, 20)

    @app.post("/api/agendamentos/executar")
    async def schedule_run(request: Request):
        user, bad = api_user(request, admin=True)
        if bad:
            return bad
        unit = str((await request.json()).get("unit", ""))
        res = await run_in_threadpool(helper, ["run", unit])
        if res.get("ok"):
            audit(request, user, f"executou agora {unit}")
        return res if res.get("ok") else JSONResponse(res, status_code=400)

    @app.post("/api/agendamentos/ligar")
    async def schedule_toggle(request: Request):
        user, bad = api_user(request, admin=True)
        if bad:
            return bad
        b = await request.json()
        unit, on = str(b.get("unit", "")), bool(b.get("on"))
        res = await run_in_threadpool(helper, ["toggle", unit, "on" if on else "off"])
        if res.get("ok"):
            audit(request, user, f"{'ligou' if on else 'desligou'} {unit}")
        return res if res.get("ok") else JSONResponse(res, status_code=400)

    @app.post("/api/agendamentos/tarefa")
    async def schedule_task_save(request: Request):
        user, bad = api_user(request, admin=True)
        if bad:
            return bad
        b = await request.json()
        if auth.is_locked_out(auth.client_ip(request)):
            return JSONResponse({"ok": False, "message": "Muitas tentativas. Aguarde alguns minutos."}, status_code=429)
        if not await run_in_threadpool(password_ok, user, str(b.get("password", "")), str(b.get("code", ""))):
            auth.register_failure(auth.client_ip(request))
            return JSONResponse({"ok": False, "message": "Senha incorreta."}, status_code=403)
        req = {k: b.get(k) for k in ("id", "name", "command", "calendar", "enabled")}
        res = await run_in_threadpool(helper, ["task-save"], req)
        if res.get("ok"):
            audit(request, user, f"salvou a tarefa {res.get('id')} ({req.get('calendar')}): {str(req.get('command'))[:200]}")
        return res if res.get("ok") else JSONResponse(res, status_code=400)

    @app.post("/api/agendamentos/apagar")
    async def schedule_task_del(request: Request):
        user, bad = api_user(request, admin=True)
        if bad:
            return bad
        b = await request.json()
        if auth.is_locked_out(auth.client_ip(request)):
            return JSONResponse({"ok": False, "message": "Muitas tentativas. Aguarde alguns minutos."}, status_code=429)
        if not await run_in_threadpool(password_ok, user, str(b.get("password", "")), str(b.get("code", ""))):
            auth.register_failure(auth.client_ip(request))
            return JSONResponse({"ok": False, "message": "Senha incorreta."}, status_code=403)
        tid = str(b.get("id", ""))
        res = await run_in_threadpool(helper, ["task-del", tid])
        if res.get("ok"):
            audit(request, user, f"apagou a tarefa {tid}")
        return res if res.get("ok") else JSONResponse(res, status_code=400)
