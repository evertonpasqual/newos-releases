"""
NewOS Panel - Sistema > Atualizacoes.

    /sistema/atualizacoes               versao instalada x disponivel, notas
    POST /sistema/atualizacoes/verificar
    POST /sistema/atualizacoes/aplicar   (confirmado na tela)
    GET  /api/atualizacao/status         andamento (a tela acompanha ao vivo;
                                         o painel reinicia no meio e volta)
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, updates

log = logging.getLogger("newos.panel.updates")


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    @app.get("/sistema/atualizacoes", response_class=HTMLResponse)
    async def updates_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        info = updates.cached()
        try:
            st = await run_in_threadpool(updates.status)
        except updates.UpdateError:
            st = {}
        return render(request, "updates.html", active="atualizacoes", info=info, run=st)

    @app.post("/sistema/atualizacoes/verificar", response_class=HTMLResponse)
    async def updates_check(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        try:
            info = await run_in_threadpool(updates.check)
            flash(request, "ok", f"Nova versão disponível: {info['latest']}." if info.get("available")
                  else f"O NewOS já está na versão mais nova ({info.get('current')}).")
        except updates.UpdateError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/atualizacoes")

    @app.post("/sistema/atualizacoes/aplicar", response_class=HTMLResponse)
    async def updates_apply(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        form = await request.form()
        version = str(form.get("version", ""))
        if str(form.get("confirm", "")) != version:
            flash(request, "erro", "Confirmação não confere: digite o número da versão.")
            return redirect("/sistema/atualizacoes")
        try:
            msg = await run_in_threadpool(updates.apply, version)
            db.log_audit(user["username"], "atualizacao", f"iniciou a atualizacao para {version}",
                         auth.client_ip(request))
            log.info("Atualizacao para %s iniciada por %s", version, user["username"])
            flash(request, "ok", msg)
        except updates.UpdateError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/atualizacoes")

    @app.get("/api/atualizacao/status")
    async def updates_status(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        try:
            return await run_in_threadpool(updates.status)
        except updates.UpdateError as exc:
            return {"ok": False, "message": str(exc)}
