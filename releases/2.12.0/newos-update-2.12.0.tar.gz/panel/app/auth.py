"""
NewOS Panel - autenticacao.

Usuarios ficam na tabela `users` do MariaDB com senha em hash bcrypt.
A sessao e um cookie assinado (SessionMiddleware do Starlette).
"""

from __future__ import annotations

import logging
import time
from typing import Any

import bcrypt
from fastapi import Request

from . import db

log = logging.getLogger("newos.panel.auth")

# Protecao simples contra forca bruta, em memoria.
# Chave: IP de origem. Valor: (tentativas, timestamp_do_bloqueio)
_FAILED: dict[str, tuple[int, float]] = {}

MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 300


def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode()


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def client_ip(request: Request) -> str:
    """IP real do cliente, considerando o proxy do nginx."""
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "?"


def is_locked_out(ip: str) -> int:
    """Retorna os segundos restantes de bloqueio (0 = liberado)."""
    entry = _FAILED.get(ip)
    if not entry:
        return 0
    attempts, first_ts = entry
    if attempts < MAX_ATTEMPTS:
        return 0
    elapsed = time.time() - first_ts
    if elapsed >= LOCKOUT_SECONDS:
        _FAILED.pop(ip, None)
        return 0
    return int(LOCKOUT_SECONDS - elapsed)


def register_failure(ip: str) -> None:
    attempts, first_ts = _FAILED.get(ip, (0, time.time()))
    if time.time() - first_ts > LOCKOUT_SECONDS:
        attempts, first_ts = 0, time.time()
    _FAILED[ip] = (attempts + 1, first_ts)


def clear_failures(ip: str) -> None:
    _FAILED.pop(ip, None)


def authenticate(username: str, password: str) -> dict[str, Any] | None:
    """Valida usuario e senha. Retorna o registro do usuario ou None."""
    if not username or not password:
        return None

    row = db.query_one(
        "SELECT id, username, password_hash, full_name, is_active "
        "FROM users WHERE username = %s LIMIT 1",
        (username,),
    )
    if not row:
        # Gasta o mesmo tempo de um bcrypt real para nao vazar, pelo
        # tempo de resposta, se o usuario existe ou nao.
        bcrypt.hashpw(b"dummy", bcrypt.gensalt(rounds=12))
        return None

    if not row.get("is_active"):
        return None

    if not verify_password(password, row["password_hash"]):
        return None

    db.execute("UPDATE users SET last_login = NOW() WHERE id = %s", (row["id"],))
    return row


def change_password(user_id: int, new_password: str) -> None:
    db.execute(
        "UPDATE users SET password_hash = %s, must_change_password = 0 "
        "WHERE id = %s",
        (hash_password(new_password), user_id),
    )


# ---------------------------------------------------------------------
# Tema da interface (claro / escuro), por usuario.
#
# A coluna users.theme chega pelo schema.sql (ALTER ... IF NOT EXISTS).
# Num banco antigo, ainda sem a coluna, isso NAO pode derrubar o login:
# por isso as duas funcoes engolem o erro e caem no tema claro.
# ---------------------------------------------------------------------
THEMES = ("light", "dark")


def get_theme(user_id: int) -> str:
    try:
        row = db.query_one("SELECT theme FROM users WHERE id = %s", (user_id,))
    except Exception as exc:  # noqa: BLE001
        log.warning("Tema do usuario %s indisponivel: %s", user_id, exc)
        return "light"
    theme = (row or {}).get("theme") or "light"
    return theme if theme in THEMES else "light"


def set_theme(user_id: int, theme: str) -> None:
    if theme not in THEMES:
        return
    try:
        db.execute("UPDATE users SET theme = %s WHERE id = %s", (theme, user_id))
    except Exception as exc:  # noqa: BLE001
        log.warning("Nao foi possivel gravar o tema do usuario %s: %s", user_id, exc)


# ---------------------------------------------------------------------
#  Sessao inativa: sem uso por X minutos, o painel desloga sozinho
# ---------------------------------------------------------------------
IDLE_DEFAULT = 15                 # minutos
IDLE_MIN, IDLE_MAX = 5, 480
# Chamadas que contam como USO mesmo sendo /api (o resto das /api sao as
# atualizacoes automaticas das telas: uma aba esquecida nao pode ficar
# logada para sempre so porque a tela se atualiza sozinha).
ACTIVITY_API = ("/api/sessao/ativo", "/api/terminal/")
_idle_cache: dict[str, Any] = {"value": None, "at": 0.0}


def idle_minutes() -> int:
    if _idle_cache["value"] is not None and time.time() - _idle_cache["at"] < 30:
        return _idle_cache["value"]
    value = IDLE_DEFAULT
    try:
        row = db.query_one("SELECT setting_value FROM settings WHERE setting_key = 'session_idle_minutes'")
        if row and str(row["setting_value"]).isdigit():
            value = int(row["setting_value"])
    except Exception:  # noqa: BLE001
        pass
    # pela tela o minimo e IDLE_MIN; direto no banco (testes) aceita 1 min
    value = max(1, min(IDLE_MAX, value))
    _idle_cache.update(value=value, at=time.time())
    return value


def set_idle_minutes(minutes: int) -> int:
    minutes = max(IDLE_MIN, min(IDLE_MAX, int(minutes)))
    db.execute("INSERT INTO settings (setting_key, setting_value) VALUES ('session_idle_minutes', %s) "
               "ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", (str(minutes),))
    _idle_cache.update(value=minutes, at=time.time())
    return minutes


def current_user(request: Request) -> dict[str, Any] | None:
    """Le o usuario da sessao. None se nao estiver autenticado (ou se a
    sessao ficou parada mais que o limite: ai ela e encerrada)."""
    data = request.session.get("user")
    if not isinstance(data, dict) or not data.get("username"):
        return None
    now = int(time.time())
    seen = int(request.session.get("seen") or now)
    if now - seen > idle_minutes() * 60:
        request.session.clear()
        request.session["expired"] = 1
        return None
    path = request.url.path
    if not path.startswith("/api/") or path.startswith(ACTIVITY_API):
        if now - seen >= 5:          # nao reescreve o cookie a cada clique
            request.session["seen"] = now
    elif "seen" not in request.session:
        request.session["seen"] = now
    return data
