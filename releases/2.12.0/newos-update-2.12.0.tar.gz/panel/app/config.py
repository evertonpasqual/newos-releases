"""
NewOS Panel - carregamento de configuracao.

Le duas fontes, nesta ordem:

  1. /etc/newos/newos.conf   -> a configuracao central da distribuicao
                               (formato shell: CHAVE="valor")
  2. /etc/newos/panel.env    -> segredos gerados por maquina no primeiro
                               boot (chave de sessao, senha do banco)

Variaveis de ambiente sempre tem prioridade sobre os arquivos, o que
facilita rodar o painel em desenvolvimento sem tocar em /etc.
"""

from __future__ import annotations

import os
import re
import shlex
from functools import lru_cache
from pathlib import Path

NEWOS_CONF = Path(os.environ.get("NEWOS_CONF", "/etc/newos/newos.conf"))
PANEL_ENV = Path(os.environ.get("NEWOS_PANEL_ENV", "/etc/newos/panel.env"))

# Linha valida: CHAVE="valor", CHAVE='valor' ou CHAVE=valor
_LINE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$")


def _parse_shell_file(path: Path) -> dict[str, str]:
    """
    Le um arquivo no formato shell simples.

    Nao executa nada: apenas extrai pares chave/valor e remove aspas.
    Valores multi-linha (como NEWOS_LOCALES_GEN) sao ignorados de
    proposito -- o painel nao precisa deles.
    """
    data: dict[str, str] = {}
    if not path.is_file():
        return data

    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return data

    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = _LINE.match(line)
        if not match:
            continue
        key, value = match.group(1), match.group(2)

        # Remove comentario no fim da linha, se o valor nao estiver entre aspas.
        if value and value[0] not in "\"'":
            value = value.split("#", 1)[0].strip()

        try:
            parts = shlex.split(value, comments=False, posix=True)
            value = parts[0] if parts else ""
        except ValueError:
            value = value.strip("\"'")

        data[key] = value

    return data


class Settings:
    """Configuracao efetiva do painel."""

    def __init__(self) -> None:
        conf: dict[str, str] = {}
        conf.update(_parse_shell_file(NEWOS_CONF))
        conf.update(_parse_shell_file(PANEL_ENV))
        conf.update(os.environ)  # ambiente vence tudo
        self._conf = conf

    def get(self, key: str, default: str = "") -> str:
        return self._conf.get(key, default)

    def get_int(self, key: str, default: int) -> int:
        try:
            return int(str(self._conf.get(key, default)).strip())
        except (TypeError, ValueError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        raw = str(self._conf.get(key, "")).strip().lower()
        if raw in ("yes", "true", "1", "on", "sim"):
            return True
        if raw in ("no", "false", "0", "off", "nao"):
            return False
        return default

    # --- Identidade ---------------------------------------------------
    @property
    def os_name(self) -> str:
        return self.get("NEWOS_NAME", "NewOS")

    @property
    def os_version(self) -> str:
        return self.get("NEWOS_VERSION", "")

    @property
    def vendor(self) -> str:
        return self.get("NEWOS_VENDOR", "NewFront")

    @property
    def home_url(self) -> str:
        return self.get("NEWOS_HOME_URL", "")

    # --- Tema ---------------------------------------------------------
    @property
    def color_bg(self) -> str:
        return self.get("THEME_BG_COLOR", "#183b90")

    @property
    def color_accent(self) -> str:
        return self.get("THEME_ACCENT_COLOR", "#00b8c0")

    # --- Banco --------------------------------------------------------
    @property
    def db_host(self) -> str:
        return self.get("PANEL_DB_HOST", "127.0.0.1")

    @property
    def db_port(self) -> int:
        return self.get_int("PANEL_DB_PORT", 3306)

    @property
    def db_name(self) -> str:
        return self.get("PANEL_DB_NAME", "newos_panel")

    @property
    def db_user(self) -> str:
        return self.get("PANEL_DB_USER", "newospanel")

    @property
    def db_password(self) -> str:
        return self.get("PANEL_DB_PASSWORD", "")

    # --- Sessao -------------------------------------------------------
    @property
    def session_secret(self) -> str:
        secret = self.get("PANEL_SESSION_SECRET", "")
        if not secret:
            # Fallback: chave efemera. Reiniciar o painel desloga todos,
            # o que e ruim mas melhor do que uma chave fixa e conhecida.
            secret = os.urandom(32).hex()
        return secret

    @property
    def session_max_age(self) -> int:
        return self.get_int("PANEL_SESSION_MAX_AGE", 28800)

    # --- Rede ---------------------------------------------------------
    @property
    def allow_network_config(self) -> bool:
        return self.get_bool("PANEL_ALLOW_NETWORK_CONFIG", True)

    @property
    def protected_interfaces(self) -> set[str]:
        raw = self.get("PANEL_PROTECTED_INTERFACES", "lo")
        return {i for i in raw.replace(",", " ").split() if i}

    @property
    def netapply_bin(self) -> str:
        return self.get("PANEL_NETAPPLY_BIN", "/usr/local/sbin/newos-netapply")

    # --- Servidor -----------------------------------------------------
    @property
    def http_port(self) -> int:
        return self.get_int("PANEL_HTTP_PORT", 81)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
