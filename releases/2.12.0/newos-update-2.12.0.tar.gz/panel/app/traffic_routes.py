"""
NewOS Panel - modulo Trafego ao vivo (Network > Trafego ao vivo).

    /network/trafego        banda por interface, quem fala com o servidor,
                            servicos e maiores conexoes (atualiza sozinho)
    GET /api/trafego        os mesmos dados em JSON (a cada 2 s)

A banda das interfaces vem de /proc/net/dev (sem privilegio); as
conexoes, do helper newos-traffic (conntrack). O iptraf-ng abre no
terminal do painel: /sistema/terminal?app=iptraf.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, modules, terminal_routes

log = logging.getLogger("newos.panel.traffic")
HELPER = "/usr/local/sbin/newos-traffic"
_PREV: dict[str, Any] = {}
_LOCK = threading.Lock()


def helper(args: list[str]) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True, timeout=40, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "message": str(exc)}
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        return {"ok": False, "message": (lines[-1] if lines else "falhou").removeprefix("ERRO: ")}
    return json.loads(proc.stdout.strip().splitlines()[-1])


def _sys(iface: str, name: str) -> str:
    try:
        with open(f"/sys/class/net/{iface}/{name}", encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def interfaces() -> list[dict[str, Any]]:
    """Banda de cada interface desde a leitura anterior (/proc/net/dev)."""
    now = time.time()
    cur: dict[str, list[int]] = {}
    with open("/proc/net/dev", encoding="utf-8") as fh:
        for ln in fh.readlines()[2:]:
            name, data = ln.split(":", 1)
            name = name.strip()
            f = data.split()
            if name == "lo" or name.startswith(("veth", "docker")):
                continue
            cur[name] = [int(f[0]), int(f[1]), int(f[8]), int(f[9]), int(f[2]) + int(f[3]), int(f[10]) + int(f[11])]
    with _LOCK:
        prev, pt = _PREV.get("v", {}), _PREV.get("t", 0)
        _PREV.update(v=cur, t=now)
    dt = now - pt if pt and now - pt < 60 else 0
    out = []
    for name, v in sorted(cur.items()):
        p = prev.get(name)
        rate = [(v[i] - p[i]) / dt if dt and p and v[i] >= p[i] else 0 for i in range(4)]
        speed = _sys(name, "speed")
        kind = "bond" if os.path.isdir(f"/sys/class/net/{name}/bonding") else \
            "bridge" if os.path.isdir(f"/sys/class/net/{name}/bridge") else \
            "vlan" if "." in name or os.path.exists(f"/proc/net/vlan/{name}") else \
            "física" if os.path.exists(f"/sys/class/net/{name}/device") else "virtual"
        out.append({"name": name, "kind": kind, "state": _sys(name, "operstate"),
                    "speed": int(speed) if speed.lstrip("-").isdigit() and int(speed) > 0 else None,
                    "rx_bps": round(rate[0] * 8), "tx_bps": round(rate[2] * 8),
                    "rx_pps": round(rate[1]), "tx_pps": round(rate[3]),
                    "rx_total": v[0], "tx_total": v[2], "errors": v[4] + v[5]})
    return out


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("trafego") or {}).get("enabled"))

    @app.get("/network/trafego", response_class=HTMLResponse)
    async def traffic_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Tráfego ao vivo em Sistema > Módulos.")
            return redirect("/modulos")
        st = await run_in_threadpool(helper, ["status"])
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        await run_in_threadpool(interfaces)          # primeira leitura: a taxa sai na proxima
        return render(request, "network_traffic.html", active="trafego", st=st, admin=admin)

    @app.get("/api/trafego")
    async def traffic_api(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        if not enabled():
            return JSONResponse({"ok": False, "message": "Módulo desligado."}, status_code=409)
        ifs = await run_in_threadpool(interfaces)
        flows = await run_in_threadpool(helper, ["flows"])
        return {"ok": True, "t": time.time(), "ifaces": ifs, "flows": flows}
