"""
NewOS Panel - repositorio offline para os hosts do cliente.

Muitos hosts nao tem internet: o NewOS guarda os pacotes (helper
newos-pkgrepo) e entrega por HTTP, sem login, so o que e publico:

    /dl/instalar-node-exporter.sh       (modulo Prometheus)
    /dl/instalar-rsyslog.sh             (modulo Logs)
    /dl/instalar-zabbix-agent2.sh       (modulo Zabbix)
    /dl/pacote/<projeto>/<arq>          node_exporter / zfs_exporter (.tar.gz)
    /dl/apt/<bookworm|trixie>/<arquivo> repositorio apt (Debian 12 e 13)

Com login: GET /api/pacotes-offline (o que esta guardado) e
POST /api/pacotes-offline/atualizar (baixa de novo, destacado).
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules

log = logging.getLogger("newos.panel.offline")

HELPER = "/usr/local/sbin/newos-pkgrepo"
REPO = "/var/lib/newos-pkgrepo"
STATE = f"{REPO}/state.json"
MODULES_DIR = "/opt/newos-panel/modules"
SCRIPTS = {
    # arquivo: (modulo que precisa estar ligado, caminho)
    "instalar-node-exporter.sh": ("prometheus", f"{MODULES_DIR}/prometheus/files/instalar-node-exporter.sh"),
    "instalar-rsyslog.sh": ("logs", f"{MODULES_DIR}/logs/files/instalar-rsyslog.sh"),
    "instalar-zabbix-agent2.sh": ("zabbix", f"{MODULES_DIR}/zabbix/files/instalar-zabbix-agent2.sh"),
}
GROUP_MODULE = {"exporters": "prometheus", "rsyslog": "logs", "zabbix": "zabbix"}
SUITES = ("bookworm", "trixie")
APT_FILE_RE = re.compile(r"^(Packages|Packages\.gz|Release|[a-z0-9][a-z0-9.+~_-]*_(amd64|all)\.deb)$")
TAR_PROJECTS = ("node_exporter", "zfs_exporter")
TAR_ARCHS = ("amd64", "arm64", "armv7")


class OfflineError(Exception):
    """Erro para mostrar ao administrador."""


def _helper(args: list[str], timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True,
                              timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise OfflineError(f"Nao foi possivel executar o newos-pkgrepo: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout or "").splitlines() if ln.strip()]
        raise OfflineError((lines[-1] if lines else f"codigo {proc.returncode}").removeprefix("ERRO: "))
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError) as exc:
        raise OfflineError("Resposta invalida do newos-pkgrepo.") from exc


def status() -> dict[str, Any]:
    """Le o estado direto do arquivo (publico): a tela nao precisa de sudo."""
    try:
        with open(STATE, encoding="utf-8") as fh:
            st = json.load(fh)
    except (OSError, ValueError):
        st = {}
    st.setdefault("groups", {})
    return st


def group_info(group: str) -> dict[str, Any]:
    """Resumo de um grupo para a tela: versoes, tamanho, quando, erro."""
    st = status()
    g = st["groups"].get(group, {})
    items = g.get("items") or []
    apt = st.get("apt") or {}
    return {
        "group": group, "ok": bool(g.get("ok")), "at": g.get("at"), "error": g.get("error", ""),
        "items": items, "apt_items": g.get("apt_items") or [], "apt_error": g.get("apt_error", ""),
        "series": g.get("series", ""), "running": bool(st.get("running")),
        "suites": {s: apt.get(s, {}) for s in SUITES},
    }


def sync(groups: list[str]) -> str:
    return _helper(["sync", *groups], timeout=60).get("message", "")


def tar_path(project: str, arch: str) -> dict[str, Any]:
    """Pacote .tar.gz: o que ja esta guardado; se faltar (outra arquitetura), baixa."""
    rx = re.compile(rf"^{project}-([0-9][^/]*)\.linux-{arch}\.tar\.gz$")
    try:
        names = [n for n in os.listdir(f"{REPO}/tar") if rx.match(n)]
    except OSError:
        names = []
    if names:
        path = max((f"{REPO}/tar/{n}" for n in names), key=os.path.getmtime)
        try:
            with open(path + ".sha256", encoding="utf-8") as fh:
                sha = fh.read().split()[0]
            return {"path": path, "version": rx.match(os.path.basename(path)).group(1), "sha256": sha}
        except (OSError, IndexError, AttributeError):
            pass
    return _helper(["tar", project, arch], timeout=400)


def script_response(request: Request, name: str) -> Response:
    """O script ja vai sabendo de onde veio: baixa os pacotes deste NewOS."""
    with open(SCRIPTS[name][1], encoding="utf-8") as fh:
        text = fh.read()
    from .config import get_settings
    host = request.headers.get("host", "")
    port = int(get_settings().http_port)
    if port != 80 and not re.search(r":[0-9]{1,5}$", host):
        host = f"{host}:{port}"          # o nginx repassa o Host sem a porta
    if re.match(r"^[A-Za-z0-9.-]{1,253}(:[0-9]{1,5})?$|^\[[0-9A-Fa-f:.]+\](:[0-9]{1,5})?$", host):
        text = text.replace('NEWOS_URL=""', f'NEWOS_URL="http://{host}"', 1)
    return Response(text, media_type="text/x-shellscript",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


def module_on(key: str) -> bool:
    return bool((modules.get_module(key) or {}).get("enabled"))


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    # Downloads pelos hosts (curl, sem login): scripts e pacotes publicos,
    # nada de segredo. Cada um so existe com o modulo dele ligado.
    for _name in SCRIPTS:
        def _make(name: str):
            async def public_script(request: Request):
                if not module_on(SCRIPTS[name][0]):
                    return PlainTextResponse("Modulo desligado neste NewOS.\n", status_code=404)
                return script_response(request, name)

            async def panel_script(request: Request):
                if not auth.current_user(request):
                    return redirect("/login")
                return script_response(request, name)
            return public_script, panel_script

        pub, pan = _make(_name)
        app.add_api_route(f"/dl/{_name}", pub, methods=["GET"])
        app.add_api_route(f"/monitoramento/scripts/{_name}", pan, methods=["GET"])

    # repositorio "plano" (deb ... ./): o apt pede /dl/apt/<suite>/./<arquivo>
    @app.get("/dl/apt/{suite}/./{name}")
    @app.get("/dl/apt/{suite}/{name}")
    async def apt_file(request: Request, suite: str, name: str):
        if suite not in SUITES or not APT_FILE_RE.match(name):
            return PlainTextResponse("Nao encontrado.\n", status_code=404)
        if not any(module_on(m) for m in GROUP_MODULE.values()):
            return PlainTextResponse("Nada ligado neste NewOS.\n", status_code=404)
        path = f"{REPO}/apt/{suite}/{name}"
        if not os.path.isfile(path):
            return PlainTextResponse("Nao encontrado.\n", status_code=404)
        kind = "application/vnd.debian.binary-package" if name.endswith(".deb") else \
            ("application/gzip" if name.endswith(".gz") else "text/plain")
        return FileResponse(path, media_type=kind)

    # node_exporter/zfs_exporter para o instalador: ?info=1 devolve "versao sha256"
    @app.get("/dl/pacote/{project}/{arch}")
    async def tar_package(request: Request, project: str, arch: str, info: int = 0):
        if not module_on("prometheus"):
            return PlainTextResponse("Prometheus desligado neste NewOS.\n", status_code=404)
        if project not in TAR_PROJECTS or arch not in TAR_ARCHS:
            return PlainTextResponse("Pacote desconhecido.\n", status_code=404)
        try:
            res = await run_in_threadpool(tar_path, project, arch)
        except OfflineError as exc:
            return PlainTextResponse(f"{exc}\n", status_code=503)
        if info:
            return PlainTextResponse(f"{res['version']} {res['sha256']}\n")
        return FileResponse(res["path"], media_type="application/gzip", filename=os.path.basename(res["path"]))

    @app.get("/api/pacotes-offline")
    async def offline_status(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        return {"ok": True, "groups": {g: group_info(g) for g in GROUP_MODULE}}

    @app.post("/api/pacotes-offline/atualizar")
    async def offline_sync(request: Request):
        user = auth.current_user(request)
        if not user:
            return JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        try:
            body = await request.json()
        except ValueError:
            body = {}
        group = str((body or {}).get("group", ""))
        if group not in GROUP_MODULE or not module_on(GROUP_MODULE[group]):
            return JSONResponse({"ok": False, "message": "Grupo desconhecido ou módulo desligado."},
                                status_code=400)
        try:
            msg = await run_in_threadpool(sync, [group, "--force"])
        except OfflineError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=500)
        db.log_audit(user["username"], "pacotes-offline", f"atualizou {group}", auth.client_ip(request))
        return {"ok": True, "message": msg}
