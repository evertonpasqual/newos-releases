"""
NewOS Panel - armazenamento: inventario de discos (somente leitura).

Fonte: "lsblk -J -b" (nao precisa de root). Mostra TODO disco do
servidor, inclusive um disco novo sem particao nenhuma, com:
  - particoes, volumes LVM e o que cada um tem (fs, ponto de montagem)
  - espaco nao particionado (o que sobra entre o fim da ultima particao
    e o fim do disco), para o administrador saber onde ainda cabe algo
  - de quem e cada coisa: sistema (/, /boot, swap...), dados ou livre

As operacoes (particionar, formatar, LVM...) ficam num helper
privilegiado proprio, nunca aqui.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from typing import Any

log = logging.getLogger("newos.panel.storage")

COLUMNS = ("NAME,PATH,TYPE,SIZE,FSTYPE,FSVER,LABEL,UUID,MOUNTPOINTS,MODEL,"
           "SERIAL,ROTA,TRAN,PKNAME,RM,RO,PTTYPE,PARTTYPENAME,FSSIZE,FSUSED,"
           "FSAVAIL,START")

# Pontos de montagem que pertencem ao proprio sistema operacional.
SYSTEM_MOUNTS = {"/", "/boot", "/boot/efi", "/var", "/home", "/usr", "/tmp", "[SWAP]"}

# Particoes do proprio boot, mesmo sem sistema de arquivos montado.
SYSTEM_PARTTYPES = {"BIOS boot", "EFI System"}

# Alinhamento de 1 MiB: espaco livre menor que isso nao serve para nada.
MIN_FREE = 8 * 1024 * 1024


def _lsblk() -> list[dict[str, Any]]:
    try:
        out = subprocess.run(["lsblk", "-J", "-b", "-o", COLUMNS],
                             capture_output=True, text=True, timeout=10, check=True).stdout
        return json.loads(out).get("blockdevices", [])
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        log.error("lsblk falhou: %s", exc)
        return []


def _int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _system_mounts() -> set[str] | None:
    """
    Pontos de montagem REAIS do servidor (vistos pelo PID 1).

    O lsblk le as montagens do PROPRIO processo, e o painel roda isolado
    (ProtectSystem/ProtectHome criam montagens internas de /usr, /etc...).
    Sem este filtro a raiz aparecia "montada em /usr, /root, /etc...".
    """
    try:
        with open("/proc/1/mountinfo", encoding="utf-8") as fh:
            return {line.split()[4].replace("\\040", " ") for line in fh}
    except (OSError, IndexError):
        return None


_REAL_MOUNTS: set[str] | None = None


def _mounts(dev: dict[str, Any]) -> list[str]:
    found = [m for m in (dev.get("mountpoints") or []) if m]
    if _REAL_MOUNTS is None:
        return found
    real = [m for m in found if m in _REAL_MOUNTS or m == "[SWAP]"]
    return real or found


def _node(dev: dict[str, Any], depth: int = 0) -> dict[str, Any]:
    """Uma particao / LV / dispositivo, ja com os filhos."""
    mounts = _mounts(dev)
    size = _int(dev.get("size"))
    fs_size = _int(dev.get("fssize"))
    fs_used = _int(dev.get("fsused"))
    children = [_node(c, depth + 1) for c in dev.get("children") or []]

    parttype = dev.get("parttypename") or ""
    if any(m in SYSTEM_MOUNTS for m in mounts) or any(c["role"] == "system" for c in children) \
            or parttype in SYSTEM_PARTTYPES:
        role = "system"
    elif mounts or children or dev.get("fstype") or dev.get("type") == "part":
        # Uma particao sem sistema de arquivos continua ALOCADA: "livre"
        # e so o espaco fora de qualquer particao.
        role = "data"
    else:
        role = "free"

    return {
        "name": dev.get("name", ""),
        "path": dev.get("path", ""),
        "type": dev.get("type", ""),
        "size": size,
        "start": _int(dev.get("start")),
        "fstype": dev.get("fstype") or "",
        "label": dev.get("label") or "",
        "uuid": dev.get("uuid") or "",
        "mounts": mounts,
        "parttype": dev.get("parttypename") or "",
        "fs_size": fs_size,
        "fs_used": fs_used,
        "fs_percent": round(fs_used * 100 / fs_size, 1) if fs_size else None,
        "role": role,
        "depth": depth,
        "children": children,
    }


def _describe(node: dict[str, Any]) -> str:
    """Texto curto do que a particao e."""
    if node["fstype"] == "crypto_LUKS":
        inner = next((c for c in node["children"] if c["fstype"] == "LVM2_member"), None)
        return "LVM criptografado (LUKS2 + TPM)" if inner else "criptografado (LUKS2)"
    if node["fstype"] == "LVM2_member":
        return "LVM (volume físico)"
    if node["fstype"] == "swap":
        return "swap"
    if node["parttype"] == "BIOS boot":
        return "BIOS boot"
    if node["fstype"]:
        return node["fstype"]
    return "sem sistema de arquivos"


def disks() -> list[dict[str, Any]]:
    """Discos do servidor (sem CD/DVD, loop e ram) com mapa de ocupacao."""
    global _REAL_MOUNTS
    _REAL_MOUNTS = _system_mounts()
    result = []
    for dev in _lsblk():
        if dev.get("type") != "disk" or dev.get("name", "").startswith(("loop", "ram", "zram")):
            continue
        disk = _node(dev)
        size = disk["size"]
        parts = [c for c in disk["children"] if c["type"] == "part"]

        # Mapa: segmentos na ordem fisica, com os buracos livres entre eles.
        segments, cursor = [], 2048 * 512        # 1 MiB reservado a tabela
        for p in sorted(parts, key=lambda x: x["start"]):
            begin = p["start"] * 512
            if begin - cursor >= MIN_FREE:
                segments.append({"kind": "free", "size": begin - cursor, "label": "não alocado"})
            role = "lvm" if p["fstype"] == "LVM2_member" or (
                p["fstype"] == "crypto_LUKS" and any(c["fstype"] == "LVM2_member" for c in p["children"])) else p["role"]
            segments.append({"kind": role, "size": p["size"], "label": p["name"],
                             "detail": _describe(p)})
            cursor = max(cursor, begin + p["size"])
        tail = size - cursor - 1024 * 1024      # backup da GPT no fim
        if parts and tail >= MIN_FREE:
            segments.append({"kind": "free", "size": tail, "label": "não alocado"})
        if not parts and not disk["fstype"]:
            segments.append({"kind": "free", "size": size, "label": "disco vazio"})
        elif not parts and disk["fstype"]:
            segments.append({"kind": "lvm" if disk["fstype"] == "LVM2_member" or (
                disk["fstype"] == "crypto_LUKS" and any(c["fstype"] == "LVM2_member" for c in disk["children"]))
                else disk["role"],
                             "size": size, "label": disk["name"], "detail": _describe(disk)})

        for seg in segments:
            seg["percent"] = round(seg["size"] * 100 / size, 2) if size else 0

        free = sum(s["size"] for s in segments if s["kind"] == "free")
        disk.update({
            "model": (dev.get("model") or "").strip(),
            "serial": (dev.get("serial") or "").strip(),
            "transport": (dev.get("tran") or "").upper(),
            "rotational": dev.get("rota") in (True, "1", 1),
            "removable": dev.get("rm") in (True, "1", 1),
            "table": (dev.get("pttype") or "").upper(),
            "partitions": parts,
            "segments": segments,
            "free": free,
            "is_system": disk["role"] == "system",
            "is_empty": not parts and not disk["fstype"],
        })
        result.append(disk)
    result.sort(key=lambda d: (not d["is_system"], d["name"]))
    return result


def flatten(node: dict[str, Any]) -> list[dict[str, Any]]:
    """Arvore -> lista (para tabelas com recuo)."""
    out = [node]
    for child in node.get("children", []):
        out.extend(flatten(child))
    return out


# =====================================================================
#  Operacoes (via helper privilegiado /usr/local/sbin/newos-storage)
# =====================================================================

STORAGE_BIN = "/usr/local/sbin/newos-storage"


class StorageError(RuntimeError):
    """Erro de validacao ou de execucao, mostrado ao administrador."""


def _helper(args: list[str], confirm: str | None = None, timeout: int = 3700) -> dict[str, Any]:
    cmd = ["sudo", "-n", STORAGE_BIN, *args]
    if confirm is not None:
        cmd += ["--confirm", confirm]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise StorageError("A operacao de disco demorou demais.") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise StorageError(f"Nao foi possivel executar o helper de discos: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout or "").strip().splitlines() if ln.strip()]
        raise StorageError((lines[-1] if lines else f"codigo {proc.returncode}").removeprefix("ERRO: "))
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (json.JSONDecodeError, IndexError):
        return {"ok": True, "message": proc.stdout.strip()}


def lvm_inventory() -> dict[str, Any]:
    """LVM e classificacao (sistema / em uso), vindos do helper como root."""
    try:
        return _helper(["inventory"], timeout=60)
    except StorageError as exc:
        log.error("Inventario LVM indisponivel: %s", exc)
        return {"vgs": [], "pvs": [], "devices": {}, "system_vgs": [], "error": str(exc)}


def overview() -> dict[str, Any]:
    """Discos (lsblk) + LVM e regras (helper), prontos para a tela."""
    lv = lvm_inventory()
    devices = lv.get("devices", {})
    dlist = disks()
    for d in dlist:
        for n in flatten(d):
            info = devices.get(n["path"], {})
            n["system"] = info.get("system", n is d and d["is_system"])
            n["zfs_active"] = bool(info.get("zfs"))
            n["in_use"] = bool(info.get("mounts") or info.get("pv_vg") or n["zfs_active"]
                               or n["children"])
            n["pv_vg"] = info.get("pv_vg")
            n["fstab"] = info.get("fstab", "")
            if n["fstab"]:
                n["in_use"] = True
            n["free_after"] = 0
        # Espaco livre logo depois de cada particao (para "ampliar").
        segs = d["segments"]
        for i, s in enumerate(segs):
            if s["kind"] != "free" and i + 1 < len(segs) and segs[i + 1]["kind"] == "free":
                part = next((p for p in d["partitions"] if p["name"] == s["label"]), None)
                if part:
                    part["free_after"] = segs[i + 1]["size"]
    # Dispositivos que podem virar PV / ser formatados (livres, fora do sistema).
    candidates = []
    for d in dlist:
        nodes = [d] if not d["children"] else d["partitions"]
        for n in nodes:
            if not n.get("system") and not n.get("in_use") and n["type"] in ("disk", "part"):
                candidates.append({"path": n["path"], "size": n["size"],
                                   "fstype": n["fstype"]})
    zfs = lv.get("zfs") or {"installed": False, "pools": []}
    for c in candidates:
        c["zfs"] = devices.get(c["path"], {}).get("zfs", False)
    # Volumes LVM com o que a tela precisa para montar/desmontar (o
    # helper da o caminho /dev/VG/LV; o lsblk, /dev/mapper/VG-LV).
    by_real = {os.path.realpath(n["path"]): n for d in dlist for n in flatten(d)}
    for vg in lv.get("vgs", []):
        for v in vg.get("lvs", []):
            n = by_real.get(os.path.realpath(v.get("path", ""))) or {}
            v["fstype"] = n.get("fstype", "")
            v["fstab"] = n.get("fstab", "")
            v["node_path"] = n.get("path", v.get("path", ""))
            v["fs_percent"] = n.get("fs_percent")
    summary = _summary(dlist, lv.get("vgs", []), zfs)
    return {"disks": dlist, "vgs": lv.get("vgs", []), "system_vgs": lv.get("system_vgs", []),
            "summary": summary,
            "candidates": [c for c in candidates if not c["zfs"]], "zfs": zfs,
            "error": lv.get("error", "")}


MOUNTABLE_FS = ("ext4", "xfs", "btrfs", "vfat", "exfat")


def _summary(dlist: list[dict[str, Any]], vgs: list[dict[str, Any]],
             zfs: dict[str, Any]) -> dict[str, Any]:
    """Numeros do topo da tela."""
    total = sum(d["size"] for d in dlist)
    free = sum(s["size"] for d in dlist for s in d["segments"] if s["kind"] == "free")
    mounts = sum(1 for d in dlist for n in flatten(d)
                 if not n.get("system") and (n.get("mounts") or n.get("fstab")))
    mounts += sum(1 for p in zfs.get("pools", []) for ds in p.get("datasets", []) if ds.get("mounted"))
    return {
        "disks": len(dlist), "total": total,
        "alloc_pct": round((total - free) * 100 / total, 1) if total else 0, "unalloc": free,
        "vgs": len(vgs), "vg_free": sum(v.get("free", 0) for v in vgs),
        "pools": len(zfs.get("pools", [])),
        "zfs_free": sum(p.get("free", 0) for p in zfs.get("pools", [])),
        "mounts": mounts,
    }


def act(action: str, form: dict[str, str]) -> dict[str, Any]:
    """Traduz um formulario da tela em chamada ao helper."""
    f = {k: (v or "").strip() for k, v in form.items() if isinstance(v, str)}
    confirm = f.get("confirm")
    if action == "disk-init":
        return _helper(["disk-init", f["device"]], confirm)
    if action == "part-create":
        size = "all" if f.get("all") else f.get("size", "")
        return _helper(["part-create", f["device"], size, f.get("kind", "linux")])
    if action == "part-delete":
        return _helper(["part-delete", f["device"]], confirm)
    if action == "part-grow":
        return _helper(["part-grow", f["device"]])
    if action == "format":
        return _helper(["format", f["device"], f.get("fstype", "ext4"), f.get("label", "")], confirm)
    if action == "wipe":
        return _helper(["wipe", f["device"]], confirm)
    if action == "vg-create":
        return _helper(["vg-create", f["vg"], f["device"]], confirm)
    if action == "vg-extend":
        return _helper(["vg-extend", f["vg"], f["device"]], confirm)
    if action == "vg-remove":
        return _helper(["vg-remove", f["vg"]], confirm)
    if action == "lv-create":
        size = "all" if f.get("all") else f.get("size", "")
        return _helper(["lv-create", f["vg"], f["lv"], size, f.get("fstype", "none")])
    if action == "lv-extend":
        size = "all" if f.get("all") else f.get("size", "")
        return _helper(["lv-extend", f"{f['vg']}/{f['lv']}", size])
    if action == "lv-remove":
        return _helper(["lv-remove", f"{f['vg']}/{f['lv']}"], confirm)
    if action == "zpool-create":
        devices = form.get("devices") or []
        if isinstance(devices, str):
            devices = [devices]
        if not devices:
            raise StorageError("Escolha os discos do pool.")
        return _helper(["zpool-create", f["pool"], f.get("layout", "single"), *devices], confirm)
    if action == "zpool-destroy":
        return _helper(["zpool-destroy", f["pool"]], confirm)
    if action == "zfs-create":
        return _helper(["zfs-create", f"{f['pool']}/{f['dataset']}", f.get("quota", ""),
                        f.get("mountpoint", "")])
    if action == "mount":
        return _helper(["mount-fs", f["device"], f["mountpoint"]])
    if action == "umount":
        return _helper(["umount-fs", f["mountpoint"]], confirm)
    if action == "zfs-mount":
        return _helper(["zfs-mount", f["dataset"], f["mountpoint"]])
    if action == "zfs-umount":
        return _helper(["zfs-umount", f["dataset"]])
    if action == "zfs-destroy":
        return _helper(["zfs-destroy", f["dataset"]], confirm)
    raise StorageError(f"Acao desconhecida: {action}")
