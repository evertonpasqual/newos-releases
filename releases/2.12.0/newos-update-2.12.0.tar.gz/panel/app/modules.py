"""
NewOS Panel - sistema de modulos.

Um modulo e software opcional que o administrador liga e desliga pela
web. Cada um mora em um diretorio proprio:

    /opt/newos-panel/modules/<chave>/
        module.json     manifesto: nome, componentes, servicos, menu
        install.sh      instala (adiciona repositorio, baixa pacotes)
        uninstall.sh    remove
        component.sh    liga/desliga um componente
        config.sh       le e grava a configuracao
        status.sh       estado atual, em pares chave=valor

O painel NUNCA executa esses scripts diretamente: quem faz isso e o
helper privilegiado /usr/local/sbin/newos-modctl, chamado via sudo.
Aqui so lemos manifestos, guardamos estado no banco e pedimos acoes.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from . import db
from .config import get_settings

log = logging.getLogger("newos.panel.modules")

KEY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,47}$")

# Servicos que o painel mostra mas nunca deixa parar: derrubariam a
# propria interface que emitiu o comando.
PROTECTED_SERVICES = {"newos-panel", "nginx"}


class ModuleError(RuntimeError):
    """Erro tratado e mostrado ao administrador."""


def _modules_dir() -> Path:
    settings = get_settings()
    return Path(settings.get("PANEL_INSTALL_DIR", "/opt/newos-panel")) / "modules"


def _modctl_bin() -> str:
    settings = get_settings()
    return settings.get("PANEL_MODCTL_BIN", "/usr/local/sbin/newos-modctl")


# =====================================================================
#  Helper privilegiado
# =====================================================================

def _run_modctl(args: list[str], timeout: int = 1800,
                stdin_text: str | None = None) -> str:
    """
    Chama o newos-modctl via sudo.

    O timeout e generoso porque instalar o Zabbix baixa pacotes: em link
    lento isso passa facil de um minuto.
    """
    cmd = ["sudo", "-n", _modctl_bin(), *args]
    log.info("Executando: %s", " ".join(cmd))

    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=False,
            input=stdin_text,
        )
    except subprocess.TimeoutExpired as exc:
        raise ModuleError(
            f"A operacao passou de {timeout // 60} minutos e foi interrompida. "
            f"Verifique a conexao do servidor com a internet."
        ) from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise ModuleError(f"Nao foi possivel executar o helper de modulos: {exc}") from exc

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        # Fica so com o final: o apt costuma despejar muita linha.
        lines = [ln for ln in detail.splitlines() if ln.strip()]
        raise ModuleError("\n".join(lines[-8:]) or
                          f"O helper retornou codigo {proc.returncode}.")

    return (proc.stdout or "").strip()


# =====================================================================
#  Manifestos
# =====================================================================

def _read_manifest(path: Path) -> dict[str, Any] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        log.error("Manifesto invalido em %s: %s", path, exc)
        return None

    key = data.get("key", "")
    if not KEY_RE.match(key):
        log.error("Manifesto com chave invalida: %s", path)
        return None

    data.setdefault("name", key)
    data.setdefault("summary", "")
    data.setdefault("description", "")
    data.setdefault("version", "")
    data.setdefault("category", "Geral")
    data.setdefault("icon", "bi-box")
    data.setdefault("components", [])
    data.setdefault("services", [])
    data.setdefault("menu", [])
    data.setdefault("notes", [])
    data.setdefault("requires_internet", False)
    return data


def discover() -> list[dict[str, Any]]:
    """Todos os modulos presentes no disco, ordenados por nome."""
    base = _modules_dir()
    found: list[dict[str, Any]] = []

    if not base.is_dir():
        log.warning("Diretorio de modulos ausente: %s", base)
        return found

    for entry in sorted(base.iterdir()):
        manifest = entry / "module.json"
        if entry.is_dir() and manifest.is_file():
            data = _read_manifest(manifest)
            if data:
                found.append(data)

    found.sort(key=lambda m: (m["category"], m["name"]))
    return found


# =====================================================================
#  Estado no banco
# =====================================================================

def _state_map() -> dict[str, dict[str, Any]]:
    try:
        rows = db.query_all("SELECT * FROM modules")
    except Exception as exc:  # noqa: BLE001
        log.warning("Nao foi possivel ler o estado dos modulos: %s", exc)
        return {}
    return {r["module_key"]: r for r in rows}


def _component_map() -> dict[tuple[str, str], bool]:
    try:
        rows = db.query_all("SELECT * FROM module_components")
    except Exception as exc:  # noqa: BLE001
        log.warning("Nao foi possivel ler os componentes: %s", exc)
        return {}
    return {(r["module_key"], r["component_key"]): bool(r["enabled"]) for r in rows}


def list_modules() -> list[dict[str, Any]]:
    """Manifesto + estado, pronto para a tela de Modulos."""
    states = _state_map()
    comps = _component_map()
    result: list[dict[str, Any]] = []

    for manifest in discover():
        key = manifest["key"]
        state = states.get(key, {})
        item = dict(manifest)
        item["installed"] = bool(state.get("installed", 0))
        item["enabled"] = bool(state.get("enabled", 0))
        item["last_error"] = state.get("last_error") or ""
        item["installed_at"] = state.get("installed_at")

        item["components"] = [
            {**c, "enabled": comps.get((key, c["key"]), False)}
            for c in manifest["components"]
        ]
        result.append(item)

    return result


def get_module(key: str) -> dict[str, Any] | None:
    if not KEY_RE.match(key or ""):
        return None
    return next((m for m in list_modules() if m["key"] == key), None)


def _save_state(key: str, *, installed: bool | None = None,
                enabled: bool | None = None, error: str | None = None) -> None:
    current = _state_map().get(key)
    if current is None:
        db.execute(
            "INSERT INTO modules (module_key, installed, enabled, last_error) "
            "VALUES (%s, %s, %s, %s)",
            (key, int(bool(installed)), int(bool(enabled)), error),
        )
        return

    sets, params = [], []
    if installed is not None:
        sets.append("installed = %s"); params.append(int(installed))
    if enabled is not None:
        sets.append("enabled = %s"); params.append(int(enabled))
    sets.append("last_error = %s"); params.append(error)
    params.append(key)

    db.execute(f"UPDATE modules SET {', '.join(sets)} WHERE module_key = %s",
               tuple(params))


def _save_component(module_key: str, component_key: str, enabled: bool) -> None:
    db.execute(
        "INSERT INTO module_components (module_key, component_key, enabled) "
        "VALUES (%s, %s, %s) "
        "ON DUPLICATE KEY UPDATE enabled = VALUES(enabled)",
        (module_key, component_key, int(enabled)),
    )


# =====================================================================
#  Acoes
# =====================================================================

def enable_module(key: str) -> str:
    """Instala e liga o modulo. Pode demorar: baixa pacotes."""
    module = get_module(key)
    if not module:
        raise ModuleError(f"Modulo '{key}' nao encontrado.")
    if module["enabled"]:
        return f"O modulo {module['name']} ja esta ligado."

    try:
        output = _run_modctl(["install", key])
    except ModuleError as exc:
        _save_state(key, installed=False, enabled=False, error=str(exc))
        raise

    db.execute(
        "INSERT INTO modules (module_key, installed, enabled, version, installed_at) "
        "VALUES (%s, 1, 1, %s, NOW()) "
        "ON DUPLICATE KEY UPDATE installed = 1, enabled = 1, "
        "                        version = VALUES(version), "
        "                        installed_at = COALESCE(installed_at, NOW()), "
        "                        last_error = NULL",
        (key, module.get("version", "")[:32]),
    )
    log.info("Modulo %s ligado.", key)
    return output or f"Modulo {module['name']} ligado."


def disable_module(key: str) -> str:
    """Desliga o modulo e desliga todos os componentes dele."""
    module = get_module(key)
    if not module:
        raise ModuleError(f"Modulo '{key}' nao encontrado.")
    if not module["enabled"]:
        return f"O modulo {module['name']} ja esta desligado."

    # Primeiro os componentes: parar servicos antes de remover pacotes.
    for comp in module["components"]:
        if comp.get("enabled"):
            try:
                _run_modctl(["component", key, comp["key"], "disable"], timeout=180)
                _save_component(key, comp["key"], False)
            except ModuleError as exc:
                log.warning("Falha ao desligar %s/%s: %s", key, comp["key"], exc)

    output = _run_modctl(["uninstall", key])
    _save_state(key, installed=False, enabled=False, error=None)
    log.info("Modulo %s desligado.", key)
    return output or f"Modulo {module['name']} desligado."


def set_component(module_key: str, component_key: str, enabled: bool) -> str:
    module = get_module(module_key)
    if not module:
        raise ModuleError(f"Modulo '{module_key}' nao encontrado.")
    if not module["enabled"]:
        raise ModuleError(
            f"Ligue o modulo {module['name']} antes de mexer nos componentes."
        )

    comp = next((c for c in module["components"] if c["key"] == component_key), None)
    if not comp:
        raise ModuleError(f"Componente '{component_key}' nao existe neste modulo.")

    action = "enable" if enabled else "disable"
    output = _run_modctl(["component", module_key, component_key, action])
    _save_component(module_key, component_key, enabled)

    log.info("Componente %s/%s: %s", module_key, component_key, action)
    return output or f"{comp['name']}: {'ligado' if enabled else 'desligado'}."


# =====================================================================
#  Configuracao dos modulos
# =====================================================================

def get_config(module_key: str, component_key: str) -> dict[str, str]:
    """Le a configuracao atual de um componente."""
    try:
        raw = _run_modctl(["config-show", module_key, component_key], timeout=60)
    except ModuleError as exc:
        log.warning("config-show %s/%s falhou: %s", module_key, component_key, exc)
        return {}

    values: dict[str, str] = {}
    for line in raw.splitlines():
        if "=" in line and not line.startswith("["):
            key, _, value = line.partition("=")
            values[key.strip()] = value.strip()
    return values


def set_config(module_key: str, component_key: str,
               values: dict[str, str]) -> str:
    """Grava a configuracao. Valores vazios comentam a diretiva."""
    if not values:
        raise ModuleError("Nada a alterar.")

    pairs = []
    for key, value in values.items():
        if not re.match(r"^[A-Za-z][A-Za-z0-9_]{0,63}$", key):
            raise ModuleError(f"Chave invalida: {key!r}")
        value = (value or "").strip()
        if "\n" in value or "\r" in value:
            raise ModuleError(f"O valor de {key} nao pode ter quebra de linha.")
        pairs.append(f"{key}={value}")

    return _run_modctl(["config", module_key, component_key, *pairs], timeout=120)


# ---------------------------------------------------------------------
# Edicao do arquivo de configuracao inteiro
#
#   A allowlist de chaves cobre o dia a dia. Isto existe para quando e
#   preciso mexer em qualquer diretiva do .conf. O conteudo vai pelo
#   STDIN do helper -- nunca por linha de comando -- e o proprio modulo
#   guarda um .bak e volta atras se o servico nao subir.
# ---------------------------------------------------------------------

MAX_CONFIG_BYTES = 512 * 1024


def get_raw_config(module_key: str, component_key: str) -> str:
    """Le o arquivo de configuracao do componente, como texto."""
    try:
        return _run_modctl(["config-file", module_key, component_key, "show"],
                           timeout=60)
    except ModuleError as exc:
        log.warning("config-file show %s/%s falhou: %s",
                    module_key, component_key, exc)
        return ""


def set_raw_config(module_key: str, component_key: str, content: str) -> str:
    """Grava o arquivo inteiro e reinicia o servico (com rollback)."""
    text = (content or "").replace("\r\n", "\n").replace("\r", "\n")

    if not text.strip():
        raise ModuleError("O conteudo esta vazio. Nada foi gravado.")
    if "\x00" in text:
        raise ModuleError("O conteudo tem bytes nulos. Nada foi gravado.")
    if len(text.encode("utf-8")) > MAX_CONFIG_BYTES:
        raise ModuleError("O arquivo passou de 512 KB. Nada foi gravado.")
    if not text.endswith("\n"):
        text += "\n"

    return _run_modctl(["config-file", module_key, component_key, "set"],
                       timeout=180, stdin_text=text)


# =====================================================================
#  Servicos
# =====================================================================

def module_action(module_key: str, action: str, *args: str,
                  timeout: int = 900) -> str:
    """Acao propria do modulo (action.sh): trocar versao, testar, log."""
    if not KEY_RE.match(module_key or "") or not KEY_RE.match(action or ""):
        raise ModuleError("Acao invalida.")
    for a in args:
        if not re.match(r"^[A-Za-z0-9_.:@/+=,-]{0,256}$", a):
            raise ModuleError(f"Argumento invalido: {a!r}")
    return _run_modctl(["action", module_key, action, *args], timeout=timeout)


def module_action_kv(module_key: str, action: str, *args: str) -> dict[str, str]:
    """Saida chave=valor de uma acao, em dicionario."""
    out: dict[str, str] = {}
    try:
        raw = module_action(module_key, action, *args, timeout=60)
    except ModuleError as exc:
        log.warning("acao %s/%s falhou: %s", module_key, action, exc)
        return out
    for line in raw.splitlines():
        if "=" in line and not line.startswith("["):
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip()
    return out


def list_services() -> list[dict[str, Any]]:
    """
    Todos os servicos que o painel conhece, com estado atual.

    A lista vem do helper, que a monta a partir dos manifestos -- o
    painel nao escolhe quais servicos existem.
    """
    try:
        raw = _run_modctl(["services"], timeout=60)
    except ModuleError as exc:
        log.error("Nao foi possivel listar os servicos: %s", exc)
        return []

    # Mapa servico -> modulo, para agrupar na tela.
    owner: dict[str, dict[str, str]] = {}
    for manifest in discover():
        for comp in manifest.get("components", []):
            if comp.get("service"):
                owner[comp["service"]] = {
                    "module": manifest["name"],
                    "module_key": manifest["key"],
                    "component": comp["name"],
                }
        for svc in manifest.get("services", []):
            owner.setdefault(svc, {"module": manifest["name"],
                                   "module_key": manifest["key"],
                                   "component": ""})

    services: list[dict[str, Any]] = []
    for line in raw.splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        name, active, enabled, desc = parts[0], parts[1], parts[2], parts[3]
        info = owner.get(name, {})
        services.append({
            "name": name,
            "active": active == "active",
            "active_raw": active,
            "enabled": enabled in ("enabled", "enabled-runtime", "static"),
            "enabled_raw": enabled,
            "description": desc,
            "module": info.get("module", "Sistema"),
            "module_key": info.get("module_key", ""),
            "component": info.get("component", ""),
            "protected": name in PROTECTED_SERVICES,
        })

    services.sort(key=lambda s: (s["module"] != "Sistema", s["module"], s["name"]))
    return services


def service_action(action: str, name: str) -> str:
    if action not in ("start", "stop", "restart", "enable", "disable"):
        raise ModuleError(f"Acao invalida: {action!r}")
    if name in PROTECTED_SERVICES:
        raise ModuleError(
            f"O servico {name} sustenta o proprio painel e nao pode ser "
            f"controlado por aqui. Use o console do servidor."
        )
    return _run_modctl(["service", action, name], timeout=120)


def module_status(key: str) -> dict[str, str]:
    """
    Estado detalhado que o proprio modulo reporta (status.sh).
    Devolve pares chave=valor. Nunca levanta: se o script falhar, a tela
    simplesmente mostra menos informacao.
    """
    if not KEY_RE.match(key or ""):
        return {}
    try:
        raw = _run_modctl(["status", key], timeout=60)
    except ModuleError as exc:
        log.warning("status do modulo %s indisponivel: %s", key, exc)
        return {}

    values: dict[str, str] = {}
    for line in raw.splitlines():
        if "=" in line and not line.startswith("["):
            k, _, v = line.partition("=")
            values[k.strip()] = v.strip()
    return values


# =====================================================================
#  Saude do APT
# =====================================================================

def apt_health() -> dict[str, Any]:
    """
    O APT do servidor consegue instalar alguma coisa?

    Um unico pacote em estado quebrado trava TODAS as instalacoes -- e
    ai nenhum modulo funciona, mesmo os que nao tem nada a ver com o
    pacote problematico. Vale avisar antes de o usuario tentar.
    """
    try:
        raw = _run_modctl(["apt-health"], timeout=90)
    except ModuleError as exc:
        log.warning("apt-health falhou: %s", exc)
        return {"ok": True, "broken": [], "checked": False}

    values: dict[str, str] = {}
    for line in raw.splitlines():
        if "=" in line:
            k, _, v = line.partition("=")
            values[k.strip()] = v.strip()

    broken = [p for p in values.get("broken", "").split() if p]
    return {
        "ok": values.get("status") == "ok",
        "broken": broken,
        "checked": True,
    }


def apt_repair() -> str:
    """Destrava o APT removendo os pacotes meio-instalados."""
    return _run_modctl(["apt-repair"], timeout=300)


# =====================================================================
#  Menu dinamico
# =====================================================================

def active_menu() -> list[dict[str, Any]]:
    """
    Secoes de menu contribuidas pelos modulos LIGADOS.

    E assim que "Monitoramento" aparece so depois de o Zabbix ser
    ativado: o manifesto declara a secao, e ela entra no menu quando o
    modulo esta ligado.
    """
    sections: dict[str, dict[str, Any]] = {}

    for module in list_modules():
        if not module["enabled"]:
            continue
        for section in module.get("menu", []):
            title = section.get("section", module["name"])
            sec = sections.setdefault(title, {"section": title, "items": [],
                                              "group": "", "icon": "", "key": "", "inline": ""})
            # "inline": os itens entram num grupo fixo do menu (Network)
            # em vez de criar uma secao nova.
            if section.get("inline"):
                sec["inline"] = section["inline"]
            # Item ligado a um componente so aparece com ele ligado
            # (Monitoramento > Zabbix > Zabbix Proxy so com o Proxy ativo).
            comps = {c["key"]: c["enabled"] for c in module.get("components", [])}
            sec["items"].extend(it for it in section.get("items", [])
                                if not it.get("component") or comps.get(it["component"]))
            # "group": os itens viram um grupo recolhivel no menu (como
            # Network), com o titulo e o icone do grupo.
            if section.get("group"):
                sec.update(group=section["group"], icon=section.get("icon", "bi-box"),
                           key=re.sub(r"[^a-z0-9-]", "-", section["group"].lower()))

    return [sections[title] for title in sorted(sections)]
