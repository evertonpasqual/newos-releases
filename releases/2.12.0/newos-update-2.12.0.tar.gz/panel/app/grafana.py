"""
NewOS Panel - dashboards do Grafana prontas para UM alvo.

As dashboards do modulo (files/grafana/*.json, formato v2 do Grafana 12)
tem filtros cliente > cluster > host. Aqui elas saem ja presas a um
host, a um cluster do NewOS, a um Proxmox ou a um Ceph: as variaveis
viram constantes escondidas (como nas dashboards de telao do NOC), com
titulo e uid proprios - importar varias nao sobrescreve nenhuma.
"""

from __future__ import annotations

import copy
import hashlib
import json
import re
from typing import Any

GF_DIR = "/opt/newos-panel/modules/prometheus/files/grafana"
GENERIC = ("newos-node-exporter", "newos-pve-exporter", "newos-ceph")


class GrafanaError(Exception):
    """Alvo sem dashboard (ex.: host sem job do node_exporter)."""


def load(name: str) -> dict[str, Any]:
    with open(f"{GF_DIR}/{name}.json", encoding="utf-8") as fh:
        return json.load(fh)


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "alvo"


def const_var(name: str, value: str, label: str = "") -> dict[str, Any]:
    return {"kind": "ConstantVariable", "spec": {
        "name": name, "query": value, "current": {"text": value, "value": value},
        "label": label or name, "hide": "hideVariable", "skipUrlSync": False}}


def lock(dash: dict[str, Any], values: dict[str, str], drop: tuple[str, ...] = ()) -> None:
    """Troca as variaveis pelo valor do alvo (constante escondida); tira as que sobram."""
    out = []
    for v in dash["spec"]["variables"]:
        name = v["spec"].get("name")
        if name in drop:
            continue
        out.append(const_var(name, values[name], v["spec"].get("label", "")) if name in values else v)
    dash["spec"]["variables"] = out


def finish(dash: dict[str, Any], kind: str, key: str, title: str, description: str) -> dict[str, Any]:
    uid = f"nos-{kind}-{slug(key)[:22]}-{hashlib.sha1(f'{kind}:{key}'.encode()).hexdigest()[:6]}"
    dash["metadata"] = {"name": uid}
    dash["spec"]["title"] = title
    dash["spec"]["description"] = description
    dash["spec"]["tags"] = sorted(set(dash["spec"].get("tags") or []) | {"newos", slug(key)})
    return dash


def prom_rx(value: str) -> str:
    """Valor literal dentro de cluster=~"...": escapa o regex e a string do PromQL."""
    return re.sub(r'([.+*?()|\[\]{}^$\\])', r'\\\\\1', value).replace('"', '\\"')


def cluster_of(st: dict[str, Any], name: str) -> dict[str, str]:
    c = next((c for c in st.get("clusters", []) if c.get("name") == name), None)
    return {"cluster": name, "cliente": (c or {}).get("cliente", "")} if name else {}


def node_instance(st: dict[str, Any], node: dict[str, Any]) -> str:
    """O rotulo instance que o Prometheus do NewOS da a este host (nome:porta)."""
    jobs = [j for j in st.get("jobs", []) if j.get("name") in node.get("jobs", []) and j.get("kind") == "node"]
    if not jobs:
        raise GrafanaError("Este host não tem um job do node_exporter: não há dashboard de host para ele.")
    return f"{node.get('name') or node['address']}:{jobs[0]['port']}"


def for_host(st: dict[str, Any], address: str) -> tuple[str, dict[str, Any]]:
    node = next((n for n in st.get("nodes", []) if n.get("address") == address), None)
    if not node:
        raise GrafanaError("Host não encontrado.")
    inst = node_instance(st, node)
    name = node.get("name") or node["address"]
    lb = cluster_of(st, node.get("cluster", ""))
    dash = copy.deepcopy(load("newos-node-exporter"))
    lock(dash, {"node": inst}, drop=("cliente", "cluster", "job"))
    who = " · ".join(x for x in (lb.get("cliente"), lb.get("cluster")) if x)
    finish(dash, "host", name, f"{name} · Host" + (f" · {who}" if who else ""),
           f"Host {name} ({inst}) pelo node_exporter: CPU, memória, discos, rede, saúde do hardware e "
           f"processos. Gerada pelo NewOS já filtrada para este host.")
    return f"grafana-host-{slug(name)}.json", dash


def for_cluster(st: dict[str, Any], name: str) -> tuple[str, dict[str, Any]]:
    if not any(c.get("name") == name for c in st.get("clusters", [])):
        raise GrafanaError("Cluster não encontrado.")
    lb = cluster_of(st, name)
    members = [n for n in st.get("nodes", []) if n.get("cluster") == name]
    if not any(j.get("kind") == "node" for n in members for j in st.get("jobs", []) if j.get("name") in n.get("jobs", [])):
        raise GrafanaError("Nenhum host deste cluster tem o node_exporter.")
    dash = copy.deepcopy(load("newos-node-exporter"))
    lock(dash, {"cluster": prom_rx(name), "cliente": prom_rx(lb["cliente"]) if lb.get("cliente") else ".*"})
    finish(dash, "cluster", name, f"{name} · Hosts" + (f" · {lb['cliente']}" if lb.get("cliente") else ""),
           f"Hosts do cluster {name} pelo node_exporter (um por vez, escolha no filtro host). "
           f"Gerada pelo NewOS já filtrada para este cluster.")
    return f"grafana-cluster-{slug(name)}.json", dash


def for_pve(st: dict[str, Any], cid: str) -> tuple[str, dict[str, Any]]:
    c = next((c for c in st.get("pve", []) if c.get("id") == cid), None)
    if not c:
        raise GrafanaError("Proxmox não encontrado.")
    lb = cluster_of(st, c.get("cluster", ""))
    dash = copy.deepcopy(load("newos-pve-exporter"))
    lock(dash, {"instance": c["name"]}, drop=("cliente", "cluster"))
    who = lb.get("cliente") or lb.get("cluster") or ""
    finish(dash, "pve", c["name"], f"Proxmox · {c['name']}" + (f" · {who}" if who else ""),
           f"Cluster Proxmox {c['name']} pelo pve-exporter do NewOS: nós, storages, VMs/CTs e "
           f"replicação ZFS. Gerada pelo NewOS já filtrada para este cluster.")
    return f"grafana-proxmox-{slug(c['name'])}.json", dash


def for_ceph(st: dict[str, Any], cid: str) -> tuple[str, dict[str, Any]]:
    c = next((c for c in st.get("ceph", []) if c.get("id") == cid), None)
    if not c:
        raise GrafanaError("Ceph não encontrado.")
    lb = cluster_of(st, c.get("cluster", ""))
    dash = copy.deepcopy(load("newos-ceph"))
    values = {"ceph_cluster": c["name"]}
    if lb:
        # os hosts do Ceph = os hosts do mesmo cluster do NewOS ("Todos" = so eles)
        values.update({"cluster": prom_rx(lb["cluster"]),
                       "cliente": prom_rx(lb["cliente"]) if lb.get("cliente") else ".*"})
        for v in dash["spec"]["variables"]:
            if v["spec"].get("name") == "nos":
                v["spec"]["hide"] = "hideVariable"
    lock(dash, values, drop=() if lb else ("cliente", "cluster"))
    if not lb:
        for v in dash["spec"]["variables"]:
            if v["spec"].get("name") == "nos":
                q = "label_values(node_uname_info, instance)"
                v["spec"]["query"]["spec"]["query"] = q
                v["spec"]["definition"] = q
    who = lb.get("cliente") or lb.get("cluster") or ""
    finish(dash, "ceph", c["name"], f"Ceph · {c['name']}" + (f" · {who}" if who else ""),
           f"Cluster Ceph {c['name']} pelo ceph-mgr: saúde, capacidade, OSDs, monitores, PGs, IOPS e "
           f"pools. Gerada pelo NewOS já filtrada para este cluster.")
    return f"grafana-ceph-{slug(c['name'])}.json", dash
