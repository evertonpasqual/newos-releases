"""
NewOS Panel - NewOS Manager: ativacao obrigatoria e estado do agente.

Servidor instalado pela ISO (marca /etc/newos/activation-required): depois
do login, todo o painel leva a /ativacao ate:
    1. colar a chave gerada no NewOS Manager (o agente newos-link ativa)
    2. trocar a senha padrao do admin (se ainda for a padrao)
So administradores ativam. Servidores atualizados (sem a marca) entram no
Manager como pendentes e nada trava aqui.

Suspenso ou desativado pelo Manager (o agente newos-link cria
/etc/newos/suspended.json ou /etc/newos/decommissioned): TODO o painel,
inclusive o login, leva a /suspenso, que so informa. Reativar e so pelo
Manager (ou, suspenso, "newos-link resume" como root no SSH).

    GET  /ativacao              passo atual
    POST /ativacao/chave        ativa com a chave
    POST /ativacao/senha        troca a senha padrao e libera o painel
    POST /sistema/manager/verificar   um sinal agora (Sistema > Servidor)
    GET  /suspenso              aviso de servidor suspenso / desativado
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, terminal_routes

log = logging.getLogger("newos.panel.link")
HELPER = "/usr/local/sbin/newos-link"
REQUIRED = "/etc/newos/activation-required"
STATUS = "/etc/newos/link-status.json"
NEWOS_CONF = "/etc/newos/newos.conf"
SUSPENDED = "/etc/newos/suspended.json"
DECOMMISSIONED = "/etc/newos/decommissioned"
LOCK_OPEN = ("/suspenso", "/static", "/healthz", "/favicon")
OPEN_PATHS = ("/ativacao", "/login", "/logout", "/static", "/healthz", "/api/tema", "/favicon")
STATUS_TEXT = {"active": "ativo", "pending": "pendente de aprovação", "revoked": "revogado",
               "awaiting-key": "aguardando a chave de ativação", "waiting-firstboot": "aguardando o 1º boot",
               "off": "desligado", "none": "ainda sem contato"}


class LinkError(Exception):
    pass


def required() -> bool:
    return os.path.exists(REQUIRED)


def locked() -> str:
    """'' | 'suspended' | 'decommissioned' (ordem do NewOS Manager)."""
    if os.path.exists(DECOMMISSIONED):
        return "decommissioned"
    return "suspended" if os.path.exists(SUSPENDED) else ""


def link_status() -> dict[str, Any]:
    try:
        with open(STATUS, encoding="utf-8") as fh:
            st = json.load(fh)
    except (OSError, ValueError):
        st = {}
    st.setdefault("status", "none")
    st["required"] = required()
    st["text"] = STATUS_TEXT.get(st["status"], st["status"])
    return st


def helper(args: list[str], payload: dict[str, Any] | None = None) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=90, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise LinkError(f"Nao foi possivel executar o agente: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise LinkError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def _default_password() -> str:
    val = "admin"
    try:
        with open(NEWOS_CONF, encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("PANEL_ADMIN_PASSWORD="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return val


def still_default(user_id: int) -> bool:
    row = db.query_one("SELECT password_hash FROM users WHERE id = %s", (user_id,))
    return bool(row) and auth.verify_password(_default_password(), row["password_hash"])


def install_gate(app: FastAPI) -> None:
    """Registrar ANTES do SessionMiddleware (para a sessao ja estar pronta aqui)."""

    @app.middleware("http")
    async def activation_gate(request: Request, call_next):
        path = request.url.path
        if locked() and not path.startswith(LOCK_OPEN):
            if path.startswith("/api/"):
                return JSONResponse({"ok": False, "message": "Servidor suspenso pelo NewOS Manager."},
                                    status_code=423)
            return RedirectResponse("/suspenso", status_code=303)
        if not required() or path.startswith(OPEN_PATHS) or not request.session.get("user"):
            return await call_next(request)
        if path.startswith("/api/"):
            return JSONResponse({"ok": False, "message": "Ative este servidor no NewOS Manager."}, status_code=423)
        return RedirectResponse("/ativacao", status_code=303)


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    @app.get("/suspenso", response_class=HTMLResponse)
    async def locked_page(request: Request):
        mode = locked()
        if not mode:
            return redirect("/")
        since = None
        try:
            with open(SUSPENDED, encoding="utf-8") as fh:
                since = json.load(fh).get("since")
        except (OSError, ValueError):
            pass
        resp = render(request, "locked.html", mode=mode, st=link_status(), since=since)
        resp.status_code = 423
        return resp

    @app.get("/ativacao", response_class=HTMLResponse)
    async def activation_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not required():
            return redirect("/dashboard")
        st = link_status()
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        step = "senha" if st["status"] == "active" else "chave"
        return render(request, "activation.html", st=st, admin=admin, step=step)

    @app.post("/ativacao/chave", response_class=HTMLResponse)
    async def activation_key(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not await run_in_threadpool(terminal_routes.is_admin, user):
            flash(request, "erro", "Só um administrador ativa o servidor.")
            return redirect("/ativacao")
        form = await request.form()
        ip = auth.client_ip(request)
        try:
            res = await run_in_threadpool(helper, ["activate"], {"key": str(form.get("key", ""))})
        except LinkError as exc:
            db.log_audit(user["username"], "ativacao", f"chave recusada: {exc}"[:200], ip)
            flash(request, "erro", str(exc))
            return redirect("/ativacao")
        db.log_audit(user["username"], "ativacao", f"ativado no Manager (cliente {res.get('client') or '-'})", ip)
        if not await run_in_threadpool(still_default, user["id"]):
            try:
                await run_in_threadpool(helper, ["finish"])
            except LinkError as exc:
                flash(request, "erro", str(exc))
                return redirect("/ativacao")
            flash(request, "ok", "Servidor ativado no NewOS Manager.")
            return redirect("/dashboard")
        flash(request, "ok", "Chave aceita. Agora troque a senha padrão para liberar o painel.")
        return redirect("/ativacao")

    @app.post("/ativacao/senha", response_class=HTMLResponse)
    async def activation_password(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if link_status()["status"] != "active":
            return redirect("/ativacao")
        form = await request.form()
        pw, pw2 = str(form.get("password", "")), str(form.get("password2", ""))
        problem = ""
        if pw == _default_password() or pw.lower() in (user["username"].lower(), "newfront", "12345678"):
            problem = "Escolha uma senha diferente da padrão."
        elif len(pw) < 8:
            problem = "A nova senha precisa ter ao menos 8 caracteres."
        elif pw != pw2:
            problem = "As duas senhas não são iguais."
        if problem:
            flash(request, "erro", problem)
            return redirect("/ativacao")
        await run_in_threadpool(auth.change_password, user["id"], pw)
        try:
            await run_in_threadpool(helper, ["finish"])
        except LinkError as exc:
            flash(request, "erro", str(exc))
            return redirect("/ativacao")
        db.log_audit(user["username"], "ativacao", "senha padrao trocada; painel liberado", auth.client_ip(request))
        flash(request, "ok", "Pronto: servidor ativado e senha trocada.")
        return redirect("/dashboard")

    @app.post("/sistema/manager/verificar", response_class=HTMLResponse)
    async def manager_check(request: Request):
        if not auth.current_user(request):
            return redirect("/login")
        try:
            st = await run_in_threadpool(helper, ["once"])
            if st.get("last_error"):
                flash(request, "erro", f"NewOS Manager: {st['last_error']}")
            else:
                flash(request, "ok", f"NewOS Manager: {STATUS_TEXT.get(st.get('status'), st.get('status'))}.")
        except LinkError as exc:
            flash(request, "erro", str(exc))
        return redirect("/sistema/servidor#manager")
