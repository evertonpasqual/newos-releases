"""
NewOS Panel - telas do modulo Backup (Bareos).

Registradas por main.py via register(); so respondem com o modulo
Backup LIGADO (senao, levam para Sistema > Modulos).

    /backup                     visao geral
    /backup/rotinas             o que, de quem, para onde e quando
    /backup/historico           backups e restauracoes (+ log de cada um)
    /backup/restaurar           escolher o ponto, navegar, restaurar/baixar
    /backup/clientes            maquinas protegidas (File Daemon)
    /backup/destinos            disco local e S3; retencao
    /backup/ajustes             o que copiar, agendas, recarregar
"""

from __future__ import annotations

import json
import logging
import re
import secrets
from urllib.parse import quote
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, backup, db, modules

log = logging.getLogger("newos.panel.backup")

WEEKDAYS = [("mon", "Seg"), ("tue", "Ter"), ("wed", "Qua"), ("thu", "Qui"),
            ("fri", "Sex"), ("sat", "Sáb"), ("sun", "Dom")]
WEEKS = [("", "toda semana"), ("1st", "1ª do mês"), ("2nd", "2ª do mês"),
         ("3rd", "3ª do mês"), ("4th", "4ª do mês"), ("last", "última do mês")]
TOKEN_RE = re.compile(r"^[0-9a-f]{32}$")


def _lines(text: str) -> list[str]:
    return [ln.strip() for ln in (text or "").replace("\r", "").split("\n") if ln.strip()]


def _schedule_data(f: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    g = lambda k, d="": (f.get(prefix + k) or d)            # noqa: E731
    days = f.get(prefix + "inc_days") or []
    if isinstance(days, str):
        days = [days]
    return {"preset": g("preset", "weekly"), "time": g("time", "23:00"),
            "full_week": g("full_week"), "full_day": g("full_day", "sun"),
            "inc_days": days, "inc_time": g("inc_time") or g("time", "23:00")}


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        mod = modules.get_module("backup") or {}
        if not mod.get("enabled") or not backup.installed():
            flash(request, "aviso", "Ligue o módulo Backup em Sistema > Módulos para usar os backups.")
            return None, redirect("/modulos")
        return user, None

    async def form_of(request: Request) -> dict[str, Any]:
        raw = await request.form()
        out: dict[str, Any] = {}
        for k in raw.keys():
            vals = [str(v) for v in raw.getlist(k)]
            out[k] = vals if len(vals) > 1 or k.endswith("[]") or k in ("inc_days", "devices",
                                                                          "fileids", "dirids",
                                                                          "r_inc_days") else vals[0]
        return out

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "backup", what, auth.client_ip(request))
        log.info("Backup por %s: %s", user["username"], what)

    async def do(request: Request, user: dict[str, Any], fn: Callable[..., Any], *args: Any,
                 ok_msg: str | None = None, **kw: Any) -> Any:
        try:
            res = await run_in_threadpool(fn, *args, **kw)
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
            return None
        msg = ok_msg or (res.get("message") if isinstance(res, dict) else "") or "Feito."
        notes = res.get("notes") if isinstance(res, dict) else None
        if notes:
            msg += " " + " ".join(notes)
        flash(request, "ok", msg)
        audit(request, user, msg)
        return res if res is not None else True

    # =================================================================
    #  Visao geral
    # =================================================================
    @app.get("/backup", response_class=HTMLResponse)
    async def backup_home(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            ov = await run_in_threadpool(backup.overview)
        except backup.BackupError as exc:
            return render(request, "backup_overview.html", active="backup", ov=None, error=str(exc))
        return render(request, "backup_overview.html", active="backup", ov=ov, error=None)

    @app.get("/api/backup/running")
    async def backup_running(request: Request):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        rows = await run_in_threadpool(backup.jobs, 50, jobstatus="R")
        return {"ok": True, "jobs": [{k: j[k] for k in ("jobid", "name", "client", "level",
                                                         "files", "bytes", "duration")}
                                     for j in rows]}

    # =================================================================
    #  Rotinas
    # =================================================================
    @app.get("/backup/rotinas", response_class=HTMLResponse)
    async def backup_routines(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        conf = await run_in_threadpool(backup.info)
        last: dict[str, dict[str, Any]] = {}
        for j in await run_in_threadpool(backup.jobs, 300, jobtype="B"):
            if j["name"] not in last and not j["running"]:
                last[j["name"]] = j
        running = {j["name"] for j in await run_in_threadpool(backup.jobs, 50, jobstatus="R")}
        return render(request, "backup_routines.html", active="backup-rotinas", conf=conf,
                      last=last, running=running, weekdays=WEEKDAYS, weeks=WEEKS,
                      mounts=await run_in_threadpool(backup.data_mounts))

    @app.post("/backup/rotinas/nova", response_class=HTMLResponse)
    async def backup_routine_new(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        data = {
            "name": f.get("name", "").strip(), "client": f.get("client", ""),
            "storage": f.get("storage", ""), "description": f.get("description", ""),
            "level": "Incremental", "max_run_hours": f.get("max_run_hours", "12"),
            "fileset": {"include": _lines(f.get("include", "")),
                        "exclude": _lines(f.get("exclude", "")),
                        "compression": f.get("compression", "LZ4")},
            "schedule": _schedule_data(f),
            "pool": {"retention": f"{f.get('retention_n', '30')} {f.get('retention_u', 'days')}",
                     "volume_bytes": f.get("volume_bytes", "10G")},
        }
        res = await do(request, user, backup.apply, "routine", data["name"], data)
        if res and f.get("run_now"):
            await do(request, user, backup.action, ["run-job", data["name"], "Full"])
        return redirect("/backup/rotinas")

    @app.post("/backup/rotinas/{name}/executar", response_class=HTMLResponse)
    async def backup_routine_run(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        res = await do(request, user, backup.action, ["run-job", name, f.get("level", "Incremental")])
        if res and res.get("jobid"):
            return redirect(f"/backup/historico/{res['jobid']}")
        return redirect("/backup/rotinas")

    @app.post("/backup/rotinas/{name}/salvar", response_class=HTMLResponse)
    async def backup_routine_save(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        data = {k: f.get(k, "") for k in ("client", "fileset", "schedule", "storage", "pool",
                                          "level", "max_run_hours", "description")}
        data["enabled"] = bool(f.get("enabled"))
        await do(request, user, backup.apply, "job", name, data)
        return redirect("/backup/rotinas")

    @app.post("/backup/rotinas/{name}/remover", response_class=HTMLResponse)
    async def backup_routine_delete(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        if f.get("confirm") != name:
            flash(request, "erro", "Confirmação não confere: digite o nome da rotina.")
            return redirect("/backup/rotinas")
        await do(request, user, backup.apply, "job", name, {}, op="delete")
        return redirect("/backup/rotinas")

    # =================================================================
    #  Historico
    # =================================================================
    @app.get("/backup/historico", response_class=HTMLResponse)
    async def backup_history(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        qp = request.query_params
        filters = {"client": qp.get("cliente", ""), "jobstatus": qp.get("status", ""),
                   "jobtype": qp.get("tipo", ""), "jobname": qp.get("rotina", "")}
        rows = await run_in_threadpool(lambda: backup.jobs(1000, **filters))
        page = max(1, int(qp.get("pagina", "1") or 1) if (qp.get("pagina") or "1").isdigit() else 1)
        per = 40
        conf = await run_in_threadpool(backup.info)
        return render(request, "backup_history.html", active="backup-historico",
                      rows=rows[(page - 1) * per: page * per], total=len(rows), page=page,
                      pages=max(1, (len(rows) + per - 1) // per), filters=filters, conf=conf,
                      status_map=backup.STATUS)

    @app.get("/backup/historico/{jobid}", response_class=HTMLResponse)
    async def backup_job(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            job = await run_in_threadpool(backup.job, jobid)
            lines = await run_in_threadpool(backup.job_log, jobid)
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/backup/historico")
        if not job:
            flash(request, "erro", f"JobId {jobid} não encontrado.")
            return redirect("/backup/historico")
        return render(request, "backup_job.html", active="backup-historico", job=job,
                      lines=lines, hint=backup.summarize_log(lines))

    @app.get("/api/backup/job/{jobid}")
    async def backup_job_json(request: Request, jobid: int):
        if not auth.current_user(request):
            return JSONResponse({"ok": False}, status_code=401)
        job = await run_in_threadpool(backup.job, jobid)
        return {"ok": bool(job), "job": job}

    @app.post("/backup/historico/{jobid}/cancelar", response_class=HTMLResponse)
    async def backup_job_cancel(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        await do(request, user, backup.action, ["cancel", str(jobid)])
        return redirect(f"/backup/historico/{jobid}")

    @app.post("/backup/historico/{jobid}/remover", response_class=HTMLResponse)
    async def backup_job_delete(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        if f.get("confirm") != str(jobid):
            flash(request, "erro", "Confirmação não confere: digite o número do job.")
            return redirect(f"/backup/historico/{jobid}")
        await do(request, user, backup.action, ["delete-job", str(jobid)])
        return redirect("/backup/historico")

    # =================================================================
    #  Restaurar
    # =================================================================
    # Selecao da restauracao: no banco, chaveada por um id na sessao
    # (o cookie de sessao tem ~4 KB; uma selecao grande nao caberia).
    def selection(request: Request) -> dict[str, Any]:
        sid = request.session.get("backup_sel")
        if not isinstance(sid, str) or not TOKEN_RE.match(sid):
            return {}
        row = db.query_one("SELECT data FROM backup_selections WHERE sel_id = %s", (sid,))
        try:
            return json.loads(row["data"]) if row else {}
        except (ValueError, TypeError):
            return {}

    def save_selection(request: Request, user: dict[str, Any], sel: dict[str, Any]) -> None:
        sid = request.session.get("backup_sel")
        if not isinstance(sid, str) or not TOKEN_RE.match(sid):
            sid = secrets.token_hex(16)
            request.session["backup_sel"] = sid
        db.execute("REPLACE INTO backup_selections (sel_id, username, data) VALUES (%s, %s, %s)",
                   (sid, user["username"], json.dumps(sel)))
        db.execute("DELETE FROM backup_selections WHERE updated_at < NOW() - INTERVAL 2 DAY")

    def clear_selection(request: Request) -> None:
        sid = request.session.pop("backup_sel", None)
        if isinstance(sid, str) and TOKEN_RE.match(sid):
            db.execute("DELETE FROM backup_selections WHERE sel_id = %s", (sid,))

    @app.get("/backup/restaurar", response_class=HTMLResponse)
    async def backup_restore(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        qp = request.query_params
        conf = await run_in_threadpool(backup.info)
        client = qp.get("cliente", "")
        points = []
        if client:
            points = [j for j in await run_in_threadpool(lambda: backup.jobs(500, client=client,
                                                                             jobtype="B"))
                      if j["status"] in "TW" and j["files"] > 0]
        downloads = await run_in_threadpool(backup.downloads)
        return render(request, "backup_restore.html", active="backup-restaurar", conf=conf,
                      client=client, points=points, sel=selection(request), downloads=downloads)

    @app.get("/backup/restaurar/{jobid}", response_class=HTMLResponse)
    async def backup_browse(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        sel = selection(request)
        try:
            job = await run_in_threadpool(backup.job, jobid)
            if not job:
                raise backup.BackupError(f"JobId {jobid} não encontrado.")
            if sel.get("jobid") != jobid:
                chain = await run_in_threadpool(backup.prepare_browse, jobid)
                sel = {"jobid": jobid, "chain": chain, "client": job["client"],
                       "name": job["name"], "start": job["start"], "files": {}, "dirs": {}}
                save_selection(request, user, sel)
            pathid = request.query_params.get("pasta")
            listing = await run_in_threadpool(backup.browse, sel["chain"],
                                              int(pathid) if pathid and pathid.isdigit() else None)
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
            return redirect("/backup/restaurar")
        # O Bareos devolve "." como caminho da pasta atual: o caminho vem
        # pela navegacao (cada link leva o caminho da pasta que abre).
        path = request.query_params.get("caminho", "")
        if path and not path.endswith("/"):
            path += "/"
        if not listing["current"] or listing["current"] in (".", "./"):
            listing["current"] = path
        trimmed = listing["current"].rstrip("/")
        listing["parent_path"] = (trimmed.rsplit("/", 1)[0] + "/") if "/" in trimmed else ""
        conf = await run_in_threadpool(backup.info)
        return render(request, "backup_browse.html", active="backup-restaurar", job=job,
                      sel=sel, ls=listing, conf=conf, pathid=pathid or "",
                      download_ok=backup.installed())

    @app.post("/backup/restaurar/{jobid}/marcar", response_class=HTMLResponse)
    async def backup_mark(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        sel = selection(request)
        if sel.get("jobid") != jobid:
            return redirect(f"/backup/restaurar/{jobid}")
        files, dirs = dict(sel.get("files") or {}), dict(sel.get("dirs") or {})
        op = f.get("op", "add")
        for item in f.get("item", []) if isinstance(f.get("item"), list) else [f.get("item", "")]:
            kind, _, rest = str(item).partition(":")
            ident, _, label = rest.partition(":")
            if not ident.isdigit():
                continue
            target = files if kind == "f" else dirs if kind == "d" else None
            if target is None:
                continue
            if op == "add":
                target[ident] = label[:300]
            else:
                target.pop(ident, None)
        if op == "clear":
            files, dirs = {}, {}
        sel.update(files=files, dirs=dirs)
        save_selection(request, user, sel)
        back = f.get("back") or ""
        path = f.get("back_path") or ""
        return redirect(f"/backup/restaurar/{jobid}"
                        + (f"?pasta={back}&caminho={quote(path)}" if back.isdigit() else ""))

    @app.post("/backup/restaurar/{jobid}/executar", response_class=HTMLResponse)
    async def backup_restore_run(request: Request, jobid: int):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        sel = selection(request)
        if sel.get("jobid") != jobid or not (sel.get("files") or sel.get("dirs")):
            flash(request, "erro", "Marque ao menos um arquivo ou pasta para restaurar.")
            return redirect(f"/backup/restaurar/{jobid}")
        fileids = [int(i) for i in sel["files"]]
        dirids = [int(i) for i in sel["dirs"]]
        dest = f.get("destination", "original")
        try:
            if dest == "download":
                label = ", ".join(list(sel["dirs"].values())[:3] + list(sel["files"].values())[:3])
                token = await run_in_threadpool(backup.start_download, jobid, sel["client"],
                                                fileids, dirids, user["username"], label)
                audit(request, user, f"restauração para download do JobId {jobid} ({token[:8]})")
                clear_selection(request)
                return redirect(f"/backup/baixar/{token}")
            where = ""
            restoreclient = sel["client"]
            if dest == "folder":
                where = (f.get("where") or "").strip()
            elif dest == "client":
                restoreclient = f.get("restoreclient", "")
                where = (f.get("where_other") or "").strip()
            if dest in ("folder", "client") and not where:
                raise backup.BackupError("Informe a pasta de destino.")
            rjob = await run_in_threadpool(lambda: backup.restore(
                jobid, sel["client"], fileids, dirids, restoreclient=restoreclient,
                where=where, replace=f.get("replace", "IfNewer")))
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
            return redirect(f"/backup/restaurar/{jobid}")
        audit(request, user, f"restauração do JobId {jobid} em {restoreclient}:{where or 'local original'}")
        flash(request, "ok", f"Restauração iniciada (JobId {rjob}).")
        clear_selection(request)
        return redirect(f"/backup/historico/{rjob}")

    @app.get("/backup/baixar/{token}", response_class=HTMLResponse)
    async def backup_download_page(request: Request, token: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if not TOKEN_RE.match(token):
            return redirect("/backup/restaurar")
        row = await run_in_threadpool(backup.download_state, token)
        if not row:
            flash(request, "erro", "Download não encontrado.")
            return redirect("/backup/restaurar")
        return render(request, "backup_download.html", active="backup-restaurar", row=row)

    @app.get("/api/backup/baixar/{token}")
    async def backup_download_status(request: Request, token: str):
        if not auth.current_user(request) or not TOKEN_RE.match(token):
            return JSONResponse({"ok": False}, status_code=401)
        row = await run_in_threadpool(backup.download_state, token)
        if not row:
            return JSONResponse({"ok": False}, status_code=404)
        return {"ok": True, "status": row["status"], "message": row.get("message"),
                "files": row.get("files"), "size": row.get("size")}

    @app.get("/backup/baixar/{token}/arquivo")
    async def backup_download_file(request: Request, token: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if not TOKEN_RE.match(token):
            return redirect("/backup/restaurar")
        row = await run_in_threadpool(backup.download_state, token)
        path = backup.download_path(token)
        if not row or row["status"] != "ready" or not path:
            flash(request, "erro", "Este download não está disponível (venceu ou ainda não terminou).")
            return redirect("/backup/restaurar")
        audit(request, user, f"baixou a restauração {token[:8]} (JobId {row['jobid']})")
        name = f"restauracao-{row['client']}-job{row['jobid']}.zip"
        return FileResponse(path, media_type="application/zip", filename=name)

    @app.post("/backup/baixar/{token}/remover", response_class=HTMLResponse)
    async def backup_download_delete(request: Request, token: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if TOKEN_RE.match(token):
            await run_in_threadpool(backup.delete_download, token)
            flash(request, "ok", "Download removido do servidor.")
        return redirect("/backup/restaurar")

    # =================================================================
    #  Clientes
    # =================================================================
    @app.get("/backup/clientes", response_class=HTMLResponse)
    async def backup_clients(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        conf = await run_in_threadpool(backup.info)
        test = request.session.pop("backup_client_test", None)
        created = request.session.pop("backup_client_new", None)
        return render(request, "backup_clients.html", active="backup-clientes", conf=conf,
                      test=test, created=created)

    @app.post("/backup/clientes/salvar", response_class=HTMLResponse)
    async def backup_client_save(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        is_new = f.get("new") == "1"
        res = await do(request, user, lambda: backup._helper(["apply"], {
            "kind": "client", "op": "save", "new": is_new, "name": f.get("name", "").strip(),
            "data": {"address": f.get("address", ""), "os": f.get("os", "linux"),
                     "description": f.get("description", ""),
                     "password": f.get("password", "")}}, timeout=300))
        if res and is_new:
            request.session["backup_client_new"] = res.get("name")
        return redirect("/backup/clientes")

    @app.post("/backup/clientes/{name}/testar", response_class=HTMLResponse)
    async def backup_client_test(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            res = await run_in_threadpool(backup.action, ["client-status", name], 90)
            request.session["backup_client_test"] = {"name": name, **{k: res.get(k) for k in
                                                                       ("online", "message")}}
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
        return redirect("/backup/clientes")

    @app.post("/backup/clientes/{name}/remover", response_class=HTMLResponse)
    async def backup_client_delete(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        if f.get("confirm") != name:
            flash(request, "erro", "Confirmação não confere: digite o nome do cliente.")
            return redirect("/backup/clientes")
        await do(request, user, backup.apply, "client", name, {}, op="delete")
        return redirect("/backup/clientes")

    # =================================================================
    #  Destinos (disco local / S3) e retencao
    # =================================================================
    @app.get("/backup/destinos", response_class=HTMLResponse)
    async def backup_targets(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        conf = await run_in_threadpool(backup.info)
        for s in conf.get("storages", []):
            s["usage"] = backup.disk_usage(s["path"]) if s["type"] == "local" and s["path"] else None
        try:
            volumes = (await run_in_threadpool(backup.api, "llist volumes")).get("volumes") or {}
        except backup.BackupError:
            volumes = {}
        test = request.session.pop("backup_s3_test", None)
        return render(request, "backup_targets.html", active="backup-destinos", conf=conf,
                      mounts=await run_in_threadpool(backup.data_mounts), volumes=volumes,
                      test=test)

    @app.post("/backup/destinos/salvar", response_class=HTMLResponse)
    async def backup_target_save(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        kind = f.get("type", "local")
        path = (f.get("path") or "").strip()
        if kind == "local" and f.get("mount") and not path:
            path = f.get("mount").rstrip("/") + "/backup"
        data = {"type": kind, "address": f.get("address", ""), "path": path,
                "max_jobs": f.get("max_jobs", "5" if kind == "local" else "1"),
                "bucket": f.get("bucket", ""), "host": f.get("host", ""),
                "access_key": f.get("access_key", ""), "secret_key": f.get("secret_key", ""),
                "https": bool(f.get("https")), "path_style": bool(f.get("path_style"))}
        res = await do(request, user, backup.apply, "storage", f.get("name", "").strip(), data,
                       new=f.get("new") == "1", force=bool(f.get("force")))
        if res and kind == "s3":
            try:
                t = await run_in_threadpool(backup.action, ["s3-test", f.get("name", "").strip()], 90)
                request.session["backup_s3_test"] = {"name": f.get("name"), "online": t.get("online"),
                                                     "message": t.get("message")}
            except backup.BackupError as exc:
                request.session["backup_s3_test"] = {"name": f.get("name"), "online": False,
                                                     "message": str(exc)}
        return redirect("/backup/destinos")

    @app.post("/backup/destinos/{name}/testar", response_class=HTMLResponse)
    async def backup_target_test(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        try:
            t = await run_in_threadpool(backup.action, ["s3-test", name], 90)
            request.session["backup_s3_test"] = {"name": name, "online": t.get("online"),
                                                 "message": t.get("message")}
        except backup.BackupError as exc:
            flash(request, "erro", str(exc))
        return redirect("/backup/destinos")

    @app.post("/backup/destinos/{name}/remover", response_class=HTMLResponse)
    async def backup_target_delete(request: Request, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        f = await form_of(request)
        if f.get("confirm") != name:
            flash(request, "erro", "Confirmação não confere: digite o nome do destino.")
            return redirect("/backup/destinos")
        await do(request, user, backup.apply, "storage", name, {}, op="delete",
                 force=bool(f.get("force")))
        return redirect("/backup/destinos")

    # =================================================================
    #  Ajustes: o que copiar, agendas, retencao
    # =================================================================
    @app.get("/backup/ajustes", response_class=HTMLResponse)
    async def backup_settings(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        conf = await run_in_threadpool(backup.info)
        return render(request, "backup_settings.html", active="backup-ajustes", conf=conf,
                      states=await run_in_threadpool(backup.service_states),
                      weekdays=WEEKDAYS, weeks=WEEKS)

    @app.post("/backup/ajustes/{kind}/salvar", response_class=HTMLResponse)
    async def backup_settings_save(request: Request, kind: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if kind not in ("fileset", "schedule", "pool"):
            return redirect("/backup/ajustes")
        f = await form_of(request)
        if kind == "fileset":
            data = {"include": _lines(f.get("include", "")), "exclude": _lines(f.get("exclude", "")),
                    "compression": f.get("compression", "LZ4")}
        elif kind == "schedule":
            data = {**_schedule_data(f), "enabled": bool(f.get("enabled"))}
        else:
            data = {"retention": f"{f.get('retention_n', '30')} {f.get('retention_u', 'days')}",
                    "volume_bytes": f.get("volume_bytes", "10G"),
                    "max_volumes": f.get("max_volumes", "0"), "label": f.get("label", "")}
        await do(request, user, backup.apply, kind, f.get("name", "").strip(), data,
                 new=f.get("new") == "1")
        return redirect("/backup/ajustes" + {"fileset": "#copiar", "schedule": "#agendas",
                                              "pool": "#retencao"}[kind])

    @app.post("/backup/ajustes/{kind}/{name}/remover", response_class=HTMLResponse)
    async def backup_settings_delete(request: Request, kind: str, name: str):
        user, bounce = guard(request)
        if bounce:
            return bounce
        if kind not in ("fileset", "schedule", "pool"):
            return redirect("/backup/ajustes")
        f = await form_of(request)
        if f.get("confirm") != name:
            flash(request, "erro", "Confirmação não confere.")
            return redirect("/backup/ajustes")
        await do(request, user, backup.apply, kind, name, {}, op="delete")
        return redirect("/backup/ajustes")

    @app.post("/backup/ajustes/recarregar", response_class=HTMLResponse)
    async def backup_reload(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        await do(request, user, backup.action, ["reload"])
        return redirect("/backup/ajustes")
