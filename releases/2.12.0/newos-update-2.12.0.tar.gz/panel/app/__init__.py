"""NewOS Panel - painel web de administracao do NewOS."""

__version__ = "1.0.0"
