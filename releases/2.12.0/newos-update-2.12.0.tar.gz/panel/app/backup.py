"""
NewOS Panel - modulo Backup (Bareos).

Camada entre as telas e o helper privilegiado newos-backup:

    - consultas ao Director (jobs, logs, clientes) em JSON (".api 2")
    - navegacao nos arquivos de um backup (BVFS)
    - restauracao no lugar original, em outra pasta, em outra maquina ou
      para BAIXAR pelo navegador (ZIP com validade)
    - painel: o que rodou nas ultimas 24 h, clientes protegidos, uso dos
      destinos e alertas

Nenhuma tela grava configuracao do Bareos: o helper recebe DADOS e gera
os arquivos, testando com o proprio Bareos antes de aplicar.
"""

from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import time
from datetime import datetime, timedelta
from typing import Any

from . import db

log = logging.getLogger("newos.panel.backup")

BACKUP_BIN = "/usr/local/sbin/newos-backup"
DOWNLOADS = "/var/lib/newos-backup/downloads"
RESTORE_AREA = "/var/lib/newos-backup/restores"
DOWNLOAD_TTL_HOURS = 24
LOCAL_CLIENT = "bareos-fd"            # o File Daemon desta maquina

# Codigo do Bareos -> (rotulo, estilo do selo)
STATUS = {
    "T": ("Concluído", "up"), "W": ("Concluído com avisos", "warn"),
    "E": ("Erro", "err"), "e": ("Erro", "err"), "f": ("Erro fatal", "err"),
    "A": ("Cancelado", "muted"), "R": ("Em execução", "run"),
    "C": ("Na fila", "muted"), "c": ("Aguardando cliente", "run"),
    "d": ("Aguardando destino", "run"), "j": ("Aguardando vaga", "run"),
    "t": ("Aguardando horário", "run"), "p": ("Aguardando prioridade", "run"),
    "q": ("Na fila", "muted"), "i": ("Incompleto", "warn"), "l": ("Gravando", "run"),
    "F": ("Aguardando cliente", "run"), "S": ("Aguardando destino", "run"),
    "m": ("Aguardando mídia", "run"), "M": ("Aguardando mídia", "run"),
}
RUNNING = set("RCcdjtpqlFSmM")
LEVEL = {"F": "Completo", "I": "Incremental", "D": "Diferencial", "B": "Base",
         "Full": "Completo", "Incremental": "Incremental", "Differential": "Diferencial"}
JOBTYPE = {"B": "Backup", "R": "Restauração", "V": "Verificação", "D": "Admin",
           "C": "Cópia", "g": "Migração", "c": "Cópia"}


# "Rotina.2026-10-22_11.36.28_54" -> "Rotina"
UNIQUE_SUFFIX = re.compile(r"\.\d{4}-\d{2}-\d{2}_\d{2}\.\d{2}\.\d{2}_\d+$")


class BackupError(Exception):
    """Erro para mostrar ao administrador."""


# =====================================================================
#  Helper
# =====================================================================

def installed() -> bool:
    return os.path.exists("/usr/sbin/bareos-dir") and os.path.exists(BACKUP_BIN)


def _helper(args: list[str], stdin: dict[str, Any] | None = None,
            timeout: int = 300) -> dict[str, Any]:
    cmd = ["sudo", "-n", BACKUP_BIN, *args]
    try:
        proc = subprocess.run(cmd, input=json.dumps(stdin) if stdin is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise BackupError("O Bareos demorou demais para responder.") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise BackupError(f"Nao foi possivel executar o helper de backup: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout or "").splitlines() if ln.strip()]
        raise BackupError((lines[-1] if lines else f"codigo {proc.returncode}").removeprefix("ERRO: "))
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (json.JSONDecodeError, IndexError) as exc:
        raise BackupError("Resposta invalida do helper de backup.") from exc


def info() -> dict[str, Any]:
    return _helper(["info"], timeout=60)


def apply(kind: str, name: str, data: dict[str, Any], op: str = "save",
          new: bool = False, force: bool = False) -> dict[str, Any]:
    return _helper(["apply"], {"kind": kind, "op": op, "name": name, "data": data,
                               "new": new, "force": force}, timeout=600)


def api(command: str, timeout: int = 120) -> dict[str, Any]:
    return _helper(["api", *command.split()], timeout=timeout).get("result") or {}


def bvfs(command: str) -> dict[str, Any]:
    return _helper(["bvfs", *command.split()], timeout=900).get("result") or {}


def action(args: list[str], timeout: int = 300) -> dict[str, Any]:
    return _helper(args, timeout=timeout)


# =====================================================================
#  Jobs
# =====================================================================

def _ts(value: str) -> float | None:
    if not value or value.startswith("0000"):
        return None
    try:
        return datetime.strptime(value[:19], "%Y-%m-%d %H:%M:%S").timestamp()
    except ValueError:
        return None


def _job(row: dict[str, Any]) -> dict[str, Any]:
    status = row.get("jobstatus", "")
    label, style = STATUS.get(status, (f"Status {status}", "muted"))
    start, end = _ts(row.get("starttime", "")), _ts(row.get("endtime", ""))
    if start and status in RUNNING:
        duration = time.time() - start
    elif start and end:
        duration = max(0.0, end - start)
    else:
        duration = None
    return {
        "jobid": int(row.get("jobid") or 0),
        # "name" = a rotina; "job" = nome unico desta execucao (rotina.data)
        "name": row.get("name") or UNIQUE_SUFFIX.sub("", row.get("job") or ""),
        "unique": row.get("job", ""),
        "client": row.get("client", ""),
        "type": JOBTYPE.get(row.get("type", ""), row.get("type", "")),
        "type_code": row.get("type", ""),
        "level": LEVEL.get(row.get("level", ""), row.get("level", "")),
        "status": status, "status_label": label, "status_style": style,
        "running": status in RUNNING,
        "start": start, "end": end, "duration": duration,
        "files": int(row.get("jobfiles") or 0),
        "bytes": int(row.get("jobbytes") or 0),
        "errors": int(row.get("joberrors") or 0),
        "pool": row.get("poolname", ""), "fileset": row.get("fileset", ""),
        "storage": row.get("storage", ""),
    }


def jobs(limit: int = 1000, **filters: str) -> list[dict[str, Any]]:
    """Mais recentes primeiro. O Bareos so lista em ordem crescente."""
    cmd = "llist jobs"
    for key in ("client", "jobstatus", "jobtype", "jobname", "level"):
        val = (filters.get(key) or "").strip()
        if val and val.replace("-", "").replace("_", "").replace(".", "").isalnum():
            cmd += f" {key}={val}"
    cmd += f" limit={int(limit)} offset=0"
    try:
        rows = api(cmd).get("jobs") or []
    except BackupError as exc:
        log.warning("Lista de jobs indisponivel: %s", exc)
        return []
    return [_job(r) for r in reversed(rows)]


def job(jobid: int) -> dict[str, Any] | None:
    rows = api(f"llist jobid={int(jobid)}").get("jobs") or []
    return _job(rows[0]) if rows else None


def job_log(jobid: int) -> list[dict[str, str]]:
    rows = api(f"list joblog jobid={int(jobid)}").get("joblog") or []
    out = []
    for r in rows:
        text = (r.get("logtext") or "").rstrip()
        kind = "err" if any(w in text.lower() for w in ("error", "fatal", "falhou")) else \
            ("warn" if "warning" in text.lower() else "")
        out.append({"time": r.get("time", ""), "text": text, "kind": kind})
    return out


def summarize_log(lines: list[dict[str, str]]) -> str:
    """Explica em portugues as falhas mais comuns."""
    text = "\n".join(l["text"] for l in lines)
    checks = [
        (("Could not connect", "Storage daemon"), "O Director nao alcancou o Storage Daemon (porta 9103)."),
        (("Name or service not known",), "Um endereco configurado (destino ou cliente) nao resolve no DNS. Use o IP."),
        (("Failed to connect to Client",), "O cliente nao respondeu na porta 9102: File Daemon parado, endereco errado ou firewall."),
        (("Authorization key rejected",), "Senha diferente entre o servidor e o cliente."),
        (("Could not stat",), "Uma pasta do que copiar nao existe no cliente."),
        (("No space left",), "O destino ficou sem espaco."),
        (("NoSuchBucket",), "O bucket S3 nao existe."),
        (("AccessDenied",), "O provedor S3 recusou as chaves."),
    ]
    for needles, msg in checks:
        if all(n in text for n in needles):
            return msg
    return ""


# =====================================================================
#  Painel (visao geral)
# =====================================================================

def service_states() -> dict[str, str]:
    out = {}
    for svc in ("bareos-director", "bareos-storage", "bareos-filedaemon", "postgresql"):
        try:
            out[svc] = subprocess.run(["systemctl", "is-active", svc], capture_output=True,
                                      text=True, timeout=5, check=False).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            out[svc] = "unknown"
    return out


def disk_usage(path: str) -> dict[str, Any] | None:
    try:
        u = shutil.disk_usage(path)
    except OSError:
        return None
    return {"total": u.total, "used": u.used, "free": u.free,
            "percent": round(u.used * 100 / u.total, 1) if u.total else 0}


def overview() -> dict[str, Any]:
    conf = info()
    all_jobs = jobs(limit=500)
    now = time.time()
    since = now - 86400
    stats = {"ok": 0, "warn": 0, "err": 0, "canceled": 0, "running": 0, "bytes": 0}
    last_by_client: dict[str, dict[str, Any]] = {}
    failed, running = [], []
    for j in all_jobs:
        if j["type_code"] == "B" and j["client"] and j["client"] not in last_by_client \
                and not j["running"]:
            last_by_client[j["client"]] = j
        if j["running"]:
            stats["running"] += 1
            running.append(j)
            continue
        if (j["start"] or 0) >= since and j["type_code"] == "B":
            if j["status"] == "T":
                stats["ok"] += 1
            elif j["status"] == "W":
                stats["warn"] += 1
            elif j["status"] in "Eef":
                stats["err"] += 1
                failed.append(j)
            elif j["status"] == "A":
                stats["canceled"] += 1
            stats["bytes"] += j["bytes"]

    clients = []
    for c in conf.get("clients", []):
        last = last_by_client.get(c["name"])
        protected = bool(last and last["status"] in "TW" and (last["start"] or 0) >= now - 172800)
        has_job = any(job_["client"] == c["name"] and job_["type"] == "Backup"
                      for job_ in conf.get("jobs", []))
        clients.append({**c, "last": last, "protected": protected, "has_job": has_job})

    storages = []
    for s in conf.get("storages", []):
        usage = disk_usage(s["path"]) if s["type"] == "local" and s["path"] else None
        storages.append({**s, "usage": usage})

    alerts = []
    states = service_states()
    for svc, state in states.items():
        if state != "active":
            alerts.append(("err", f"O serviço {svc} está {state or 'parado'}."))
    for s in storages:
        if s["usage"] and s["usage"]["percent"] >= 85:
            alerts.append(("err" if s["usage"]["percent"] >= 95 else "warn",
                           f"Destino {s['name']} com {s['usage']['percent']:.0f}% de uso."))
    if s_ := [c["name"] for c in clients if c["has_job"] and not c["protected"]]:
        alerts.append(("warn", "Sem backup com sucesso nas últimas 48 h: " + ", ".join(s_) + "."))
    if failed:
        alerts.append(("err", f"{len(failed)} backup(s) com erro nas últimas 24 h."))

    routines = [j for j in conf.get("jobs", []) if j["type"] == "Backup"]
    return {
        "conf": conf, "stats": stats, "running": running, "failed": failed[:10],
        "recent": [j for j in all_jobs if not j["running"]][:12],
        "clients": clients, "storages": storages, "alerts": alerts, "states": states,
        "protected": sum(1 for c in clients if c["protected"]),
        "routines": routines,
        "series": _daily_series(all_jobs, now),
    }


def _daily_series(all_jobs: list[dict[str, Any]], now: float) -> list[dict[str, Any]]:
    """Bytes copiados por dia (14 dias) para o grafico da visao geral."""
    days = []
    today = datetime.fromtimestamp(now).date()
    for back in range(13, -1, -1):
        d = today - timedelta(days=back)
        days.append({"day": d.strftime("%d/%m"), "date": d, "bytes": 0, "ok": 0, "err": 0})
    index = {d["date"]: d for d in days}
    for j in all_jobs:
        if j["type_code"] != "B" or not j["start"] or j["running"]:
            continue
        d = index.get(datetime.fromtimestamp(j["start"]).date())
        if not d:
            continue
        d["bytes"] += j["bytes"]
        if j["status"] in "TW":
            d["ok"] += 1
        elif j["status"] in "Eef":
            d["err"] += 1
    for d in days:
        d.pop("date")
    return days


# =====================================================================
#  Navegacao nos arquivos (BVFS) e restauracao
# =====================================================================

def prepare_browse(jobid: int) -> str:
    """Cadeia Full+Diff+Inc do ponto escolhido, com o cache BVFS pronto."""
    res = bvfs(f".bvfs_get_jobids jobid={int(jobid)}")
    ids = []
    for item in res.get("jobids", []) if isinstance(res, dict) else []:
        val = item.get("id") if isinstance(item, dict) else item
        if str(val).isdigit():
            ids.append(str(val))
    chain = ",".join(ids) or str(int(jobid))
    bvfs(f".bvfs_update jobid={chain}")
    return chain


def browse(chain: str, pathid: int | None = None) -> dict[str, Any]:
    if not all(p.isdigit() for p in chain.split(",")):
        raise BackupError("Lista de jobs invalida.")
    where = f"pathid={int(pathid)}" if pathid else "path="
    listing = bvfs(f".bvfs_lsdirs jobid={chain} {where}").get("directories", [])
    dirs = [d for d in listing if d.get("name") not in (".", "..", "")]
    files = [f for f in bvfs(f".bvfs_lsfiles jobid={chain} {where}").get("files", [])
             if int(f.get("fileid") or 0) > 0]
    current = next((d.get("fullpath") or "" for d in listing if d.get("name") == "."), "")
    parent = next((int(d.get("pathid") or 0) or None for d in listing
                   if d.get("name") == ".."), None)
    return {
        "dirs": [{"pathid": int(d.get("pathid") or 0), "name": d.get("name", ""),
                  "fullpath": d.get("fullpath", "")} for d in dirs],
        "files": [{"fileid": int(f.get("fileid") or 0), "name": f.get("name", ""),
                   "size": int((f.get("stat") or {}).get("size") or 0),
                   "mtime": int((f.get("stat") or {}).get("mtime") or 0)} for f in files],
        "current": current, "parent": parent if pathid else None,
    }


def restore(jobid: int, client: str, fileids: list[int], dirids: list[int], *,
            restoreclient: str, where: str, replace: str) -> int:
    res = _helper(["restore"], {"jobid": int(jobid), "client": client,
                                "restoreclient": restoreclient, "where": where,
                                "replace": replace, "fileids": fileids, "dirids": dirids},
                  timeout=1800)
    return int(res.get("jobid") or 0)


def start_download(jobid: int, client: str, fileids: list[int], dirids: list[int],
                   user: str, label: str) -> str:
    """Restaura numa area temporaria; o ZIP sai quando o job terminar."""
    token = secrets.token_hex(16)
    rjob = restore(jobid, client, fileids, dirids, restoreclient=LOCAL_CLIENT,
                   where=f"{RESTORE_AREA}/{token}", replace="Always")
    db.execute(
        "INSERT INTO backup_restores (token, jobid, restore_jobid, client, label, status,"
        " created_by, expires_at) VALUES (%s, %s, %s, %s, %s, 'restoring', %s, %s)",
        (token, int(jobid), rjob, client, label[:255], user,
         datetime.now() + timedelta(hours=DOWNLOAD_TTL_HOURS)))
    return token


def download_state(token: str) -> dict[str, Any] | None:
    """Estado de um download; empacota em ZIP quando o restore termina."""
    row = db.query_one("SELECT * FROM backup_restores WHERE token = %s", (token,))
    if not row:
        return None
    if row["expires_at"] < datetime.now() and row["status"] != "expired":
        _expire(row)
        row["status"] = "expired"
    if row["status"] != "restoring":
        return row
    rjob = job(row["restore_jobid"]) if row["restore_jobid"] else None
    if not rjob or rjob["running"]:
        return row
    if rjob["status"] not in "TW":
        _set(token, "error", message=f"A restauração terminou como: {rjob['status_label']}.")
        _cleanup(token)
        row.update(status="error", message=f"A restauração terminou como: {rjob['status_label']}.")
        return row
    try:
        res = _helper(["restore-pack", token], timeout=3600)
    except BackupError as exc:
        _set(token, "error", message=str(exc)[:255])
        row.update(status="error", message=str(exc))
        return row
    _set(token, "ready", files=res.get("files"), size=res.get("size"))
    row.update(status="ready", files=res.get("files"), size=res.get("size"))
    return row


def _set(token: str, status: str, **extra: Any) -> None:
    sets, params = ["status = %s"], [status]
    for k in ("message", "files", "size"):
        if k in extra:
            sets.append(f"{k} = %s")
            params.append(extra[k])
    db.execute(f"UPDATE backup_restores SET {', '.join(sets)} WHERE token = %s",
               (*params, token))


def _cleanup(token: str) -> None:
    try:
        _helper(["restore-cleanup", token], timeout=120)
    except BackupError as exc:
        log.warning("Limpeza do restore %s falhou: %s", token, exc)


def _expire(row: dict[str, Any]) -> None:
    _cleanup(row["token"])
    _set(row["token"], "expired")


def downloads(user: str | None = None) -> list[dict[str, Any]]:
    """Downloads recentes; os vencidos sao limpos aqui."""
    rows = db.query_all("SELECT * FROM backup_restores ORDER BY created_at DESC LIMIT 50")
    for r in rows:
        if r["status"] in ("ready", "restoring", "error") and r["expires_at"] < datetime.now():
            _expire(r)
            r["status"] = "expired"
    return rows


def download_path(token: str) -> str | None:
    path = os.path.join(DOWNLOADS, f"{token}.zip")
    return path if os.path.isfile(path) else None


def delete_download(token: str) -> None:
    _cleanup(token)
    db.execute("DELETE FROM backup_restores WHERE token = %s", (token,))


# =====================================================================
#  Pastas de discos de DADOS montados (sugestao de destino local)
# =====================================================================

SYSTEM_POINTS = {"/", "/boot", "/boot/efi", "/var", "/home", "/usr", "/tmp"}


def data_mounts() -> list[dict[str, Any]]:
    """Montagens de discos de dados (Armazenamento > Discos), com espaco livre."""
    out, seen = [], set()
    try:
        with open("/proc/1/mountinfo", encoding="utf-8") as fh:
            lines = fh.readlines()
    except OSError:
        return out
    for line in lines:
        parts = line.split()
        sep = parts.index("-")
        point, fstype, src = parts[4], parts[sep + 1], parts[sep + 2]
        if point in SYSTEM_POINTS or point in seen or point.startswith(("/proc", "/sys", "/dev", "/run")):
            continue
        if not (src.startswith("/dev/") or fstype == "zfs"):
            continue
        if fstype in ("swap", "squashfs", "iso9660", "vfat") and point.startswith("/boot"):
            continue
        seen.add(point)
        usage = disk_usage(point)
        out.append({"point": point, "fstype": fstype, "source": src, "usage": usage})
    return sorted(out, key=lambda m: m["point"])
