"""
NewOS Panel - modulo Processos (Sistema > Processos), o "btop" do painel.

    /sistema/processos               CPU por nucleo, memoria, disco, rede e
                                     a lista de processos ao vivo
    GET  /api/processos              leitura (a tela pede a cada 1-5 s)
    POST /api/processos/encerrar     {pid, start, signal: TERM|KILL}  (admin)
    POST /api/processos/reiniciar    {unit}                            (admin)

Tudo pelo helper newos-top (sudo): so ele ve o disco de cada processo e
so ele protege o que o painel precisa para continuar de pe.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules, terminal_routes

log = logging.getLogger("newos.panel.processes")
HELPER = "/usr/local/sbin/newos-top"


def helper(args: list[str], timeout: int = 30) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True,
                              timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "message": str(exc)}
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        return {"ok": False, "message": (lines[-1] if lines else "falhou").removeprefix("ERRO: ")}
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "message": "Resposta inválida do newos-top."}


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("processos") or {}).get("enabled"))

    def api_guard(request: Request, admin: bool = False) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        if not enabled():
            return None, JSONResponse({"ok": False, "message": "Módulo desligado."}, status_code=409)
        if admin and not terminal_routes.is_admin(user):
            return None, JSONResponse({"ok": False, "message": "Só administradores encerram processos."},
                                      status_code=403)
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "processos", what, auth.client_ip(request))
        log.info("Processos por %s: %s", user["username"], what)

    @app.get("/sistema/processos", response_class=HTMLResponse)
    async def processes_page(request: Request):
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Processos em Sistema > Módulos.")
            return redirect("/modulos")
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        return render(request, "processes.html", active="processos", admin=admin)

    @app.get("/api/processos")
    async def processes_api(request: Request, kernel: int = 0):
        _, bad = api_guard(request)
        if bad:
            return bad
        res = await run_in_threadpool(helper, ["snapshot", *(["--kernel"] if kernel else [])])
        return res if res.get("ok") else JSONResponse(res, status_code=500)

    @app.post("/api/processos/encerrar")
    async def processes_kill(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        try:
            b = await request.json()
            pid, start, sig = int(b.get("pid")), int(b.get("start")), str(b.get("signal", "TERM"))
        except (ValueError, TypeError):
            return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)
        if sig not in ("TERM", "KILL"):
            return JSONResponse({"ok": False, "message": "Sinal inválido."}, status_code=400)
        res = await run_in_threadpool(helper, ["kill", str(pid), str(start), sig])
        if not res.get("ok"):
            return JSONResponse(res, status_code=400)
        audit(request, user, f"{'kill -9' if sig == 'KILL' else 'encerrou'} PID {pid} ({b.get('name', '')})")
        return res

    @app.post("/api/processos/reiniciar")
    async def processes_restart(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        try:
            unit = str((await request.json()).get("unit", ""))
        except ValueError:
            unit = ""
        res = await run_in_threadpool(helper, ["restart", unit], 150)
        if not res.get("ok"):
            return JSONResponse(res, status_code=400)
        audit(request, user, f"reiniciou o serviço {unit}")
        return res
