/* =====================================================================
   NewOS Panel - Sistema > Terminal
   xterm.js no navegador; saida por Server-Sent Events, teclado por POST
   (agrupado a cada 15 ms para nao fazer uma requisicao por tecla).
   ===================================================================== */
(function () {
    "use strict";
    var box = document.getElementById("term");
    if (!box || !window.Terminal) return;
    var dot = document.getElementById("term-dot"), state = document.getElementById("term-state");
    var fsizeEl = document.getElementById("term-fsize"), themeSel = document.getElementById("term-theme");

    var THEMES = {
        escuro: { background: "#14161b", foreground: "#e6e6e6", cursor: "#00b8c0", selectionBackground: "#2c4a6b" },
        claro:  { background: "#fbfcfe", foreground: "#1b2333", cursor: "#0b3d91", selectionBackground: "#cfe0ff",
                  black: "#1b2333", white: "#8a93a6", brightWhite: "#5c667a", yellow: "#a35c00", brightYellow: "#8a4d00" },
        newio:  { background: "#0b1733", foreground: "#e8eefc", cursor: "#00b8c0", selectionBackground: "#1f3a7a",
                  blue: "#5fa8ff", cyan: "#00d1d9", green: "#3fd68f" }
    };
    function pref(k, d) { try { return localStorage.getItem("newos.term." + k) || d; } catch (e) { return d; } }
    function save(k, v) { try { localStorage.setItem("newos.term." + k, v); } catch (e) { /* ok */ } }

    var size = parseInt(pref("font", "14"), 10);
    var theme = pref("theme", "escuro");
    themeSel.value = theme;
    fsizeEl.textContent = size;

    var term = new window.Terminal({
        fontFamily: '"JetBrains Mono", "Fira Code", ui-monospace, Menlo, Consolas, monospace',
        fontSize: size, cursorBlink: true, scrollback: 5000, theme: THEMES[theme], allowProposedApi: false
    });
    var fit = new window.FitAddon.FitAddon();
    term.loadAddon(fit);
    term.open(box);
    fit.fit();
    box.classList.add("on");

    var tid = null, es = null, pending = "", timer = null;

    function setState(cls, text) {
        dot.className = "term-dot " + cls;
        state.textContent = text;
    }
    function post(path, body, type) {
        return fetch("/api/terminal/" + path, {
            method: "POST", credentials: "same-origin",
            headers: { "Content-Type": type || "application/json" }, body: body
        });
    }
    function flush() {
        timer = null;
        if (!tid || !pending) return;
        var data = pending; pending = "";
        post(tid + "/entrada", data, "application/octet-stream").then(function (r) {
            if (r.status === 401) { window.location = "/login?motivo=inatividade"; }
            else if (r.status === 403) { window.location.reload(); }
            else if (r.status === 410) { ended("sessão encerrada"); }
        });
    }
    term.onData(function (d) {
        pending += d;
        if (!timer) timer = setTimeout(flush, 15);
    });
    function sendSize() {
        if (tid) post(tid + "/tamanho", JSON.stringify({ cols: term.cols, rows: term.rows }));
    }
    term.onResize(function () { sendSize(); });
    window.addEventListener("resize", function () { fit.fit(); });

    function decode(b64) {
        var bin = atob(b64), out = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
        return out;
    }
    function ended(text) {
        if (es) { es.close(); es = null; }
        tid = null;
        setState("off", text);
        term.write("\r\n\x1b[90m[" + text + " — use Nova sessão]\x1b[0m\r\n");
    }
    function connect() {
        setState("wait", "conectando…");
        post("abrir", JSON.stringify({ cols: term.cols, rows: term.rows, app: document.getElementById("term-wrap").getAttribute("data-app") || "shell" }))
            .then(function (r) {
                if (r.status === 403) { window.location.reload(); return null; }
                return r.json();
            })
            .then(function (d) {
                if (!d) return;
                if (!d.ok) { setState("off", d.message || "não abriu"); term.write("\x1b[31m" + (d.message || "erro") + "\x1b[0m\r\n"); return; }
                tid = d.id;
                es = new EventSource("/api/terminal/" + tid + "/saida");
                es.onopen = function () { setState("on", "conectado"); term.focus(); };
                es.onmessage = function (ev) { term.write(decode(ev.data)); };
                es.addEventListener("fim", function () { ended("sessão encerrada"); });
                es.onerror = function () {
                    if (es && es.readyState === EventSource.CLOSED) ended("conexão perdida");
                    else setState("wait", "reconectando…");
                };
            })
            .catch(function () { setState("off", "sem conexão com o painel"); });
    }

    document.getElementById("term-new").addEventListener("click", function () {
        if (tid) post(tid + "/fechar", "{}");
        if (es) { es.close(); es = null; }
        tid = null;
        term.reset();
        connect();
    });
    document.querySelectorAll("[data-font]").forEach(function (b) {
        b.addEventListener("click", function () {
            size = Math.max(10, Math.min(28, size + parseInt(b.getAttribute("data-font"), 10)));
            term.options.fontSize = size;
            fsizeEl.textContent = size;
            save("font", size);
            fit.fit();
        });
    });
    themeSel.addEventListener("change", function () {
        theme = themeSel.value;
        term.options.theme = THEMES[theme];
        document.getElementById("term-wrap").setAttribute("data-theme", theme);
        save("theme", theme);
    });
    document.getElementById("term-wrap").setAttribute("data-theme", theme);
    window.addEventListener("beforeunload", function () {
        if (tid) navigator.sendBeacon("/api/terminal/" + tid + "/fechar", "{}");
    });
    connect();
})();
