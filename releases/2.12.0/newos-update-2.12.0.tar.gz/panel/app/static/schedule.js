/* =====================================================================
   NewOS Panel - Sistema > Agendamentos
   - avisos (falhou na ultima vez, timer sem proxima, cron parado)
   - linha do tempo das proximas 24 h, lista dos timers com ultima
     execucao/resultado/proxima, cron e o agendador do Bareos
   - detalhes com o journal, Executar agora, ligar/desligar, e tarefas
     novas (admin + senha) com previa das proximas execucoes
   GET /api/agendamentos a cada 30 s.
   ===================================================================== */
(function () {
    "use strict";
    var $ = function (s) { return document.querySelector(s); };
    var ADMIN = !!window.SC_ADMIN;
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    var data = null, filter = "*", sel = null, timer = null;
    var DAYS = { Mon: "segunda", Tue: "terça", Wed: "quarta", Thu: "quinta", Fri: "sexta", Sat: "sábado", Sun: "domingo" };

    function when(ts) {
        if (!ts) return "—";
        return new Date(ts * 1000).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    }
    function rel(ts, now) {
        if (!ts) return "";
        var d = ts - now, a = Math.abs(d), s;
        if (a < 60) s = "menos de 1 min";
        else if (a < 3600) s = Math.round(a / 60) + " min";
        else if (a < 86400) s = Math.floor(a / 3600) + " h" + (a % 3600 >= 60 ? " " + Math.round(a % 3600 / 60) + " min" : "");
        else s = Math.floor(a / 86400) + " d " + Math.floor(a % 86400 / 3600) + " h";
        return d >= 0 ? "em " + s : "há " + s;
    }
    function dur(s) { return s == null ? "" : s < 60 ? s + " s" : Math.floor(s / 60) + " min " + (s % 60) + " s"; }

    // OnCalendar -> texto para gente
    function human(cal) {
        if (!cal) return "—";
        if (/On\w+Sec=/.test(cal)) return cal.replace(/OnBootUSec=/, "após o boot: ").replace(/OnUnitActiveUSec=/, "depois a cada ").replace(/OnUnitActiveSec=/, "depois a cada ").replace(/OnBootSec=/, "após o boot: ");
        return cal.split(" | ").map(function (c) {
            var m;
            if ((m = c.match(/^\*-\*-\* (\d\d):(\d\d):00$/))) return "todo dia às " + m[1] + ":" + m[2];
            if ((m = c.match(/^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) \*-\*-\* (\d\d):(\d\d):00$/))) return (m[1] === "Sat" || m[1] === "Sun" ? "todo " : "toda ") + DAYS[m[1]] + " às " + m[2] + ":" + m[3];
            if ((m = c.match(/^Mon\.\.Fri \*-\*-\* (\d\d):(\d\d):00$/))) return "seg a sex às " + m[1] + ":" + m[2];
            if ((m = c.match(/^\*-\*-(\d\d) (\d\d):(\d\d):00$/))) return "todo dia " + (+m[1]) + " do mês às " + m[2] + ":" + m[3];
            if ((m = c.match(/^\*-\*-\* \*:(\d\d)\/(\d+):00$/))) return "a cada " + (+m[2]) + " min";
            if ((m = c.match(/^\*-\*-\* (\d\d)\/(\d+):(\d\d):00$/))) return "a cada " + (+m[2]) + " h";
            if (/^\*-\*-\* \*:00:00$/.test(c)) return "a cada hora";
            return c;
        }).join(" e ");
    }
    function badge(t) {
        var map = { ok: ["sc-ok", "bi-check-circle-fill", "deu certo"], falhou: ["sc-bad", "bi-x-octagon-fill", "falhou"],
                    rodando: ["sc-run", "bi-arrow-repeat", "rodando agora"], "nunca rodou": ["sc-never", "bi-dash-circle", "nunca rodou"] };
        var b = map[t.result] || map["nunca rodou"];
        return '<span class="sc-badge ' + b[0] + '"><i class="bi ' + b[1] + '"></i> ' + b[2] + (t.result === "falhou" && t.exit && t.exit !== "0" ? " (código " + esc(t.exit) + ")" : "") + "</span>";
    }
    function isBad(t) { return t.result === "falhou" || !!t.problem; }

    // ------------------------------------------------------------- render
    function render() {
        var d = data, now = d.now, T = d.timers;
        var on = T.filter(function (t) { return t.state === "ligado"; });
        var bad = T.filter(isBad);
        var in24 = T.filter(function (t) { return t.next && t.next - now <= 86400; });
        $("#sc-t-on").textContent = on.length;
        $("#sc-t-on-sub").textContent = T.length + " no total · " + (d.cron.jobs.length) + " no cron";
        $("#sc-t-bad").textContent = bad.length;
        $("#sc-t-bad").parentNode.parentNode.classList.toggle("sc-tile-bad", bad.length > 0);
        $("#sc-t-24").textContent = in24.length;
        $("#sc-t-tasks").textContent = T.filter(function (t) { return t.kind === "tarefa"; }).length;

        // avisos
        var al = bad.map(function (t) {
            var why = t.problem || ("falhou na última execução (" + when(t.last) + ")");
            return '<div class="alert alert-erro sc-alert"><span class="ico"><i class="bi bi-exclamation-octagon"></i></span><span><strong>' + esc(t.name) + ":</strong> " + esc(why) +
                ' <button type="button" class="btn btn-ghost btn-sm" data-open="' + esc(t.id) + '">ver detalhes</button></span></div>';
        });
        if (d.cron.active !== "active") al.unshift('<div class="alert alert-aviso"><span class="ico"><i class="bi bi-exclamation-triangle"></i></span><span>O serviço <strong>cron</strong> está ' + esc(d.cron.active || "parado") + ": o que está no cron não roda.</span></div>");
        $("#sc-alerts").innerHTML = al.join("");

        // linha do tempo 24 h
        var lanes = $("#sc-lanes"), axis = $("#sc-axis"), H = 24;
        var ax = "";
        for (var h = 0; h <= H; h += 3) {
            var dt = new Date((now + h * 3600) * 1000);
            ax += '<span style="left:' + (100 * h / H) + '%">' + (h === 0 ? "" : dt.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })) + "</span>";
        }
        axis.innerHTML = ax;
        var dots = in24.sort(function (a, b) { return a.next - b.next; }).map(function (t, i) {
            var x = 100 * (t.next - now) / 86400;
            return '<button type="button" class="sc-dot ' + t.kind + (isBad(t) ? " bad" : "") + '" style="left:' + x + "%;top:" + (8 + (i % 4) * 22) + "px;--d:" + (i * 40) + 'ms" data-open="' + esc(t.id) + '" title="' + esc(t.name + " · " + when(t.next) + " (" + rel(t.next, now) + ")") + '"><i></i><span>' + esc(t.name) + "</span></button>";
        });
        if (d.bareos) d.bareos.scheduled.forEach(function (j, i) {
            dots.push('<span class="sc-dot bareos" style="left:98%;top:' + (8 + ((in24.length + i) % 4) * 22) + 'px" title="Bareos: ' + esc(j.job + " " + j.when) + '"><i></i><span>' + esc(j.job) + "</span></span>");
        });
        lanes.innerHTML = dots.join("") || '<p class="nic-sub sc-empty">Nada previsto para as próximas 24 horas.</p>';

        // tabela
        var rows = T.filter(function (t) { return filter === "*" ? true : filter === "bad" ? isBad(t) : t.kind === filter; });
        $("#sc-body").innerHTML = rows.map(function (t) {
            var kind = { tarefa: "tarefa", newos: "NewOS", sistema: "sistema" }[t.kind];
            return '<tr data-open="' + esc(t.id) + '" class="' + (isBad(t) ? "sc-row-bad" : "") + '">' +
                '<td><b>' + esc(t.name) + '</b> <span class="sc-kind ' + t.kind + '">' + kind + '</span><span class="mono nic-sub sc-unit">' + esc(t.id) + "</span></td>" +
                "<td>" + esc(human(t.when)) + "</td>" +
                "<td>" + (t.next ? "<b>" + rel(t.next, now) + '</b><span class="nic-sub sc-unit">' + when(t.next) + "</span>" : '<span class="zbx-bad">—</span>') + "</td>" +
                "<td>" + badge(t) + (t.last ? '<span class="nic-sub sc-unit">' + rel(t.last, now) + (t.duration ? " · " + dur(t.duration) : "") + "</span>" : "") + "</td>" +
                '<td><span class="sc-state ' + (t.state === "ligado" ? "on" : "off") + '">' + t.state + "</span></td>" +
                '<td class="n"><i class="bi bi-chevron-right pc-open"></i></td></tr>';
        }).join("") || '<tr><td colspan="6" class="empty">Nada aqui.</td></tr>';

        // cron
        $("#sc-cron-state").innerHTML = d.cron.active === "active" ? '<span class="sys-ok"><i class="bi bi-check-circle"></i> serviço cron rodando</span>' : '<span class="zbx-bad">cron ' + esc(d.cron.active) + "</span>";
        $("#sc-cron").innerHTML = d.cron.jobs.map(function (j) {
            return '<tr><td class="sc-when-c"><b>' + esc(j.when) + '</b><span class="mono nic-sub sc-unit">' + esc(j.schedule) + " · " + esc(j.user) + '</span></td><td class="sc-cmd-c"><span class="mono sc-cmd" title="' + esc(j.command) + '">' + esc(j.command) + '</span><span class="nic-sub sc-unit">' + esc(j.file) + '</span></td><td class="sc-last-c">' + (j.last ? rel(j.last, now) : '<span class="nic-sub">—</span>') + "</td></tr>";
        }).join("") || '<tr><td colspan="3" class="empty">Nada no cron.</td></tr>';
        var f = d.cron.folders || {};
        $("#sc-folders").innerHTML = ["daily", "weekly", "monthly", "hourly"].filter(function (k) { return (f[k] || []).length; }).map(function (k) {
            return "<div><b>cron." + k + ":</b> " + f[k].map(esc).join(", ") + "</div>";
        }).join("");

        // bareos: so aparece com o modulo Backup ligado (sem ele o cron ocupa a largura toda)
        $("#bareos").hidden = !d.bareos;
        $("#sc-bottom").classList.toggle("solo", !d.bareos);
        if (d.bareos) {
            $("#sc-bareos-state").innerHTML = d.bareos.scheduled.length + " job(s) agendado(s) · <a href='/backup/rotinas'>rotinas</a>";
            var s = d.bareos.scheduled.map(function (j) { return "<tr><td>" + esc(j.when) + "</td><td>" + esc(j.job) + "</td><td>" + esc(j.level) + "</td></tr>"; }).join("");
            var r = d.bareos.terminated.map(function (j) {
                var ok = /^OK/i.test(j.status);
                return "<tr><td>" + esc(j.when) + "</td><td>" + esc(j.job) + '</td><td><span class="sc-badge ' + (ok ? "sc-ok" : "sc-bad") + '">' + esc(j.status) + "</span></td></tr>";
            }).join("");
            $("#sc-bareos").innerHTML = '<h3 class="bk-sub">Próximos</h3><table class="data"><thead><tr><th>Quando</th><th>Job</th><th>Nível</th></tr></thead><tbody>' +
                (s || '<tr><td colspan="3" class="empty">Nenhum job agendado no Bareos: confira as rotinas (dias e horário).</td></tr>') + "</tbody></table>" +
                '<h3 class="bk-sub">Últimos que terminaram</h3><table class="data"><thead><tr><th>Quando</th><th>Job</th><th>Resultado</th></tr></thead><tbody>' +
                (r || '<tr><td colspan="3" class="empty">Nenhum ainda.</td></tr>') + "</tbody></table>";
        }
        if (sel) drawer(sel, true);
    }

    // ------------------------------------------------------------- detalhes
    function find(id) { return data && data.timers.filter(function (t) { return t.id === id; })[0]; }
    function drawer(id, refresh) {
        var t = find(id); if (!t) return;
        sel = id;
        $("#sc-d-name").textContent = t.name;
        $("#sc-d-unit").textContent = t.id + " → " + t.service;
        $("#sc-d-stats").innerHTML = [["Quando", human(t.when)], ["Próxima", t.next ? when(t.next) : "—"], ["Última", t.last ? when(t.last) : "nunca"], ["Duração", dur(t.duration) || "—"]]
            .map(function (s) { return "<div><small>" + s[0] + "</small><b>" + esc(s[1]) + "</b></div>"; }).join("");
        $("#sc-d-extra").innerHTML = '<p>' + badge(t) + ' <span class="sc-state ' + (t.state === "ligado" ? "on" : "off") + '">' + t.state + "</span></p>" +
            (t.problem ? '<div class="alert alert-erro"><span class="ico"><i class="bi bi-exclamation-octagon"></i></span><span>' + esc(t.problem) + "</span></div>" : "") +
            (t.command ? '<pre class="mono pc-d-cmd">' + esc(t.command) + "</pre>" : "") +
            '<p class="nic-sub">' + esc(t.description) + (t.where ? ' · <a href="' + esc(t.where) + '">onde se ajusta</a>' : "") + "</p>";
        if (!refresh) {
            var a = "";
            if (ADMIN) {
                a += '<button type="button" class="btn" data-act="run"><i class="bi bi-play-circle"></i> Executar agora</button>';
                if (t.toggle && t.id !== "newos-sysbackup.timer") a += '<button type="button" class="btn btn-ghost" data-act="toggle"><i class="bi bi-power"></i> ' + (t.state === "ligado" ? "Desligar" : "Ligar") + "</button>";
                if (t.editable) a += '<button type="button" class="btn btn-ghost" data-act="edit"><i class="bi bi-pencil"></i> Editar</button><button type="button" class="btn btn-danger" data-act="del"><i class="bi bi-trash"></i> Apagar a tarefa</button>';
            } else a = '<p class="nic-sub"><i class="bi bi-lock"></i> Executar e editar: só administradores.</p>';
            $("#sc-d-actions").innerHTML = a;
            $("#sc-d-out").hidden = true;
            $("#sc-drawer").classList.add("open"); $("#sc-shade").classList.add("on");
        }
        fetch("/api/agendamentos/log/" + encodeURIComponent(t.id)).then(function (r) { return r.json(); }).then(function (l) {
            var pre = $("#sc-d-log");
            pre.textContent = (l.lines || []).join("\n") || "Sem registros no journal.";
            if (!refresh) pre.scrollTop = pre.scrollHeight;
        });
    }
    function close() { sel = null; $("#sc-drawer").classList.remove("open"); $("#sc-shade").classList.remove("on"); }
    function post(url, body) {
        return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
            .then(function (r) { return r.json(); }).catch(function () { return { ok: false, message: "Sem resposta do painel." }; });
    }
    function out(d) { var o = $("#sc-d-out"); o.hidden = false; o.className = "lg-result " + (d.ok ? "lg-good" : "lg-bad"); o.textContent = d.message || (d.ok ? "Feito." : "Falhou."); }

    // ------------------------------------------------------------- tarefa (criar/editar)
    var form = $("#sc-form");
    function calFromForm() {
        var f = form, k = f.kind.value, t = (f.time.value || "02:30") + ":00", n = Math.max(1, +f.every.value || 1);
        if (k === "daily") return "*-*-* " + t;
        if (k === "weekly") return f.dow.value + " *-*-* " + t;
        if (k === "monthly") return "*-*-" + String(Math.min(28, Math.max(1, +f.dom.value || 1))).padStart(2, "0") + " " + t;
        if (k === "minutes") return "*-*-* *:00/" + n + ":00";
        if (k === "hours") return "*-*-* 00/" + n + ":00:00";
        return f.raw.value.trim();
    }
    function showKind() {
        form.querySelectorAll("[data-k]").forEach(function (el) { el.hidden = el.dataset.k.split(" ").indexOf(form.kind.value) < 0; });
        preview();
    }
    var pv;
    function preview() {
        clearTimeout(pv);
        pv = setTimeout(function () {
            var c = calFromForm(), box = $("#sc-preview");
            if (!c) { box.textContent = "—"; return; }
            fetch("/api/agendamentos/calendario?q=" + encodeURIComponent(c)).then(function (r) { return r.json(); }).then(function (d) {
                box.className = "sc-preview " + (d.ok ? "" : "bad");
                box.innerHTML = d.ok ? "<b>" + esc(human(d.normalized)) + '</b> <span class="mono">(' + esc(d.normalized) + ")</span><br>Próximas: " + d.next.slice(0, 4).map(function (n) { return esc(n.replace(/ -0\d$/, "")); }).join(" · ") : esc(d.message);
            });
        }, 250);
    }
    function openForm(t) {
        if (!form) return;
        form.reset(); form.id.value = ""; $("#sc-f-out").hidden = true;
        $("#sc-f-title").textContent = t ? "Editar tarefa" : "Nova tarefa agendada";
        if (t) {
            form.id.value = t.id.replace(/^newos-tarefa-/, "").replace(/\.timer$/, "");
            form.name.value = t.name; form.command.value = t.command;
            form.kind.value = "raw"; form.raw.value = t.when;
        }
        showKind();
        var m = $("#sc-modal"); m.hidden = false; requestAnimationFrame(function () { m.classList.add("on"); }); form.name.focus();
    }
    function closeForm() { var m = $("#sc-modal"); m.classList.remove("on"); setTimeout(function () { m.hidden = true; }, 180); }
    if (form) {
        form.addEventListener("input", function (e) { if (e.target.name !== "password" && e.target.name !== "code" && e.target.name !== "name" && e.target.name !== "command") preview(); });
        form.kind.addEventListener("change", showKind);
        $("#sc-f-cancel").addEventListener("click", closeForm);
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var o = $("#sc-f-out"), btn = form.querySelector("[type=submit]");
            btn.disabled = true;
            post("/api/agendamentos/tarefa", { id: form.id.value || null, name: form.name.value, command: form.command.value,
                calendar: calFromForm(), password: form.password.value, code: form.code ? form.code.value : "" })
                .then(function (d) {
                    o.hidden = false; o.className = "lg-result " + (d.ok ? "lg-good" : "lg-bad"); o.textContent = d.message || "Falhou.";
                    if (d.ok) { setTimeout(function () { closeForm(); load(); }, 900); }
                }).finally(function () { btn.disabled = false; form.password.value = ""; });
        });
        $("#sc-new").addEventListener("click", function () { openForm(null); });
    }

    // ------------------------------------------------------------- eventos
    document.addEventListener("click", function (e) {
        var o = e.target.closest && e.target.closest("[data-open]");
        if (o) { drawer(o.dataset.open, false); return; }
        var f = e.target.closest && e.target.closest("#sc-filter button");
        if (f) { filter = f.dataset.f; document.querySelectorAll("#sc-filter button").forEach(function (b) { b.classList.toggle("on", b === f); }); render(); }
    });
    $("#sc-d-close").addEventListener("click", close);
    $("#sc-shade").addEventListener("click", close);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") { if ($("#sc-modal") && !$("#sc-modal").hidden) closeForm(); else close(); } });
    $("#sc-d-actions").addEventListener("click", function (e) {
        var b = e.target.closest("[data-act]"); if (!b || !sel) return;
        var t = find(sel), act = b.dataset.act;
        if (act === "run") post("/api/agendamentos/executar", { unit: t.id }).then(function (d) { out(d); setTimeout(load, 3000); });
        if (act === "toggle") post("/api/agendamentos/ligar", { unit: t.id, on: t.state !== "ligado" }).then(function (d) { out(d); load(); });
        if (act === "edit") { close(); openForm(t); }
        if (act === "del") {
            var pw = prompt("Apagar a tarefa '" + t.name + "'? Digite sua senha para confirmar:");
            if (!pw) return;
            var code = window.SC_CODE ? prompt("Código do MFA:") : "";
            post("/api/agendamentos/apagar", { id: t.id.replace(/^newos-tarefa-/, "").replace(/\.timer$/, ""), password: pw, code: code || "" })
                .then(function (d) { out(d); if (d.ok) { close(); load(); } });
        }
    });

    function load() {
        clearTimeout(timer);
        fetch("/api/agendamentos", { credentials: "same-origin" })
            .then(function (r) { if (r.status === 401) location.href = "/login"; return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message);
                data = d; render();
                $("#sc-clock").textContent = "atualizado " + new Date().toLocaleTimeString("pt-BR");
                $("#sc-dot").classList.remove("off");
            })
            .catch(function () { $("#sc-clock").textContent = "sem resposta"; $("#sc-dot").classList.add("off"); })
            .finally(function () { timer = setTimeout(load, 30000); });
    }
    load();
})();
