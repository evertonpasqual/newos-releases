/* =====================================================================
   NewOS Panel - contagem da faixa "alteracao de rede pendente"
   ---------------------------------------------------------------------
   Conta os segundos na tela e, ao chegar a zero, consulta o servidor:
   se o rollback ja aconteceu, recarrega a pagina para mostrar a
   configuracao que voltou a valer.
   ===================================================================== */
(function () {
    "use strict";

    var bar = document.getElementById("netPending");
    if (!bar) return;
    var label = document.getElementById("netPendingSecs");
    var left = parseInt(bar.getAttribute("data-remaining"), 10) || 0;

    var timer = setInterval(function () {
        left = Math.max(0, left - 1);
        label.textContent = left;
        if (left > 0) return;
        clearInterval(timer);
        setTimeout(function () {
            fetch("/api/network/pending", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (p) { if (!p.pending) window.location.reload(); })
                .catch(function () { /* sem acesso: o rollback esta acontecendo */ });
        }, 5000);
    }, 1000);
})();

/* Mesma contagem para a faixa "firewall alterado" */
(function () {
    "use strict";
    var bar = document.getElementById("fwPending");
    if (!bar) return;
    var label = document.getElementById("fwPendingSecs");
    var left = parseInt(bar.getAttribute("data-remaining"), 10) || 0;
    var timer = setInterval(function () {
        left = Math.max(0, left - 1);
        label.textContent = left;
        if (left > 0) return;
        clearInterval(timer);
        setTimeout(function () {
            fetch("/api/firewall/pending", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (p) { if (!p.pending) window.location.reload(); })
                .catch(function () { /* sem acesso: a volta automatica esta acontecendo */ });
        }, 5000);
    }, 1000);
})();
