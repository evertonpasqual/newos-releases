/* =====================================================================
   NewOS Panel - telas de Monitoramento (Zabbix)
   ---------------------------------------------------------------------
   - "Testar conexão": este servidor alcança o(s) Server(s)?
   - log do serviço, carregado na abertura e sob demanda
   ===================================================================== */
(function () {
    "use strict";

    function esc(t) {
        var d = document.createElement("div");
        d.textContent = t == null ? "" : String(t);
        return d.innerHTML;
    }
    function getJSON(url) {
        return fetch(url, { credentials: "same-origin" }).then(function (r) { return r.json(); });
    }

    /* ---------------- teste de conexao ------------------------------ */
    document.querySelectorAll("[data-zbx-test]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var card = document.getElementById("zbx-test");
            var list = card.querySelector(".zbx-results");
            card.hidden = false;
            list.innerHTML = '<li class="zbx-r run"><i class="bi bi-arrow-repeat"></i> testando…</li>';
            btn.disabled = true;
            getJSON("/api/zabbix/" + btn.getAttribute("data-zbx-test") + "/teste")
                .then(function (d) {
                    if (!d.ok) { list.innerHTML = '<li class="zbx-r fail">' + esc(d.message || "falhou") + "</li>"; return; }
                    if (!d.results.length) { list.innerHTML = '<li class="zbx-r skip">Nenhum Server configurado ainda.</li>'; return; }
                    list.innerHTML = d.results.map(function (r, i) {
                        var ico = r.state === "ok" ? "bi-check-circle-fill" : (r.state === "skip" ? "bi-dash-circle" : "bi-x-circle-fill");
                        return '<li class="zbx-r ' + r.state + '" style="--i:' + i + '"><i class="bi ' + ico + '"></i> <span class="mono">' +
                            esc(r.target) + "</span> " + esc(r.message) + "</li>";
                    }).join("");
                })
                .catch(function (e) { list.innerHTML = '<li class="zbx-r fail">' + esc(e.message) + "</li>"; })
                .then(function () { btn.disabled = false; });
        });
    });

    /* ---------------- log ------------------------------------------- */
    function loadLog(name) {
        var box = document.getElementById("zbx-log");
        if (!box) return;
        getJSON("/api/zabbix/" + name + "/log").then(function (d) {
            if (!d.ok || !d.lines.length) { box.innerHTML = '<div class="empty">' + esc(d.message || "Sem linhas no log.") + "</div>"; return; }
            box.innerHTML = d.lines.map(function (l) {
                var cls = /error|fail|cannot|denied/i.test(l) ? "err" : (/warn/i.test(l) ? "warn" : "");
                return '<div class="bk-log-line ' + cls + '"><span class="bk-log-text">' + esc(l) + "</span></div>";
            }).join("");
            box.scrollTop = box.scrollHeight;
        }).catch(function () { box.innerHTML = '<div class="empty">Não foi possível ler o log.</div>'; });
    }
    document.querySelectorAll("[data-zbx-autoload]").forEach(function (el) { loadLog(el.getAttribute("data-zbx-autoload")); });
    document.querySelectorAll("[data-zbx-log]").forEach(function (b) {
        b.addEventListener("click", function () { loadLog(b.getAttribute("data-zbx-log")); });
    });
})();
