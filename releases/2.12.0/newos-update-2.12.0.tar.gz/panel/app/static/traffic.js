/* =====================================================================
   NewOS Panel - Trafego ao vivo
   - cartoes por interface com grafico de 60 s (canvas) e numeros animados
   - quem fala com o servidor / servicos: barras que crescem e reordenam
   - maiores conexoes
   Atualiza a cada 2 s (GET /api/trafego); "Pausar" congela a tela.
   ===================================================================== */
(function () {
    "use strict";
    function $(s) { return document.querySelector(s); }
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function bits(b) {
        if (b == null) return "—";
        var u = ["b/s", "Kb/s", "Mb/s", "Gb/s"], i = 0;
        while (b >= 1000 && i < u.length - 1) { b /= 1000; i++; }
        return b.toLocaleString("pt-BR", { maximumFractionDigits: b < 10 ? 2 : b < 100 ? 1 : 0 }) + " " + u[i];
    }
    function bytesRate(b) { return bits(b * 8); }
    function css(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }

    var HIST = {}, paused = false, dirFilter = "*", last = null;
    var DIRS = { "in": ["entrando", "bi-box-arrow-in-down-right"], out: ["saindo", "bi-box-arrow-up-right"], fwd: ["passando", "bi-arrow-left-right"], mix: ["nos dois", "bi-arrow-down-up"] };

    function spark(canvas, rx, tx, max) {
        var ctx = canvas.getContext("2d"), dpr = window.devicePixelRatio || 1, W = canvas.clientWidth, H = canvas.clientHeight;
        if (!W) return;
        if (canvas.width !== W * dpr) { canvas.width = W * dpr; canvas.height = H * dpr; }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
        var navy = document.documentElement.classList.contains("dark-mode") ? "#8aa0e6" : (css("--brand-navy") || "#183b90");
        var teal = css("--accent-teal") || "#00b8c0";
        [[rx, navy], [tx, teal]].forEach(function (s) {
            var d = s[0]; if (d.length < 2) return;
            ctx.beginPath();
            d.forEach(function (v, i) { var x = W - (d.length - 1 - i) * (W / 29), y = H - 2 - (H - 6) * v / max; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
            ctx.strokeStyle = s[1]; ctx.lineWidth = 2; ctx.lineJoin = "round"; ctx.stroke();
            ctx.lineTo(W, H); ctx.lineTo(W - (d.length - 1) * (W / 29), H); ctx.closePath();
            var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, s[1] + "44"); g.addColorStop(1, s[1] + "00");
            ctx.fillStyle = g; ctx.fill();
        });
    }

    function renderIfaces(list) {
        var box = $("#tr-ifaces");
        list.forEach(function (f, i) {
            var h = HIST[f.name] = HIST[f.name] || { rx: [], tx: [] };
            h.rx.push(f.rx_bps); h.tx.push(f.tx_bps);
            if (h.rx.length > 30) { h.rx.shift(); h.tx.shift(); }
            var el = box.querySelector('[data-if="' + f.name + '"]');
            if (!el) {
                el = document.createElement("div");
                el.className = "card tr-if reveal"; el.style.setProperty("--i", i + 1);
                el.setAttribute("data-if", f.name);
                el.innerHTML = '<div class="tr-if-head"><span class="tr-if-name mono"></span><span class="tr-if-kind nic-sub"></span><span class="tr-if-state"></span></div>' +
                    '<div class="tr-if-nums"><div><i class="bi bi-arrow-down"></i><strong data-rx>—</strong><small data-rxp></small></div>' +
                    '<div><i class="bi bi-arrow-up"></i><strong data-tx>—</strong><small data-txp></small></div></div>' +
                    '<canvas class="tr-spark"></canvas><div class="tr-if-meter"><span data-m></span></div><div class="tr-if-foot nic-sub" data-foot></div>';
                box.appendChild(el);
            }
            el.querySelector(".tr-if-name").textContent = f.name;
            el.querySelector(".tr-if-kind").textContent = f.kind + (f.speed ? " · " + (f.speed >= 1000 ? f.speed / 1000 + " Gb/s" : f.speed + " Mb/s") : "");
            el.querySelector(".tr-if-state").innerHTML = f.state === "up" ? '<span class="zbx-dot on"></span>' : '<span class="zbx-dot"></span>';
            el.classList.toggle("down", f.state !== "up");
            el.querySelector("[data-rx]").textContent = bits(f.rx_bps);
            el.querySelector("[data-tx]").textContent = bits(f.tx_bps);
            el.querySelector("[data-rxp]").textContent = f.rx_pps.toLocaleString("pt-BR") + " pkt/s";
            el.querySelector("[data-txp]").textContent = f.tx_pps.toLocaleString("pt-BR") + " pkt/s";
            var cap = f.speed ? f.speed * 1e6 : 0, use = cap ? Math.min(100, Math.max(f.rx_bps, f.tx_bps) / cap * 100) : 0;
            var m = el.querySelector("[data-m]"); m.style.width = use.toFixed(1) + "%";
            m.className = use > 80 ? "hot" : use > 50 ? "warm" : "";
            el.querySelector("[data-foot]").textContent = (cap ? "uso do link " + use.toFixed(1).replace(".", ",") + "% · " : "") +
                "total ↓ " + (f.rx_total / 1073741824).toFixed(2).replace(".", ",") + " GB ↑ " + (f.tx_total / 1073741824).toFixed(2).replace(".", ",") + " GB" +
                (f.errors ? " · " + f.errors + " erros" : "");
            var max = Math.max(1, Math.max.apply(null, h.rx.concat(h.tx))) * 1.15;
            spark(el.querySelector("canvas"), h.rx, h.tx, max);
        });
    }

    function rows(box, items, key, html) {
        var max = 1;
        items.forEach(function (a) { max = Math.max(max, a.rx + a.tx); });
        var seen = {};
        items.forEach(function (a, i) {
            var k = key(a); seen[k] = 1;
            var el = box.querySelector('[data-k="' + CSS.escape(k) + '"]');
            if (!el) {
                el = document.createElement("div"); el.className = "tr-row tr-new"; el.setAttribute("data-k", k);
                el.innerHTML = '<div class="tr-m"></div><div class="tr-bar"><span class="rx"></span><span class="tx"></span></div>';
                box.appendChild(el);
                (function (e) { setTimeout(function () { e.classList.remove("tr-new"); }, 900); })(el);
            }
            el.querySelector(".tr-m").innerHTML = html(a);
            el.querySelector(".tr-bar .rx").style.width = (a.rx / max * 100).toFixed(1) + "%";
            el.querySelector(".tr-bar .tx").style.width = (a.tx / max * 100).toFixed(1) + "%";
            el.style.order = i;
        });
        Array.prototype.slice.call(box.querySelectorAll(".tr-row")).forEach(function (el) { if (!seen[el.getAttribute("data-k")]) el.remove(); });
        var empty = box.querySelector(".empty");
        if (items.length && empty) empty.remove();
        if (!items.length && !empty) box.innerHTML = '<div class="empty">Nada no momento.</div>';
    }

    function render(d) {
        last = d;
        renderIfaces(d.ifaces || []);
        var rx = 0, tx = 0;
        (d.ifaces || []).forEach(function (f) { if (f.kind === "física" || f.kind === "bond") { rx += f.rx_bps; tx += f.tx_bps; } });
        if (!rx && !tx) (d.ifaces || []).forEach(function (f) { rx += f.rx_bps; tx += f.tx_bps; });
        $("#tr-rx").textContent = bits(rx); $("#tr-tx").textContent = bits(tx);
        var fl = d.flows || {};
        if (!fl.ok) { $("#tr-remotes").innerHTML = '<div class="empty">' + esc(fl.message || "Sem dados de conexões.") + "</div>"; return; }
        var rem = (fl.remotes || []).filter(function (a) { return dirFilter === "*" || a.dir === dirFilter || (a.dir === "mix" && dirFilter !== "fwd"); });
        $("#tr-peers").textContent = (fl.remotes || []).length;
        $("#tr-conns").textContent = (fl.total || 0).toLocaleString("pt-BR");
        var bp = fl.by_proto || {};
        $("#tr-conns-sub").textContent = Object.keys(bp).map(function (k) { return k.toUpperCase() + " " + bp[k]; }).join(" · ") || "—";
        rows($("#tr-remotes"), rem.slice(0, 15), function (a) { return a.ip; }, function (a) {
            var dd = DIRS[a.dir] || DIRS.mix;
            return '<div class="tr-row-main"><span class="tr-dir d-' + a.dir + '" title="' + dd[0] + '"><i class="bi ' + dd[1] + '"></i></span>' +
                '<span class="mono tr-ip">' + esc(a.ip) + '</span><span class="nic-sub">' + a.conns + " conex. · " + esc((a.ports || []).join(", ")) + "</span>" +
                '<span class="tr-rates"><span class="rx">↓ ' + bytesRate(a.rx) + '</span><span class="tx">↑ ' + bytesRate(a.tx) + "</span></span></div>";
        });
        rows($("#tr-services"), (fl.services || []).slice(0, 12), function (s) { return s.dir + s.port + s.proto; }, function (s) {
            return '<div class="tr-row-main"><span class="tr-dir d-' + s.dir + '"><i class="bi ' + DIRS[s.dir][1] + '"></i></span>' +
                '<span class="mono tr-ip">' + s.port + "/" + esc(s.proto) + "</span>" +
                '<span class="nic-sub">' + esc(s.name || "—") + " · " + s.peers + " IP(s) · " + s.conns + " conex.</span>" +
                '<span class="tr-rates"><span class="rx">↓ ' + bytesRate(s.rx) + '</span><span class="tx">↑ ' + bytesRate(s.tx) + "</span></span></div>";
        });
        $("#tr-flows").innerHTML = (fl.flows || []).slice(0, 20).map(function (f) {
            var dd = DIRS[f.dir] || DIRS.mix;
            return '<tr><td><span class="tr-dir d-' + f.dir + '"><i class="bi ' + dd[1] + '"></i></span> ' + dd[0] + "</td>" +
                '<td class="mono">' + esc(f.src) + (f.sport ? ":" + esc(f.sport) : "") + '</td><td class="mono">' + esc(f.dst) + (f.dport ? ":" + esc(f.dport) : "") + "</td>" +
                "<td>" + esc(f.proto) + (f.svc ? ' <span class="nic-sub">' + esc(f.svc) + "</span>" : "") + '</td><td class="nic-sub">' + esc(f.state || "") + "</td>" +
                '<td class="n">' + (f.rx ? bytesRate(f.rx) : '<span class="nic-sub">—</span>') + '</td><td class="n">' + (f.tx ? bytesRate(f.tx) : '<span class="nic-sub">—</span>') + "</td></tr>";
        }).join("") || '<tr><td colspan="7" class="nic-sub">Nenhuma conexão.</td></tr>';
        $("#tr-flows-sub").textContent = fl.max ? "tabela do kernel: " + (fl.total || 0).toLocaleString("pt-BR") + " de " + fl.max.toLocaleString("pt-BR") : "";
        $("#tr-clock").textContent = "ao vivo · " + new Date().toLocaleTimeString("pt-BR");
    }

    function tick() {
        if (paused) { setTimeout(tick, 2000); return; }
        fetch("/api/trafego", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { if (r.status === 401) { location.href = "/login"; throw 0; } return r.json(); })
            .then(function (d) { if (d.ok) render(d); })
            .catch(function () {})
            .then(function () { setTimeout(tick, 2000); });
    }
    $("#tr-pause").addEventListener("click", function () {
        paused = !paused;
        this.innerHTML = paused ? '<i class="bi bi-play-fill"></i> Continuar' : '<i class="bi bi-pause-fill"></i> Pausar';
        document.querySelector(".tr-live").classList.toggle("paused", paused);
    });
    $("#tr-dir").addEventListener("click", function (e) {
        var b = e.target.closest("[data-d]"); if (!b) return;
        dirFilter = b.getAttribute("data-d");
        Array.prototype.slice.call(this.querySelectorAll("button")).forEach(function (x) { x.classList.toggle("on", x === b); });
        if (last) render(last);
    });
    tick();
})();
