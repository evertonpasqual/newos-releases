/* =====================================================================
   NewOS Panel - telas de Backup
   ---------------------------------------------------------------------
   - campos que aparecem conforme a opcao escolhida (data-when)
   - "marcar todos" na navegacao dos arquivos
   - visao geral: tabela "Rodando agora" ao vivo
   - job em execucao: numeros ao vivo e recarrega ao terminar
   - download de restauracao: acompanha ate o ZIP ficar pronto
   ===================================================================== */
(function () {
    "use strict";

    function fmtBytes(n) {
        var u = ["B", "KiB", "MiB", "GiB", "TiB"], i = 0;
        n = Number(n) || 0;
        while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
        return (i ? n.toLocaleString("pt-BR", { maximumFractionDigits: 1, minimumFractionDigits: 1 }) : n) + " " + u[i];
    }
    function fmtDur(s) {
        s = Math.floor(Number(s) || 0);
        var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
        if (h) return h + " h " + String(m).padStart(2, "0") + " min";
        if (m) return m + " min " + String(r).padStart(2, "0") + " s";
        return r + " s";
    }
    function esc(t) {
        var d = document.createElement("div");
        d.textContent = t == null ? "" : String(t);
        return d.innerHTML;
    }

    /* ---------------- campos condicionais ------------------------------ */
    // data-when="campo=valor" ou "campo!=valor" (radio do mesmo formulario).
    document.querySelectorAll("[data-when]").forEach(function (el) {
        var form = el.closest("form");
        var m = el.getAttribute("data-when").match(/^([\w-]+)(!?=)(.*)$/);
        if (!form || !m) return;
        function sync() {
            var cur = form.querySelector('input[name="' + m[1] + '"]:checked');
            var val = cur ? cur.value : "";
            var show = m[2] === "=" ? val === m[3] : val !== m[3];
            el.hidden = !show;
            el.querySelectorAll("input, select, textarea").forEach(function (i) { i.disabled = !show; });
        }
        form.querySelectorAll('input[name="' + m[1] + '"]').forEach(function (r) {
            r.addEventListener("change", sync);
        });
        sync();
    });

    /* ---------------- marcar todos ------------------------------------- */
    document.querySelectorAll("[data-check-all]").forEach(function (all) {
        all.addEventListener("change", function () {
            all.closest("table").querySelectorAll('tbody input[type=checkbox]:not(:disabled)')
                .forEach(function (c) { c.checked = all.checked; });
        });
    });

    /* ---------------- link que abre um bloco recolhivel ---------------- */
    document.querySelectorAll("[data-open-fold]").forEach(function (a) {
        a.addEventListener("click", function () {
            var f = document.getElementById(a.getAttribute("data-open-fold"));
            if (f && !f.classList.contains("open")) f.querySelector(".fold-head").click();
        });
    });
    if (location.hash === "#nova") {
        var nova = document.getElementById("nova");
        if (nova && !nova.classList.contains("open")) nova.querySelector(".fold-head").click();
    }

    /* ---------------- visao geral: rodando agora ----------------------- */
    var runTable = document.getElementById("bk-running");
    if (runTable) {
        setInterval(function () {
            fetch("/api/backup/running", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (!d.ok) return;
                    var body = runTable.querySelector("tbody");
                    if (!d.jobs.length) {
                        body.innerHTML = '<tr class="bk-none"><td colspan="6" class="empty">Nada rodando agora.</td></tr>';
                    } else {
                        body.innerHTML = d.jobs.map(function (j) {
                            return "<tr><td><a class=\"strong\" href=\"/backup/historico/" + j.jobid + "\">" + esc(j.name) +
                                "</a></td><td class=\"mono\">" + esc(j.client) + "</td><td>" + esc(j.level) +
                                "</td><td>" + j.files + "</td><td>" + fmtBytes(j.bytes) + "</td><td>" + fmtDur(j.duration) + "</td></tr>";
                        }).join("");
                    }
                    var c = document.getElementById("bk-running-count");
                    if (c) c.textContent = d.jobs.length;
                })
                .catch(function () { /* proxima rodada */ });
        }, 5000);
    }

    /* ---------------- job em execucao --------------------------------- */
    var jobBox = document.getElementById("bk-job");
    if (jobBox && jobBox.getAttribute("data-running") === "1") {
        var jobid = jobBox.getAttribute("data-jobid");
        var timer = setInterval(function () {
            fetch("/api/backup/job/" + jobid, { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (!d.ok || !d.job) return;
                    var set = function (k, v) {
                        var el = jobBox.querySelector('[data-live="' + k + '"]');
                        if (el) el.textContent = v;
                    };
                    set("files", d.job.files);
                    set("bytes", fmtBytes(d.job.bytes));
                    set("duration", fmtDur(d.job.duration));
                    if (!d.job.running) { clearInterval(timer); location.reload(); }
                })
                .catch(function () { /* proxima rodada */ });
        }, 3000);
    }

    /* ---------------- download da restauracao ------------------------- */
    var dl = document.getElementById("bk-dl");
    if (dl) {
        var token = dl.getAttribute("data-token");
        var paint = function (st) {
            dl.setAttribute("data-status", st);
            dl.querySelector(".bk-dl-ico").setAttribute("data-state", st);
        };
        paint(dl.getAttribute("data-status"));
        if (dl.getAttribute("data-status") === "restoring") {
            var poll = setInterval(function () {
                fetch("/api/backup/baixar/" + token, { credentials: "same-origin" })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (!d.ok || d.status === "restoring") return;
                        clearInterval(poll);
                        if (d.status === "ready") {
                            dl.querySelector('[data-dl="files"]').textContent = d.files;
                            dl.querySelector('[data-dl="size"]').textContent = fmtBytes(d.size);
                        }
                        if (d.message) dl.querySelector('[data-dl="message"]').textContent = d.message;
                        paint(d.status);
                    })
                    .catch(function () { /* proxima rodada */ });
            }, 3000);
        }
    }
})();
