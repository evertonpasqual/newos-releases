/* =====================================================================
   NewOS Panel - fundo animado do login: corredor de datacenter
   ---------------------------------------------------------------------
   Canvas atras do cartao de login: corredor em perspectiva com racks dos
   dois lados, LEDs piscando cada um no seu ritmo, a faixa de luz do teto
   e o reflexo no piso; a "camera" avanca devagar, sem fim.
   - nada de video nem biblioteca: tudo desenhado aqui (leve)
   - pausa com a aba escondida; "reduzir movimento" do sistema = quadro
     parado
   - sem JavaScript fica o fundo de antes (login-bg.jpg)
   ===================================================================== */
(function () {
    "use strict";
    var wrap = document.querySelector(".login-wrap");
    if (!wrap) return;
    var canvas = document.createElement("canvas");
    canvas.className = "dc-bg";
    canvas.setAttribute("aria-hidden", "true");
    wrap.insertBefore(canvas, wrap.firstChild);
    wrap.classList.add("has-dc");
    var ctx = canvas.getContext("2d");
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Mundo: x para os lados, y para baixo, z para a frente (a camera fica em z=0)
    var WALL = 1.25, FLOOR = 1.0, CEIL = -1.05;   // paredes de racks, piso e teto
    var RACK = 0.62;                                // largura (em z) de cada rack
    var NEAR = 0.25, FAR = 26;                      // corte de perto e de longe
    var SPEED = 0.55;                               // unidades por segundo
    var W = 0, H = 0, DPR = 1, cx = 0, cy = 0, F = 0;

    // Cada rack (por indice, infinito) tem LEDs fixos: posicao, cor e ritmo
    function rand(seed) {                           // pseudoaleatorio estavel por semente
        var x = Math.sin(seed * 12.9898) * 43758.5453;
        return x - Math.floor(x);
    }
    var COLORS = ["#d8ecff", "#cfe6ff", "#9fdcff", "#7fd7ff", "#00c8d0", "#d8ecff", "#5ad48a", "#ffd479"];
    var cache = {};
    var UNITS = 16;                                 // "servidores" por rack (linhas)
    function unitY(r) { return CEIL + 0.12 + (r + 0.5) * (FLOOR - CEIL - 0.2) / UNITS; }
    function leds(index, side) {
        var key = index + ":" + side;
        if (cache[key]) return cache[key];
        var out = [];
        for (var r = 0; r < UNITS; r++) {
            var s0 = index * 131.7 + side * 17.3 + r * 7.7;
            if (rand(s0) < 0.12) continue;                  // posicao vazia no rack
            var n = 1 + Math.floor(rand(s0 + 0.5) * 4);     // LEDs na frente do servidor
            for (var i = 0; i < n; i++) {
                var s = s0 + i * 3.11;
                out.push({
                    u: 0.10 + i * 0.07 + rand(s) * 0.02,            // na frente, lado a lado
                    v: unitY(r) + (rand(s + 1) - 0.5) * 0.02,
                    c: COLORS[Math.floor(rand(s + 2) * COLORS.length)],
                    f: 0.4 + rand(s + 3) * 2.6,
                    p: rand(s + 4) * 6.28,
                    b: rand(s + 5) < 0.2
                });
            }
        }
        if (Object.keys(cache).length > 400) cache = {};
        cache[key] = out;
        return out;
    }

    function resize() {
        DPR = Math.min(window.devicePixelRatio || 1, 1.5);
        W = wrap.clientWidth; H = wrap.clientHeight;
        canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
        canvas.style.width = W + "px"; canvas.style.height = H + "px";
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        cx = W / 2; cy = H * 0.47;
        F = Math.max(W, H) * 0.62;
    }
    function px(x, z) { return cx + x * F / z; }
    function py(y, z) { return cy + y * F / z; }
    function fog(z) { return Math.max(0, Math.min(1, 1 - (z - 1.2) / (FAR - 1.2))); }

    function quad(x1, y1, x2, y2, x3, y3, x4, y4) {
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.lineTo(x4, y4); ctx.closePath();
    }

    function frame(t) {
        var off = (t * SPEED) % RACK;
        var first = Math.floor((t * SPEED) / RACK);

        // fundo: azul profundo com a "boca" do corredor mais clara
        var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.75);
        g.addColorStop(0, "#1b3f8f"); g.addColorStop(0.18, "#0f2560"); g.addColorStop(0.6, "#071433"); g.addColorStop(1, "#030917");
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

        // piso e teto (planos escuros com brilho no fundo)
        var zF = FAR, zN = NEAR;
        ctx.fillStyle = "rgba(10, 24, 60, 0.85)";
        quad(px(-WALL, zN), py(FLOOR, zN), px(WALL, zN), py(FLOOR, zN), px(WALL, zF), py(FLOOR, zF), px(-WALL, zF), py(FLOOR, zF)); ctx.fill();
        ctx.fillStyle = "rgba(6, 14, 38, 0.9)";
        quad(px(-WALL, zN), py(CEIL, zN), px(WALL, zN), py(CEIL, zN), px(WALL, zF), py(CEIL, zF), px(-WALL, zF), py(CEIL, zF)); ctx.fill();

        // racks: do fundo para a frente (os de perto cobrem os de longe)
        for (var k = Math.ceil(FAR / RACK); k >= 0; k--) {
            var z0 = k * RACK - off + NEAR, z1 = z0 + RACK;
            if (z1 <= NEAR) continue;
            var za = Math.max(z0, NEAR), a = fog(za);
            if (a <= 0.01) continue;
            var idx = first + k;
            for (var side = -1; side <= 1; side += 2) {
                var X = side * WALL;
                // face do rack (com um vao escuro antes do proximo)
                var zb = Math.max(z0 + RACK * 0.06, NEAR), ze = z1 - RACK * 0.04;
                if (ze > zb) {
                    ctx.fillStyle = "rgba(" + Math.round(10 + 14 * a) + "," + Math.round(22 + 30 * a) + "," + Math.round(56 + 52 * a) + "," + (0.6 + 0.4 * a) + ")";
                    quad(px(X, zb), py(CEIL + 0.06, zb), px(X, ze), py(CEIL + 0.06, ze), px(X, ze), py(FLOOR - 0.04, ze), px(X, zb), py(FLOOR - 0.04, zb));
                    ctx.fill();
                    // cada servidor: uma linha clara na frente
                    ctx.strokeStyle = "rgba(110, 150, 235," + (0.22 * a) + ")";
                    ctx.lineWidth = Math.max(0.4, F / zb / 1100);
                    for (var sh = 0; sh <= UNITS && za < 9; sh += (za < 4 ? 1 : 2)) {
                        var yy = CEIL + 0.12 + sh * (FLOOR - CEIL - 0.2) / UNITS;
                        ctx.beginPath(); ctx.moveTo(px(X, zb), py(yy, zb)); ctx.lineTo(px(X, ze), py(yy, ze)); ctx.stroke();
                    }
                    // borda do gabinete
                    ctx.strokeStyle = "rgba(140, 175, 255," + (0.45 * a) + ")";
                    ctx.lineWidth = Math.max(0.6, 2 * F / zb / 900);
                    ctx.beginPath(); ctx.moveTo(px(X, zb), py(CEIL + 0.06, zb)); ctx.lineTo(px(X, zb), py(FLOOR - 0.04, zb)); ctx.stroke();
                }
                // LEDs
                var L = leds(idx, side);
                for (var i = 0; i < L.length; i++) {
                    var d = L[i], z = z0 + d.u * RACK;
                    if (z <= NEAR + 0.05) continue;
                    var on = 0.5 + 0.5 * Math.sin(t * d.f * (d.b ? 6 : 1) + d.p);
                    if (d.b) on = on > 0.55 ? 1 : 0.15;
                    var al = a * (0.25 + 0.75 * on);
                    if (al < 0.03) continue;
                    var r = Math.max(0.6, 2.4 * F / z / 700);
                    var sx = px(X, z), sy = py(d.v, z);
                    ctx.fillStyle = d.c;
                    if (z < 6) {                            // brilho e reflexo so perto
                        ctx.globalAlpha = al * 0.3;
                        ctx.beginPath(); ctx.arc(sx, sy, r * 3, 0, 6.283); ctx.fill();
                        ctx.globalAlpha = al * 0.1;
                        ctx.fillRect(sx - r, py(FLOOR + (FLOOR - d.v) * 0.35, z) - r, r * 2, r * 2);
                    }
                    ctx.globalAlpha = al;
                    if (r < 1.2) ctx.fillRect(sx - r, sy - r, r * 2, r * 2);
                    else { ctx.beginPath(); ctx.arc(sx, sy, r, 0, 6.283); ctx.fill(); }
                    ctx.globalAlpha = 1;
                }
            }
        }

        // faixa de luz no teto (segmentos que passam por cima)
        for (var j = Math.ceil(FAR / (RACK * 2)); j >= 0; j--) {
            var s0 = j * RACK * 2 - (t * SPEED) % (RACK * 2) + NEAR, s1 = s0 + RACK * 1.4;
            if (s1 <= NEAR) continue;
            var sa = Math.max(s0, NEAR), fa = fog(sa);
            ctx.fillStyle = "rgba(200, 225, 255," + (0.12 + 0.55 * fa) + ")";
            quad(px(-0.22, sa), py(CEIL, sa), px(0.22, sa), py(CEIL, sa), px(0.22, s1), py(CEIL, s1), px(-0.22, s1), py(CEIL, s1));
            ctx.fill();
        }
        // brilho da luz do teto no piso
        var gl = ctx.createLinearGradient(0, cy, 0, H);
        gl.addColorStop(0, "rgba(120, 170, 255, 0)"); gl.addColorStop(1, "rgba(120, 170, 255, 0.08)");
        ctx.fillStyle = gl;
        quad(px(-0.5, NEAR), py(FLOOR, NEAR), px(0.5, NEAR), py(FLOOR, NEAR), px(0.5, FAR), py(FLOOR, FAR), px(-0.5, FAR), py(FLOOR, FAR));
        ctx.fill();

        // vinheta: o cartao do login no centro fica em destaque
        var vg = ctx.createRadialGradient(cx, H / 2, Math.min(W, H) * 0.2, cx, H / 2, Math.max(W, H) * 0.8);
        vg.addColorStop(0, "rgba(3, 9, 23, 0)"); vg.addColorStop(1, "rgba(3, 9, 23, 0.55)");
        ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    }

    var start = performance.now(), raf = null, last = 0;
    function loop(now) {
        raf = requestAnimationFrame(loop);
        if (now - last < 33) return;                // ~30 quadros por segundo bastam
        last = now;
        frame((now - start) / 1000);
    }
    resize();
    window.addEventListener("resize", function () { resize(); if (reduce) frame(8); });
    if (reduce) { frame(8); return; }
    document.addEventListener("visibilitychange", function () {
        if (document.hidden) { cancelAnimationFrame(raf); raf = null; }
        else if (!raf) raf = requestAnimationFrame(loop);
    });
    raf = requestAnimationFrame(loop);
})();
