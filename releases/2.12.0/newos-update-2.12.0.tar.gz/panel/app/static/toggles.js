/* =====================================================================
   NewOS Panel - interruptores de modulos e servicos
   ---------------------------------------------------------------------
   Um clique no interruptor chama a API e espera a resposta. Enquanto
   isso o controle fica desabilitado e uma barra indeterminada aparece:
   instalar o Zabbix baixa pacotes e pode levar minutos, entao dar um
   retorno falso e imediato seria mentira.

   Se a acao falhar, o interruptor VOLTA ao estado anterior e o erro
   aparece na tela. Nada de deixar a interface dizendo "ligado" quando
   o servidor nao conseguiu ligar.
   ===================================================================== */
(function () {
    "use strict";

    function $(id) { return document.getElementById(id); }

    function showWork(key, text) {
        var box = $("work-" + key);
        var txt = $("worktxt-" + key);
        if (txt && text) { txt.textContent = text; }
        if (box) { box.classList.add("show"); }
    }

    function hideWork(key) {
        var box = $("work-" + key);
        if (box) { box.classList.remove("show"); }
    }

    function setLabel(id, on, words) {
        var el = $(id);
        if (!el) { return; }
        el.textContent = on ? words[0] : words[1];
        el.classList.toggle("on", on);
        el.classList.toggle("off", !on);
    }

    function banner(kind, message) {
        var main = document.querySelector(".main");
        if (!main) { return; }

        var old = main.querySelector(".alert.js-flash");
        if (old) { old.remove(); }

        var div = document.createElement("div");
        div.className = "alert alert-" + kind + " js-flash";
        div.innerHTML = '<span class="ico"><i class="bi ' + (kind === "ok" ? "bi-check-circle-fill" : "bi-x-circle-fill") + '"></i>' +
                        "</span><span></span>";
        div.querySelector("span:last-child").textContent = message;
        main.insertBefore(div, main.firstChild);
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    /* ---------------------------------------------------------------
       post - envia a acao e devolve {ok, message}
       --------------------------------------------------------------- */
    function post(url, body) {
        return fetch(url, {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json", "Accept": "application/json" },
            body: JSON.stringify(body)
        }).then(function (resp) {
            if (resp.status === 401) {
                window.location.href = "/login";
                throw new Error("sessao expirada");
            }
            return resp.json().then(function (data) {
                return { ok: resp.ok && data.ok !== false, data: data };
            });
        });
    }

    /* ---------------------------------------------------------------
       Interruptores de MODULO e COMPONENTE
       --------------------------------------------------------------- */
    function wireModuleToggles() {
        document.querySelectorAll('input[data-kind="module"], input[data-kind="component"]')
            .forEach(function (input) {
                input.addEventListener("change", function () {
                    var kind = input.dataset.kind;
                    var mod = input.dataset.module;
                    var comp = input.dataset.component || "";
                    var want = input.checked;
                    var key = comp ? (mod + "-" + comp) : mod;

                    var sw = $("sw-" + key);
                    input.disabled = true;
                    if (sw) { sw.classList.add("is-busy"); }
                    showWork(mod, want ? "instalando e ligando… isso pode levar alguns minutos"
                                       : "desligando…");

                    var url = kind === "module"
                        ? "/api/modules/" + encodeURIComponent(mod)
                        : "/api/modules/" + encodeURIComponent(mod) +
                          "/components/" + encodeURIComponent(comp);

                    post(url, { enabled: want })
                        .then(function (res) {
                            if (res.ok) {
                                setLabel("lbl-" + key, want, ["ligado", "desligado"]);
                                banner("ok", res.data.message || "Aplicado.");
                                /* Recarrega: ligar um modulo muda o menu e
                                   libera os componentes. */
                                setTimeout(function () { window.location.reload(); }, 900);
                            } else {
                                input.checked = !want;
                                setLabel("lbl-" + key, !want, ["ligado", "desligado"]);
                                banner("erro", res.data.message || "A operacao falhou.");
                            }
                        })
                        .catch(function (err) {
                            input.checked = !want;
                            setLabel("lbl-" + key, !want, ["ligado", "desligado"]);
                            banner("erro", "Falha de comunicacao: " + err.message);
                        })
                        .finally(function () {
                            input.disabled = false;
                            if (sw) { sw.classList.remove("is-busy"); }
                            hideWork(mod);
                        });
                });
            });
    }

    /* ---------------------------------------------------------------
       Interruptores de SERVICO (rodando agora / inicia no boot)
       --------------------------------------------------------------- */
    function wireServiceToggles() {
        document.querySelectorAll('input[data-kind="service"]').forEach(function (input) {
            input.addEventListener("change", function () {
                var svc = input.dataset.service;
                var field = input.dataset.field;          /* active | enabled */
                var want = input.checked;
                var key = svc.replace(/[^a-zA-Z0-9]/g, "_") + "-" + field;

                var sw = $("sw-" + key);
                input.disabled = true;
                if (sw) { sw.classList.add("is-busy"); }

                var action;
                if (field === "active") { action = want ? "start" : "stop"; }
                else                    { action = want ? "enable" : "disable"; }

                post("/api/services/" + encodeURIComponent(svc), { action: action })
                    .then(function (res) {
                        if (res.ok) {
                            setLabel("lbl-" + key, want,
                                     field === "active" ? ["ativo", "parado"]
                                                        : ["sim", "não"]);
                            banner("ok", res.data.message || "Aplicado.");
                            setTimeout(function () { window.location.reload(); }, 800);
                        } else {
                            input.checked = !want;
                            banner("erro", res.data.message || "A operacao falhou.");
                        }
                    })
                    .catch(function (err) {
                        input.checked = !want;
                        banner("erro", "Falha de comunicacao: " + err.message);
                    })
                    .finally(function () {
                        input.disabled = false;
                        if (sw) { sw.classList.remove("is-busy"); }
                    });
            });
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        wireModuleToggles();
        wireServiceToggles();
    });
}());
