/* =====================================================================
   NewOS Panel - Sistema > Processos (o "btop" do painel)
   - CPU total + cada nucleo, memoria (sem swap), disco e rede com
     graficos de 60 pontos
   - lista ao vivo: filtro, ordenar por coluna, agrupar por servico,
     linhas que reordenam animadas (FLIP) e barras que crescem
   - painel lateral com detalhes e acoes: encerrar (TERM), matar
     (kill -9), reiniciar o servico - sempre com confirmacao
   GET /api/processos a cada 1/2/5 s; "Pausar" congela; "/" busca.
   ===================================================================== */
(function () {
    "use strict";
    var $ = function (s) { return document.querySelector(s); };
    var ADMIN = !!window.PC_ADMIN;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function num(v, d) { return v.toLocaleString("pt-BR", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); }
    function bytes(b) {
        if (b == null) return "—";
        var u = ["B", "KiB", "MiB", "GiB", "TiB"], i = 0;
        while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
        return num(b, i === 0 ? 0 : b < 10 ? 1 : 0) + " " + u[i];
    }
    function rate(b) { return b ? bytes(b) + "/s" : "—"; }
    function css(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
    function dark() { return document.documentElement.classList.contains("dark-mode"); }
    function heat(p) { return p >= 85 ? "hot" : p >= 60 ? "warm" : p >= 25 ? "mid" : "low"; }
    function ago(ts) {
        var s = Math.max(0, Date.now() / 1000 - ts);
        if (s < 3600) return Math.floor(s / 60) + " min";
        if (s < 86400) return Math.floor(s / 3600) + " h " + Math.floor(s % 3600 / 60) + " min";
        return Math.floor(s / 86400) + " d " + Math.floor(s % 86400 / 3600) + " h";
    }
    var STATES = { R: ["rodando", "run"], S: ["dormindo", "sleep"], D: ["esperando disco", "io"], Z: ["zumbi", "zombie"],
                   T: ["parado", "stop"], t: ["parado", "stop"], I: ["ocioso", "sleep"] };

    // ------------------------------------------------------------- estado
    var data = null, paused = false, every = 2000, timer = null, view = "proc", q = "", kernel = false;
    var sort = { proc: { key: "cpu", dir: -1 }, unit: { key: "cpu", dir: -1 } };
    var HIST = { cpu: [], drd: [], dwr: [], nrx: [], ntx: [] }, selected = null;
    try { var saved = JSON.parse(localStorage.getItem("pc-prefs") || "{}"); every = saved.every || every; view = saved.view || view; sort = saved.sort || sort; } catch (e) { /* sem storage */ }
    function savePrefs() { try { localStorage.setItem("pc-prefs", JSON.stringify({ every: every, view: view, sort: sort })); } catch (e) { /* sem storage */ } }

    var COLS = {
        proc: [["pid", "PID", "n"], ["name", "Processo"], ["unit", "Serviço"], ["user", "Usuário"], ["cpu", "CPU", "n bar"],
               ["mem", "Memória", "n bar"], ["rd", "Leitura", "n"], ["wr", "Gravação", "n"], ["state", "Estado"]],
        unit: [["unit", "Serviço"], ["count", "Processos", "n"], ["cpu", "CPU", "n bar"], ["mem", "Memória", "n bar"],
               ["rd", "Leitura", "n"], ["wr", "Gravação", "n"], ["user", "Usuários"]]
    };

    // ------------------------------------------------------------- graficos
    function spark(canvas, series, max) {
        var ctx = canvas.getContext("2d"), dpr = window.devicePixelRatio || 1, W = canvas.clientWidth, H = canvas.clientHeight;
        if (!W || !H) return;
        if (canvas.width !== W * dpr) { canvas.width = W * dpr; canvas.height = H * dpr; }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
        series.forEach(function (s) {
            var d = s[0]; if (d.length < 2) return;
            var step = W / 59;
            ctx.beginPath();
            d.forEach(function (v, i) { var x = W - (d.length - 1 - i) * step, y = H - 2 - (H - 6) * Math.min(v / (max || 1), 1); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
            ctx.strokeStyle = s[1]; ctx.lineWidth = 2; ctx.lineJoin = "round"; ctx.stroke();
            ctx.lineTo(W, H); ctx.lineTo(W - (d.length - 1) * step, H); ctx.closePath();
            var g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, s[1] + "55"); g.addColorStop(1, s[1] + "00");
            ctx.fillStyle = g; ctx.fill();
        });
    }
    function push(arr, v) { arr.push(v); if (arr.length > 60) arr.shift(); }

    // ------------------------------------------------------------- cartoes
    function tiles(d) {
        var navy = dark() ? "#8aa0e6" : (css("--brand-navy") || "#183b90"), teal = css("--accent-teal") || "#00b8c0";
        $("#pc-cpu").textContent = num(d.cpu.total, 1);
        $("#pc-ncpu").textContent = d.ncpu + " núcleos";
        $("#pc-load").textContent = "carga " + d.load.map(function (l) { return num(l, 2); }).join(" · ") +
            " · " + d.totals.procs + " processos, " + d.totals.threads + " threads";
        var cores = $("#pc-cores");
        if (cores.children.length !== d.cpu.cores.length) {
            cores.innerHTML = d.cpu.cores.map(function (_, i) { return '<div class="pc-core" title="núcleo ' + i + '"><i></i><span>' + i + "</span></div>"; }).join("");
            cores.style.setProperty("--n", Math.min(d.cpu.cores.length, 16));
        }
        d.cpu.cores.forEach(function (v, i) {
            var c = cores.children[i], bar = c.firstChild;
            bar.style.height = Math.max(v, 2) + "%"; bar.className = heat(v); c.title = "núcleo " + i + ": " + num(v, 0) + "%";
        });
        var m = d.mem, usedPct = m.total ? 100 * m.used / m.total : 0, cachePct = m.total ? 100 * Math.min(m.cache, m.available) / m.total : 0;
        $("#pc-mem").textContent = num(usedPct, 1);
        $("#pc-membar .m-used").style.width = usedPct + "%";
        $("#pc-membar .m-cache").style.width = cachePct + "%";
        $("#pc-membar").className = "pc-membar " + heat(usedPct);
        $("#pc-mem-used").textContent = bytes(m.used);
        $("#pc-mem-cache").textContent = bytes(m.cache);
        $("#pc-mem-free").textContent = bytes(Math.max(m.available - m.cache, 0));
        $("#pc-mem-total").textContent = bytes(m.used) + " de " + bytes(m.total) + " de RAM · " + bytes(m.available) + " disponível";
        $("#pc-swap").textContent = m.swap_total ? "swap " + bytes(m.swap_used) : "sem swap";
        $("#pc-drd").textContent = bytes(d.disk.rd) + "/s"; $("#pc-dwr").textContent = bytes(d.disk.wr) + "/s";
        $("#pc-nrx").textContent = bytes(d.net.rx) + "/s"; $("#pc-ntx").textContent = bytes(d.net.tx) + "/s";
        push(HIST.cpu, d.cpu.total); push(HIST.drd, d.disk.rd); push(HIST.dwr, d.disk.wr); push(HIST.nrx, d.net.rx); push(HIST.ntx, d.net.tx);
        spark($("#pc-cpu-spark"), [[HIST.cpu, teal]], 100);
        spark($("#pc-disk-spark"), [[HIST.drd, navy], [HIST.dwr, teal]], Math.max.apply(null, HIST.drd.concat(HIST.dwr, [1024 * 1024])));
        spark($("#pc-net-spark"), [[HIST.nrx, navy], [HIST.ntx, teal]], Math.max.apply(null, HIST.nrx.concat(HIST.ntx, [128 * 1024])));
    }

    // ------------------------------------------------------------- linhas
    function unitLabel(u) {
        if (!u) return "";
        return u.replace(/\.service$/, "").replace(/^session-(\d+)\.scope$/, "sessão $1").replace(/\.scope$/, "");
    }
    function rows() {
        var list = data.procs, ql = q.toLowerCase();
        if (ql) list = list.filter(function (p) {
            return String(p.pid) === ql || p.name.toLowerCase().indexOf(ql) >= 0 || p.cmd.toLowerCase().indexOf(ql) >= 0 ||
                p.user.toLowerCase().indexOf(ql) >= 0 || (p.unit || "").toLowerCase().indexOf(ql) >= 0;
        });
        if (view === "unit") {
            var g = {};
            list.forEach(function (p) {
                var k = p.unit || "(sem serviço)";
                var u = g[k] || (g[k] = { id: k, unit: k, count: 0, cpu: 0, mem: 0, rd: 0, wr: 0, users: {}, procs: [] });
                u.count++; u.cpu += p.cpu; u.mem += p.mem; u.rd += p.rd; u.wr += p.wr; u.users[p.user] = 1; u.procs.push(p);
            });
            list = Object.keys(g).map(function (k) { var u = g[k]; u.user = Object.keys(u.users).join(", "); u.cpu = Math.round(u.cpu * 10) / 10; return u; });
        } else {
            list = list.map(function (p) { p.id = p.pid; return p; });
        }
        var s = sort[view];
        list.sort(function (a, b) {
            var x = a[s.key], y = b[s.key];
            if (typeof x === "string" || typeof y === "string") return s.dir * String(x || "").localeCompare(String(y || ""), "pt-BR");
            return s.dir * ((x || 0) - (y || 0)) || (b.mem - a.mem);
        });
        return list;
    }

    function head() {
        var s = sort[view];
        $("#pc-head").innerHTML = COLS[view].map(function (c) {
            var on = s.key === c[0];
            return '<th class="' + (c[2] || "") + (on ? " sorted" : "") + '" data-k="' + c[0] + '"' +
                (c[0] === "cpu" ? ' title="% de um núcleo (100% = um núcleo inteiro, como no top)"' : "") + ">" + c[1] +
                (on ? ' <i class="bi ' + (s.dir < 0 ? "bi-caret-down-fill" : "bi-caret-up-fill") + '"></i>' : "") + "</th>";
        }).join("");
    }

    function cellsProc(p, maxMem) {
        var st = STATES[p.state] || [p.state, "sleep"];
        return [
            '<td class="n mono pc-pid">' + p.pid + "</td>",
            '<td class="pc-name"><b>' + esc(p.name) + '</b><span class="mono">' + esc(p.cmd) + "</span></td>",
            "<td>" + (p.unit ? '<span class="pc-unit" title="' + esc(p.unit) + '">' + esc(unitLabel(p.unit)) + "</span>" : '<span class="nic-sub">—</span>') + "</td>",
            '<td class="pc-user">' + esc(p.user) + "</td>",
            '<td class="n bar"><div class="pc-bar ' + heat(Math.min(p.cpu, 100)) + '"><i style="width:' + Math.min(p.cpu, 100) + '%"></i></div><span>' + num(p.cpu, 1) + "%</span></td>",
            '<td class="n bar"><div class="pc-bar mem"><i style="width:' + (100 * p.mem / maxMem) + '%"></i></div><span>' + bytes(p.mem) + "</span></td>",
            '<td class="n' + (p.rd ? " io" : " nil") + '">' + rate(p.rd) + "</td>",
            '<td class="n' + (p.wr ? " io" : " nil") + '">' + rate(p.wr) + "</td>",
            '<td><span class="pc-state ' + st[1] + '">' + st[0] + '</span><i class="bi bi-chevron-right pc-open"></i></td>'
        ].join("");
    }
    function cellsUnit(u, maxMem) {
        return [
            '<td class="pc-name"><b>' + esc(unitLabel(u.unit) || u.unit) + '</b><span class="mono">' + esc(u.unit) + "</span></td>",
            '<td class="n">' + u.count + "</td>",
            '<td class="n bar"><div class="pc-bar ' + heat(Math.min(u.cpu, 100)) + '"><i style="width:' + Math.min(u.cpu, 100) + '%"></i></div><span>' + num(u.cpu, 1) + "%</span></td>",
            '<td class="n bar"><div class="pc-bar mem"><i style="width:' + (100 * u.mem / maxMem) + '%"></i></div><span>' + bytes(u.mem) + "</span></td>",
            '<td class="n' + (u.rd ? " io" : " nil") + '">' + rate(u.rd) + "</td>",
            '<td class="n' + (u.wr ? " io" : " nil") + '">' + rate(u.wr) + "</td>",
            '<td class="pc-user">' + esc(u.user) + '<i class="bi bi-chevron-right pc-open"></i></td>'
        ].join("");
    }

    var ROWS = new Map(), lastView = null;
    function table() {
        var list = rows(), body = $("#pc-body"), LIMIT = 250, shown = list.slice(0, LIMIT);
        var maxMem = Math.max.apply(null, shown.map(function (r) { return r.mem; }).concat([1]));
        if (lastView !== view) { ROWS.clear(); body.innerHTML = ""; lastView = view; head(); }
        // FLIP: posicao antes
        var before = new Map();
        if (!reduce) ROWS.forEach(function (tr, id) { before.set(id, tr.getBoundingClientRect().top); });
        var keep = new Set();
        var frag = document.createDocumentFragment();
        shown.forEach(function (r) {
            var id = String(r.id), tr = ROWS.get(id), fresh = !tr;
            if (fresh) { tr = document.createElement("tr"); tr.dataset.id = id; tr.className = "pc-new"; ROWS.set(id, tr); }
            var html = view === "unit" ? cellsUnit(r, maxMem) : cellsProc(r, maxMem);
            if (tr._h !== html) {
                if (!fresh && tr._h) {
                    var hot = view === "proc" ? r.cpu >= 50 : r.cpu >= 80;
                    if (hot) { tr.classList.remove("pc-flash"); void tr.offsetWidth; tr.classList.add("pc-flash"); }
                }
                tr.innerHTML = html; tr._h = html;
            }
            tr.classList.toggle("sel", selected && String(selected.id) === id);
            keep.add(id); frag.appendChild(tr);
        });
        ROWS.forEach(function (tr, id) { if (!keep.has(id)) { ROWS.delete(id); } });
        body.innerHTML = ""; body.appendChild(frag);
        if (!shown.length) body.innerHTML = '<tr><td class="empty" colspan="10">Nada com "' + esc(q) + '".</td></tr>';
        if (!reduce) {
            ROWS.forEach(function (tr, id) {
                var top = before.get(id);
                if (top == null) return;
                var dy = top - tr.getBoundingClientRect().top;
                if (Math.abs(dy) < 2) return;
                tr.style.transform = "translateY(" + dy + "px)"; tr.style.transition = "none";
                requestAnimationFrame(function () { tr.style.transition = ""; tr.style.transform = ""; });
            });
        }
        setTimeout(function () { body.querySelectorAll(".pc-new").forEach(function (tr) { tr.classList.remove("pc-new"); }); }, 600);
        $("#pc-count").textContent = (view === "unit" ? list.length + " serviço(s)" : list.length + " de " + data.totals.procs + " processos") +
            (list.length > LIMIT ? " · mostrando " + LIMIT : "");
        if (selected) drawer(true);
    }

    // ------------------------------------------------------------- detalhes e acoes
    function findSel() {
        if (!selected || !data) return null;
        if (selected.kind === "unit") {
            var g = rows().filter(function (r) { return r.id === selected.id; })[0];
            return g || null;
        }
        return data.procs.filter(function (p) { return p.pid === selected.id && p.start === selected.start; })[0] || null;
    }
    function drawer(refresh) {
        var r = findSel(), box = $("#pc-drawer");
        if (!r) {
            if (refresh && selected) { $("#pc-d-sub").innerHTML = '<span class="zbx-bad">não está mais rodando</span>'; }
            return;
        }
        var st = STATES[r.state] || [r.state || "", "sleep"];
        if (selected.kind === "unit") {
            $("#pc-d-name").textContent = unitLabel(r.unit) || r.unit;
            $("#pc-d-sub").innerHTML = '<span class="mono">' + esc(r.unit) + "</span> · " + r.count + " processo(s)";
            $("#pc-d-cmd").innerHTML = r.procs.slice(0, 12).map(function (p) { return '<div><span class="pc-pid">' + p.pid + "</span> " + esc(p.cmd) + "</div>"; }).join("");
            $("#pc-d-info").innerHTML = "<dt>Usuários</dt><dd>" + esc(r.user) + "</dd>";
        } else {
            $("#pc-d-name").textContent = r.name;
            $("#pc-d-sub").innerHTML = "PID " + r.pid + " · pai " + r.ppid + ' · <span class="pc-state ' + st[1] + '">' + st[0] + "</span>";
            $("#pc-d-cmd").textContent = r.cmd;
            $("#pc-d-info").innerHTML = "<dt>Serviço</dt><dd>" + (r.unit ? '<span class="mono">' + esc(r.unit) + "</span>" : "—") + "</dd>" +
                "<dt>Usuário</dt><dd>" + esc(r.user) + "</dd><dt>Rodando há</dt><dd>" + ago(r.since) + "</dd>" +
                "<dt>Threads</dt><dd>" + r.threads + "</dd><dt>Prioridade (nice)</dt><dd>" + r.nice + "</dd>";
        }
        $("#pc-d-stats").innerHTML = [["CPU", num(r.cpu, 1) + "%"], ["Memória", bytes(r.mem)], ["Leitura", rate(r.rd)], ["Gravação", rate(r.wr)]]
            .map(function (s) { return "<div><small>" + s[0] + "</small><b>" + s[1] + "</b></div>"; }).join("");
        if (refresh) return;
        var acts = "";
        if (!ADMIN) acts = '<p class="nic-sub"><i class="bi bi-lock"></i> Encerrar e reiniciar: só administradores.</p>';
        else if (selected.kind === "unit") {
            acts = r.unit.endsWith(".service") ? '<button type="button" class="btn" data-act="restart"><i class="bi bi-arrow-repeat"></i> Reiniciar o serviço</button>' : '<p class="nic-sub">Sem serviço do systemd: encerre os processos um a um.</p>';
        } else {
            acts = '<button type="button" class="btn btn-ghost" data-act="TERM"><i class="bi bi-stop-circle"></i> Encerrar (SIGTERM)</button>' +
                '<button type="button" class="btn btn-danger" data-act="KILL"><i class="bi bi-x-octagon"></i> Matar (kill -9)</button>' +
                (r.unit && r.unit.endsWith(".service") ? '<button type="button" class="btn" data-act="restart"><i class="bi bi-arrow-repeat"></i> Reiniciar ' + esc(unitLabel(r.unit)) + "</button>" : "");
        }
        $("#pc-d-actions").innerHTML = acts;
        $("#pc-d-out").hidden = true;
        box.classList.add("open"); box.setAttribute("aria-hidden", "false"); $("#pc-shade").classList.add("on");
    }
    function closeDrawer() {
        selected = null; $("#pc-drawer").classList.remove("open"); $("#pc-drawer").setAttribute("aria-hidden", "true");
        $("#pc-shade").classList.remove("on");
        ROWS.forEach(function (tr) { tr.classList.remove("sel"); });
    }
    function confirmBox(title, text, danger, label) {
        return new Promise(function (ok) {
            var m = $("#pc-modal");
            $("#pc-m-title").textContent = title; $("#pc-m-text").innerHTML = text;
            $("#pc-m-yes").className = "btn " + (danger ? "btn-danger" : "");
            $("#pc-m-yes").textContent = label; $("#pc-m-ico").className = "pc-modal-ico" + (danger ? " danger" : "");
            m.hidden = false; requestAnimationFrame(function () { m.classList.add("on"); }); $("#pc-m-yes").focus();
            function done(v) { m.classList.remove("on"); setTimeout(function () { m.hidden = true; }, 180); $("#pc-m-yes").onclick = $("#pc-m-no").onclick = null; ok(v); }
            $("#pc-m-yes").onclick = function () { done(true); }; $("#pc-m-no").onclick = function () { done(false); };
        });
    }
    function act(kind) {
        var r = findSel(); if (!r) return;
        var out = $("#pc-d-out"), unit = r.unit, p;
        if (kind === "restart") {
            p = confirmBox("Reiniciar " + unitLabel(unit) + "?", "O serviço <b>" + esc(unit) + "</b> para e sobe de novo. Quem estiver usando perde a conexão por alguns segundos.", false, "Reiniciar")
                .then(function (y) { return y && post("/api/processos/reiniciar", { unit: unit }); });
        } else {
            var kill = kind === "KILL";
            p = confirmBox((kill ? "Matar " : "Encerrar ") + r.name + " (PID " + r.pid + ")?",
                kill ? "<b>kill -9</b>: o processo para na hora, <b>sem salvar nada</b>. Use só se ele não responder ao Encerrar." +
                    (unit && unit.endsWith(".service") ? "<br>Ele é do serviço <b>" + esc(unit) + "</b>: o systemd pode subi-lo de novo." : "")
                    : "Pede para o processo terminar (SIGTERM): ele fecha o que estiver fazendo e sai." +
                    (unit && unit.endsWith(".service") ? "<br>Ele é do serviço <b>" + esc(unit) + "</b>; para reiniciar o serviço inteiro use <b>Reiniciar</b>." : ""),
                kill, kill ? "Matar agora" : "Encerrar")
                .then(function (y) { return y && post("/api/processos/encerrar", { pid: r.pid, start: r.start, signal: kind, name: r.name }); });
        }
        p.then(function (d) {
            if (!d) return;
            out.hidden = false; out.className = "lg-result " + (d.ok ? "lg-good" : "lg-bad"); out.textContent = d.message || (d.ok ? "Feito." : "Falhou.");
            tick(true);
        });
    }
    function post(url, body) {
        return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
            .then(function (r) { return r.json(); }).catch(function () { return { ok: false, message: "Sem resposta do painel." }; });
    }

    // ------------------------------------------------------------- ciclo
    function tick(now) {
        clearTimeout(timer);
        if (paused && !now) return;
        if (document.hidden && !now) { timer = setTimeout(tick, every); return; }    // aba escondida: nao le
        fetch("/api/processos" + (kernel ? "?kernel=1" : ""), { credentials: "same-origin" })
            .then(function (r) { if (r.status === 401) { location.href = "/login"; } return r.json(); })
            .then(function (d) {
                if (!d.ok) throw new Error(d.message);
                data = d; tiles(d); table();
                $("#pc-clock").textContent = new Date(d.t * 1000).toLocaleTimeString("pt-BR");
                $("#pc-dot").classList.remove("off");
            })
            .catch(function () { $("#pc-clock").textContent = "sem resposta"; $("#pc-dot").classList.add("off"); })
            .finally(function () { if (!paused) timer = setTimeout(tick, every); });
    }

    // ------------------------------------------------------------- eventos
    $("#pc-every").value = String(every);
    document.querySelectorAll("#pc-view button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === view); });
    $("#pc-every").addEventListener("change", function () { every = +this.value; savePrefs(); tick(true); });
    $("#pc-pause").addEventListener("click", function () {
        paused = !paused;
        this.innerHTML = paused ? '<i class="bi bi-play-fill"></i> Continuar' : '<i class="bi bi-pause-fill"></i> Pausar';
        $("#pc-dot").classList.toggle("off", paused);
        if (!paused) tick(true);
    });
    var qt;
    $("#pc-q").addEventListener("input", function () { var v = this.value.trim(); clearTimeout(qt); qt = setTimeout(function () { q = v; if (data) table(); }, 120); });
    document.addEventListener("keydown", function (e) {
        if (e.key === "/" && document.activeElement.tagName !== "INPUT" && document.activeElement.tagName !== "TEXTAREA") { e.preventDefault(); $("#pc-q").focus(); }
        if (e.key === "Escape") { if (!$("#pc-modal").hidden) $("#pc-m-no").click(); else closeDrawer(); }
    });
    $("#pc-view").addEventListener("click", function (e) {
        var b = e.target.closest("button"); if (!b) return;
        view = b.dataset.v; savePrefs(); closeDrawer();
        this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
        if (data) table();
    });
    $("#pc-kernel").addEventListener("change", function () { kernel = this.checked; tick(true); });
    $("#pc-head").addEventListener("click", function (e) {
        var th = e.target.closest("th[data-k]"); if (!th) return;
        var s = sort[view], k = th.dataset.k;
        if (s.key === k) s.dir = -s.dir; else { s.key = k; s.dir = ["name", "unit", "user", "state"].indexOf(k) >= 0 ? 1 : -1; }
        savePrefs(); head(); if (data) table();
    });
    $("#pc-body").addEventListener("click", function (e) {
        var tr = e.target.closest("tr[data-id]"); if (!tr || !data) return;
        var id = tr.dataset.id;
        if (view === "unit") selected = { kind: "unit", id: id };
        else { var p = data.procs.filter(function (x) { return String(x.pid) === id; })[0]; if (!p) return; selected = { kind: "proc", id: p.pid, start: p.start }; }
        ROWS.forEach(function (x, k) { x.classList.toggle("sel", k === id); });
        drawer(false);
    });
    $("#pc-d-close").addEventListener("click", closeDrawer);
    $("#pc-shade").addEventListener("click", closeDrawer);
    $("#pc-d-actions").addEventListener("click", function (e) { var b = e.target.closest("[data-act]"); if (b) act(b.dataset.act); });
    document.addEventListener("visibilitychange", function () { if (!document.hidden && !paused) tick(true); });

    // link direto: ?q=filtro e ?abrir=PID (abre os detalhes)
    var qs = new URLSearchParams(location.search), openPid = +qs.get("abrir") || 0;
    if (qs.get("q")) { q = qs.get("q"); $("#pc-q").value = q; }
    if (openPid) {
        var once = setInterval(function () {
            if (!data) return;
            clearInterval(once);
            var p = data.procs.filter(function (x) { return x.pid === openPid; })[0];
            if (p) { view = "proc"; selected = { kind: "proc", id: p.pid, start: p.start }; drawer(false); }
        }, 200);
    }

    head();
    tick(true);
})();
