/* =====================================================================
   NewOS Panel - tela de Discos
   ---------------------------------------------------------------------
   - blocos recolhiveis (disco, grupo LVM, pool ZFS): fechados por
     padrao, lembrados no navegador; "Expandir/Recolher tudo"
   - numeros do resumo contam de 0 ate o valor
   - uma acao aberta por vez (os <details> se fecham entre si) e
     sempre inteira na tela
   - digitar um tamanho desmarca "usar todo o espaco livre"
   - ao enviar: barra "executando" e botao travado (formatar um disco
     grande ou mexer no LVM pode levar minutos; clicar duas vezes nao
     pode disparar a operacao duas vezes)
   ===================================================================== */
(function () {
    "use strict";

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var KEY = "newos.storage.open";

    /* ---------------- blocos recolhiveis ------------------------------ */
    function loadOpen() {
        try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; }
    }
    function saveOpen(list) {
        try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* sem storage */ }
    }
    var folds = Array.prototype.slice.call(document.querySelectorAll(".fold[data-fold]"));

    function setFold(f, open, remember) {
        var head = f.querySelector(".fold-head");
        f.classList.toggle("open", open);
        if (head) head.setAttribute("aria-expanded", open ? "true" : "false");
        if (!open) {
            f.classList.remove("settled");
            f.querySelectorAll("details.act[open]").forEach(function (d) { d.open = false; });
        } else if (REDUCED || !f.classList.contains("fold-ready")) {
            f.classList.add("settled");
        }
        if (remember) {
            var id = f.getAttribute("data-fold");
            var list = loadOpen().filter(function (x) { return x !== id; });
            if (open) list.push(id);
            saveOpen(list);
        }
    }

    var remembered = loadOpen();
    folds.forEach(function (f) {
        if (remembered.indexOf(f.getAttribute("data-fold")) !== -1) setFold(f, true, false);
        f.querySelector(".fold-head").addEventListener("click", function () {
            setFold(f, !f.classList.contains("open"), true);
        });
        // So depois de aberto por inteiro o conteudo pode "vazar" (menus).
        f.querySelector(".fold-body").addEventListener("transitionend", function (ev) {
            if (ev.propertyName === "grid-template-rows" && f.classList.contains("open")) {
                f.classList.add("settled");
            }
        });
    });
    document.querySelectorAll("[data-fold-all]").forEach(function (b) {
        b.addEventListener("click", function () {
            var open = b.getAttribute("data-fold-all") === "open";
            folds.forEach(function (f, i) {
                // em cascata, como a entrada dos cartoes
                setTimeout(function () { setFold(f, open, true); }, REDUCED ? 0 : i * 60);
            });
        });
    });
    requestAnimationFrame(function () {
        requestAnimationFrame(function () {
            folds.forEach(function (f) { f.classList.add("fold-ready"); });
        });
    });

    /* ---------------- numeros que contam ------------------------------ */
    document.querySelectorAll("[data-countup]").forEach(function (el) {
        var target = parseFloat(el.getAttribute("data-countup")) || 0;
        var dec = parseInt(el.getAttribute("data-decimals") || "0", 10);
        var fmt = function (v) {
            return v.toLocaleString("pt-BR", { minimumFractionDigits: dec, maximumFractionDigits: dec });
        };
        if (REDUCED || target === 0) { el.textContent = fmt(target); return; }
        var start = null, dur = 800;
        el.textContent = fmt(0);
        function step(ts) {
            if (start === null) start = ts;
            var k = Math.min(1, (ts - start) / dur);
            el.textContent = fmt(target * (1 - Math.pow(1 - k, 3)));
            if (k < 1) requestAnimationFrame(step);
        }
        setTimeout(function () { requestAnimationFrame(step); }, 150);
    });

    var acts = document.querySelectorAll("details.act");
    acts.forEach(function (d) {
        d.addEventListener("toggle", function () {
            if (!d.open) return;
            acts.forEach(function (o) { if (o !== d) o.open = false; });
            // menu perto do fim da tela: rola so o necessario para ve-lo inteiro
            var body = d.querySelector(".act-body");
            if (body) body.scrollIntoView({ block: "nearest", behavior: "smooth" });
            var first = d.querySelector("input[type=text], select");
            if (first) first.focus({ preventScroll: true });
        });
    });

    document.querySelectorAll('input[name="size"]').forEach(function (input) {
        input.addEventListener("input", function () {
            var all = input.form.querySelector('input[name="all"]');
            if (all && input.value.trim()) all.checked = false;
        });
    });

    var working = document.getElementById("diskWorking");
    document.querySelectorAll("form[data-busy]").forEach(function (form) {
        form.addEventListener("submit", function () {
            form.querySelectorAll("button").forEach(function (b) { b.disabled = true; });
            if (working) {
                working.classList.add("show");
                window.scrollTo({ top: 0, behavior: "smooth" });
            }
        });
    });
})();
