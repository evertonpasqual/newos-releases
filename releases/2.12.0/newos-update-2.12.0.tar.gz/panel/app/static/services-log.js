/* =====================================================================
   NewOS Panel - Servicos: log ao vivo (journal)
   - as linhas novas entram no topo com destaque (como o Trafego ao vivo)
   - filtro por servico, por gravidade (tudo / avisos e erros / so erros)
     e por texto; "Pausar" congela a tela
   - o botao de log em cada linha da tabela foca aquele servico
   ===================================================================== */
(function () {
    "use strict";
    var box = document.getElementById("svc-log");
    if (!box) return;
    var feed = document.getElementById("svl-feed"), unitSel = document.getElementById("svl-unit");
    var q = document.getElementById("svl-q"), counts = document.getElementById("svl-counts");
    var allUnits = (box.getAttribute("data-units") || "").split(/\s+/).filter(Boolean);
    var cursor = "", prio = 7, paused = false, gen = 0, seen = { err: 0, warn: 0, total: 0 };
    var MAX = 400;
    var PRIO = { 0: ["err", "emerg"], 1: ["err", "alert"], 2: ["err", "crit"], 3: ["err", "erro"], 4: ["warn", "aviso"],
                 5: ["note", "nota"], 6: ["info", "info"], 7: ["dbg", "debug"] };

    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function row(e, fresh) {
        var p = PRIO[e.prio] || PRIO[6];
        var el = document.createElement("div");
        el.className = "svl-line p-" + p[0] + (fresh ? " svl-new" : "");
        el.setAttribute("data-text", (e.unit + " " + e.msg).toLowerCase());
        el.innerHTML = '<span class="svl-t mono">' + esc(e.t) + "</span>" +
            '<button type="button" class="svl-unit" data-svl-unit="' + esc(e.unit) + '">' + esc(e.unit || e.ident) + "</button>" +
            '<span class="svl-p">' + p[1] + "</span>" +
            '<span class="svl-msg mono">' + esc(e.msg) + "</span>";
        return el;
    }
    function applyQ(el) {
        var t = (q.value || "").toLowerCase();
        el.hidden = !!t && el.getAttribute("data-text").indexOf(t) < 0;
    }
    function updCounts() {
        counts.innerHTML = '<span><strong>' + seen.total + "</strong> linhas</span>" +
            (seen.warn ? '<span class="c-warn"><i class="bi bi-exclamation-triangle"></i> ' + seen.warn + " aviso(s)</span>" : "") +
            (seen.err ? '<span class="c-err"><i class="bi bi-x-octagon"></i> ' + seen.err + " erro(s)</span>" : "");
    }
    function add(entries, fresh) {
        var empty = feed.querySelector(".empty");
        if (empty && entries.length) empty.remove();
        var frag = document.createDocumentFragment();
        // o journal vem do mais antigo para o mais novo: o mais novo fica em cima
        for (var i = entries.length - 1; i >= 0; i--) {
            var e = entries[i], el = row(e, fresh);
            applyQ(el);
            frag.appendChild(el);
            seen.total++;
            if (e.prio <= 3) seen.err++; else if (e.prio === 4) seen.warn++;
        }
        feed.insertBefore(frag, feed.firstChild);
        while (feed.children.length > MAX) feed.removeChild(feed.lastChild);
        updCounts();
    }
    function units() { return unitSel.value ? [unitSel.value] : allUnits; }
    function reset() {
        gen++; cursor = ""; seen = { err: 0, warn: 0, total: 0 };
        feed.innerHTML = '<div class="empty"><span class="bk-pulse"></span> lendo o journal…</div>';
        updCounts();
        tick(gen);
    }
    function tick(g) {
        if (g !== gen) return;
        if (paused) { setTimeout(function () { tick(g); }, 2000); return; }
        fetch("/api/servicos/log", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ units: units(), cursor: cursor, prio: prio, lines: 150 }) })
            .then(function (r) { if (r.status === 401) { location.href = "/login"; throw 0; } return r.json(); })
            .then(function (d) {
                if (g !== gen) return;
                if (!d.ok) { feed.innerHTML = '<div class="empty">' + esc(d.message || "Não consegui ler o journal.") + "</div>"; return; }
                var first = !cursor;
                if (d.entries.length) add(d.entries, !first);
                else if (first) feed.innerHTML = '<div class="empty">Nada no log com esse filtro.</div>';
                cursor = d.cursor || cursor;
                document.getElementById("svl-clock").textContent = "ao vivo · " + new Date().toLocaleTimeString("pt-BR");
            })
            .catch(function () {})
            .then(function () { if (g === gen) setTimeout(function () { tick(g); }, 2000); });
    }
    unitSel.addEventListener("change", reset);
    document.getElementById("svl-prio").addEventListener("click", function (e) {
        var b = e.target.closest("[data-p]"); if (!b) return;
        prio = parseInt(b.getAttribute("data-p"), 10);
        this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
        reset();
    });
    q.addEventListener("input", function () { feed.querySelectorAll(".svl-line").forEach(applyQ); });
    document.getElementById("svl-pause").addEventListener("click", function () {
        paused = !paused;
        this.innerHTML = paused ? '<i class="bi bi-play-fill"></i> Continuar' : '<i class="bi bi-pause-fill"></i> Pausar';
        document.getElementById("svl-live").classList.toggle("paused", paused);
    });
    document.addEventListener("click", function (e) {
        var b = e.target.closest("[data-svl-unit]"); if (!b) return;
        var u = b.getAttribute("data-svl-unit");
        if (!Array.prototype.some.call(unitSel.options, function (o) { return o.value === u; })) return;
        unitSel.value = u; reset();
        box.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    reset();
})();
