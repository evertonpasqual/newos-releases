/* =====================================================================
   NewOS Panel - Benchmark (fio, iperf3, internet)
   - formulario -> POST /api/benchmark/iniciar -> painel ao vivo
   - painel ao vivo: etapas, numeros grandes animados, grafico (canvas)
   - internet: velocimetros de download/upload
   - rede: servidor iperf3 (liga/desliga, testes recebidos ao vivo)
   ===================================================================== */
(function () {
    "use strict";

    function $(s, el) { return (el || document).querySelector(s); }
    function $$(s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); }
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function fmt(n, dec) {
        if (n == null || isNaN(n)) return "—";
        return Number(n).toLocaleString("pt-BR", { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 });
    }
    function api(url, body) {
        var o = { credentials: "same-origin", cache: "no-store", headers: {} };
        if (body !== undefined) { o.method = "POST"; o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(body); }
        return fetch(url, o).then(function (r) {
            if (r.status === 401) { location.href = "/login"; throw new Error("sessao"); }
            return r.json();
        });
    }
    function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

    /* ---------------- chips (radio visual) -------------------------- */
    $$(".bn-chips").forEach(function (box) {
        box.addEventListener("change", function () {
            $$(".prom-chip", box).forEach(function (c) { var i = $("input[type=radio]", c); c.classList.toggle("on", !!(i && i.checked)); });
        });
        box.addEventListener("click", function (e) {
            var c = e.target.closest(".prom-chip"); if (!c) return;
            var r = $("input[type=radio]", c); if (r && !r.checked) { r.checked = true; r.dispatchEvent(new Event("change", { bubbles: true })); }
        });
    });

    /* ---------------- formulario: estimativa e avisos --------------- */
    var form = $("[data-bn-form]");
    var kind = form ? form.getAttribute("data-bn-form") : null;
    function val(name) {
        var el = form.querySelector("[name=" + name + "]:checked") || form.querySelector("[name=" + name + "]");
        return el ? el.value : "";
    }
    function updateForm() {
        if (!form) return;
        var eta = $("#bn-eta");
        if (kind === "fio") {
            var t = form.querySelector("[name=target]:checked");
            var raw = t && t.getAttribute("data-raw") === "1";
            $("#bn-raw-warn").hidden = !raw;
            var rt = parseInt(val("runtime"), 10) || 60, steps = val("profile") === "completo" ? 6 : 2;
            if (eta) eta.textContent = "duração estimada: até " + Math.ceil(steps * (rt + 8) / 60) + " min";
            var free = t ? parseInt(t.getAttribute("data-free"), 10) : 0, gb = parseInt(val("size_gb"), 10) || 0;
            var h = $("#bn-free-hint");
            if (h && free) {
                var ok = gb * 1.1 * 1073741824 < free;
                h.innerHTML = ok ? '<i class="bi bi-check-circle"></i> Cabe: ' + fmt(free / 1073741824, 1) + " GB livres"
                    : '<i class="bi bi-exclamation-triangle"></i> Pouco espaço: ' + fmt(free / 1073741824, 1) + " GB livres";
                h.className = "hint " + (ok ? "bn-ok" : "bn-bad");
            }
            $$(".bn-target").forEach(function (l) { l.classList.toggle("on", $("input", l).checked); });
            $$(".bn-profile").forEach(function (l) { l.classList.toggle("on", $("input", l).checked); });
        } else if (kind === "iperf") {
            if (eta) eta.textContent = "≈ " + (parseInt(val("duration"), 10) || 30) + " s";
            $("#bn-udp").hidden = val("proto") !== "udp";
        }
    }
    if (form) {
        form.addEventListener("change", updateForm);
        form.addEventListener("input", updateForm);
        updateForm();
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            var body = { kind: kind };
            $$("input, select", form).forEach(function (el) {
                if (!el.name || el.name === "streams_custom") return;
                if ((el.type === "radio" || el.type === "checkbox") && !el.checked) return;
                body[el.name] = el.value;
            });
            if (kind === "iperf" && body.streams === "custom") body.streams = val("streams_custom");
            ["size_gb", "runtime", "port", "streams", "duration"].forEach(function (k) { if (body[k] !== undefined) body[k] = parseInt(body[k], 10); });
            var btn = $("#bn-go");
            btn.disabled = true;
            api("/api/benchmark/iniciar", body).then(function (d) {
                btn.disabled = false;
                if (!d.ok) { toast(d.message || "Não foi possível iniciar.", true); return; }
                watch(d.id, true);
            }).catch(function () { btn.disabled = false; toast("Falha de comunicação com o painel.", true); });
        });
    }

    function toast(msg, bad) {
        var t = document.createElement("div");
        t.className = "alert " + (bad ? "alert-erro" : "alert-ok") + " bn-toast";
        t.innerHTML = '<span class="ico"><i class="bi ' + (bad ? "bi-x-octagon" : "bi-check-circle") + '"></i></span><span>' + esc(msg) + "</span>";
        document.body.appendChild(t);
        setTimeout(function () { t.classList.add("out"); }, 4500);
        setTimeout(function () { t.remove(); }, 5200);
    }

    /* ---------------- grafico ao vivo (canvas, sem biblioteca) ------- */
    function Chart(canvas) {
        this.c = canvas; this.ctx = canvas.getContext("2d"); this.series = []; this.unit = ""; this.shown = 0;
        var self = this;
        window.addEventListener("resize", function () { self.draw(); });
    }
    Chart.prototype.set = function (series, unit) {
        this.series = series; this.unit = unit; this.draw();
    };
    Chart.prototype.draw = function () {
        var c = this.c, ctx = this.ctx, dpr = window.devicePixelRatio || 1;
        var W = c.clientWidth, H = c.clientHeight || 220;
        if (!W) return;
        if (c.width !== W * dpr) { c.width = W * dpr; c.height = H * dpr; }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, W, H);
        var pts = [];
        this.series.forEach(function (s) { pts = pts.concat(s.data); });
        var L = 54, R = 12, T = 10, B = 24;
        var grid = css("--border-color") || "#e6ebf5", muted = css("--text-muted") || "#6b7480";
        var tmax = 10, vmax = 1;
        pts.forEach(function (p) { tmax = Math.max(tmax, p[0]); vmax = Math.max(vmax, p[1]); });
        vmax *= 1.15;
        // alvo animado: o eixo cresce suave em vez de pular
        this.shown = this.shown ? this.shown + (vmax - this.shown) * 0.35 : vmax;
        var vm = this.shown;
        ctx.font = "11px Inter, system-ui, sans-serif"; ctx.fillStyle = muted; ctx.strokeStyle = grid; ctx.lineWidth = 1;
        for (var i = 0; i <= 4; i++) {
            var y = T + (H - T - B) * (1 - i / 4);
            ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke();
            ctx.textAlign = "right"; ctx.fillText(fmt(vm * i / 4, vm < 10 ? 1 : 0), L - 6, y + 4);
        }
        ctx.textAlign = "left"; ctx.fillText("0 s", L, H - 6);
        ctx.textAlign = "right"; ctx.fillText(fmt(tmax, 0) + " s", W - R, H - 6);
        ctx.textAlign = "left"; ctx.fillText(this.unit, L + 4, T + 12);
        function X(t) { return L + (W - L - R) * t / tmax; }
        function Y(v) { return T + (H - T - B) * (1 - Math.min(v, vm) / vm); }
        this.series.forEach(function (s) {
            if (s.data.length < 1) return;
            var g = ctx.createLinearGradient(0, T, 0, H - B);
            g.addColorStop(0, s.color + "55"); g.addColorStop(1, s.color + "00");
            ctx.beginPath();
            s.data.forEach(function (p, i) { if (i) ctx.lineTo(X(p[0]), Y(p[1])); else ctx.moveTo(X(p[0]), Y(p[1])); });
            ctx.lineWidth = 2.2; ctx.strokeStyle = s.color; ctx.lineJoin = "round"; ctx.stroke();
            var last = s.data[s.data.length - 1];
            ctx.lineTo(X(last[0]), H - B); ctx.lineTo(X(s.data[0][0]), H - B); ctx.closePath();
            ctx.fillStyle = g; ctx.fill();
            ctx.beginPath(); ctx.arc(X(last[0]), Y(last[1]), 4, 0, Math.PI * 2); ctx.fillStyle = s.color; ctx.fill();
            ctx.beginPath(); ctx.arc(X(last[0]), Y(last[1]), 8 + 3 * Math.sin(Date.now() / 200), 0, Math.PI * 2);
            ctx.strokeStyle = s.color + "66"; ctx.lineWidth = 2; ctx.stroke();
        });
    };

    /* ---------------- numeros grandes que "contam" ------------------ */
    function tween(el, to, dec) {
        var from = parseFloat(el.getAttribute("data-v") || "0") || 0;
        el.setAttribute("data-v", to);
        if (to == null || isNaN(to)) { el.textContent = "—"; return; }
        var t0 = performance.now();
        function step(now) {
            var k = Math.min(1, (now - t0) / 600), e = 1 - Math.pow(1 - k, 3);
            el.textContent = fmt(from + (to - from) * e, dec);
            if (k < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
    }

    /* ---------------- velocimetros (internet) ----------------------- */
    function gauge(k, mbps, active) {
        var g = $('[data-gauge="' + k + '"]'); if (!g) return;
        var fill = $(".g-fill", g), len = fill.getTotalLength ? fill.getTotalLength() : 377;
        // escala logaritmica: 1 Mb/s a 10 Gb/s
        var f = mbps > 0 ? Math.min(1, Math.log10(Math.max(1, mbps)) / 4) : 0;
        fill.style.strokeDasharray = len; fill.style.strokeDashoffset = len * (1 - f);
        g.classList.toggle("active", !!active);
        tween($("[data-gval]", g), mbps, mbps < 100 ? 1 : 0);
    }

    /* ---------------- painel ao vivo -------------------------------- */
    var live = $("#bn-live"), chart = live ? new Chart($("#bn-chart")) : null, timer = null, current = null;
    var NAMES = { fio: "Teste de disco", iperf: "Teste de rede (iperf3)", internet: "Velocidade de internet" };
    var STEP_ICON = { pending: "bi-circle", running: "bi-arrow-repeat", done: "bi-check-circle-fill", failed: "bi-x-circle-fill", stopped: "bi-stop-circle" };

    function big(items) {
        var box = $("#bn-big");
        var keys = items.map(function (i) { return i.k; }).join("|");
        if (box.getAttribute("data-keys") !== keys) {
            box.setAttribute("data-keys", keys);
            box.innerHTML = items.map(function (i) {
                return '<div class="bn-num" data-k="' + i.k + '" style="--c:' + i.color + '"><span class="bn-num-v" data-v="0">0</span>' +
                    '<small>' + esc(i.unit) + '</small><span class="bn-num-l">' + esc(i.label) + "</span></div>";
            }).join("");
        }
        items.forEach(function (i) { tween($('[data-k="' + i.k + '"] .bn-num-v', box), i.v, i.dec || 0); });
    }

    function render(d) {
        var m = d.meta, k = m.kind, L = d.live || [];
        $("#bn-title").textContent = (m.title ? m.title + " · " : "") + NAMES[k];
        var sub = k === "fio" ? (m.target || {}).label + " · " + (m.profile === "completo" ? "perfil completo" : "perfil rápido") + " · " + m.size_gb + " GB"
            : k === "iperf" ? m.server + ":" + m.port + " · " + m.proto.toUpperCase() + " · -P " + m.streams + " · " + m.direction
            : (m.engine === "speedtest" ? "Speedtest.net" : "Cloudflare");
        $("#bn-sub").textContent = sub;
        var running = m.state === "running" || m.state === "queued";
        live.classList.toggle("is-running", running);
        var stLabel = { running: "rodando", queued: "na fila", done: "concluído", partial: "parcial", failed: "falhou", stopped: "interrompido" }[m.state] || m.state;
        $("#bn-state").innerHTML = '<span class="badge ' + (running ? "bn-run" : m.state === "done" ? "badge-up" : m.state === "failed" ? "badge-err" : "badge-warn") + '">' +
            (running ? '<span class="bn-pulse"></span>' : "") + esc(stLabel) + "</span>";
        $("#bn-stop").hidden = !running;
        var rep = $("#bn-report"); rep.hidden = !d.report; rep.href = "/benchmark/relatorio/" + d.id;

        // etapas
        var now = Date.now() / 1000, total = k === "fio" ? m.runtime : k === "iperf" ? m.duration : 12;
        $("#bn-steps").innerHTML = m.steps.map(function (s) {
            var pct = s.state === "done" ? 100 : s.state === "running" && s.started ? Math.min(98, (now - s.started) / (total + 2) * 100) : 0;
            return '<div class="bn-step s-' + s.state + '"><i class="bi ' + STEP_ICON[s.state] + '"></i><span>' + esc(s.title) + "</span>" +
                '<span class="bn-step-bar"><span style="width:' + pct.toFixed(1) + '%"></span></span></div>';
        }).join("");

        var navy = css("--brand-navy") || "#183b90", teal = css("--accent-teal") || "#00b8c0";
        if (document.documentElement.classList.contains("dark-mode")) navy = "#8aa0e6";
        if (k === "fio") {
            var step = m.step || (m.steps.filter(function (s) { return s.state === "done"; }).slice(-1)[0] || {}).key;
            var pts = L.filter(function (p) { return p.step === step; });
            var small = /RAND|MIXED|LATENCY/.test(step || "");
            var rk = small ? "r_iops" : "r_mbps", wk = small ? "w_iops" : "w_mbps";
            var sr = pts.filter(function (p) { return p[rk] > 0; }).map(function (p) { return [p.t, p[rk]]; });
            var sw = pts.filter(function (p) { return p[wk] > 0; }).map(function (p) { return [p.t, p[wk]]; });
            var series = [];
            if (sr.length) series.push({ name: "Leitura", color: navy, data: sr });
            if (sw.length) series.push({ name: "Gravação", color: teal, data: sw });
            chart.set(series, small ? "IOPS" : "MB/s");
            var res = d.result || {}, sq = (res.SEQ_READ || {}).read, sqw = (res.SEQ_WRITE || {}).write, rr = (res.RAND_READ || {}).read, lt = (res.LATENCY || {}).read;
            var lastp = pts[pts.length - 1] || {};
            var items = [];
            if (running) items.push({ k: "now", label: "agora (" + (small ? "IOPS" : "MB/s") + ")", unit: small ? "IOPS" : "MB/s",
                v: (lastp[rk] || 0) + (lastp[wk] || 0), color: navy });
            items.push({ k: "sr", label: "leitura sequencial", unit: "MB/s", v: sq ? sq.mbps : null, color: navy });
            items.push({ k: "sw", label: "gravação sequencial", unit: "MB/s", v: sqw ? sqw.mbps : null, color: teal });
            if (m.profile === "completo") {
                items.push({ k: "rr", label: "leitura aleatória 4K", unit: "IOPS", v: rr ? rr.iops : null, color: navy });
                items.push({ k: "lt", label: "latência de leitura", unit: "ms", v: lt ? lt.lat_ms : null, color: teal, dec: 3 });
            }
            big(items);
            legend(series);
        } else if (k === "iperf") {
            var a = L.map(function (p) { return [p.t, p.gbps]; }), b = L.filter(function (p) { return p.gbps_rev != null; }).map(function (p) { return [p.t, p.gbps_rev]; });
            var ser = [{ name: b.length ? "ida" : "banda", color: navy, data: a }];
            if (b.length) ser.push({ name: "volta", color: teal, data: b });
            chart.set(ser, "Gb/s");
            var r = (d.result || {}).iperf, lp = L[L.length - 1] || {};
            var it = [{ k: "g", label: running ? "agora" : "banda média", unit: "Gb/s", v: running ? lp.gbps : (r ? r.gbps : null), color: navy, dec: 2 }];
            if (b.length || (r && r.gbps_rev)) it.push({ k: "gr", label: running ? "volta agora" : "volta (média)", unit: "Gb/s", v: running ? lp.gbps_rev : r.gbps_rev, color: teal, dec: 2 });
            if (m.proto === "tcp") it.push({ k: "rt", label: "retransmissões", unit: "", v: r ? r.retransmits : L.reduce(function (s, p) { return s + (p.retr || 0); }, 0), color: teal });
            else if (r) it.push({ k: "lo", label: "perda", unit: "%", v: r.lost_pct, color: teal, dec: 2 });
            big(it);
            legend(ser);
        } else {
            var dn = L.filter(function (p) { return p.step === "down"; }).map(function (p) { return [p.t, p.mbps]; });
            var up = L.filter(function (p) { return p.step === "up"; }).map(function (p) { return [p.t, p.mbps]; });
            var s2 = [];
            if (dn.length) s2.push({ name: "Download", color: navy, data: dn });
            if (up.length) s2.push({ name: "Upload", color: teal, data: up });
            chart.set(s2, "Mb/s");
            legend(s2);
            var ri = (d.result || {}).internet || {};
            var cur = m.step, lst = L[L.length - 1] || {};
            var pings = L.filter(function (p) { return p.step === "ping" && p.ms; });
            gauge("down", ri.down_mbps != null ? ri.down_mbps : (cur === "down" ? lst.mbps : (stepVal(m, "down"))), cur === "down");
            gauge("up", ri.up_mbps != null ? ri.up_mbps : (cur === "up" ? lst.mbps : (stepVal(m, "up"))), cur === "up");
            var pv = ri.ping_ms != null ? ri.ping_ms : (pings.length ? pings[pings.length - 1].ms : null);
            var pe = $("[data-ping]"); if (pe) tween(pe, pv, 0);
            var je = $("[data-jitter]"); if (je) je.textContent = ri.jitter_ms != null ? fmt(ri.jitter_ms, 1) : "—";
            var ie = $("[data-isp]"); if (ie) ie.innerHTML = ri.isp ? '<i class="bi bi-building"></i> ' + esc(ri.isp) + (ri.ip ? " · " + esc(ri.ip) : "") + (ri.colo ? " · " + esc(ri.colo) : "") : "";
            $("#bn-big").innerHTML = "";
        }

        var err = $("#bn-error");
        err.hidden = !(m.error && (m.state === "failed" || m.state === "partial"));
        if (!err.hidden) $("span:last-child", err).textContent = m.error;
        var done = $("#bn-done");
        done.hidden = !(m.state === "done" || m.state === "partial");
        if (!done.hidden) done.innerHTML = '<i class="bi bi-check2-circle"></i> <strong>' + esc(d.summary || "Concluído") + "</strong>" +
            (d.report ? ' <a href="/benchmark/relatorio/' + d.id + '" target="_blank" rel="noopener">abrir o relatório</a> · <a href="/benchmark/relatorio/' + d.id + '?baixar=1">baixar</a>' : "");
        return running;
    }
    function stepVal(m, k) { var s = m.steps.filter(function (x) { return x.key === k; })[0]; return s && s.value != null ? s.value : 0; }
    function legend(series) {
        $("#bn-leg").innerHTML = series.map(function (s) { return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + "</span>"; }).join("");
    }

    function watch(id, scroll) {
        if (!live) { location.reload(); return; }
        current = id;
        live.hidden = false;
        live.classList.add("bn-in");
        if (scroll) live.scrollIntoView({ behavior: "smooth", block: "start" });
        if (form) form.classList.add("bn-locked");
        clearTimeout(timer);
        var anim = null;
        (function frame() { if (chart) chart.draw(); anim = requestAnimationFrame(frame); })();
        function poll() {
            api("/api/benchmark/teste/" + id).then(function (d) {
                if (!d.ok) return;
                var running = render(d);
                if (running && current === id) timer = setTimeout(poll, 1000);
                else {
                    if (form) form.classList.remove("bn-locked");
                    cancelAnimationFrame(anim); if (chart) chart.draw();
                    if (d.meta.state === "done") toast("Teste concluído: " + (d.summary || ""), false);
                }
            }).catch(function () { timer = setTimeout(poll, 3000); });
        }
        poll();
    }
    if (live) {
        $("#bn-stop").addEventListener("click", function () {
            if (!current || !confirm("Interromper o teste? Os dados de teste são apagados.")) return;
            this.disabled = true;
            var b = this;
            api("/api/benchmark/teste/" + current + "/parar", {}).then(function (d) { b.disabled = false; toast(d.message || "Interrompido.", !d.ok); });
        });
        if (live.getAttribute("data-test")) watch(live.getAttribute("data-test"), false);
    }
    $$("[data-bn-watch]").forEach(function (b) {
        b.addEventListener("click", function () { watch(b.getAttribute("data-bn-watch"), true); });
    });

    /* ---------------- servidor iperf3 ------------------------------- */
    var srv = $("#bn-srv");
    if (srv) {
        var srvTimer = null;
        function srvRender(s) {
            srv.classList.toggle("on", !!s.active);
            $("#bn-srv-on").hidden = !!s.active; $("#bn-srv-off").hidden = !s.active;
            $("#bn-srv-state").innerHTML = s.active ? '<span class="sys-ok"><span class="zbx-dot on"></span> escutando</span>' : '<span class="nic-sub">desligado</span>';
            var p = $("[data-port]"); if (p) p.textContent = s.port;
            var fw = $("#bn-srv-fw");
            fw.innerHTML = s.active && s.firewall && s.firewall.firewall ? (s.firewall.open ? '<i class="bi bi-shield-check"></i> Porta liberada no firewall enquanto o servidor estiver ligado.'
                : '<i class="bi bi-exclamation-triangle"></i> O firewall foi reaplicado e fechou a porta: desligue e ligue o servidor.') : "";
            var tb = $("#bn-recv"), seen = tb.getAttribute("data-n");
            if (s.tests && s.tests.length) {
                tb.innerHTML = s.tests.map(function (t, i) {
                    return '<tr class="' + (seen !== null && i < s.tests.length - parseInt(seen, 10) ? "bn-new" : "") + '"><td class="nic-sub">' + esc(t.when) + '</td><td class="mono">' + esc(t.client) + "</td><td>" + esc(t.proto) + " -P " + esc(t.streams) + (t.reverse ? " -R" : "") +
                        '</td><td class="n"><strong>' + fmt(t.gbps, 2) + "</strong> Gb/s</td></tr>";
                }).join("");
            }
            tb.setAttribute("data-n", (s.tests || []).length);
        }
        function srvPoll() {
            api("/api/benchmark/servidor").then(function (s) { srvRender(s); if (s.active) srvTimer = setTimeout(srvPoll, 3000); });
        }
        function srvAct(action) {
            var port = parseInt($("#bn-srv-port").value, 10) || 5201;
            api("/api/benchmark/servidor", { action: action, port: port }).then(function (d) {
                toast(d.message || (d.ok ? "Feito." : "Falhou."), !d.ok);
                clearTimeout(srvTimer); srvPoll();
            });
        }
        $("#bn-srv-on").addEventListener("click", function () { srvAct("start"); });
        $("#bn-srv-off").addEventListener("click", function () { srvAct("stop"); });
        $("#bn-recv").setAttribute("data-n", $$("#bn-recv tr:not(.bn-recv-empty)").length);
        if (srv.getAttribute("data-active") === "1") srvTimer = setTimeout(srvPoll, 3000);
    }
})();
