/* =====================================================================
   NewOS Panel - tema claro / escuro
   ---------------------------------------------------------------------
   O tema e do USUARIO (gravado no banco, coluna users.theme), como no
   kit NewIO: segue a pessoa entre navegadores e dispositivos. O servidor
   ja entrega o <html> com a classe certa; aqui so alternamos na hora e
   avisamos o servidor.
   ===================================================================== */
(function () {
    "use strict";

    var button = document.getElementById("themeSwitch");
    if (!button) return;

    button.addEventListener("click", function () {
        var root = document.documentElement;
        var dark = root.classList.toggle("dark-mode");

        fetch("/api/tema", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            body: JSON.stringify({ tema: dark ? "dark" : "light" })
        }).catch(function () {
            /* Sem rede: o tema vale nesta pagina e volta no proximo login. */
        });
    });
})();
