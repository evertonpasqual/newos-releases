/* =====================================================================
   NewOS Panel - Firewall: mapa animado das regras
   Origens (grupos, zonas, internet) -> escudo do NewOS -> servicos.
   - liberado: o caminho vai ate o servico, particulas teal/verde
   - bloqueado: o caminho para no escudo, particulas vermelhas que
     "batem" e somem
   - a quantidade de particulas segue os pacotes/s reais de cada regra
     (contadores do nftables, GET /api/firewall/mapa a cada 3 s)
   - passar o mouse num cartao ou caminho destaca so aquele fluxo
   Sem animacao para quem pediu "reduzir movimento".
   ===================================================================== */
(function () {
    "use strict";
    var root = document.getElementById("fw-map");
    if (!root) return;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var SVGNS = "http://www.w3.org/2000/svg";
    var srcBox = root.querySelector(".fwm-src"), dstBox = root.querySelector(".fwm-dst"), core = root.querySelector(".fwm-core");
    var svg = root.querySelector("svg.fwm-lines"), tip = root.querySelector(".fwm-tip");
    var flows = [], prev = null, prevT = 0, focus = null;

    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function rate(n) { return n >= 100 ? Math.round(n) + "/s" : n >= 1 ? n.toFixed(1).replace(".", ",") + "/s" : n > 0 ? "<1/s" : "0/s"; }
    var SVC = { 22: "SSH", 53: "DNS", 80: "HTTP", 123: "NTP", 161: "SNMP", 443: "HTTPS", 514: "Syslog", 3306: "MariaDB",
                8006: "Proxmox", 9090: "Prometheus", 9100: "node_exporter", 9101: "Bareos Director", 9102: "Bareos File",
                9103: "Bareos Storage", 10050: "Zabbix Agent", 10051: "Zabbix Proxy" };

    // ------------------------------------------------------------- modelo
    function build(d) {
        var st = d.state || {}, groups = {}, src = {}, dst = {}, out = [];
        (st.groups || []).forEach(function (g) { groups[g.id] = g; });
        function S(key, label, sub, kind, icon) {
            if (!src[key]) src[key] = { key: key, label: label, sub: sub, kind: kind, icon: icon };
            return key;
        }
        function D(key, label, sub, icon) {
            if (!dst[key]) dst[key] = { key: key, label: label, sub: sub, icon: icon };
            return key;
        }
        function gsub(g) {
            var it = g.items || [];
            if (it.indexOf("@qualquer") >= 0) return "qualquer origem";
            return it.slice(0, 2).map(function (x) {
                return { "@redes-locais": "redes do NewOS", "@redes-privadas": "redes privadas" }[x] || x.replace(/^@zona:/, "zona ");
            }).join(" · ") + (it.length > 2 ? " +" + (it.length - 2) : "");
        }
        function srcKeys(r) {
            var keys = [];
            (r.src_groups || []).forEach(function (gid) {
                var g = groups[gid];
                keys.push(S("g:" + gid, g ? g.name : gid, g ? gsub(g) : "grupo", "group", "bi-people"));
            });
            if (r.src_zone) keys.push(S("z:" + r.src_zone, "Zona " + ((d.zone_names || {})[r.src_zone] || r.src_zone), ((d.zones || {})[r.src_zone] || []).join(", "), "zone", "bi-diagram-3"));
            if ((r.src || []).length) keys.push(S("a:" + r.id, r.src[0], r.src.length > 1 ? "+" + (r.src.length - 1) + " endereço(s)" : "endereço", "addr", "bi-geo-alt"));
            if (!keys.length) keys.push(S("any", "Qualquer origem", "internet inclusive", "any", "bi-globe2"));
            return keys;
        }
        function svcKey(r) {
            if (r.port_group) {
                var g = groups[r.port_group];
                return D("pg:" + r.port_group, g ? g.name : r.port_group, g ? (g.items || []).join(", ") : "", "bi-plug");
            }
            var p = r.ports || "", first = parseInt(p, 10);
            var label = r.comment ? r.comment.replace(/ \(em uso ao ligar\)$/, "") : (SVC[first] || (p ? "porta " + p : "tudo"));
            return D("p:" + r.proto + ":" + p, label, ({ "tcp+udp": "tcp/udp", any: "todos", icmp: "ping" }[r.proto] || r.proto) + (p ? " " + p : ""), "bi-hdd-network");
        }
        // painel e SSH
        var panelKey = D("panel", "Painel do NewOS", "tcp " + (d.panel_port || 81), "bi-window-sidebar");
        out.push({ id: "painel", from: [S("g:painel-admin", "PAINEL-ADMIN", groups["painel-admin"] ? gsub(groups["painel-admin"]) : "", "group", "bi-shield-lock")], to: panelKey, ok: true, label: "Painel (porta " + (d.panel_port || 81) + ")" });
        var ssh = st.ssh || {}, sshKey = D("ssh", "SSH", ssh.enabled ? "tcp 22" : "bloqueado · console pela web", "bi-terminal");
        if (ssh.enabled) {
            out.push({ id: "ssh", from: (ssh.groups || []).map(function (gid) { var g = groups[gid]; return S("g:" + gid, g ? g.name : gid, g ? gsub(g) : "", "group", "bi-people"); }), to: sshKey, ok: true, label: "SSH" });
        } else {
            dst[sshKey].off = true;
        }
        (st.rules || []).forEach(function (r) {
            if (r.chain !== "input" || r.enabled === false) return;
            out.push({ id: r.id, from: srcKeys(r), to: svcKey(r), ok: r.action === "accept", label: r.comment || r.id, rule: r });
        });
        // o resto: bloqueado no escudo
        var rest = S("rest", "Todo o resto", "bloqueado por padrão", "rest", "bi-x-octagon");
        out.push({ id: "default-in", from: [rest], to: null, ok: false, label: "Bloqueado por padrão", extra: ["blocklist", "blocklist6", "geo", "bruteforce", "portscan", "autoblock", "synflood", "invalid"] });
        return { src: src, dst: dst, flows: out };
    }

    // ------------------------------------------------------------- desenho
    var model = null, cards = {}, paths = [];
    function card(n, side) {
        var el = document.createElement("div");
        el.className = "fwm-card " + (n.kind || "svc") + (n.off ? " off" : "");
        el.dataset.key = side + ":" + n.key;
        el.innerHTML = '<span class="fwm-ico"><i class="bi ' + n.icon + '"></i></span><span class="fwm-txt"><b>' + esc(n.label) + "</b><small>" + esc(n.sub || "") + '</small></span><span class="fwm-rate" data-rate>0/s</span>';
        return el;
    }
    function layout(m) {
        var sig = JSON.stringify([Object.keys(m.src), Object.keys(m.dst), m.flows.map(function (f) { return f.id + f.ok + f.from.join() + f.to; })]);
        if (sig === root.dataset.sig) return false;
        root.dataset.sig = sig;
        srcBox.innerHTML = ""; dstBox.innerHTML = ""; cards = {};
        Object.keys(m.src).forEach(function (k, i) { var c = card(m.src[k], "s"); c.style.setProperty("--i", i); srcBox.appendChild(c); cards["s:" + k] = c; });
        Object.keys(m.dst).forEach(function (k, i) { var c = card(m.dst[k], "d"); c.style.setProperty("--i", i); dstBox.appendChild(c); cards["d:" + k] = c; });
        return true;
    }
    function anchor(el, side) {
        var r = el.getBoundingClientRect(), b = root.getBoundingClientRect();
        return { x: (side === "right" ? r.right : r.left) - b.left, y: r.top + r.height / 2 - b.top };
    }
    function curve(a, b) {
        var dx = Math.max(60, (b.x - a.x) * 0.5);
        return "M" + a.x + "," + a.y + " C" + (a.x + dx) + "," + a.y + " " + (b.x - dx) + "," + b.y + " " + b.x + "," + b.y;
    }
    function draw() {
        if (!model) return;
        var b = root.getBoundingClientRect();
        svg.setAttribute("viewBox", "0 0 " + b.width + " " + b.height);
        svg.setAttribute("width", b.width); svg.setAttribute("height", b.height);
        svg.querySelectorAll(".fwm-path").forEach(function (p) { p.remove(); });
        paths = [];
        var cr = core.getBoundingClientRect(), cin = { x: cr.left - b.left + 8, y: cr.top + cr.height / 2 - b.top },
            cout = { x: cr.right - b.left - 8, y: cin.y };
        model.flows.forEach(function (f) {
            f.from.forEach(function (sk, i) {
                var sc = cards["s:" + sk]; if (!sc) return;
                var a = anchor(sc, "right"), d1 = curve(a, { x: cin.x, y: cin.y + (i - (f.from.length - 1) / 2) * 6 });
                var full = d1;
                if (f.ok && f.to && cards["d:" + f.to]) {
                    var e = anchor(cards["d:" + f.to], "left");
                    // atravessa por baixo do escudo (o SVG fica atras dele)
                    full = d1 + " L" + cout.x + "," + cout.y + " " + curve(cout, e).replace(/^M[\d.,-]+ /, "");
                }
                var p = document.createElementNS(SVGNS, "path");
                p.setAttribute("d", full);
                p.setAttribute("class", "fwm-path " + (f.ok ? "ok" : "no"));
                p.dataset.flow = f.id; p.dataset.src = sk; p.dataset.dst = f.to || "";
                svg.insertBefore(p, svg.firstChild);
                paths.push({ el: p, flow: f, src: sk, len: 0, seg: null });
            });
        });
        paths.forEach(function (p) { p.len = p.el.getTotalLength(); });
    }

    // ------------------------------------------------------------- particulas
    var dots = [], last = 0;
    function spawn(p) {
        var c = document.createElementNS(SVGNS, "circle");
        c.setAttribute("r", p.flow.ok ? 3.2 : 3);
        c.setAttribute("class", "fwm-dot " + (p.flow.ok ? "ok" : "no"));
        svg.appendChild(c);
        dots.push({ el: c, p: p, t: 0, dur: p.flow.ok ? 2600 : 1500 });
    }
    function burst(x, y) {
        var c = document.createElementNS(SVGNS, "circle");
        c.setAttribute("cx", x); c.setAttribute("cy", y); c.setAttribute("r", 3);
        c.setAttribute("class", "fwm-burst");
        svg.appendChild(c);
        setTimeout(function () { c.remove(); }, 650);
    }
    function frame(ts) {
        var dt = last ? Math.min(ts - last, 100) : 16; last = ts;
        paths.forEach(function (p) {
            var r = p.flow.pps || 0;
            if (focus && focus !== p.flow.id && focus !== "s:" + p.src && focus !== "d:" + p.flow.to) return;
            var want = r > 0 ? Math.min(6, 0.5 + Math.log10(1 + r) * 1.8) : 0;       // particulas por segundo
            p.acc = (p.acc || 0) + want * dt / 1000;
            while (p.acc >= 1) { p.acc -= 1; spawn(p); }
        });
        dots = dots.filter(function (d) {
            d.t += dt;
            var k = d.t / d.dur, len = d.p.len;
            if (k >= 1) {
                if (!d.p.flow.ok) { var e = d.p.el.getPointAtLength(len); burst(e.x, e.y); }
                d.el.remove(); return false;
            }
            var pt = d.p.el.getPointAtLength(len * k);
            d.el.setAttribute("cx", pt.x); d.el.setAttribute("cy", pt.y);
            d.el.style.opacity = k < 0.1 ? k * 10 : k > 0.9 ? (1 - k) * 10 : 1;
            return true;
        });
        requestAnimationFrame(frame);
    }

    // ------------------------------------------------------------- dados
    function counter(cnt, id) { return (cnt[id] || {}).packets || 0; }
    function load() {
        fetch("/api/firewall/mapa", { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (d) {
            if (!d.ok) return;
            var m = build(d), changed = layout(m), now = Date.now() / 1000;
            model = m;
            var cnt = d.counters || {}, dt = prevT ? Math.max(now - prevT, 1) : 0, inOk = 0, inNo = 0;
            m.flows.forEach(function (f) {
                var ids = [f.id].concat(f.extra || []), tot = 0;
                ids.forEach(function (i) { tot += counter(cnt, i); });
                f.total = tot;
                f.pps = prev && dt ? Math.max(0, (tot - (prev[f.id] || 0)) / dt) : 0;
                if (f.ok) inOk += f.pps; else inNo += f.pps;
            });
            // taxa em cada cartao
            Object.keys(cards).forEach(function (k) {
                var sum = 0;
                m.flows.forEach(function (f) {
                    if (k === "d:" + f.to || f.from.some(function (s) { return k === "s:" + s; })) sum += f.pps || 0;
                });
                var el = cards[k].querySelector("[data-rate]"); el.textContent = rate(sum);
                cards[k].classList.toggle("hot", sum > 0);
            });
            prev = {}; m.flows.forEach(function (f) { prev[f.id] = f.total; }); prevT = now;
            core.querySelector("[data-ok]").textContent = rate(inOk);
            core.querySelector("[data-no]").textContent = rate(inNo);
            core.classList.toggle("off", !d.active);
            core.querySelector("[data-state]").textContent = d.active ? "protegendo" : "desligado";
            if (changed) requestAnimationFrame(draw);
            else paths.forEach(function (p) { p.flow = m.flows.filter(function (f) { return f.id === p.flow.id; })[0] || p.flow; });
        }).catch(function () {}).finally(function () { setTimeout(load, 3000); });
    }

    // ------------------------------------------------------------- foco e dica
    function setFocus(key) {
        focus = key;
        root.classList.toggle("focusing", !!key);
        paths.forEach(function (p) {
            var on = !key || key === p.flow.id || key === "s:" + p.src || key === "d:" + p.flow.to;
            p.el.classList.toggle("lit", !!key && on);
        });
        Object.keys(cards).forEach(function (k) {
            var on = !key || k === key || paths.some(function (p) {
                return (key === "s:" + p.src || key === "d:" + p.flow.to || key === p.flow.id) && (k === "s:" + p.src || k === "d:" + p.flow.to);
            });
            cards[k].classList.toggle("lit", !!key && on);
        });
    }
    root.addEventListener("mouseover", function (e) {
        var c = e.target.closest(".fwm-card");
        var p = e.target.closest(".fwm-path");
        if (c) setFocus(c.dataset.key);
        else if (p) {
            setFocus(p.dataset.flow);
            var f = paths.filter(function (x) { return x.el === p; })[0].flow;
            tip.innerHTML = "<b>" + esc(f.label) + "</b><br>" + (f.ok ? '<span class="ok">liberado</span>' : '<span class="no">bloqueado</span>') + " · " + rate(f.pps || 0) + " · " + (f.total || 0).toLocaleString("pt-BR") + " pacotes";
            tip.hidden = false;
        }
    });
    root.addEventListener("mousemove", function (e) {
        if (tip.hidden) return;
        var b = root.getBoundingClientRect();
        tip.style.left = (e.clientX - b.left + 14) + "px"; tip.style.top = (e.clientY - b.top + 14) + "px";
    });
    root.addEventListener("mouseout", function (e) {
        if (!e.relatedTarget || !root.contains(e.relatedTarget) || (!e.relatedTarget.closest(".fwm-card") && !e.relatedTarget.closest(".fwm-path"))) {
            setFocus(null); tip.hidden = true;
        }
    });
    window.addEventListener("resize", function () { clearTimeout(root._rz); root._rz = setTimeout(draw, 150); });

    load();
    if (!reduce) requestAnimationFrame(frame);
})();
