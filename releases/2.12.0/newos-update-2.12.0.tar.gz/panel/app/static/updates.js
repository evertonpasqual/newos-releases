/* =====================================================================
   NewOS Panel - Sistema > Atualizacoes
   Acompanha a atualizacao ao vivo. No fim o painel reinicia: as falhas
   de conexao nesse intervalo sao esperadas; a tela continua tentando e
   recarrega quando a versao nova responde.
   ===================================================================== */
(function () {
    "use strict";
    var box = document.getElementById("upd-run");
    if (!box || box.getAttribute("data-status") !== "running") return;
    var logBox = document.getElementById("upd-log");
    var title = document.getElementById("upd-title");
    var msg = document.getElementById("upd-msg");

    function esc(t) { var d = document.createElement("div"); d.textContent = t; return d.innerHTML; }

    var timer = setInterval(function () {
        fetch("/api/atualizacao/status", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) return;
                logBox.innerHTML = (d.log || []).map(function (l) {
                    return '<div class="bk-log-line ' + (/ERRO|FALHOU/.test(l) ? "err" : "") + '"><span class="bk-log-text">' + esc(l) + "</span></div>";
                }).join("");
                logBox.scrollTop = logBox.scrollHeight;
                var st = (d.state || {}).status;
                if (st && st !== "running") {
                    clearInterval(timer);
                    title.textContent = st === "done" ? "Atualização concluída" : "A atualização falhou";
                    msg.textContent = (d.state || {}).message || "";
                    setTimeout(function () { location.reload(); }, 2500);
                }
            })
            .catch(function () { msg.textContent = "painel reiniciando…"; });
    }, 2500);
})();
