/* =====================================================================
   NewFront · menu lateral recolhivel (NewOS e NewOS Manager: arquivo igual)
   ---------------------------------------------------------------------
   - botao no alto da sidebar: menu inteiro <-> so os icones
   - o estado fica no navegador (localStorage "nf.nav.mini"); o <head>
     ja aplica a classe antes de desenhar (sem "pulo")
   - com o menu recolhido, passar o mouse mostra o nome do item
   - atalho: Ctrl/Cmd + B; link direto: ?menu=mini ou ?menu=cheio
   ===================================================================== */
(function () {
    "use strict";
    var KEY = "nf.nav.mini";
    var root = document.documentElement;
    var side = document.querySelector(".sidebar");
    if (!side) return;
    var want = /[?&]menu=(mini|cheio)\b/.exec(location.search);   // link direto: ?menu=mini
    if (want) root.classList.toggle("nav-mini", want[1] === "mini");

    function save(v) { try { localStorage.setItem(KEY, v ? "1" : "0"); } catch (e) { /* sem storage */ } }
    function set(mini) {
        root.classList.toggle("nav-mini", mini);
        btn.setAttribute("aria-label", mini ? "Abrir o menu" : "Recolher o menu");
        btn.setAttribute("aria-pressed", mini ? "true" : "false");
        btn.title = (mini ? "Abrir o menu" : "Recolher o menu") + " (Ctrl+B)";
        save(mini);
    }

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "nav-toggle";
    btn.innerHTML = '<i class="bi bi-chevron-double-left" aria-hidden="true"></i>';
    side.insertBefore(btn, side.firstChild);
    set(root.classList.contains("nav-mini"));
    btn.addEventListener("click", function () { set(!root.classList.contains("nav-mini")); });
    document.addEventListener("keydown", function (e) {
        if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === "b" || e.key === "B")) {
            var t = e.target;
            if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
            e.preventDefault();
            set(!root.classList.contains("nav-mini"));
        }
    });

    // dica com o nome do item (so com o menu recolhido)
    var tip = document.createElement("div");
    tip.className = "nav-tip";
    tip.setAttribute("role", "tooltip");
    document.body.appendChild(tip);
    function label(el) {
        var s = el.querySelector(".nav-group-title span");
        return ((s ? s.textContent : el.textContent) || "").replace(/\s+/g, " ").trim();
    }
    function show(el) {
        if (!root.classList.contains("nav-mini")) return;
        var text = label(el);
        if (!text) return;
        tip.textContent = text;
        var r = el.getBoundingClientRect();
        tip.style.left = (r.right + 14) + "px";
        tip.style.top = (r.top + r.height / 2 - 15) + "px";
        tip.classList.add("on");
    }
    function hide() { tip.classList.remove("on"); }
    side.querySelectorAll(".nav > a, .sidebar-foot a").forEach(function (a) {
        a.addEventListener("mouseenter", function () { show(a); });
        a.addEventListener("mouseleave", hide);
        a.addEventListener("focus", function () { show(a); });
        a.addEventListener("blur", hide);
        if (!a.getAttribute("aria-label")) a.setAttribute("aria-label", label(a));
    });
    window.addEventListener("scroll", hide, { passive: true });

    requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.remove("nav-boot"); }); });
})();
