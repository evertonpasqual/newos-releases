"""
NewOS Panel - modulo Benchmark (fio, iperf3, velocidade de internet).

    /benchmark                          visao geral + historico
    /benchmark/disco                    fio: escolhe onde, perfil, acompanha ao vivo
    /benchmark/rede                     iperf3: servidor e cliente
    /benchmark/internet                 download / upload / latencia
    /benchmark/relatorio/<id>           relatorio HTML (identidade NewOS)
    POST /benchmark/teste/<id>/apagar
    POST /api/benchmark/iniciar         {"kind": ...}            -> {"id"}
    GET  /api/benchmark/teste/<id>      estado + amostras ao vivo
    POST /api/benchmark/teste/<id>/parar
    GET  /api/benchmark/servidor        servidor iperf3 + testes recebidos
    POST /api/benchmark/servidor        {"action": "start"|"stop", "port"}

O helper newos-bench executa tudo fora do sandbox do painel, um teste por
vez; o relatorio e gerado no fim de cada teste.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules

log = logging.getLogger("newos.panel.benchmark")
HELPER = "/usr/local/sbin/newos-bench"
BASE = Path("/var/lib/newos/bench")
ID_RE = re.compile(r"^\d{8}-\d{6}-(fio|iperf|internet)$")


class BenchError(Exception):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args],
                              input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise BenchError(f"Nao foi possivel executar o helper do benchmark: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise BenchError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("benchmark") or {}).get("enabled"))

    def guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Benchmark em Sistema > Módulos.")
            return None, redirect("/modulos")
        return user, None

    def api_guard(request: Request) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão encerrada."}, status_code=401)
        if not enabled():
            return None, JSONResponse({"ok": False, "message": "Módulo Benchmark desligado."}, status_code=409)
        return user, None

    async def tests(kind: str | None = None) -> tuple[list[dict[str, Any]], str | None]:
        try:
            data = await run_in_threadpool(helper, ["list"])
        except BenchError as exc:
            log.warning("Historico do benchmark: %s", exc)
            return [], None
        items = data.get("tests", [])
        if kind:
            items = [t for t in items if t["kind"] == kind]
        return items, data.get("running")

    async def server() -> dict[str, Any]:
        try:
            return await run_in_threadpool(helper, ["server-status"])
        except BenchError as exc:
            return {"active": False, "error": str(exc), "tests": [], "ips": [], "port": 5201, "firewall": {}}

    @app.get("/benchmark", response_class=HTMLResponse)
    async def bench_overview(request: Request):
        _, bad = guard(request)
        if bad:
            return bad
        items, running = await tests()
        last = {}
        for t in items:
            if t["state"] in ("done", "partial") and t["kind"] not in last:
                last[t["kind"]] = t
        return render(request, "benchmark_overview.html", active="benchmark", tests=items,
                      running=running, last=last, srv=await server())

    @app.get("/benchmark/disco", response_class=HTMLResponse)
    async def bench_disk(request: Request):
        _, bad = guard(request)
        if bad:
            return bad
        try:
            targets = await run_in_threadpool(helper, ["targets"])
        except BenchError as exc:
            flash(request, "erro", str(exc))
            targets = {"fs": [], "zfs": [], "disks": [], "tools": {}}
        items, running = await tests("fio")
        return render(request, "benchmark_disk.html", active="benchmark-disco", targets=targets,
                      tests=items, running=running)

    @app.get("/benchmark/rede", response_class=HTMLResponse)
    async def bench_net(request: Request):
        _, bad = guard(request)
        if bad:
            return bad
        items, running = await tests("iperf")
        return render(request, "benchmark_net.html", active="benchmark-rede", tests=items,
                      running=running, srv=await server())

    @app.get("/benchmark/internet", response_class=HTMLResponse)
    async def bench_inet(request: Request):
        _, bad = guard(request)
        if bad:
            return bad
        items, running = await tests("internet")
        return render(request, "benchmark_internet.html", active="benchmark-internet", tests=items,
                      running=running)

    @app.get("/benchmark/relatorio/{tid}")
    async def bench_report(request: Request, tid: str):
        _, bad = guard(request)
        if bad:
            return bad
        path = BASE / tid / "relatorio.html"
        if not ID_RE.match(tid) or not path.is_file():
            flash(request, "erro", "Relatório não encontrado.")
            return redirect("/benchmark")
        if request.query_params.get("baixar"):
            return FileResponse(path, media_type="text/html", filename=f"newos-benchmark-{tid}.html")
        return FileResponse(path, media_type="text/html", headers={"Cache-Control": "no-store"})

    @app.post("/benchmark/teste/{tid}/apagar")
    async def bench_delete(request: Request, tid: str):
        user, bad = guard(request)
        if bad:
            return bad
        back = "/benchmark"
        m = ID_RE.match(tid)
        if m:
            back = {"fio": "/benchmark/disco", "iperf": "/benchmark/rede", "internet": "/benchmark/internet"}[m.group(1)]
        try:
            res = await run_in_threadpool(helper, ["delete", tid])
            db.log_audit(user["username"], "benchmark", f"apagou o teste {tid}", auth.client_ip(request))
            flash(request, "ok", res["message"])
        except BenchError as exc:
            flash(request, "erro", str(exc))
        return redirect(request.query_params.get("voltar") or back)

    # ---------------------------------------------------------------- API
    @app.post("/api/benchmark/iniciar")
    async def bench_start(request: Request):
        user, bad = api_guard(request)
        if bad:
            return bad
        try:
            body = await request.json()
        except ValueError:
            return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)
        body["user"] = user["username"]
        try:
            res = await run_in_threadpool(helper, ["start"], body)
        except BenchError as exc:
            return {"ok": False, "message": str(exc)}
        what = {"fio": "disco", "iperf": "rede", "internet": "internet"}.get(body.get("kind"), "?")
        db.log_audit(user["username"], "benchmark", f"iniciou teste de {what} ({res['id']})", auth.client_ip(request))
        return res

    @app.get("/api/benchmark/teste/{tid}")
    async def bench_status(request: Request, tid: str):
        _, bad = api_guard(request)
        if bad:
            return bad
        try:
            return await run_in_threadpool(helper, ["status", tid])
        except BenchError as exc:
            return JSONResponse({"ok": False, "message": str(exc)}, status_code=404)

    @app.post("/api/benchmark/teste/{tid}/parar")
    async def bench_stop(request: Request, tid: str):
        user, bad = api_guard(request)
        if bad:
            return bad
        try:
            res = await run_in_threadpool(helper, ["stop", tid])
        except BenchError as exc:
            return {"ok": False, "message": str(exc)}
        db.log_audit(user["username"], "benchmark", f"interrompeu o teste {tid}", auth.client_ip(request))
        return res

    @app.get("/api/benchmark/servidor")
    async def bench_server_status(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        return await server()

    @app.post("/api/benchmark/servidor")
    async def bench_server(request: Request):
        user, bad = api_guard(request)
        if bad:
            return bad
        try:
            body = await request.json()
            res = await run_in_threadpool(helper, ["iperf-server"], {"action": body.get("action"),
                                                                      "port": body.get("port")})
        except ValueError:
            return JSONResponse({"ok": False, "message": "Pedido inválido."}, status_code=400)
        except BenchError as exc:
            return {"ok": False, "message": str(exc)}
        db.log_audit(user["username"], "benchmark",
                     f"servidor iperf3 {'ligado' if body.get('action') == 'start' else 'desligado'}",
                     auth.client_ip(request))
        return res
