"""
NewOS Panel - modulo Prometheus.

    - configuracao: pelo helper newos-prometheus (gera e valida tudo)
    - estado ao vivo: direto da API do Prometheus local (alvos, series,
      remote_write, ingestao), sem precisar de root
"""

from __future__ import annotations

import json
import logging
import subprocess
import time
import urllib.parse
import urllib.request
from typing import Any

log = logging.getLogger("newos.panel.prometheus")

HELPER = "/usr/local/sbin/newos-prometheus"
API = "http://127.0.0.1:9090"


class PromError(Exception):
    """Erro para mostrar ao administrador."""


def _helper(args: list[str], stdin: Any = None, timeout: int = 600) -> dict[str, Any]:
    data = None if stdin is None else (stdin if isinstance(stdin, str) else json.dumps(stdin))
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], input=data, capture_output=True,
                              text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise PromError("A operacao demorou demais.") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise PromError(f"Nao foi possivel executar o helper do Prometheus: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout or "").splitlines()
                 if ln.strip() and not ln.startswith("[prometheus]")]
        raise PromError((lines[-1] if lines else f"codigo {proc.returncode}").removeprefix("ERRO: "))
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError) as exc:
        raise PromError("Resposta invalida do helper do Prometheus.") from exc


def state() -> dict[str, Any]:
    return _helper(["state"], timeout=60)["state"]


def apply(section: str, data: dict[str, Any], op: str = "save") -> str:
    return _helper(["apply"], {"section": section, "op": op, "data": data}).get("message", "")


def apply_full(section: str, data: dict[str, Any], op: str = "save") -> dict[str, Any]:
    return _helper(["apply"], {"section": section, "op": op, "data": data})


def raw_get() -> dict[str, Any]:
    return _helper(["raw-get"], timeout=30)


def raw_set(text: str) -> str:
    return _helper(["raw-set"], text).get("message", "")


def set_mode(mode: str) -> str:
    return _helper(["set-mode", mode]).get("message", "")


def test(kind: str, target: str, extra: str = "") -> dict[str, Any]:
    return _helper(["test", kind, target, *([extra] if extra else [])], timeout=300)


def versions() -> dict[str, Any]:
    return _helper(["versions"], timeout=120).get("versions", {})


def update(kind: str) -> str:
    return _helper(["install", kind], timeout=1800).get("message", "")


def rules() -> dict[str, Any]:
    return _helper(["rules"], timeout=300)


def import_preview(texts: dict[str, str]) -> dict[str, Any]:
    return _helper(["import-preview"], texts, timeout=900)


def import_apply(iid: str, options: dict[str, Any]) -> dict[str, Any]:
    return _helper(["import-apply", iid], options, timeout=900)


def dl_cache(project: str, arch: str) -> dict[str, Any]:
    """Pacote (node_exporter/zfs_exporter) em cache para os hosts sem internet."""
    return _helper(["dl-cache", project, arch], timeout=400)


# =====================================================================
#  API do Prometheus (somente leitura)
# =====================================================================

def _api(path: str, params: dict[str, Any] | None = None, timeout: int = 10) -> Any:
    url = API + path + ("?" + urllib.parse.urlencode(params) if params else "")
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            body = json.load(resp)
    except Exception as exc:  # noqa: BLE001
        raise PromError(f"O Prometheus nao respondeu: {exc}") from exc
    if body.get("status") != "success":
        raise PromError(body.get("error", "erro na consulta"))
    return body["data"]


def _scalar(query: str) -> float | None:
    try:
        res = _api("/api/v1/query", {"query": query})["result"]
    except PromError:
        return None
    try:
        return float(res[0]["value"][1]) if res else None
    except (KeyError, IndexError, ValueError):
        return None


def targets() -> list[dict[str, Any]]:
    try:
        data = _api("/api/v1/targets", {"state": "active"})
    except PromError:
        return []
    out = []
    for t in data.get("activeTargets", []):
        labels = t.get("labels", {})
        last = t.get("lastScrape", "")
        out.append({
            "job": labels.get("job", ""), "instance": labels.get("instance", ""),
            "health": t.get("health", "unknown"), "error": t.get("lastError", ""),
            "duration": t.get("lastScrapeDuration", 0), "last": last[:19].replace("T", " "),
            "url": t.get("scrapeUrl", ""), "address": t.get("discoveredLabels", {}).get("__address__", ""),
            "labels": labels,
        })
    return out


def overview() -> dict[str, Any]:
    tg = targets()
    jobs: dict[str, dict[str, int]] = {}
    for t in tg:
        j = jobs.setdefault(t["job"], {"up": 0, "down": 0})
        j["up" if t["health"] == "up" else "down"] += 1
    try:
        build = _api("/api/v1/status/buildinfo")
    except PromError:
        build = {}
    try:
        head = _api("/api/v1/status/tsdb").get("headStats", {})
    except PromError:
        head = {}
    series = []
    try:
        end = time.time()
        res = _api("/api/v1/query_range", {
            "query": "sum(rate(prometheus_tsdb_head_samples_appended_total[5m]))",
            "start": end - 6 * 3600, "end": end, "step": 900})["result"]
        series = [{"t": float(v[0]), "v": float(v[1])} for v in (res[0]["values"] if res else [])]
    except (PromError, KeyError, IndexError, ValueError):
        pass
    return {
        "online": bool(build), "version": build.get("version", ""),
        "targets": tg, "jobs": jobs,
        "up": sum(1 for t in tg if t["health"] == "up"),
        "down": sum(1 for t in tg if t["health"] != "up"),
        "series_count": head.get("numSeries"),
        "ingest": _scalar("sum(rate(prometheus_tsdb_head_samples_appended_total[5m]))"),
        "rw_failed": _scalar("sum(rate(prometheus_remote_storage_samples_failed_total[5m]))"),
        "rw_sent": _scalar("sum(rate(prometheus_remote_storage_samples_total[5m]))"),
        "rw_lag": _scalar("max(prometheus_remote_storage_highest_timestamp_in_seconds) "
                          "- max(prometheus_remote_storage_queue_highest_sent_timestamp_seconds)"),
        "storage_bytes": _scalar("prometheus_tsdb_storage_blocks_bytes + prometheus_tsdb_wal_storage_size_bytes"
                                 " or prometheus_tsdb_storage_blocks_bytes"),
        "chart": series,
    }


# =====================================================================
#  Alertas (Alertmanager + Telegram)
# =====================================================================

def alerts_detect() -> dict[str, Any]:
    return _helper(["alerts-detect"], timeout=60)


def alerts_test() -> dict[str, Any]:
    return _helper(["alerts-test"], timeout=60)


def active_alerts() -> list[dict[str, Any]]:
    try:
        data = _api("/api/v1/alerts")
    except PromError:
        return []
    # O mesmo alerta (nome + host + estado) vindo de varias series/regras
    # vira uma linha so, com a contagem: a tela fica limpa.
    seen: dict[tuple[str, str, str], dict[str, Any]] = {}
    for a in data.get("alerts", []):
        lb, an = a.get("labels", {}), a.get("annotations", {})
        item = {"name": lb.get("alertname", ""), "severity": lb.get("severity", "info"),
                "state": a.get("state", ""), "summary": an.get("summary", ""),
                "description": an.get("description", ""), "cluster": lb.get("cluster", ""),
                "host": lb.get("nodename") or lb.get("node") or lb.get("instance", ""),
                "since": (a.get("activeAt") or "")[:19].replace("T", " "), "count": 1}
        key = (item["name"], item["host"], item["state"])
        if key in seen:
            seen[key]["count"] += 1
            seen[key]["since"] = min(seen[key]["since"], item["since"])
        else:
            seen[key] = item
    order = {"critical": 0, "warning": 1, "info": 2}
    return sorted(seen.values(), key=lambda x: (x["state"] != "firing", order.get(x["severity"], 3), x["since"]))


def rule_groups() -> list[dict[str, Any]]:
    try:
        data = _api("/api/v1/rules", {"type": "alert"})
    except PromError:
        return []
    groups = []
    for g in data.get("groups", []):
        rules = g.get("rules", [])
        groups.append({"name": g.get("name", ""), "file": g.get("file", "").rsplit("/", 1)[-1],
                       "total": len(rules),
                       "firing": sum(1 for r in rules if r.get("state") == "firing"),
                       "pending": sum(1 for r in rules if r.get("state") == "pending")})
    return groups
