/* =====================================================================
   NewOS Panel - menu lateral
   ---------------------------------------------------------------------
   - clique no titulo do grupo: fixa aberto / fecha (lembrado no
     navegador); o mouse por cima abre so de passagem (CSS :hover)
   - o grupo da pagina atual ja vem aberto do servidor
   - entrada escalonada dos itens 1x por sessao
   ===================================================================== */
(function () {
    "use strict";

    var nav = document.querySelector(".nav");
    if (!nav) return;
    var KEY = "newos.nav.open";

    function load() {
        try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; }
    }
    function save(list) {
        try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* sem storage: so nesta pagina */ }
    }

    var pinned = load();
    nav.querySelectorAll(".nav-group[data-group]").forEach(function (g) {
        var id = g.getAttribute("data-group");
        var btn = g.querySelector(".nav-group-title");
        function set(open) {
            g.classList.toggle("open", open);
            btn.setAttribute("aria-expanded", open ? "true" : "false");
        }
        if (pinned.indexOf(id) !== -1) set(true);

        btn.addEventListener("click", function () {
            var open = !g.classList.contains("open");
            set(open);
            var list = load().filter(function (x) { return x !== id; });
            if (open) list.push(id);
            save(list);
            // fechado com o mouse ainda em cima: o :hover o manteria aberto
            if (!open) {
                g.classList.add("nav-shut");
                g.addEventListener("mouseleave", function off() {
                    g.classList.remove("nav-shut");
                    g.removeEventListener("mouseleave", off);
                });
            }
        });
    });

    try {
        if (!sessionStorage.getItem("newos.nav.intro")) {
            Array.prototype.forEach.call(nav.children, function (el, i) { el.style.setProperty("--n", i); });
            nav.classList.add("nav-intro");
            sessionStorage.setItem("newos.nav.intro", "1");
        }
    } catch (e) { /* sem storage: sem animacao de entrada */ }

    // Liga as transicoes so depois do 1o quadro (estado lembrado sem "pulo").
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { nav.classList.add("nav-ready"); });
    });
})();

/* Botao "Copiar" (data-copy="texto"): codigos de recuperacao etc. */
document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-copy]");
    if (!b) return;
    var text = b.getAttribute("data-copy");
    var done = function () {
        var old = b.innerHTML;
        b.innerHTML = '<i class="bi bi-check2"></i> Copiado';
        setTimeout(function () { b.innerHTML = old; }, 1800);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done);
    } else {
        var t = document.createElement("textarea");
        t.value = text; document.body.appendChild(t); t.select();
        try { document.execCommand("copy"); done(); } catch (err) { /* sem permissao */ }
        t.remove();
    }
});

/* =====================================================================
   Sessao inativa: conta o tempo sem uso; 60 s antes do fim avisa com
   contagem e "Continuar"; no fim leva ao login. Mexer na tela (mouse,
   teclado, toque) avisa o servidor no maximo 1x por minuto.
   ===================================================================== */
(function () {
    "use strict";
    var limit = parseInt(document.body.getAttribute("data-idle"), 10);
    if (!limit) return;
    var WARN = Math.min(60, Math.floor(limit / 3));
    var last = Date.now(), lastPing = Date.now(), dirty = false, box = null, num = null;

    function ping() {
        lastPing = Date.now(); dirty = false;
        fetch("/api/sessao/ativo", { method: "POST", credentials: "same-origin" })
            .then(function (r) { if (r.status === 401) window.location = "/login?motivo=inatividade"; })
            .catch(function () { /* sem rede agora: tenta no proximo movimento */ });
    }
    function used() {
        last = Date.now(); dirty = true;
        if (box) { box.remove(); box = null; ping(); }
        else if (Date.now() - lastPing > 60000) ping();
    }
    ["mousemove", "mousedown", "keydown", "touchstart", "wheel"].forEach(function (ev) {
        document.addEventListener(ev, used, { passive: true });
    });
    // formularios e links ja renovam no servidor: so zera o relogio local
    document.addEventListener("submit", function () { last = Date.now(); lastPing = Date.now(); });

    function warn(left) {
        if (!box) {
            box = document.createElement("div");
            box.className = "idle-warn";
            box.setAttribute("role", "alertdialog");
            box.innerHTML = '<div class="idle-card"><i class="bi bi-hourglass-split"></i>' +
                '<div><strong>Sua sessão vai expirar</strong><span>Por segurança, o painel desconecta em <b class="idle-n"></b> s sem uso.</span></div>' +
                '<button type="button" class="btn btn-sm">Continuar conectado</button></div>';
            document.body.appendChild(box);
            box.querySelector("button").addEventListener("click", function () { used(); });
            num = box.querySelector(".idle-n");
        }
        num.textContent = left;
    }
    var asking = false;
    function server(then) {          // outra aba pode estar em uso: o servidor decide
        if (asking) return;
        asking = true;
        fetch("/api/sessao", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.status === 401 ? { left: 0 } : r.json(); })
            .then(function (d) { asking = false; then(d.left || 0); })
            .catch(function () { asking = false; });
    }
    setInterval(function () {
        var idle = Math.floor((Date.now() - last) / 1000);
        var left = limit - idle;
        if (left <= WARN && !box) {
            server(function (srv) {
                if (srv > WARN) { last = Date.now() - (limit - srv) * 1000; }   // usada em outra aba
                else if (srv <= 0) { window.location = "/login?motivo=inatividade"; }
                else { last = Date.now() - (limit - srv) * 1000; warn(srv); }
            });
            return;
        }
        if (box) {
            if (left <= 0) {
                server(function (srv) {
                    if (srv > 0) { box.remove(); box = null; last = Date.now() - (limit - srv) * 1000; }
                    else { window.location = "/logout?motivo=inatividade"; }
                });
                return;
            }
            warn(left);
        } else if (dirty && Date.now() - lastPing > 60000) ping();
    }, 1000);
})();
