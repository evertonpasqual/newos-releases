/* =====================================================================
   NewOS Panel - Firewall
   - atalhos de servico preenchem protocolo e portas da regra
   - atividade ao vivo: novos pacotes entram no topo com destaque
   - contadores de cada regra atualizam sozinhos
   - filtro da atividade (bloqueado / automatico / liberado)
   ===================================================================== */
(function () {
    "use strict";

    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
    function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, "."); }

    /* ---------------- atalhos de servico -------------------------------- */
    document.querySelectorAll("[data-fw-presets]").forEach(function (box) {
        box.addEventListener("click", function (e) {
            var b = e.target.closest("[data-proto]");
            if (!b) return;
            var form = box.closest("form");
            form.querySelector("[name=proto]").value = b.getAttribute("data-proto");
            form.querySelector("[name=ports]").value = b.getAttribute("data-ports");
            var c = form.querySelector("[name=comment]");
            if (c && !c.value) c.value = b.textContent.trim();
            box.querySelectorAll("[data-proto]").forEach(function (x) { x.classList.toggle("on", x === b); });
        });
    });

    /* ---------------- filtro da atividade -------------------------------- */
    var filter = "*";
    var bar = document.querySelector("[data-fw-filter]");
    function applyFilter() {
        document.querySelectorAll("#fw-feed tr[data-a]").forEach(function (r) {
            r.hidden = !(filter === "*" || r.getAttribute("data-a") === filter);
        });
    }
    if (bar) {
        bar.addEventListener("click", function (e) {
            var b = e.target.closest("[data-f]");
            if (!b) return;
            filter = b.getAttribute("data-f");
            bar.querySelectorAll("[data-f]").forEach(function (x) { x.classList.toggle("on", x === b); });
            applyFilter();
        });
    }

    /* ---------------- ao vivo ------------------------------------------- */
    var WHY = { "in": "sem regra que libere", "fwd": "encaminhamento sem regra", "bruteforce": "muitas tentativas (força bruta)",
                "portscan": "varredura de portas", "blocklist": "na lista de bloqueio" };
    var feed = document.getElementById("fw-feed");
    var hitsEls = document.querySelectorAll("[data-hits]");
    if (!feed && !hitsEls.length) return;

    // Cada linha e um grupo (mesma origem, porta, resultado e motivo):
    // a repeticao so aumenta o contador e traz a linha para o topo.
    var shown = {};
    if (feed) {
        feed.querySelectorAll("tr[data-k]").forEach(function (r) {
            var c = r.querySelector(".fw-count");
            shown[r.getAttribute("data-k")] = { row: r, count: c ? parseInt(c.textContent.slice(1), 10) : 1 };
        });
    }

    function whyText(e) { return e.why_text || WHY[e.why] || e.why; }
    function cells(e) {
        var res = e.action === "accept" ? '<span class="fw-act acc"><i class="bi bi-check-lg"></i> liberado</span>'
            : e.action === "block" ? '<span class="fw-act blk"><i class="bi bi-person-x"></i> bloqueio auto</span>'
            : '<span class="fw-act drp"><i class="bi bi-x-lg"></i> bloqueado</span>';
        return '<td><span class="nic-sub mono">' + esc(e.time.slice(11)) + "</span></td><td>" + res + "</td>" +
            '<td><span class="mono">' + esc(e.src) + "</span>" + (e.zkey ? ' <span class="fw-zone fw-z-' + esc(e.zkey) + '">' + esc(e.zone) + "</span>" : "") + "</td>" +
            '<td><span class="mono">' + esc(e.proto) + (e.port ? "/" + esc(e.port) : "") + "</span>" + (e.service ? ' <span class="nic-sub">' + esc(e.service) + "</span>" : "") + "</td>" +
            '<td><span class="nic-sub">' + esc(whyText(e)) + "</span>" +
            (e.count > 1 ? ' <span class="fw-count" title="desde ' + esc(e.first.slice(11)) + '">×' + e.count + "</span>" : "") + "</td>";
    }

    function tick() {
        fetch("/api/firewall/atividade?segundos=3600", { credentials: "same-origin", cache: "no-store" })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (!d.ok) return;
                hitsEls.forEach(function (el) {
                    var c = d.counters[el.getAttribute("data-hits")];
                    var v = c ? fmt(c.packets) : "0";
                    if (el.textContent !== v) {
                        el.textContent = v;
                        el.classList.remove("bump"); void el.offsetWidth; el.classList.add("bump");
                    }
                });
                if (!feed) return;
                var changed = [];
                (d.events || []).forEach(function (e) {
                    var cur = shown[e.key];
                    if (cur && cur.count === e.count) return;
                    changed.push(e);
                });
                if (!changed.length) return;
                var empty = feed.querySelector(".fw-empty");
                if (empty) empty.remove();
                changed.reverse().forEach(function (e) {
                    var cur = shown[e.key];
                    var tr = cur ? cur.row : document.createElement("tr");
                    tr.setAttribute("data-a", e.action);
                    tr.setAttribute("data-k", e.key);
                    tr.innerHTML = cells(e);
                    tr.classList.remove("fw-new"); void tr.offsetWidth; tr.classList.add("fw-new");
                    feed.insertBefore(tr, feed.firstChild);
                    shown[e.key] = { row: tr, count: e.count };
                });
                while (feed.children.length > 80) {
                    var last = feed.lastChild;
                    delete shown[last.getAttribute("data-k")];
                    feed.removeChild(last);
                }
                applyFilter();
                var n = document.getElementById("fw-n-blocked");
                if (n) {
                    var tot = 0;
                    (d.events || []).forEach(function (e) { if (e.action !== "accept") tot += e.count; });
                    n.textContent = tot;
                }
            })
            .catch(function () { /* o painel pode estar reaplicando: tenta de novo */ });
    }
    tick();
    setInterval(tick, 4000);
})();
