#!/bin/bash
# =====================================================================================================
#  instalar-node-exporter.sh — node_exporter + coletores NewIO num único script
#
#  ./instalar-node-exporter.sh online   [--configure] [--pve-cluster NOME]   instala/atualiza pelo NewOS (ou internet)
#  ./instalar-node-exporter.sh offline  [--configure] [--pve-cluster NOME]   usa os arquivos desta pasta:
#        node_exporter-<versão>.linux-amd64.tar.gz  +  sha256sums.txt   (e, se houver RAID, storcli_*.deb;
#        host ZFS: zfs_exporter-<versão>.linux-amd64.tar.gz + sha256sums-zfs_exporter.txt)
#  ./instalar-node-exporter.sh status                                       o que está instalado e publicando
#  ./instalar-node-exporter.sh remover  [--tudo]                            tira os coletores (--tudo: e o node_exporter)
#  ./instalar-node-exporter.sh baixar                                       (máquina COM internet) baixa para esta pasta
#                                                                           o pacote + sha256sums.txt do modo offline
#  ./instalar-node-exporter.sh exportar-coletores DIR                       grava os .py embutidos numa pasta
#
#  --configure instala/atualiza, além do node_exporter (com o coletor textfile):
#     • saúde dos discos (hwhealth)  : SMART, wearout, temperatura, erros de cabo, boot espelhado,
#                                      discos atrás de controladora MegaRAID (usa o storcli se houver)
#     • disco real das VMs (guestdisk): agente QEMU, ZFS e Ceph RBD
#     • processos (hosttop)           : top CPU/memória por processo (com a VM/CT de cada um), serviços com falha
#     • replicação Ceph (rbd-mirror)  : só se o host for Ceph com mirroring ativo (pede --pve-cluster)
#  A replicação ZFS vem do pve-exporter na VM proxy: o resumo final mostra o alvo para o job pve-replicacao.
#
#  Host com pool ZFS: instala também o zfs_exporter (porta 9134, job 'zfs').
#  Baixado do painel do NewOS (curl .../dl/instalar-node-exporter.sh), o script já vem com o endereço dele
#  em NEWOS_URL e pega os pacotes de lá: o host não precisa de internet, só alcançar o NewOS.
#
#  Pode rodar quantas vezes quiser: atualiza o que mudou, mantém configurações e credenciais existentes.
# =====================================================================================================
set -euo pipefail

BIN=/usr/local/bin/node_exporter
UNIT=/etc/systemd/system/node_exporter.service
TXT=/var/lib/prometheus/node-exporter
DIR_SCRIPT="$(cd "$(dirname "$0")" && pwd)"
NEWOS_URL=""        # preenchido pelo NewOS quando o script é baixado do painel (ou --newos URL)
MODO=""; CONFIGURAR=0; PVE_CLUSTER=""; TUDO=0; DESTINO=""; ORIGEM=""
ZBIN=/usr/local/bin/zfs_exporter
ZUNIT=/etc/systemd/system/zfs_exporter.service

uso() { sed -n '3,12p' "$0" | sed 's/^#  //'; exit 1; }
ok()   { echo "    ✔ $*"; }
info() { echo "    • $*"; }
aviso(){ echo "    ⚠ $*"; }
etapa(){ echo; echo "==> $*"; }
publica() { [[ "$(curl -s --max-time 10 http://127.0.0.1:9100/metrics | grep -c "^$1" || true)" -gt 0 ]]; }

# versão mais nova: primeiro no NewOS que entregou o script, depois no GitHub  ->  "versão origem"
ultima_versao() {   # projeto repo
  local v=""
  if [[ -n "$NEWOS_URL" ]]; then
    v=$(curl -fsS --max-time 120 "$NEWOS_URL/dl/pacote/$1/$ARCH?info=1" 2>/dev/null | awk '{print $1}' || true)
    [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]] && { echo "$v newos"; return 0; }
    aviso "o NewOS ($NEWOS_URL) não entregou o $1; tentando o GitHub" >&2
  fi
  v=$(curl -fsSI --max-time 20 "https://github.com/$2/releases/latest" 2>/dev/null | grep -i '^location:' \
      | sed -E 's#.*/tag/v?([^[:space:]]+).*#\1#' | tr -d '\r' || true)
  [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]] && echo "$v github"
  return 0
}
# baixa o .tar.gz e confere o sha256 (do NewOS ou do sha256sums.txt oficial)
baixar_pacote() {   # projeto repo versão origem destino
  local pkg="$1-$3.linux-$ARCH" soma=""
  if [[ "$4" == "newos" ]]; then
    curl -fsS --max-time 600 -o "$5" "$NEWOS_URL/dl/pacote/$1/$ARCH" || return 1
    soma=$(curl -fsS --max-time 60 "$NEWOS_URL/dl/pacote/$1/$ARCH?info=1" | awk -v v="$3" '$1==v{print $2}')
  else
    curl -fsSL --max-time 600 -o "$5" "https://github.com/$2/releases/download/v$3/$pkg.tar.gz" || return 1
    soma=$(curl -fsSL --max-time 60 "https://github.com/$2/releases/download/v$3/sha256sums.txt" \
           | awk -v f="$pkg.tar.gz" '$2==f{print $1}')
  fi
  [[ -n "$soma" ]] && echo "$soma  $5" | sha256sum -c - >/dev/null 2>&1
}

# ----------------------------------------------------------------------------------------------- argumentos
[[ $# -ge 1 ]] || uso
MODO=$1; shift
while [[ $# -gt 0 ]]; do
  case "$1" in
    --configure)   CONFIGURAR=1 ;;
    --pve-cluster) PVE_CLUSTER=${2:-}; shift ;;
    --newos)       NEWOS_URL=${2:-}; shift ;;
    --tudo)        TUDO=1 ;;
    *)             if [[ "$MODO" == "exportar-coletores" && -z "$DESTINO" ]]; then DESTINO=$1; else echo "opção desconhecida: $1"; uso; fi ;;
  esac
  shift
done
case "$MODO" in online|offline|status|remover|exportar-coletores|baixar) ;; *) uso ;; esac
[[ "$MODO" == "exportar-coletores" || "$MODO" == "baixar" ]] || [[ $EUID -eq 0 ]] || { echo "Rode como root."; exit 1; }

# ----------------------------------------------------------------------------------------------- baixar (prepara o offline)
if [[ "$MODO" == "baixar" ]]; then
  ARCH_B=${ARCH:-amd64}
  V=$(curl -fsSI https://github.com/prometheus/node_exporter/releases/latest | grep -i '^location:' \
      | sed -E 's#.*/tag/v?([^[:space:]]+).*#\1#' | tr -d '\r' || true)
  [[ "$V" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]] || { echo "ERRO: sem acesso ao GitHub."; exit 1; }
  U="https://github.com/prometheus/node_exporter/releases/download/v$V"
  curl -fsSL -o "$DIR_SCRIPT/node_exporter-$V.linux-$ARCH_B.tar.gz" "$U/node_exporter-$V.linux-$ARCH_B.tar.gz"
  curl -fsSL -o "$DIR_SCRIPT/sha256sums.txt" "$U/sha256sums.txt"
  (cd "$DIR_SCRIPT" && grep " node_exporter-$V.linux-$ARCH_B.tar.gz\$" sha256sums.txt | sha256sum -c - >/dev/null) || { echo "ERRO: checksum não confere."; exit 1; }
  echo "Pronto: node_exporter $V + sha256sums.txt em $DIR_SCRIPT (checksum conferido)."
  ZV=$(curl -fsSI --max-time 20 https://github.com/pdf/zfs_exporter/releases/latest | grep -i '^location:' \
       | sed -E 's#.*/tag/v?([^[:space:]]+).*#\1#' | tr -d '\r' || true)
  if [[ "$ZV" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]]; then
    ZU="https://github.com/pdf/zfs_exporter/releases/download/v$ZV"
    curl -fsSL -o "$DIR_SCRIPT/zfs_exporter-$ZV.linux-$ARCH_B.tar.gz" "$ZU/zfs_exporter-$ZV.linux-$ARCH_B.tar.gz"
    curl -fsSL -o "$DIR_SCRIPT/sha256sums-zfs_exporter.txt" "$ZU/sha256sums.txt"
    (cd "$DIR_SCRIPT" && grep " zfs_exporter-$ZV.linux-$ARCH_B.tar.gz\$" sha256sums-zfs_exporter.txt | sha256sum -c - >/dev/null) \
      && echo "      zfs_exporter $ZV (para hosts com ZFS) também, checksum conferido." || echo "AVISO: checksum do zfs_exporter não confere."
  fi
  echo "Hosts com controladora MegaRAID: coloque também o storcli_*_all.deb (Broadcom) nesta pasta."
  echo "Copie a pasta inteira para o host e rode:  ./$(basename "$0") offline --configure"
  exit 0
fi

# ----------------------------------------------------------------------------------------------- coletores embutidos
grava_hwhealth() {
cat > "$1" <<'PYEOF_HWHEALTH'
#!/usr/bin/env python3
"""
hwhealth_textfile.py — saúde de discos e hardware para o node_exporter (textfile).

Por disco (NVMe, SATA, SAS): SMART aprovado/reprovado, wearout %, spare, temperatura, horas ligado,
volume escrito, erros de mídia, setores realocados/pendentes, erros de link (cabo/backplane: CRC no SATA,
contadores de PHY no SAS), log de erros NVMe, desligamentos inseguros. Também identifica a função do disco
(boot, pool ZFS, Ceph, LVM) e se o BOOT tem espelho.

Periféricos: temperatura dos sensores do kernel (hwmon: CPU, chipset, placas de rede...) e dos módulos
SFP/QSFP (ethtool -m), quando existirem.

Controladora RAID MegaRAID (LSI/Broadcom, DELL PERC, Intel RMS): os volumes virtuais (/dev/sdX) não têm SMART;
os discos FÍSICOS atrás dela são lidos com "smartctl -d megaraid,N". Se o storcli/perccli estiver instalado,
cada disco físico herda a função do volume (boot/zfs...) e o nível de RAID diz se o boot é espelhado.

Somente leitura. Usa smartctl (o mesmo do Proxmox em Disks → S.M.A.R.T.) com "-n standby": não acorda HDD parado.
Uso: hwhealth_textfile.py [--textfile-dir DIR] [--stdout]
"""
import argparse, glob, json, os, re, subprocess, sys, tempfile, time

NODE = os.uname().nodename.split('.')[0]
SYS = os.environ.get('HWHEALTH_SYS', '/sys')                    # só muda em teste
IGNORAR = ('zd', 'rbd', 'loop', 'sr', 'dm-', 'zram', 'nbd', 'md', 'ram')
BOOT_MNT = {'/', '/boot', '/boot/efi'}
WEAR_ATA = (177, 231, 233, 202, 169)   # Samsung, Kingston/SSD_Life_Left, Intel/SanDisk, Crucial/Micron, outros (valor normalizado = vida restante)


def run(cmd, timeout=30, ok_codes=None):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if ok_codes is not None and p.returncode not in ok_codes:
        raise RuntimeError(p.stderr.strip()[:200] or f'exit {p.returncode}')
    return p.stdout


def lsblk_arvore():
    """disco -> {'descendentes': nomes, 'mounts': pontos de montagem, 'fstypes': tipos}"""
    out = json.loads(run(['lsblk', '-J', '-b', '-o', 'NAME,TYPE,MOUNTPOINT,FSTYPE'], ok_codes=(0,)))
    info, dono = {}, {}
    def walk(no, raiz):
        d = info[raiz]
        for f in no.get('children', []) or []:
            d['desc'].add(f['name']); dono[f['name']] = raiz
            if f.get('mountpoint'): d['mounts'].add(f['mountpoint'])
            if f.get('fstype'): d['fstypes'].add(f['fstype'])
            walk(f, raiz)
    for b in out.get('blockdevices', []):
        info[b['name']] = {'desc': set(), 'mounts': {b['mountpoint']} if b.get('mountpoint') else set(), 'fstypes': set()}
        dono[b['name']] = b['name']
        walk(b, b['name'])
    return info, dono


def discos():
    out = json.loads(run(['lsblk', '-J', '-d', '-b', '-o', 'NAME,TYPE,SIZE,MODEL,SERIAL,ROTA,TRAN'], ok_codes=(0,)))
    return [b for b in out.get('blockdevices', []) if b.get('type') == 'disk' and not b['name'].startswith(IGNORAR)]


def zfs_pools(dono):
    """disco -> pool; e o pool onde está o / (se for ZFS)."""
    mapa, raiz = {}, None
    try:
        out = run(['zpool', 'status', '-P'], timeout=20)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return mapa, raiz
    pool = None
    for linha in out.splitlines():
        m = re.match(r'\s*pool:\s*(\S+)', linha)
        if m:
            pool = m.group(1); continue
        tok = linha.split()
        if pool and tok and tok[0].startswith('/dev/'):
            nome = os.path.basename(os.path.realpath(tok[0]))
            if nome in dono:
                mapa[dono[nome]] = pool
    try:
        src, fst = run(['findmnt', '-n', '-o', 'SOURCE,FSTYPE', '/'], timeout=10).split()[:2]
        if fst == 'zfs':
            raiz = src.split('/')[0]
    except Exception:
        pass
    return mapa, raiz


RAID_DRIVERS = ('megaraid_sas',)


def volume_raid(dev):
    """True se /dev/<dev> é um volume VIRTUAL de controladora MegaRAID (canal SCSI 2)."""
    try:
        real = os.path.realpath(f'{SYS}/block/{dev}/device')
        hctl = os.path.basename(real).split(':')                     # host:canal:target:lun
        host = next(p for p in real.split('/') if re.fullmatch(r'host\d+', p))
        drv = open(f'{SYS}/class/scsi_host/{host}/proc_name').read().strip()
        return drv in RAID_DRIVERS and len(hctl) == 4 and hctl[1] == '2'
    except (OSError, StopIteration):
        return False


def discos_megaraid():
    """[(device, tipo)] dos discos físicos atrás de controladoras MegaRAID (smartctl --scan-open)."""
    try:
        out = json.loads(run(['smartctl', '--scan-open', '-j'], timeout=60) or '{}')
    except (ValueError, FileNotFoundError, subprocess.TimeoutExpired):
        return []
    # SAS aparece como "megaraid,N"; SATA atrás da controladora aparece como "sat+megaraid,N"
    return [(d['name'], d['type']) for d in out.get('devices', []) if re.search(r'megaraid,\d+', str(d.get('type', '')))]


def mapa_storcli():
    """{'/dev/sdX': {'level': 'RAID1', 'dids': [10, 11], 'state': 'Optl'}} via storcli/perccli (opcional)."""
    exe = None
    for c in ('storcli64', 'storcli', 'perccli64', 'perccli', '/opt/MegaRAID/storcli/storcli64', '/opt/MegaRAID/perccli/perccli64'):
        if os.path.isabs(c):
            if os.access(c, os.X_OK): exe = c; break
        elif subprocess.run(['which', c], capture_output=True).returncode == 0:
            exe = c; break
    if not exe:
        return {}
    try:
        j = json.loads(run([exe, '/call/vall', 'show', 'all', 'J'], timeout=60))
    except Exception:
        return {}
    mapa = {}
    for c in j.get('Controllers', []):
        rd = c.get('Response Data', {}) or {}
        for k, v in rd.items():
            m = re.fullmatch(r'/c\d+/v(\d+)', k)
            if not m or not v:
                continue
            vd = m.group(1)
            props = rd.get(f'VD{vd} Properties', {}) or {}
            osdev = props.get('OS Drive Name') or ''
            dids = [int(p['DID']) for p in rd.get(f'PDs for VD {vd}', []) if str(p.get('DID', '')).isdigit()]
            if osdev:
                mapa[osdev] = {'level': str(v[0].get('TYPE', '')), 'state': str(v[0].get('State', '')), 'dids': dids}
    return mapa


def smart(dev, tipo=None, caminho=None):
    try:
        cmd = ['smartctl', '-j', '-x', '-n', 'standby'] + (['-d', tipo] if tipo else []) + [caminho or f'/dev/{dev}']
        out = run(cmd, timeout=60)
        return json.loads(out) if out.strip() else {}
    except (subprocess.TimeoutExpired, ValueError, FileNotFoundError):
        return {}


def extrair(j):
    """métricas de um JSON do smartctl (NVMe, ATA ou SCSI/SAS)."""
    r = {}
    msgs = ' '.join(m.get('string', '') for m in (j.get('smartctl', {}).get('messages') or []))
    if 'STANDBY' in msgs.upper():
        r['standby'] = 1
        return r
    if 'smart_status' in j and 'passed' in j['smart_status']:
        r['smart_passed'] = 1 if j['smart_status']['passed'] else 0
    if isinstance(j.get('temperature'), dict) and j['temperature'].get('current'):   # 0 = sem leitura
        r['temperature_celsius'] = j['temperature']['current']
    if isinstance(j.get('power_on_time'), dict) and 'hours' in j['power_on_time']:
        r['power_on_hours'] = j['power_on_time']['hours']
    if isinstance(j.get('endurance_used'), dict) and 'current_percent' in j['endurance_used']:      # smartctl >= 7.5
        r['wearout_percent'] = j['endurance_used']['current_percent']

    nv = j.get('nvme_smart_health_information_log')
    if nv:
        r['wearout_percent'] = nv.get('percentage_used', r.get('wearout_percent'))
        for k_json, k in (('available_spare', 'spare_percent'), ('available_spare_threshold', 'spare_threshold_percent'),
                          ('media_errors', 'media_errors'), ('critical_warning', 'critical_warning'),
                          ('num_err_log_entries', 'error_log_entries'), ('unsafe_shutdowns', 'unsafe_shutdowns'),
                          ('power_on_hours', 'power_on_hours')):
            if k_json in nv:
                r[k] = nv[k_json]
        if 'data_units_written' in nv:
            r['written_bytes'] = nv['data_units_written'] * 512000              # unidade NVMe = 1000 blocos de 512 bytes
        if nv.get('temperature') and 'temperature_celsius' not in r:
            r['temperature_celsius'] = nv['temperature']

    tab = {a['id']: a for a in (j.get('ata_smart_attributes', {}) or {}).get('table', [])}
    if tab:
        for aid in WEAR_ATA:
            # só vale se o NOME for de desgaste: em vários HDDs o mesmo número é outra coisa (ex.: 202 = Data_Address_Mark_Errs)
            if aid in tab and 'value' in tab[aid] and re.search(r'wear|life|remain', str(tab[aid].get('name', '')), re.I):
                r['wearout_percent'] = max(0, min(100, 100 - int(tab[aid]['value'])))
                break
        raw = lambda aid: int(tab[aid]['raw']['value']) if aid in tab else None
        if raw(5) is not None: r['reallocated_sectors'] = raw(5)
        if raw(197) is not None: r['pending_sectors'] = raw(197)
        erros = [raw(a) for a in (187, 198) if raw(a) is not None]
        if erros: r['media_errors'] = sum(erros)
        if raw(199) is not None: r['link_errors'] = raw(199)            # UDMA_CRC_Error_Count: cabo/backplane
        # volume gravado: cada fabricante usa um nome/unidade diferente
        for aid, a in tab.items():
            nome_a = str(a.get('name', ''))
            if nome_a == 'Total_LBAs_Written':
                r['written_bytes'] = raw(aid) * int(j.get('logical_block_size', 512)); break
            if nome_a in ('Lifetime_Writes_GiB', 'Host_Writes_GiB', 'Total_Writes_GiB'):          # Kingston, outros
                r['written_bytes'] = raw(aid) * 1024 ** 3; break
            if nome_a == 'Host_Writes_32MiB':                                                   # Intel
                r['written_bytes'] = raw(aid) * 32 * 1024 ** 2; break
        if 'temperature_celsius' not in r:
            for aid in (194, 190):
                if aid in tab:
                    r['temperature_celsius'] = int(tab[aid]['raw']['value']) & 0xFF; break

    if 'scsi_percentage_used_endurance_indicator' in j:                         # smartctl < 7.5 (SAS SSD)
        r['wearout_percent'] = j['scsi_percentage_used_endurance_indicator']
    if 'scsi_grown_defect_list' in j:
        r['reallocated_sectors'] = j['scsi_grown_defect_list']
    ecl = j.get('scsi_error_counter_log')
    if ecl:
        r['media_errors'] = sum(int(ecl.get(k, {}).get('total_uncorrected_errors', 0)) for k in ('read', 'write', 'verify'))
    phy_err = None
    for porta, phys in j.items():                                               # SAS: scsi_sas_port_N -> phy_N -> contadores
        if porta.startswith('scsi_sas_port_') and isinstance(phys, dict):
            for phy in phys.values():
                if isinstance(phy, dict):
                    for k in ('invalid_dword_count', 'running_disparity_error_count',
                              'loss_of_dword_synchronization_count', 'phy_reset_problem_count'):
                        if isinstance(phy.get(k), int):
                            phy_err = (phy_err or 0) + phy[k]
    if phy_err is not None:
        r['link_errors'] = phy_err
    return r


def sfp():
    res = []
    for d in sorted(glob.glob(f'{SYS}/class/net/*/device')):
        iface = d.split('/')[-2]
        try:
            out = run(['ethtool', '-m', iface], timeout=5)
        except Exception:
            continue
        m = re.search(r'Module temperature\s*:\s*([-\d.]+)\s*degrees C', out)
        if not m:
            continue
        vend = re.search(r'Vendor name\s*:\s*(.+)', out); pn = re.search(r'Vendor PN\s*:\s*(.+)', out)
        res.append((iface, vend.group(1).strip() if vend else '', pn.group(1).strip() if pn else '', float(m.group(1))))
    return res


def hwmon():
    res = []
    for h in sorted(glob.glob(f'{SYS}/class/hwmon/hwmon*')):
        try:
            chip = open(f'{h}/name').read().strip()
        except OSError:
            continue
        if chip in ('nvme', 'drivetemp'):          # já medidos pelo SMART
            continue
        for inp in sorted(glob.glob(f'{h}/temp*_input')):
            base = inp[:-len('_input')]
            try:
                v = int(open(inp).read()) / 1000.0
            except (OSError, ValueError):
                continue
            rotulo = open(f'{base}_label').read().strip() if os.path.exists(f'{base}_label') else os.path.basename(base)
            lim = None
            for suf in ('_crit', '_max'):
                try:
                    x = int(open(base + suf).read()) / 1000.0
                    if 0 < x < 200: lim = x; break
                except (OSError, ValueError):
                    pass
            res.append((chip, f'{os.path.basename(h)}/{rotulo}', v, lim))
    return res


def lbl(v): return str(v).replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ').strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--textfile-dir', default='/var/lib/prometheus/node-exporter')
    ap.add_argument('--stdout', action='store_true')
    a = ap.parse_args()
    ini, ok, fam = time.time(), 1, {}
    def add(nome, labels, v, help_=''):
        if v is None: return
        fam.setdefault(nome, (help_, []))[1].append((labels, float(v)))

    try:
        arv, dono = lsblk_arvore()
        pools, pool_raiz = zfs_pools(dono)
        n_boot, boot_virtual, seriais, funcoes = 0, [], set(), {}
        raid = mapa_storcli()
        for dk in discos():
            nome = dk['name']; a_ = arv.get(nome, {'desc': set(), 'mounts': set(), 'fstypes': set()})
            if a_['mounts'] & BOOT_MNT or (pool_raiz and pools.get(nome) == pool_raiz):
                funcao = 'boot'
            elif nome in pools:
                funcao = 'zfs'
            elif any(x.startswith('ceph--') for x in a_['desc']) or 'ceph_bluestore' in a_['fstypes']:
                funcao = 'ceph'
            elif 'LVM2_member' in a_['fstypes']:
                funcao = 'lvm'
            else:
                funcao = 'livre'
            n_boot += funcao == 'boot'
            funcoes[f'/dev/{nome}'] = (funcao, pools.get(nome, ''))
            info_raid = raid.get(f'/dev/{nome}', {})
            if volume_raid(nome):
                # volume da controladora: sem SMART (os discos de verdade são lidos logo abaixo)
                if funcao == 'boot':
                    boot_virtual.append(info_raid)
                vb = {'node': NODE, 'disk': nome, 'serial': lbl(dk.get('serial') or f'{NODE}-{nome}')}   # mesmo serial de antes: não dispara 'Disco sumiu'
                add('hwhealth_disk_info', {**vb, 'model': lbl(dk.get('model') or ''), 'type': 'raid-virtual', 'rota': '',
                    'role': funcao, 'pool': pools.get(nome, ''), 'firmware': '', 'raid_level': lbl(info_raid.get('level', ''))}, 1)
                add('hwhealth_disk_size_bytes', vb, dk.get('size'))
                continue
            j = smart(nome); v = extrair(j)
            serial = dk.get('serial') or j.get('serial_number') or nome
            seriais.add(str(serial).strip())
            tipo = (dk.get('tran') or j.get('device', {}).get('type') or '').lower()
            if nome.startswith('nvme'): tipo = 'nvme'
            base = {'node': NODE, 'disk': nome, 'serial': lbl(serial)}
            add('hwhealth_disk_info', {**base, 'model': lbl(dk.get('model') or j.get('model_name') or j.get('scsi_model_name') or ''),
                'type': tipo, 'rota': str(dk.get('rota', '')).replace('True', '1').replace('False', '0'),
                'role': funcao, 'pool': pools.get(nome, ''), 'firmware': lbl(j.get('firmware_version', '')), 'raid_level': ''}, 1,
                'Disco (modelo, serial, tipo, função: boot/zfs/ceph/lvm/livre/raid)')
            add('hwhealth_disk_size_bytes', base, dk.get('size'), 'Tamanho do disco')
            for k, val in v.items():
                add('hwhealth_disk_power_on_seconds', base, val * 3600) if k == 'power_on_hours' else add(f'hwhealth_disk_{k}', base, val)

        # discos físicos atrás da controladora MegaRAID
        dono_did = {did: osdev for osdev, i in raid.items() for did in i['dids']}
        for caminho, tipo_dev in discos_megaraid():
            did = int(re.search(r'megaraid,(\d+)', tipo_dev).group(1))
            rotulo = f'megaraid,{did}'                  # nome estável na dashboard, seja SAS ou SATA
            j = smart(None, tipo_dev, caminho); v = extrair(j)
            serial = str(j.get('serial_number') or f'{NODE}-{rotulo}').strip()
            if serial in seriais:                       # o mesmo disco já foi lido direto (JBOD)
                continue
            seriais.add(serial)
            proto = str(j.get('device', {}).get('protocol', '')).upper()
            tipo = {'ATA': 'sata', 'SCSI': 'sas', 'NVME': 'nvme'}.get(proto, proto.lower() or 'raid')
            rr = j.get('rotation_rate')
            funcao, pool = funcoes.get(dono_did.get(did, ''), ('raid', ''))
            base = {'node': NODE, 'disk': rotulo, 'serial': lbl(serial)}
            modelo = j.get('model_name') or ' '.join(x for x in (j.get('scsi_vendor'), j.get('scsi_product')) if x) or ''
            add('hwhealth_disk_info', {**base, 'model': lbl(modelo), 'type': tipo, 'rota': '' if rr is None else ('0' if rr == 0 else '1'),
                'role': funcao, 'pool': pool, 'firmware': lbl(j.get('firmware_version', '') or j.get('scsi_revision', '')),
                'raid_level': lbl(raid.get(dono_did.get(did, ''), {}).get('level', ''))}, 1)
            add('hwhealth_disk_size_bytes', base, (j.get('user_capacity') or {}).get('bytes'))
            for k, val in v.items():
                add('hwhealth_disk_power_on_seconds', base, val * 3600) if k == 'power_on_hours' else add(f'hwhealth_disk_{k}', base, val)

        # boot espelhado? 2+ discos de boot, ou volume RAID com redundância (RAID1/5/6/10...)
        if n_boot >= 2:
            redundante = 1
        elif boot_virtual:
            nivel = boot_virtual[0].get('level', '').upper()
            redundante = -1 if not nivel else (0 if nivel == 'RAID0' or len(boot_virtual[0].get('dids', [])) < 2 else 1)
        else:
            redundante = 0
        add('hwhealth_boot_disks', {'node': NODE}, n_boot, 'Quantos discos têm o sistema (boot) neste host')
        add('hwhealth_boot_redundant', {'node': NODE}, redundante, '1 = espelhado · 0 = disco único · -1 = boot em RAID de nível desconhecido (instale o storcli)')
    except Exception as e:
        ok = 0; print(f'erro discos: {e}', file=sys.stderr)
    try:
        for iface, vend, pn, t in sfp():
            add('hwhealth_sfp_temperature_celsius', {'node': NODE, 'iface': iface, 'vendor': lbl(vend), 'part': lbl(pn)}, t, 'Temperatura do módulo SFP/QSFP')
        for chip, sensor, t, lim in hwmon():
            s = {'node': NODE, 'chip': lbl(chip), 'sensor': lbl(sensor)}
            add('hwhealth_hwmon_temperature_celsius', s, t, 'Temperatura de sensor do hardware (CPU, chipset, placas)')
            add('hwhealth_hwmon_temperature_limit_celsius', s, lim, 'Limite (crit/max) informado pelo sensor')
    except Exception as e:
        print(f'aviso periféricos: {e}', file=sys.stderr)
    add('hwhealth_collector_up', {'node': NODE}, ok, '1 = coleta ok')
    add('hwhealth_collector_timestamp_seconds', {'node': NODE}, time.time(), 'Horário da última coleta')
    add('hwhealth_collector_duration_seconds', {'node': NODE}, round(time.time() - ini, 3), 'Duração da coleta')

    linhas = []
    for nome, (help_, amostras) in fam.items():
        linhas += [f'# HELP {nome} {help_ or nome}', f'# TYPE {nome} gauge']
        for labels, v in amostras:
            ls = ','.join(f'{k}="{x}"' for k, x in labels.items())
            linhas.append(f'{nome}{{{ls}}} {int(v) if v.is_integer() else repr(v)}')
    txt = '\n'.join(linhas) + '\n'
    if a.stdout:
        sys.stdout.write(txt); return
    os.makedirs(a.textfile_dir, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=a.textfile_dir, prefix='.hwhealth.')
    with os.fdopen(fd, 'w') as f:
        f.write(txt)
    os.chmod(tmp, 0o644)
    os.replace(tmp, os.path.join(a.textfile_dir, 'hwhealth.prom'))


if __name__ == '__main__':
    main()
PYEOF_HWHEALTH
}
grava_guestdisk() {
cat > "$1" <<'PYEOF_GUESTDISK'
#!/usr/bin/env python3
"""
pve_guestdisk_textfile.py — consumo REAL de disco das VMs para o node_exporter (textfile).

O Proxmox não mede o disco por dentro das VMs (a API manda 0). Este coletor roda em cada host e
publica duas medidas, por VM que está NESTE nó:

  1) Agente QEMU (qemu-guest-agent): uso dentro do sistema da VM (o que o Windows/Linux mostra).
     Só para VMs com "agent: 1" na configuração. Atualizado a cada 5 min (cache), em paralelo.
  2) ZFS: quanto cada disco (zvol) da VM ocupa de verdade no pool ("referenced").
     Funciona sem agente. Atualizado a cada execução (1 comando para o nó inteiro).
  3) Ceph RBD: quanto cada imagem de disco ocupa no pool ("rbd du"). Roda em UM nó do cluster por vez
     (o primeiro nó online em ordem alfabética; se ele cair, o próximo assume) e a cada 15 min (cache).

Somente leitura: não altera VMs, discos, pools nem configuração.

Uso: pve_guestdisk_textfile.py [--textfile-dir DIR] [--stdout] [--agent-ttl 300]
"""
import argparse, json, os, re, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor

NODE = os.uname().nodename.split('.')[0]          # é o nome do nó no Proxmox (mesmo do label node do pve-exporter)
RE_ZVOL = re.compile(r'(?:^|/)(?:vm|base)-(\d+)-disk-\d+$')
RE_RBD = re.compile(r'^(?:vm|base)-(\d+)-disk-\d+$')
FS_IGNORAR = {'squashfs', 'tmpfs', 'devtmpfs', 'overlay', 'iso9660', 'udf', 'cdfs', 'ramfs', 'nsfs', 'autofs',
              'proc', 'sysfs', 'fuse.lxcfs', 'efivarfs', 'devpts', 'cgroup', 'cgroup2'}
CACHE = os.environ.get('PVE_GUESTDISK_CACHE', '/var/lib/pve-guestdisk/agent-cache.json')
ETC = os.environ.get('PVE_GUESTDISK_ETC', '/etc/pve')   # só muda em teste
CACHE_RBD = os.environ.get('PVE_GUESTDISK_CACHE_RBD', '/var/lib/pve-guestdisk/rbd-cache.json')


def run(cmd, timeout=30):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip()[:200] or f'exit {p.returncode}')
    return p.stdout


def zvols():
    """[(vmid, volume, volsize, referenced, used)] de todos os zvols de VM deste nó."""
    try:
        out = run(['zfs', 'list', '-Hp', '-t', 'volume', '-o', 'name,volsize,referenced,used'])
    except FileNotFoundError:
        return []
    res = []
    for linha in out.splitlines():
        partes = linha.split('\t')
        if len(partes) != 4:
            continue
        nome, vs, ref, used = partes
        m = RE_ZVOL.search(nome)
        if m and vs.isdigit():
            res.append((m.group(1), nome, int(vs), int(ref), int(used)))
    return res


def sou_o_coletor_rbd():
    """só um nó do cluster roda o rbd du: o primeiro nó online em ordem alfabética."""
    try:
        with open(f'{ETC}/.members') as f:
            mb = json.load(f)
        online = sorted(n for n, i in mb.get('nodelist', {}).items() if i.get('online'))
        return bool(online) and online[0] == NODE
    except (OSError, ValueError):
        return True                       # sem cluster/arquivo: nó único, pode rodar


def rbd_imagens(ttl):
    """[(vmid, pool, image, provisionado, usado)] via rbd du, com cache."""
    try:
        with open(CACHE_RBD) as f:
            c = json.load(f)
        if c.get('node') == NODE and time.time() - c.get('ts', 0) < ttl:
            return c['imgs']
    except (OSError, ValueError, KeyError):
        pass
    try:
        pools = [p['pool_name'] for p in json.loads(run(['ceph', 'osd', 'pool', 'ls', 'detail', '--format', 'json'], timeout=30))
                 if 'rbd' in (p.get('application_metadata') or {})]
    except (FileNotFoundError, RuntimeError, ValueError, subprocess.TimeoutExpired):
        return []
    imgs = []
    for pool in pools:
        try:
            du = json.loads(run(['rbd', 'du', '--pool', pool, '--format', 'json'], timeout=240))
        except Exception as e:
            print(f'aviso: rbd du {pool}: {e}', file=sys.stderr)
            continue
        for im in du.get('images', []):
            if im.get('snapshot'):            # linhas de snapshot: fora (queremos a imagem)
                continue
            m = RE_RBD.match(im.get('name', ''))
            if m:
                imgs.append([m.group(1), pool, im['name'], int(im.get('provisioned_size', 0)), int(im.get('used_size', 0))])
    try:
        os.makedirs(os.path.dirname(CACHE_RBD), exist_ok=True)
        with open(CACHE_RBD + '.tmp', 'w') as f:
            json.dump({'node': NODE, 'ts': time.time(), 'imgs': imgs}, f)
        os.replace(CACHE_RBD + '.tmp', CACHE_RBD)
    except OSError:
        pass
    return imgs


def vms_com_agente():
    """VMs rodando NESTE nó com o agente habilitado na configuração."""
    try:
        vms = json.loads(run(['pvesh', 'get', f'/nodes/{NODE}/qemu', '--output-format', 'json']))
    except Exception as e:
        print(f'aviso: pvesh qemu: {e}', file=sys.stderr)
        return []
    lista = []
    for vm in vms:
        if vm.get('status') != 'running' or vm.get('template'):
            continue
        vmid = str(vm['vmid'])
        try:
            with open(f'{ETC}/qemu-server/{vmid}.conf') as f:
                conf = f.read().split('\n[')[0]            # só a configuração atual (sem snapshots)
        except OSError:
            continue
        m = re.search(r'^agent:\s*(\S+)', conf, re.M)
        if m and re.match(r'(1|enabled=1|.*,enabled=1)', m.group(1)):
            lista.append(vmid)
    return lista


def fsinfo(vmid):
    """soma total/usado dos filesystems reais da VM, via agente. None se o agente não respondeu."""
    try:
        dados = json.loads(run(['qm', 'guest', 'cmd', vmid, 'get-fsinfo'], timeout=15))
    except Exception:
        return None
    if isinstance(dados, dict):
        dados = dados.get('result', [])
    vistos, total, usado, n = set(), 0, 0, 0
    for fs in dados or []:
        if 'total-bytes' not in fs or 'used-bytes' not in fs:
            continue
        if str(fs.get('type', '')).lower() in FS_IGNORAR:
            continue
        chave = fs.get('name') or fs.get('mountpoint')
        if chave in vistos:                                  # mesmo dispositivo montado 2x (bind, btrfs...)
            continue
        vistos.add(chave)
        total += int(fs['total-bytes']); usado += int(fs['used-bytes']); n += 1
    return {'total': total, 'used': usado, 'n': n} if n else {'total': 0, 'used': 0, 'n': 0}


def agente(ttl):
    """resultado do agente com cache: não consulta todas as VMs a cada minuto."""
    try:
        with open(CACHE) as f:
            c = json.load(f)
        if c.get('node') == NODE and time.time() - c.get('ts', 0) < ttl:
            return c
    except (OSError, ValueError):
        pass
    vmids = vms_com_agente()
    with ThreadPoolExecutor(max_workers=6) as ex:
        resultados = dict(zip(vmids, ex.map(fsinfo, vmids)))
    c = {'node': NODE, 'ts': time.time(), 'vms': resultados}
    try:
        os.makedirs(os.path.dirname(CACHE), exist_ok=True)
        with open(CACHE + '.tmp', 'w') as f:
            json.dump(c, f)
        os.replace(CACHE + '.tmp', CACHE)
    except OSError:
        pass
    return c


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--textfile-dir', default='/var/lib/prometheus/node-exporter')
    ap.add_argument('--stdout', action='store_true')
    ap.add_argument('--agent-ttl', type=int, default=300)
    ap.add_argument('--rbd-ttl', type=int, default=900)
    a = ap.parse_args()

    ini, ok, L = time.time(), 1, []
    def m(nome, help_, amostras):
        L.append(f'# HELP {nome} {help_}'); L.append(f'# TYPE {nome} gauge')
        for labels, v in amostras:
            ls = ','.join(f'{k}="{str(x)}"' for k, x in labels.items())
            L.append(f'{nome}{{{ls}}} {int(v) if float(v).is_integer() else repr(float(v))}')

    try:
        zv = zvols()
    except Exception as e:
        zv, ok = [], 0
        print(f'erro zfs: {e}', file=sys.stderr)
    m('pve_guestdisk_zvol_size_bytes', 'Tamanho do disco (zvol) da VM', [({'id': f'qemu/{v}', 'node': NODE, 'volume': n}, s) for v, n, s, r, u in zv])
    m('pve_guestdisk_zvol_referenced_bytes', 'Dados realmente gravados no zvol (ocupa no pool, sem snapshots)',
      [({'id': f'qemu/{v}', 'node': NODE, 'volume': n}, r) for v, n, s, r, u in zv])
    m('pve_guestdisk_zvol_used_bytes', 'Espaço total do zvol no pool (inclui snapshots e reserva)',
      [({'id': f'qemu/{v}', 'node': NODE, 'volume': n}, u) for v, n, s, r, u in zv])

    rb = rbd_imagens(a.rbd_ttl) if sou_o_coletor_rbd() else []
    m('pve_guestdisk_rbd_size_bytes', 'Tamanho (provisionado) da imagem RBD da VM',
      [({'id': f'qemu/{v}', 'node': NODE, 'pool': p, 'image': i}, s_) for v, p, i, s_, u in rb])
    m('pve_guestdisk_rbd_used_bytes', 'Espaço realmente usado pela imagem RBD no pool (rbd du)',
      [({'id': f'qemu/{v}', 'node': NODE, 'pool': p, 'image': i}, u) for v, p, i, s_, u in rb])

    try:
        ag = agente(a.agent_ttl)
    except Exception as e:
        ag, ok = {'ts': time.time(), 'vms': {}}, 0
        print(f'erro agente: {e}', file=sys.stderr)
    boas = {v: r for v, r in ag['vms'].items() if r and r['n']}
    m('pve_guestdisk_agent_up', '1 = agente respondeu; 0 = agente habilitado mas sem resposta',
      [({'id': f'qemu/{v}', 'node': NODE}, 1 if r and r['n'] else 0) for v, r in ag['vms'].items()])
    m('pve_guestdisk_fs_total_bytes', 'Tamanho dos filesystems dentro da VM (agente)', [({'id': f'qemu/{v}', 'node': NODE}, r['total']) for v, r in boas.items()])
    m('pve_guestdisk_fs_used_bytes', 'Usado dentro da VM (agente)', [({'id': f'qemu/{v}', 'node': NODE}, r['used']) for v, r in boas.items()])
    m('pve_guestdisk_agent_timestamp_seconds', 'Última consulta aos agentes', [({'node': NODE}, ag['ts'])])
    m('pve_guestdisk_up', '1 = coleta ok', [({'node': NODE}, ok)])
    m('pve_guestdisk_duration_seconds', 'Duração da coleta', [({'node': NODE}, round(time.time() - ini, 3))])
    txt = '\n'.join(L) + '\n'

    if a.stdout:
        sys.stdout.write(txt); return
    os.makedirs(a.textfile_dir, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=a.textfile_dir, prefix='.pve_guestdisk.')
    with os.fdopen(fd, 'w') as f:
        f.write(txt)
    os.chmod(tmp, 0o644)
    os.replace(tmp, os.path.join(a.textfile_dir, 'pve_guestdisk.prom'))


if __name__ == '__main__':
    main()
PYEOF_GUESTDISK
}
grava_hosttop() {
cat > "$1" <<'PYEOF_HOSTTOP'
#!/usr/bin/env python3
"""
hosttop_textfile.py — quem está consumindo o host, para o node_exporter (textfile).

O node_exporter não mede por processo. Este coletor publica, a cada execução:
  • os 10 processos que mais usam CPU AGORA (2 leituras do /proc com intervalo; não é a média de vida do ps)
  • os 10 processos que mais usam memória (RSS)
  • no Proxmox: a qual VM (kvm -id N -name X) ou container LXC (cgroup /lxc/N) cada processo pertence
  • processos zumbis e travados esperando disco (estado D)
  • serviços systemd com falha (systemctl --failed)

Somente leitura. Uso: hosttop_textfile.py [--textfile-dir DIR] [--stdout] [--intervalo 3] [--top 10]
"""
import argparse, glob, os, pwd, re, subprocess, sys, tempfile, time

PROC = os.environ.get('HOSTTOP_PROC', '/proc')            # só muda em teste
ETC_PVE = os.environ.get('HOSTTOP_ETC_PVE', '/etc/pve')
TICK = os.sysconf('SC_CLK_TCK')
PAGINA = os.sysconf('SC_PAGE_SIZE')


def ler(caminho, modo='r'):
    try:
        with open(caminho, modo) as f:
            return f.read()
    except OSError:
        return None


def amostra():
    """{pid: (comm, estado, ticks_cpu)}"""
    r = {}
    for d in os.listdir(PROC):
        if not d.isdigit():
            continue
        st = ler(f'{PROC}/{d}/stat')
        if not st:
            continue
        i, j = st.find('('), st.rfind(')')
        campos = st[j + 2:].split()
        try:
            r[int(d)] = (st[i + 1:j], campos[0], int(campos[11]) + int(campos[12]))   # utime + stime
        except (IndexError, ValueError):
            continue
    return r


_nomes_vm = {}
def nome_vm(vmid):
    if vmid not in _nomes_vm:
        nome = ''
        for c in glob.glob(f'{ETC_PVE}/nodes/*/qemu-server/{vmid}.conf') + glob.glob(f'{ETC_PVE}/nodes/*/lxc/{vmid}.conf'):
            m = re.search(r'^(?:name|hostname):\s*(\S+)', ler(c) or '', re.M)
            if m:
                nome = m.group(1); break
        _nomes_vm[vmid] = nome
    return _nomes_vm[vmid]


def guest(pid, comm):
    """'VM 101 · erp' / 'CT 105 · dns' / '' """
    if comm.startswith(('kvm', 'qemu')):
        cmd = (ler(f'{PROC}/{pid}/cmdline', 'rb') or b'').split(b'\0')
        args = [a.decode(errors='replace') for a in cmd]
        vmid = nome = ''
        for k, a in enumerate(args[:-1]):
            if a == '-id':
                vmid = args[k + 1]
            elif a == '-name':
                nome = args[k + 1].split(',')[0].replace('guest=', '')
        if vmid:
            return f'VM {vmid} · {nome or nome_vm(vmid)}'.rstrip(' ·')
    cg = ler(f'{PROC}/{pid}/cgroup') or ''
    m = re.search(r'/lxc(?:\.payload)?[./](\d+)', cg)
    if m:
        ct = m.group(1)
        return f'CT {ct} · {nome_vm(ct)}'.rstrip(' ·')
    return ''


def usuario(pid):
    try:
        return pwd.getpwuid(os.stat(f'{PROC}/{pid}').st_uid).pw_name
    except (KeyError, OSError):
        return '?'


def servicos_com_falha():
    try:
        out = subprocess.run(['systemctl', 'list-units', '--state=failed', '--no-legend', '--plain', '--no-pager'],
                             capture_output=True, text=True, timeout=20).stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    return [l.split()[0] for l in out.splitlines() if l.strip()]


def lbl(v):
    return str(v).replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ').strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--textfile-dir', default='/var/lib/prometheus/node-exporter')
    ap.add_argument('--stdout', action='store_true')
    ap.add_argument('--intervalo', type=float, default=3.0)
    ap.add_argument('--top', type=int, default=10)
    a = ap.parse_args()
    ini, ok, linhas = time.time(), 1, []
    def fam(nome, ajuda, amostras):
        linhas.extend([f'# HELP {nome} {ajuda}', f'# TYPE {nome} gauge'])
        for labels, v in amostras:
            ls = ','.join(f'{k}="{lbl(x)}"' for k, x in labels.items())
            linhas.append(f'{nome}{{{ls}}} {round(v, 4) if isinstance(v, float) else v}')
    try:
        t0 = amostra(); time.sleep(a.intervalo); t1 = amostra()
        cpu = []
        for pid, (comm, est, ticks) in t1.items():
            if pid in t0 and t0[pid][0] == comm:
                cores = max(0, ticks - t0[pid][2]) / TICK / a.intervalo          # núcleos usados (1.0 = 1 núcleo inteiro)
                if cores > 0:
                    cpu.append((cores, pid, comm))
        cpu.sort(reverse=True)
        mem = []
        for pid, (comm, est, _) in t1.items():
            sm = ler(f'{PROC}/{pid}/statm')
            if sm:
                try:
                    mem.append((int(sm.split()[1]) * PAGINA, pid, comm))
                except (IndexError, ValueError):
                    pass
        mem.sort(reverse=True)
        base = lambda pid, comm: {'pid': pid, 'process': comm, 'user': usuario(pid), 'guest': guest(pid, comm)}
        fam('hosttop_process_cpu_cores', 'Top processos por CPU agora (1 = um núcleo inteiro)',
            [(base(p, c), v) for v, p, c in cpu[:a.top]])
        fam('hosttop_process_memory_bytes', 'Top processos por memória (RSS)',
            [(base(p, c), v) for v, p, c in mem[:a.top]])
        estados = {'Z': 0, 'D': 0}
        for _, est, _ in t1.values():
            if est in estados:
                estados[est] += 1
        fam('hosttop_processes', 'Processos por estado (Z = zumbi, D = travado esperando disco/IO)',
            [({'state': 'zombie'}, estados['Z']), ({'state': 'blocked'}, estados['D']), ({'state': 'total'}, len(t1))])
    except Exception as e:
        ok = 0; print(f'erro processos: {e}', file=sys.stderr)
    falhas = servicos_com_falha()
    if falhas is not None:
        fam('hosttop_systemd_unit_failed', 'Serviço systemd em estado failed', [({'unit': u}, 1) for u in falhas])
        fam('hosttop_systemd_failed_units', 'Quantidade de serviços systemd com falha', [({}, len(falhas))])
    fam('hosttop_collector_up', '1 = coleta ok', [({}, ok)])
    fam('hosttop_collector_timestamp_seconds', 'Horário da última coleta', [({}, round(time.time(), 1))])
    fam('hosttop_collector_duration_seconds', 'Duração da coleta', [({}, round(time.time() - ini, 3))])
    txt = '\n'.join(l.replace('{}', '') for l in linhas) + '\n'
    if a.stdout:
        sys.stdout.write(txt); return
    os.makedirs(a.textfile_dir, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=a.textfile_dir, prefix='.hosttop.')
    with os.fdopen(fd, 'w') as f:
        f.write(txt)
    os.chmod(tmp, 0o644)
    os.replace(tmp, os.path.join(a.textfile_dir, 'hosttop.prom'))


if __name__ == '__main__':
    main()
PYEOF_HOSTTOP
}
grava_rbdmirror() {
cat > "$1" <<'PYEOF_RBDMIRROR'
#!/usr/bin/env python3
"""
rbdmirror_textfile.py — coletor de replicação Ceph RBD-mirror para o node_exporter (textfile).

Roda num nó Ceph (Proxmox), consulta `rbd`/`ceph` e grava métricas em
<textfile_dir>/rbd_mirror.prom. Sem dependências além do Python 3 e do ceph-common.

Uso:
  rbdmirror_textfile.py --pve-cluster NOME_DO_INSTANCE_NO_PVE_EXPORTER [--textfile-dir DIR] [--stdout]

  --pve-cluster  precisa ser IGUAL ao valor do label `instance` do pve-exporter deste cluster
                 (é por ele que a dashboard junta a replicação com o cluster).

Formatos lidos (conferidos no código do Ceph):
  rbd mirror pool info   --format json   -> {mode, site_name, peers[{uuid,direction,site_name,...}]}
  rbd mirror pool status --verbose --format json
                                         -> {summary{health,daemon_health,image_health,states},
                                             daemons[{hostname,instance_id,leader,health,...}],
                                             images[{name,global_id,state,description,last_update,peer_sites[...]}]}
  rbd mirror snapshot schedule ls -R --format json      -> [{pool,namespace,image,items[{interval,start_time}]}]
  rbd mirror snapshot schedule status --format json     -> [{schedule_time(UTC),image}]
"""
import argparse, json, os, re, subprocess, sys, tempfile, time, calendar

TIMEOUT = 30
HEALTH = {'OK': 0, 'UNKNOWN': 1, 'WARNING': 2, 'ERROR': 3}
# status por imagem (a dashboard acrescenta 2 = ATRASADA com base no agendamento)
OK, SINCRONIZANDO, ALERTA, ERRO, SEM_STATUS = 0, 1, 3, 4, 5
RE_VMID = re.compile(r'^(?:vm|base)-(\d+)-')


def run(cmd, env=None):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT, env=env)
    if p.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)}: {p.stderr.strip()[:300]}")
    out = p.stdout.strip()
    return json.loads(out) if out else None


def lbl(v):
    return str(v).replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ')


class Out:
    def __init__(self):
        self.fam = {}   # nome -> (help, [(labels, value)])

    def add(self, name, help_, labels, value):
        if value is None:
            return
        self.fam.setdefault(name, (help_, []))[1].append((labels, float(value)))

    def render(self):
        linhas = []
        for name, (help_, amostras) in self.fam.items():
            linhas += [f'# HELP {name} {help_}', f'# TYPE {name} gauge']
            vistos = set()
            for labels, v in amostras:
                ls = ','.join(f'{k}="{lbl(x)}"' for k, x in labels.items())
                if ls in vistos:
                    continue
                vistos.add(ls)
                txt = str(int(v)) if v.is_integer() else repr(v)      # precisão total (timestamps!)
                linhas.append(f'{name}{{{ls}}} {txt}')
        return '\n'.join(linhas) + '\n'


def local_ts(s):
    """last_update do rbd vem em horário LOCAL, formato %Y-%m-%d %H:%M:%S (vazio = nunca)."""
    if not s:
        return None
    try:
        return time.mktime(time.strptime(s, '%Y-%m-%d %H:%M:%S'))
    except ValueError:
        return None


def utc_ts(s):
    """schedule_time do mgr vem em UTC."""
    try:
        return calendar.timegm(time.strptime(s, '%Y-%m-%d %H:%M:%S'))
    except (ValueError, TypeError):
        return None


def interval_s(txt):
    m = re.fullmatch(r'(\d+)([mhd])', str(txt or '').strip())
    return int(m.group(1)) * {'m': 60, 'h': 3600, 'd': 86400}[m.group(2)] if m else None


def parse_desc(desc):
    """'replaying, {json}' -> dict; outros textos -> {}"""
    i = desc.find('{')
    if i >= 0:
        try:
            return json.loads(desc[i:])
        except ValueError:
            pass
    return {}


def gravidade(state, desc_json):
    st = state.split('+', 1)[-1]
    if 'error' in st:
        return ERRO
    if state.startswith('down+'):
        return ALERTA          # nenhum daemon rbd-mirror reportando esta imagem
    if st == 'replaying':
        return SINCRONIZANDO if desc_json.get('replay_state') == 'syncing' else OK
    if st in ('syncing', 'starting_replay', 'stopping_replay'):
        return SINCRONIZANDO
    return ALERTA              # stopped no lado de destino, unknown...


def guests_pve():
    """vmid -> nome da VM/CT, via pvesh (só existe nos nós Proxmox)."""
    try:
        return {str(r['vmid']): r.get('name', '') for r in
                run(['pvesh', 'get', '/cluster/resources', '--type', 'vm', '--output-format', 'json']) or []
                if 'vmid' in r}
    except Exception:
        return {}


def schedules():
    """Agendamentos de snapshot (só existem no cluster onde a imagem é primária)."""
    niveis, proximos = {}, {}
    try:
        for s in run(['rbd', 'mirror', 'snapshot', 'schedule', 'ls', '--recursive', '--format', 'json']) or []:
            ivs = [interval_s(i.get('interval')) for i in s.get('items', [])]
            ivs = [i for i in ivs if i]
            if ivs:
                niveis[(s.get('pool', '-'), s.get('namespace', '-'), s.get('image', '-'))] = min(ivs)
    except Exception as e:
        print(f'aviso: schedule ls: {e}', file=sys.stderr)
    try:
        st = run(['rbd', 'mirror', 'snapshot', 'schedule', 'status', '--format', 'json']) or []
        # o CLI do rbd devolve uma LISTA [{schedule_time, image}]; o mgr puro devolve {"scheduled_images": [...]}
        itens = st.get('scheduled_images', []) if isinstance(st, dict) else st
        for it in itens:
            partes = it['image'].split('/')
            chave = (partes[0], '', partes[1]) if len(partes) == 2 else (partes[0], partes[1], partes[2])
            t = utc_ts(it.get('schedule_time'))
            if t and (chave not in proximos or t < proximos[chave]):
                proximos[chave] = t
    except Exception as e:
        print(f'aviso: schedule status: {e}', file=sys.stderr)
    return niveis, proximos


def intervalo_efetivo(niveis, pool, ns, img):
    for chave in ((pool, ns, img), (pool, ns or '-', '-'), (pool, '-', '-'), ('-', '-', '-')):
        if chave in niveis:
            return niveis[chave]
    return None


def coletar(cluster, out):
    base = {'pve_cluster': cluster}
    pools = [p['pool_name'] for p in run(['ceph', 'osd', 'pool', 'ls', 'detail', '--format', 'json'])
             if 'rbd' in (p.get('application_metadata') or {})]
    niveis, proximos = schedules()
    vms = guests_pve()

    for pool in pools:
        try:
            nss = [''] + [n['name'] for n in (run(['rbd', 'namespace', 'ls', '--pool', pool, '--format', 'json']) or [])]
        except Exception:
            nss = ['']
        for ns in nss:
            nsarg = ['--namespace', ns] if ns else []
            info = run(['rbd', 'mirror', 'pool', 'info', '--pool', pool, *nsarg, '--format', 'json']) or {}
            if info.get('mode', 'disabled') == 'disabled':
                continue
            site = info.get('site_name') or 'local'
            peers = info.get('peers', [])
            pl = {**base, 'pool': pool, 'namespace': ns}
            out.add('rbdmirror_pool_info', 'Pool/namespace com mirroring habilitado', {**pl, 'mode': info['mode'], 'site': site}, 1)
            for pr in peers:
                out.add('rbdmirror_pool_peer_info', 'Peers do pool', {**pl, 'peer_site': pr.get('site_name', ''),
                        'direction': pr.get('direction', '')}, 1)

            st = run(['rbd', 'mirror', 'pool', 'status', '--pool', pool, *nsarg, '--verbose', '--format', 'json']) or {}
            sm = st.get('summary', {})
            for escopo in ('health', 'daemon_health', 'image_health'):
                out.add('rbdmirror_pool_health', '0=OK 1=UNKNOWN 2=WARNING 3=ERROR', {**pl, 'scope': escopo},
                        HEALTH.get(str(sm.get(escopo, 'UNKNOWN')).upper(), 1))
            for estado, n in (sm.get('states') or {}).items():
                out.add('rbdmirror_pool_images', 'Imagens por estado (visão do Ceph)', {**pl, 'state': estado}, n)
            for dm in st.get('daemons', []):
                out.add('rbdmirror_daemon_health', 'Daemon rbd-mirror deste cluster: 0=OK 1=UNKNOWN 2=WARNING 3=ERROR',
                        {**pl, 'hostname': dm.get('hostname', ''), 'instance_id': dm.get('instance_id', ''),
                         'leader': str(dm.get('leader', False)).lower(), 'ceph_version': dm.get('ceph_version', '')},
                        HEALTH.get(str(dm.get('health', 'UNKNOWN')).upper(), 1))

            for im in st.get('images', []):
                nome, gid = im['name'], im.get('global_id', '')
                entradas = []
                if 'state' in im:
                    entradas.append({'site': site, 'local': True, 'state': im['state'], 'desc': im.get('description', ''),
                                     'upd': local_ts(im.get('last_update'))})
                for ps in im.get('peer_sites', []):
                    entradas.append({'site': ps.get('site_name') or 'peer', 'local': False, 'state': ps.get('state', ''),
                                     'desc': ps.get('description', ''), 'upd': local_ts(ps.get('last_update'))})
                primarias = [e for e in entradas if e['desc'].startswith('local image is primary')]
                destinos = [e for e in entradas if e not in primarias]
                for e in destinos:
                    e['json'] = parse_desc(e['desc'])
                    e['sev'] = gravidade(e['state'], e['json'])
                alvo = max(destinos, key=lambda e: e['sev']) if destinos else None

                if primarias:
                    origem = primarias[0]['site']
                elif not any(e['local'] for e in entradas):
                    origem = site                              # aqui é o primário sem daemon local (one-way)
                else:
                    outros = [p.get('site_name') for p in peers if p.get('site_name') and p.get('direction') != 'tx-only']
                    origem = outros[0] if outros else 'desconhecido'
                destino = alvo['site'] if alvo else ', '.join(p.get('site_name', '') for p in peers) or 'desconhecido'

                dj = alvo['json'] if alvo else {}
                modo = 'snapshot' if 'remote_snapshot_timestamp' in dj or (pool, ns, nome) in proximos \
                    else ('journal' if 'entries_behind_primary' in dj else 'snapshot')
                sev = alvo['sev'] if alvo else SEM_STATUS
                estado = alvo['state'] if alvo else 'sem status'
                if sev in (OK, SINCRONIZANDO):
                    detalhe = ''
                elif not alvo:
                    detalhe = 'o destino não reporta status para este cluster (veja o coletor do cluster de destino)'
                elif alvo['state'].startswith('down+'):
                    detalhe = 'daemon rbd-mirror do destino parou de reportar'
                elif alvo['state'].endswith('+stopped'):
                    detalhe = 'replicação parada no destino'
                else:
                    detalhe = alvo['desc'].split(', {')[0][:110]

                il = {**pl, 'image': nome, 'global_id': gid}
                out.add('rbdmirror_image_info', 'Imagem replicada (origem -> destino)',
                        {**il, 'source': origem, 'target': destino, 'mode': modo, 'state': estado, 'detail': detalhe,
                         'visao': 'destino' if alvo and alvo['local'] else 'origem'}, 1)
                out.add('rbdmirror_image_status', '0=OK 1=SINCRONIZANDO 3=ALERTA 4=ERRO 5=SEM STATUS DO DESTINO', il, sev)
                if alvo:
                    out.add('rbdmirror_image_last_update_timestamp_seconds', 'Último report do daemon', il, alvo['upd'])
                    out.add('rbdmirror_image_last_sync_timestamp_seconds', 'Horário do último snapshot já aplicado no destino',
                            il, dj.get('local_snapshot_timestamp'))
                    out.add('rbdmirror_image_remote_snapshot_timestamp_seconds', 'Horário do snapshot mais novo na origem',
                            il, dj.get('remote_snapshot_timestamp'))
                    out.add('rbdmirror_image_last_sync_duration_seconds', 'Duração da última sync', il, dj.get('last_snapshot_sync_seconds'))
                    out.add('rbdmirror_image_last_sync_bytes', 'Bytes da última sync', il, dj.get('last_snapshot_bytes'))
                    out.add('rbdmirror_image_bytes_per_second', 'Vazão média', il, dj.get('bytes_per_second'))
                    out.add('rbdmirror_image_seconds_until_synced', 'Estimativa para terminar', il, dj.get('seconds_until_synced'))
                    out.add('rbdmirror_image_entries_behind', 'Entradas atrás (modo journal)', il, dj.get('entries_behind_primary'))
                    if dj.get('replay_state') == 'syncing' or 'syncing_percent' in dj:
                        out.add('rbdmirror_image_sync_percent', 'Progresso da sync em andamento', il, dj.get('syncing_percent', 0))
                gl = {**base, 'global_id': gid}
                out.add('rbdmirror_image_schedule_interval_seconds', 'Intervalo do agendamento de snapshot (cluster primário)',
                        gl, intervalo_efetivo(niveis, pool, ns, nome) if origem == site else None)
                out.add('rbdmirror_image_next_snapshot_timestamp_seconds', 'Próximo snapshot agendado (UTC)', gl, proximos.get((pool, ns, nome)))
                m = RE_VMID.match(nome)
                if m and m.group(1) in vms:
                    out.add('rbdmirror_image_guest_info', 'VM/CT dona da imagem', {**gl, 'vmid': m.group(1), 'guest': vms[m.group(1)]}, 1)


def textfile_dir_padrao():
    try:
        for linha in subprocess.run(['ps', '-eo', 'args'], capture_output=True, text=True).stdout.splitlines():
            m = re.search(r'--collector\.textfile\.directory[= ](\S+)', linha)
            if m and ('node_exporter' in linha or 'node-exporter' in linha):
                return m.group(1)
    except Exception:
        pass
    return '/var/lib/prometheus/node-exporter'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pve-cluster', required=True, help='mesmo valor do label instance do pve-exporter')
    ap.add_argument('--textfile-dir', default=None)
    ap.add_argument('--stdout', action='store_true', help='imprime em vez de gravar (teste)')
    a = ap.parse_args()

    out, ini, ok = Out(), time.time(), 1
    try:
        coletar(a.pve_cluster, out)
    except Exception as e:
        ok = 0
        print(f'erro: {e}', file=sys.stderr)
    b = {'pve_cluster': a.pve_cluster}
    out.add('rbdmirror_up', '1 = última coleta ok', b, ok)
    out.add('rbdmirror_collector_timestamp_seconds', 'Horário da última coleta', b, time.time())
    out.add('rbdmirror_collector_duration_seconds', 'Duração da coleta', b, time.time() - ini)
    txt = out.render()

    if a.stdout:
        sys.stdout.write(txt)
        return
    d = a.textfile_dir or textfile_dir_padrao()
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix='.rbd_mirror.')
    with os.fdopen(fd, 'w') as f:
        f.write(txt)
    os.chmod(tmp, 0o644)
    os.replace(tmp, os.path.join(d, 'rbd_mirror.prom'))   # escrita atômica: o node_exporter nunca lê arquivo pela metade


if __name__ == '__main__':
    main()
PYEOF_RBDMIRROR
}

if [[ "$MODO" == "exportar-coletores" ]]; then
  [[ -n "$DESTINO" ]] || uso
  mkdir -p "$DESTINO"
  grava_hwhealth "$DESTINO/hwhealth_textfile.py"; grava_hosttop "$DESTINO/hosttop_textfile.py"; grava_guestdisk "$DESTINO/pve_guestdisk_textfile.py"; grava_rbdmirror "$DESTINO/rbdmirror_textfile.py"
  echo "Coletores gravados em $DESTINO"; exit 0
fi

# ----------------------------------------------------------------------------------------------- systemd helpers
servico_coletor() {   # nome  descrição  ExecStart  intervalo(s)  [EnvironmentFile]
  local nome=$1 desc=$2 exec=$3 intervalo=$4 envf=${5:-}
  cat > "/etc/systemd/system/$nome.service" <<EOF
[Unit]
Description=$desc
After=network-online.target pve-cluster.service

[Service]
Type=oneshot
${envf:+EnvironmentFile=$envf}
ExecStart=$exec
Nice=10
IOSchedulingClass=idle
TimeoutStartSec=300
EOF
  cat > "/etc/systemd/system/$nome.timer" <<EOF
[Unit]
Description=$desc (a cada ${intervalo}s)

[Timer]
OnBootSec=60s
OnUnitActiveSec=${intervalo}s
AccuracySec=5s

[Install]
WantedBy=timers.target
EOF
}

# ----------------------------------------------------------------------------------------------- status
mostrar_status() {
  etapa "node_exporter"
  if [[ -x "$BIN" ]]; then
    ok "versão $("$BIN" --version 2>&1 | head -1 | sed -nE 's/.*version ([0-9][^ ]*).*/\1/p') · serviço $(systemctl is-active node_exporter 2>/dev/null || true)"
    systemctl show -p ExecStart --value node_exporter 2>/dev/null | grep -q -- '--collector.textfile.directory' \
      || grep -qs -- '--collector.textfile.directory' "$UNIT" /etc/systemd/system/node_exporter.service.d/*.conf \
      && ok "coletor textfile ligado ($TXT)" || aviso "coletor textfile DESLIGADO"
  else
    aviso "node_exporter não instalado"
  fi
  if [[ -x "$ZBIN" ]]; then
    etapa "zfs_exporter"
    if curl -s --max-time 30 http://127.0.0.1:9134/metrics | grep -q '^zfs_'; then
      ok "versão $("$ZBIN" --version 2>&1 | head -1 | sed -nE 's/.*version ([0-9][^ ]*).*/\1/p') · respondendo na 9134"
    else aviso "instalado, mas não responde na 9134 (serviço $(systemctl is-active zfs_exporter 2>/dev/null || true))"; fi
  fi
  etapa "coletores"
  for c in hwhealth-textfile:hwhealth.prom:hwhealth_collector_up hosttop-textfile:hosttop.prom:hosttop_collector_up pve-guestdisk-textfile:pve_guestdisk.prom:pve_guestdisk_up rbdmirror-textfile:rbd_mirror.prom:rbdmirror_up; do
    IFS=: read -r u arq met <<< "$c"
    if systemctl list-unit-files "$u.timer" >/dev/null 2>&1 && [[ -f "/etc/systemd/system/$u.timer" ]]; then
      local idade="—"; [[ -f "$TXT/$arq" ]] && idade="$(( $(date +%s) - $(stat -c %Y "$TXT/$arq") ))s atrás"
      if publica "$met"; then ok "$u: última coleta $idade · publicando"; else aviso "$u: última coleta $idade · NÃO publicado pelo node_exporter"; fi
    else
      info "$u: não instalado"
    fi
  done
  if [[ -f "$TXT/hwhealth.prom" ]]; then
    etapa "saúde dos discos (resumo)"
    info "discos físicos: $(grep '^hwhealth_disk_info{' "$TXT/hwhealth.prom" | grep -vc 'type="raid-virtual"' || true) · SMART reprovado: $(grep -c '^hwhealth_disk_smart_passed{.*} 0$' "$TXT/hwhealth.prom" || true)"
    local mw; mw=$(grep '^hwhealth_disk_wearout_percent{' "$TXT/hwhealth.prom" | awk '{print $2}' | sort -n | tail -1 || true)
    info "maior wearout: ${mw:-—}${mw:+%}"
    case "$(grep '^hwhealth_boot_redundant{' "$TXT/hwhealth.prom" | awk '{print $2}')" in
      1) ok "boot espelhado" ;; -1) aviso "boot em volume RAID de nível desconhecido (instale o storcli)" ;; *) aviso "boot SEM espelho (um disco só)" ;;
    esac
  fi
}

# ----------------------------------------------------------------------------------------------- remover
if [[ "$MODO" == "remover" ]]; then
  for u in hwhealth-textfile hosttop-textfile pve-guestdisk-textfile rbdmirror-textfile; do
    systemctl disable --now "$u.timer" 2>/dev/null || true
    rm -f "/etc/systemd/system/$u.service" "/etc/systemd/system/$u.timer"
  done
  rm -f /usr/local/bin/hwhealth_textfile.py /usr/local/bin/hosttop_textfile.py /usr/local/bin/pve_guestdisk_textfile.py /usr/local/bin/rbdmirror_textfile.py
  rm -f "$TXT/hwhealth.prom" "$TXT/hosttop.prom" "$TXT/pve_guestdisk.prom" "$TXT/rbd_mirror.prom"
  rm -rf /var/lib/pve-guestdisk
  if [[ $TUDO -eq 1 ]]; then
    systemctl disable --now node_exporter 2>/dev/null || true
    rm -rf "$UNIT" /etc/systemd/system/node_exporter.service.d "$BIN"
    systemctl disable --now zfs_exporter 2>/dev/null || true
    rm -f "$ZUNIT" "$ZBIN"
    echo "Coletores, node_exporter e zfs_exporter removidos."
  else
    echo "Coletores removidos (node_exporter mantido; use --tudo para remover também)."
  fi
  systemctl daemon-reload; exit 0
fi
if [[ "$MODO" == "status" ]]; then mostrar_status; exit 0; fi

# =============================================================================================== 1) NODE_EXPORTER
etapa "node_exporter ($MODO)"
case "$(uname -m)" in x86_64) ARCH=amd64 ;; aarch64) ARCH=arm64 ;; armv7l) ARCH=armv7 ;; *) echo "Arquitetura não suportada: $(uname -m)"; exit 1 ;; esac
if systemctl is-active --quiet prometheus-node-exporter 2>/dev/null; then
  echo "ERRO: o node exporter do pacote Debian (prometheus-node-exporter) já usa a porta 9100."
  echo "      Use um só. Para trocar por este:  systemctl disable --now prometheus-node-exporter"; exit 1
fi

if [[ "$MODO" == "offline" ]]; then
  ARQUIVO=$(ls -1 "$DIR_SCRIPT"/node_exporter-*.linux-"$ARCH".tar.gz 2>/dev/null | sort -V | tail -1 || true)
  [[ -n "$ARQUIVO" ]] || { echo "ERRO: coloque node_exporter-<versão>.linux-$ARCH.tar.gz e sha256sums.txt nesta pasta ($DIR_SCRIPT)."; exit 1; }
  VERSAO=$(basename "$ARQUIVO" | sed -nE "s/^node_exporter-([0-9][^ ]*)\.linux-$ARCH\.tar\.gz$/\1/p")
  [[ -f "$DIR_SCRIPT/sha256sums.txt" ]] || { echo "ERRO: falta o sha256sums.txt ao lado de $(basename "$ARQUIVO")."; exit 1; }
else
  read -r VERSAO ORIGEM <<< "$(ultima_versao node_exporter prometheus/node_exporter)" || true
fi
[[ "${VERSAO:-}" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]] || { echo "ERRO: não consegui descobrir a versão: sem acesso ao NewOS${NEWOS_URL:+ ($NEWOS_URL)} nem à internet. Use: offline"; exit 1; }
ATUAL=$( ("$BIN" --version 2>&1 || true) | head -1 | sed -nE 's/.*version ([0-9][^ ]*).*/\1/p')
info "instalado: ${ATUAL:-nenhum} · disponível: $VERSAO${ORIGEM:+ (via $([[ $ORIGEM == newos ]] && echo "NewOS $NEWOS_URL" || echo GitHub))}"

if [[ "$ATUAL" != "$VERSAO" ]]; then
  PKG="node_exporter-${VERSAO}.linux-${ARCH}"
  TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
  if [[ "$MODO" == "offline" ]]; then
    cp "$ARQUIVO" "$TMP/${PKG}.tar.gz"; cp "$DIR_SCRIPT/sha256sums.txt" "$TMP/"
    (cd "$TMP" && grep " ${PKG}.tar.gz\$" sha256sums.txt | sha256sum -c - >/dev/null) || { echo "ERRO: checksum não confere. Abortando."; exit 1; }
  else
    baixar_pacote node_exporter prometheus/node_exporter "$VERSAO" "$ORIGEM" "$TMP/${PKG}.tar.gz" \
      || { echo "ERRO: download do node_exporter falhou ou o checksum não confere. Abortando."; exit 1; }
  fi
  ok "checksum conferido"
  tar -xzf "$TMP/${PKG}.tar.gz" -C "$TMP"
  "$TMP/$PKG/node_exporter" --version >/dev/null 2>&1 || { echo "ERRO: binário novo não executa."; exit 1; }
  id node_exporter >/dev/null 2>&1 || useradd --system --no-create-home --shell /bin/false node_exporter
  systemctl is-active --quiet node_exporter && systemctl stop node_exporter
  [[ -f "$BIN" && -n "$ATUAL" ]] && cp -a "$BIN" "$BIN.bkp-$ATUAL"
  install -o node_exporter -g node_exporter -m 0755 "$TMP/$PKG/node_exporter" "$BIN"
  ok "node_exporter $VERSAO instalado${ATUAL:+ (anterior $ATUAL guardado em $BIN.bkp-$ATUAL)}"
else
  ok "já está na última versão"
fi
id node_exporter >/dev/null 2>&1 || useradd --system --no-create-home --shell /bin/false node_exporter
mkdir -p "$TXT"; chmod 755 "$TXT"

if [[ ! -f "$UNIT" ]]; then
  cat > "$UNIT" <<EOF
[Unit]
Description=Node Exporter
Wants=network-online.target
After=network-online.target

[Service]
User=node_exporter
Group=node_exporter
Type=simple
ExecStart=$BIN --collector.textfile.directory=$TXT
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  ok "serviço criado (com o coletor textfile)"
else
  CMD=$(systemctl show -p ExecStart --value node_exporter 2>/dev/null | sed -nE 's/.*argv\[\]=([^;]*);.*/\1/p' | head -1 | sed 's/ *$//')
  if [[ "$CMD" != *"--collector.textfile.directory"* ]] && \
     ! grep -qs -- '--collector.textfile.directory' "$UNIT" /etc/systemd/system/node_exporter.service.d/*.conf; then
    mkdir -p /etc/systemd/system/node_exporter.service.d
    printf '[Service]\nExecStart=\nExecStart=%s --collector.textfile.directory=%s\n' "${CMD:-$BIN}" "$TXT" \
      > /etc/systemd/system/node_exporter.service.d/textfile.conf
    ok "coletor textfile acrescentado ao serviço existente (opções antigas mantidas)"
  else
    ok "serviço existente mantido (textfile já ligado)"
  fi
fi
systemctl daemon-reload
systemctl enable node_exporter >/dev/null 2>&1
systemctl restart node_exporter
sleep 2
publica "node_exporter_build_info" || { echo "ERRO: node_exporter não responde na 9100. Veja: journalctl -u node_exporter -n 50"; exit 1; }
ok "respondendo na porta 9100"

# =============================================================================================== 1b) ZFS_EXPORTER (host com pool ZFS)
instalar_zfs_exporter() {
  local zver="" zorig="" zatual zarq ztmp zpkg
  if [[ "$MODO" == "offline" ]]; then
    zarq=$(ls -1 "$DIR_SCRIPT"/zfs_exporter-*.linux-"$ARCH".tar.gz 2>/dev/null | sort -V | tail -1 || true)
    [[ -n "$zarq" ]] && zver=$(basename "$zarq" | sed -nE "s/^zfs_exporter-([0-9][^ ]*)\.linux-$ARCH\.tar\.gz$/\1/p")
  else
    read -r zver zorig <<< "$(ultima_versao zfs_exporter pdf/zfs_exporter)" || true
  fi
  zatual=$( ("$ZBIN" --version 2>&1 || true) | head -1 | sed -nE 's/.*version ([0-9][^ ]*).*/\1/p')
  if [[ ! "${zver:-}" =~ ^[0-9]+\.[0-9]+\.[0-9]+ ]]; then
    if [[ -n "$zatual" ]]; then aviso "versão nova indisponível; mantido o $zatual"
    else aviso "zfs_exporter não instalado: sem o pacote (offline: zfs_exporter-*.linux-$ARCH.tar.gz + sha256sums-zfs_exporter.txt nesta pasta)"; return 1; fi
  elif [[ "$zatual" != "$zver" ]]; then
    zpkg="zfs_exporter-${zver}.linux-${ARCH}"; ztmp=$(mktemp -d)
    if [[ "$MODO" == "offline" ]]; then
      cp "$zarq" "$ztmp/$zpkg.tar.gz"
      (cd "$ztmp" && grep " $zpkg.tar.gz\$" "$DIR_SCRIPT/sha256sums-zfs_exporter.txt" 2>/dev/null | sha256sum -c - >/dev/null 2>&1) \
        || { aviso "zfs_exporter: checksum não confere (ou falta o sha256sums-zfs_exporter.txt)"; rm -rf "$ztmp"; return 1; }
    else
      baixar_pacote zfs_exporter pdf/zfs_exporter "$zver" "$zorig" "$ztmp/$zpkg.tar.gz" \
        || { aviso "zfs_exporter: download falhou ou o checksum não confere"; rm -rf "$ztmp"; return 1; }
    fi
    tar -xzf "$ztmp/$zpkg.tar.gz" -C "$ztmp" && "$ztmp/$zpkg/zfs_exporter" --version >/dev/null 2>&1 \
      || { aviso "zfs_exporter: pacote inválido"; rm -rf "$ztmp"; return 1; }
    systemctl stop zfs_exporter 2>/dev/null || true
    install -m 0755 "$ztmp/$zpkg/zfs_exporter" "$ZBIN"
    rm -rf "$ztmp"
    ok "zfs_exporter $zver instalado${zatual:+ (era $zatual)}${zorig:+ · via $([[ $zorig == newos ]] && echo NewOS || echo GitHub)}"
  else
    ok "zfs_exporter já está na última versão ($zatual)"
  fi
  if [[ ! -f "$ZUNIT" ]]; then
    # root: o zfs_exporter chama zpool/zfs, que exigem root
    cat > "$ZUNIT" <<EOF
[Unit]
Description=ZFS Exporter (Prometheus)
Wants=network-online.target
After=network-online.target zfs.target

[Service]
Type=simple
ExecStart=$ZBIN --web.listen-address=:9134
Restart=on-failure
RestartSec=5
Nice=10

[Install]
WantedBy=multi-user.target
EOF
    ok "serviço zfs_exporter criado (porta 9134)"
  fi
  systemctl daemon-reload
  systemctl enable zfs_exporter >/dev/null 2>&1
  systemctl restart zfs_exporter
  sleep 2
  if curl -s --max-time 30 http://127.0.0.1:9134/metrics | grep -q '^zfs_'; then ok "respondendo na porta 9134"
  else aviso "zfs_exporter não responde na 9134: journalctl -u zfs_exporter -n 50"; return 1; fi
}
TEM_ZFS=0
command -v zpool >/dev/null && [[ -n "$(zpool list -H -o name 2>/dev/null || true)" ]] && TEM_ZFS=1
if [[ $TEM_ZFS -eq 1 ]]; then
  etapa "zfs_exporter (pools ZFS: $(zpool list -H -o name | paste -sd, - | sed 's/,/, /g'))"
  instalar_zfs_exporter || aviso "o node_exporter segue funcionando; rode o script de novo depois para o zfs_exporter"
fi

[[ $CONFIGURAR -eq 1 ]] || { echo; echo "Pronto. Para instalar também os coletores (discos, VMs, RBD): $0 $MODO --configure"; exit 0; }

# =============================================================================================== 2) COLETORES
command -v python3 >/dev/null || { echo "ERRO: python3 não encontrado."; exit 1; }
EH_PVE=0; command -v pveversion >/dev/null && EH_PVE=1
EH_PBS=0; command -v proxmox-backup-manager >/dev/null && EH_PBS=1

# --------------------------------------------------------------------------- 2a) saúde dos discos
etapa "saúde dos discos (SMART · wearout · temperatura · RAID)"
if ! command -v smartctl >/dev/null; then
  if [[ "$MODO" == "online" ]]; then
    timeout 180 apt-get install -y -qq smartmontools >/dev/null 2>&1 && ok "smartmontools instalado" \
      || aviso "smartmontools não instalado (sem repositório apt?): sem ele a saúde dos discos fica incompleta"
  else aviso "smartctl não encontrado e o modo é offline: copie e instale o .deb do smartmontools (o Proxmox já traz)"; fi
fi
TEM_MEGARAID=0
grep -qs megaraid_sas /sys/class/scsi_host/*/proc_name && TEM_MEGARAID=1
if [[ $TEM_MEGARAID -eq 1 ]]; then
  if command -v storcli64 >/dev/null || [[ -x /opt/MegaRAID/storcli/storcli64 ]] || command -v perccli64 >/dev/null; then
    ok "controladora MegaRAID com storcli"
  else
    DEB=$(ls -1 "$DIR_SCRIPT"/storcli*_all.deb 2>/dev/null | sort -V | tail -1 || true)
    if [[ -n "$DEB" ]]; then
      dpkg -i "$DEB" >/dev/null && ln -sf /opt/MegaRAID/storcli/storcli64 /usr/local/sbin/storcli64 && ok "storcli instalado ($(basename "$DEB"))"
    else
      aviso "controladora MegaRAID sem storcli: coloque o storcli_*_all.deb (Broadcom) nesta pasta e rode de novo"
      aviso "sem ele os discos físicos aparecem como 'RAID' e o espelho do boot como 'RAID ?'"
    fi
  fi
fi
grava_hwhealth /usr/local/bin/hwhealth_textfile.py; chmod 755 /usr/local/bin/hwhealth_textfile.py
servico_coletor hwhealth-textfile "Saúde de discos e hardware para o node_exporter" \
  "/usr/bin/env python3 /usr/local/bin/hwhealth_textfile.py --textfile-dir $TXT" 300

# --------------------------------------------------------------------------- 2a2) processos (todo host)
etapa "processos (top CPU/memória · VM de cada processo · serviços com falha)"
grava_hosttop /usr/local/bin/hosttop_textfile.py; chmod 755 /usr/local/bin/hosttop_textfile.py
servico_coletor hosttop-textfile "Top processos e serviços com falha para o node_exporter" \
  "/usr/bin/env python3 /usr/local/bin/hosttop_textfile.py --textfile-dir $TXT" 60

# --------------------------------------------------------------------------- 2b) disco real das VMs
if [[ $EH_PVE -eq 1 ]]; then
  etapa "disco real das VMs (agente QEMU · ZFS · Ceph RBD)"
  grava_guestdisk /usr/local/bin/pve_guestdisk_textfile.py; chmod 755 /usr/local/bin/pve_guestdisk_textfile.py
  servico_coletor pve-guestdisk-textfile "Consumo real de disco das VMs para o node_exporter" \
    "/usr/bin/env python3 /usr/local/bin/pve_guestdisk_textfile.py --textfile-dir $TXT" 60
fi

# --------------------------------------------------------------------------- 2c) RBD-mirror (só Ceph com mirroring)
RBD=0
if [[ $EH_PVE -eq 1 ]] && command -v rbd >/dev/null && command -v ceph >/dev/null; then
  for p in $(timeout 20 ceph osd pool ls detail --format json 2>/dev/null \
             | python3 -c 'import json,sys;[print(p["pool_name"]) for p in json.load(sys.stdin) if "rbd" in (p.get("application_metadata") or {})]' 2>/dev/null || true); do
    m=$(timeout 20 rbd mirror pool info --pool "$p" --format json 2>/dev/null | python3 -c 'import json,sys;print(json.load(sys.stdin).get("mode","disabled"))' 2>/dev/null || echo disabled)
    [[ "$m" != "disabled" ]] && RBD=1 && break
  done
fi
if [[ $RBD -eq 1 ]]; then
  etapa "replicação Ceph (rbd-mirror)"
  ENVF=/etc/default/rbdmirror-textfile
  [[ -z "$PVE_CLUSTER" && -f "$ENVF" ]] && PVE_CLUSTER=$(sed -n 's/^PVE_CLUSTER="\{0,1\}\([^"]*\)"\{0,1\}$/\1/p' "$ENVF")
  if [[ -z "$PVE_CLUSTER" ]]; then
    SUG=$(sed -n 's/^\s*cluster_name:\s*//p' /etc/pve/corosync.conf 2>/dev/null | head -1)
    if [[ -t 0 ]]; then
      read -rp "    Nome do cluster no pve-exporter (o 'instance' do Prometheus) [${SUG:-}]: " PVE_CLUSTER
      PVE_CLUSTER=${PVE_CLUSTER:-$SUG}
    fi
  fi
  if [[ -n "$PVE_CLUSTER" ]]; then
    printf 'PVE_CLUSTER="%s"\nTEXTFILE_DIR="%s"\n' "$PVE_CLUSTER" "$TXT" > "$ENVF"
    grava_rbdmirror /usr/local/bin/rbdmirror_textfile.py; chmod 755 /usr/local/bin/rbdmirror_textfile.py
    servico_coletor rbdmirror-textfile "Replicação Ceph RBD-mirror para o node_exporter" \
      "/usr/bin/env python3 /usr/local/bin/rbdmirror_textfile.py --pve-cluster \${PVE_CLUSTER} --textfile-dir \${TEXTFILE_DIR}" 60 "$ENVF"
    ok "cluster: $PVE_CLUSTER"
  else
    aviso "mirroring Ceph detectado, mas sem nome do cluster: rode de novo com --pve-cluster NOME"
  fi
fi

# --------------------------------------------------------------------------- 2d) ativa tudo e faz a primeira coleta
etapa "primeira coleta"
systemctl daemon-reload
for u in hwhealth-textfile hosttop-textfile pve-guestdisk-textfile rbdmirror-textfile; do
  [[ -f "/etc/systemd/system/$u.timer" ]] || continue
  systemctl enable --now "$u.timer" >/dev/null 2>&1
  if systemctl start "$u.service"; then ok "$u"; else aviso "$u falhou: journalctl -u $u.service -n 30"; fi
done
sleep 2
mostrar_status

# --------------------------------------------------------------------------- resumo: o que fazer na VM proxy
IP=$(hostname -I | awk '{print $1}')
etapa "na VM proxy (Prometheus)"
info "job 'node'          : - targets: ['$IP:9100']"
[[ $TEM_ZFS -eq 1 && -x "$ZBIN" ]] && info "job 'zfs'           : - targets: ['$IP:9134']"
[[ $EH_PVE -eq 1 ]] && info "job 'pve-replicacao': - $(hostname -f 2>/dev/null || hostname)   (replicação ZFS deste nó)"
[[ $EH_PBS -eq 1 ]] && info "host PBS            : dashboard NEWIO · PBS · BACKUP (datastores em /mnt/datastore)"
[[ $EH_PVE -eq 0 && $EH_PBS -eq 0 ]] && info "host standalone     : dashboard NEWIO · HOST · NODE EXPORTER"
info "firewall            : liberar da proxy para $IP as portas TCP 9100$([[ $TEM_ZFS -eq 1 ]] && echo ", 9134") e 8006"
echo
echo "Pronto."
