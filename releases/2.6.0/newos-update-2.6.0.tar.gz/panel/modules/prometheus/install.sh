#!/usr/bin/env bash
# =====================================================================
#  Modulo Prometheus - instalacao
# ---------------------------------------------------------------------
#  Chamado por: newos-modctl install prometheus   (root, precisa de internet)
#  O trabalho todo fica no helper newos-prometheus: baixa a versao
#  oficial mais nova do GitHub (sha256 conferido), cria o servico e gera
#  o prometheus.yml a partir da configuracao feita na web.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="prometheus"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

have_internet "https://github.com/prometheus/prometheus/releases/latest" || \
    mod_die "Sem acesso ao github.com: o Prometheus oficial vem de la." 2
# python3-yaml: o importador (Prometheus > Importar) le os arquivos YAML.
dpkg -s python3-yaml >/dev/null 2>&1 || apt-get install -y -q python3-yaml >/dev/null 2>&1 || true
mod_info "Instalando o Prometheus oficial (github.com/prometheus/prometheus)..."
NEWOS_MODULE_DIR="${NEWOS_MODULE_DIR:-$(cd "$(dirname "$0")" && pwd)}" \
    /usr/local/sbin/newos-prometheus install prometheus | sed -n 's/.*"message": "\([^"]*\)".*/[prometheus] \1/p'
mod_info "Abra Monitoramento > Prometheus no menu. Os exporters ligam aqui, nos componentes."
