"""
NewOS Panel - modulo NBackup (backup das configuracoes de rede).

    /nbackup                                visao geral: equipamentos, ultima coleta, S3
    /nbackup/equipamentos                   lista e cadastro
    /nbackup/equipamentos/{id}              editar, testar, versoes e diferencas
    /nbackup/equipamentos/{id}/versao/{c}   configuracao de uma versao (?baixar=1 baixa)
    /nbackup/equipamentos/{id}/diferenca    diferenca entre duas versoes (?a=&b=)
    /nbackup/ajustes                        diretorio, horario, S3 e restauracao

Tudo passa pelo helper newos-nbackup (sudo). O painel nunca ve as
credenciais: manda a senha nova uma vez, o helper cifra e guarda.
Ver a configuracao (ela tem senhas dos equipamentos) e alterar e so para
administradores; a visao geral e para todos.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, Response
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules, terminal_routes

log = logging.getLogger("newos.panel.nbackup")
HELPER = "/usr/local/sbin/newos-nbackup"
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,47}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{7,40}$")

# Como criar o usuario somente leitura em cada fabricante (mostrado no cadastro)
HOWTO = {
    "cisco_ios": "username nbackup privilege 15 secret <senha>\n"
                 "line vty 0 15\n access-class ACL-NBACKUP in   (ACL só com o IP deste NewOS)\n"
                 "Para um usuário mais restrito, use um parser view que só permita show running-config.",
    "cisco_nxos": "username nbackup password <senha> role network-operator\n"
                  "(network-operator só lê, inclusive show running-config).",
    "huawei": "aaa\n local-user nbackup password irreversible-cipher <senha>\n local-user nbackup privilege level 3\n"
              " local-user nbackup service-type ssh\nssh user nbackup authentication-type password\n"
              "ssh user nbackup service-type stelnet",
    "fortinet": "System > Admin Profiles: crie um perfil só leitura.\nSystem > Administrators > Create New > REST API Admin:\n"
                "perfil só leitura, Trusted Hosts = IP deste NewOS, e copie o token gerado.",
    "mikrotik": "/user group add name=nbackup policy=ssh,read,sensitive,!write,!policy\n"
                "/user add name=nbackup group=nbackup password=<senha>\n"
                "(sensitive é o que permite o export trazer as senhas, para o backup restaurar completo).",
}


class NBackupError(RuntimeError):
    pass


def helper(args: list[str], payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], input=json.dumps(payload) if payload is not None else None,
                              capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise NBackupError("A operação demorou demais; ela segue em segundo plano. Atualize a página em instantes.") from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise NBackupError(f"Não foi possível executar o newos-nbackup: {exc}") from exc
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        raise NBackupError((lines[-1] if lines else "falhou").removeprefix("ERRO: "))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def guard(request: Request, admin: bool = False) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, redirect("/login")
        if not (modules.get_module("nbackup") or {}).get("enabled"):
            flash(request, "aviso", "Ligue o módulo NBackup em Sistema > Módulos.")
            return None, redirect("/modulos")
        if admin and not terminal_routes.is_admin(user):
            flash(request, "erro", "Só administradores veem e alteram as configurações dos equipamentos.")
            return None, redirect("/nbackup")
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "nbackup", what, auth.client_ip(request))
        log.info("NBackup por %s: %s", user["username"], what)

    async def status() -> dict[str, Any]:
        try:
            return await run_in_threadpool(helper, ["status"])
        except NBackupError as exc:
            return {"ok": False, "error": str(exc), "devices": [], "conf": {}, "dir": {}, "s3": {}, "vendors": {}, "last": {}}

    async def act(request: Request, user: dict[str, Any], args: list[str], what: str,
                  payload: dict[str, Any] | None = None, timeout: int = 120) -> dict[str, Any] | None:
        try:
            res = await run_in_threadpool(helper, args, payload, timeout)
        except NBackupError as exc:
            flash(request, "erro", str(exc))
            return None
        audit(request, user, what)
        flash(request, "ok" if not res.get("failed") else "aviso", res.get("message", "Feito."))
        return res

    # ------------------------------------------------------------------ telas
    @app.get("/nbackup", response_class=HTMLResponse)
    async def nbk_overview(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        st = await status()
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        return render(request, "nbackup_overview.html", active="nbackup", st=st, admin=admin)

    @app.get("/nbackup/equipamentos", response_class=HTMLResponse)
    async def nbk_devices(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        st = await status()
        admin = await run_in_threadpool(terminal_routes.is_admin, user)
        return render(request, "nbackup_devices.html", active="nbackup-equipamentos", st=st, admin=admin, howto=HOWTO, dev=None)

    @app.get("/nbackup/equipamentos/{did}", response_class=HTMLResponse)
    async def nbk_device(request: Request, did: str):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        if not ID_RE.match(did):
            return redirect("/nbackup/equipamentos")
        st = await status()
        dev = next((d for d in st.get("devices", []) if d["id"] == did), None)
        if not dev:
            flash(request, "erro", "Equipamento não encontrado.")
            return redirect("/nbackup/equipamentos")
        try:
            hist = (await run_in_threadpool(helper, ["history", did])).get("items", [])
        except NBackupError as exc:
            hist = []
            flash(request, "aviso", str(exc))
        return render(request, "nbackup_device.html", active="nbackup-equipamentos", st=st, dev=dev, hist=hist, howto=HOWTO)

    @app.get("/nbackup/equipamentos/{did}/versao/{commit}")
    async def nbk_version(request: Request, did: str, commit: str, baixar: int = 0):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        if not ID_RE.match(did) or not COMMIT_RE.match(commit):
            return redirect("/nbackup/equipamentos")
        try:
            res = await run_in_threadpool(helper, ["show", did, commit])
        except NBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect(f"/nbackup/equipamentos/{did}")
        if baixar:
            audit(request, user, f"baixou a configuração de {res['name']} ({commit[:10]})")
            return Response(res["text"], media_type="text/plain; charset=utf-8",
                            headers={"Content-Disposition": f'attachment; filename="{did}-{commit[:10]}.cfg"'})
        audit(request, user, f"viu a configuração de {res['name']} ({commit[:10]})")
        return render(request, "nbackup_view.html", active="nbackup-equipamentos", did=did, commit=commit, res=res)

    @app.get("/nbackup/equipamentos/{did}/diferenca", response_class=HTMLResponse)
    async def nbk_diff(request: Request, did: str, a: str = "", b: str = ""):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        if not ID_RE.match(did) or not COMMIT_RE.match(a) or not COMMIT_RE.match(b):
            flash(request, "aviso", "Escolha duas versões para comparar.")
            return redirect(f"/nbackup/equipamentos/{did}")
        try:
            res = await run_in_threadpool(helper, ["diff", did, a, b])
            hist = (await run_in_threadpool(helper, ["history", did])).get("items", [])
        except NBackupError as exc:
            flash(request, "erro", str(exc))
            return redirect(f"/nbackup/equipamentos/{did}")
        st = await status()
        dev = next((d for d in st.get("devices", []) if d["id"] == did), {"id": did, "name": did})
        when = {h["commit"]: h["when"] for h in hist}
        return render(request, "nbackup_diff.html", active="nbackup-equipamentos", dev=dev, res=res, a=a, b=b, when=when)

    @app.get("/nbackup/ajustes", response_class=HTMLResponse)
    async def nbk_settings(request: Request):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        st = await status()
        copies, copies_err = [], ""
        if st.get("s3", {}).get("ready"):
            try:
                copies = (await run_in_threadpool(helper, ["s3-list"], None, 60)).get("items", [])
            except NBackupError as exc:
                copies_err = str(exc)
        return render(request, "nbackup_settings.html", active="nbackup-ajustes", st=st, copies=copies, copies_err=copies_err)

    # ------------------------------------------------------------------ acoes
    @app.post("/nbackup/ajustes")
    async def nbk_settings_save(request: Request):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        f = await request.form()
        payload = {"path": str(f.get("path") or ""), "time": str(f.get("time") or "03:00"), "enabled": bool(f.get("enabled")),
                   "s3_enabled": bool(f.get("s3_enabled")), "s3_keep": str(f.get("s3_keep") or "30")}
        await act(request, user, ["settings"], f"ajustes: {payload['path']} às {payload['time']}", payload)
        return redirect("/nbackup/ajustes")

    @app.post("/nbackup/s3-restaurar")
    async def nbk_s3_restore(request: Request):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        f = await request.form()
        name = str(f.get("name") or "")
        if f.get("confirm") != "RESTAURAR":
            flash(request, "aviso", "Digite RESTAURAR para confirmar.")
            return redirect("/nbackup/ajustes")
        await act(request, user, ["s3-restore", name], f"restaurou o histórico do S3 ({name})", None, 900)
        return redirect("/nbackup/ajustes")

    @app.post("/nbackup/rodar")
    async def nbk_run_all(request: Request):
        user, bounce = guard(request)
        if bounce:
            return bounce
        await act(request, user, ["run-bg"], "coleta de todos os equipamentos (agora)")
        return redirect("/nbackup")

    @app.post("/nbackup/equipamentos/salvar")
    async def nbk_device_save(request: Request):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        f = await request.form()
        payload = {k: str(f.get(k) or "") for k in ("id", "name", "vendor", "method", "host", "port", "username", "note",
                                                     "password", "secret", "token")}
        payload["enabled"] = bool(f.get("enabled"))
        for k in ("password", "secret", "token"):
            payload[f"clear_{k}"] = bool(f.get(f"clear_{k}"))
        res = await act(request, user, ["device-save"], f"salvou o equipamento {payload['name']} ({payload['host']})", payload)
        if res and f.get("test"):
            await act(request, user, ["run", res["id"]], f"testou {payload['name']}", None, 300)
        if res:
            return redirect(f"/nbackup/equipamentos/{res['id']}")
        return redirect(f"/nbackup/equipamentos/{payload['id']}" if ID_RE.match(payload["id"]) else "/nbackup/equipamentos")

    @app.post("/nbackup/equipamentos/{did}/{acao}")
    async def nbk_device_action(request: Request, did: str, acao: str):
        user, bounce = guard(request, admin=True)
        if bounce:
            return bounce
        if not ID_RE.match(did):
            return redirect("/nbackup/equipamentos")
        if acao == "coletar":
            await act(request, user, ["run", did], f"coletou agora {did}", None, 300)
        elif acao == "confiar":
            await act(request, user, ["trust", did], f"aceitou a chave nova de {did}")
        elif acao == "excluir":
            await act(request, user, ["device-del", did], f"removeu o equipamento {did}")
            return redirect("/nbackup/equipamentos")
        return redirect(f"/nbackup/equipamentos/{did}")
