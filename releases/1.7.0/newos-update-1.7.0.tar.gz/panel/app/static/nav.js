/* =====================================================================
   NewOS Panel - menu lateral
   ---------------------------------------------------------------------
   - clique no titulo do grupo: fixa aberto / fecha (lembrado no
     navegador); o mouse por cima abre so de passagem (CSS :hover)
   - o grupo da pagina atual ja vem aberto do servidor
   - entrada escalonada dos itens 1x por sessao
   ===================================================================== */
(function () {
    "use strict";

    var nav = document.querySelector(".nav");
    if (!nav) return;
    var KEY = "newos.nav.open";

    function load() {
        try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; }
    }
    function save(list) {
        try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* sem storage: so nesta pagina */ }
    }

    var pinned = load();
    nav.querySelectorAll(".nav-group[data-group]").forEach(function (g) {
        var id = g.getAttribute("data-group");
        var btn = g.querySelector(".nav-group-title");
        function set(open) {
            g.classList.toggle("open", open);
            btn.setAttribute("aria-expanded", open ? "true" : "false");
        }
        if (pinned.indexOf(id) !== -1) set(true);

        btn.addEventListener("click", function () {
            var open = !g.classList.contains("open");
            set(open);
            var list = load().filter(function (x) { return x !== id; });
            if (open) list.push(id);
            save(list);
            // fechado com o mouse ainda em cima: o :hover o manteria aberto
            if (!open) {
                g.classList.add("nav-shut");
                g.addEventListener("mouseleave", function off() {
                    g.classList.remove("nav-shut");
                    g.removeEventListener("mouseleave", off);
                });
            }
        });
    });

    try {
        if (!sessionStorage.getItem("newos.nav.intro")) {
            Array.prototype.forEach.call(nav.children, function (el, i) { el.style.setProperty("--n", i); });
            nav.classList.add("nav-intro");
            sessionStorage.setItem("newos.nav.intro", "1");
        }
    } catch (e) { /* sem storage: sem animacao de entrada */ }

    // Liga as transicoes so depois do 1o quadro (estado lembrado sem "pulo").
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { nav.classList.add("nav-ready"); });
    });
})();

/* Botao "Copiar" (data-copy="texto"): codigos de recuperacao etc. */
document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-copy]");
    if (!b) return;
    var text = b.getAttribute("data-copy");
    var done = function () {
        var old = b.innerHTML;
        b.innerHTML = '<i class="bi bi-check2"></i> Copiado';
        setTimeout(function () { b.innerHTML = old; }, 1800);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done);
    } else {
        var t = document.createElement("textarea");
        t.value = text; document.body.appendChild(t); t.select();
        try { document.execCommand("copy"); done(); } catch (err) { /* sem permissao */ }
        t.remove();
    }
});
