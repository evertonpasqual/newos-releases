#!/usr/bin/env bash
# =====================================================================
#  Modulo Logs (Graylog) - instalacao
#  Chamado por: newos-modctl install logs
#  rsyslog + rsyslog-gnutls (TLS), limpeza diaria da copia local e o
#  newos-logs liga o recebimento (pede o certificado ao Manager).
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="logs"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

missing=()
for p in rsyslog rsyslog-gnutls; do
    pkg_installed "${p}" || missing+=("${p}")
done
if ((${#missing[@]} > 0)); then
    apt_require_healthy
    apt_ensure_lists
    mod_info "Instalando ${missing[*]}..."
    apt_install "${missing[@]}"
fi
systemctl enable rsyslog.service >/dev/null 2>&1 || true

cat >/etc/systemd/system/newos-logs-clean.service <<'UNIT'
[Unit]
Description=NewOS: limpeza da copia local do modulo Logs

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/newos-logs clean
UNIT
cat >/etc/systemd/system/newos-logs-clean.timer <<'UNIT'
[Unit]
Description=NewOS: limpeza diaria da copia local do modulo Logs

[Timer]
OnCalendar=*-*-* 03:40
RandomizedDelaySec=15min
Persistent=true

[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now newos-logs-clean.timer >/dev/null 2>&1 || true

out="$(/usr/local/sbin/newos-logs enable)" || mod_die "Nao foi possivel ligar o recebimento de logs."
mod_info "$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read().splitlines()[-1]).get("message",""))' <<<"${out}")"
mod_info "Pronto. Veja em Monitoramento > Logs (Graylog)."
