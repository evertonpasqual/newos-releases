/* =====================================================================
   NewOS Panel - modulo Docker (2.19): Containers, Novo container, Imagens e ajustes
   ===================================================================== */
(function () {
    "use strict";
    var root = document.querySelector("[data-docker-page]");
    if (!root) return;
    var page = root.getAttribute("data-docker-page"), admin = root.getAttribute("data-admin") === "1";

    function $(id) { return document.getElementById(id); }
    function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
    function bytes(n) {
        n = +n || 0; var u = ["B", "KB", "MB", "GB", "TB"], i = 0;
        while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
        return (i ? n.toFixed(n < 10 ? 1 : 0) : n) + " " + u[i];
    }
    function since(iso) {
        var t = Date.parse(iso); if (!t || t < 0) return "";
        var s = Math.max(0, (Date.now() - t) / 1000);
        if (s < 90) return Math.round(s) + " s";
        if (s < 5400) return Math.round(s / 60) + " min";
        if (s < 172800) return Math.round(s / 3600) + " h";
        return Math.round(s / 86400) + " dias";
    }
    function ptAgo(s) {                    // "43 minutes ago" (texto do Docker) -> "há 43 min"
        var m = String(s || "").match(/^(?:About )?(an?|\d+) (second|minute|hour|day|week|month|year)s? ago$/i);
        if (!m) return s || "";
        var n = /^an?$/i.test(m[1]) ? 1 : +m[1], u = { second: "s", minute: "min", hour: "h", day: n > 1 ? "dias" : "dia", week: n > 1 ? "semanas" : "semana", month: n > 1 ? "meses" : "mês", year: n > 1 ? "anos" : "ano" }[m[2].toLowerCase()];
        return "há " + n + " " + u;
    }
    function post(url, body) {
        return fetch(url, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) })
            .then(function (r) { if (r.status === 401) location.href = "/login"; return r.json(); })
            .catch(function () { return { ok: false, message: "Sem resposta do painel." }; });
    }
    function getState() {
        return fetch("/api/docker", { credentials: "same-origin" }).then(function (r) { if (r.status === 401) location.href = "/login"; return r.json(); });
    }
    function showErr(msg) { var e = $("dk-err"); if (!e) return; e.hidden = !msg; if (msg) e.querySelector("span:last-child").textContent = msg; }
    function bar(id, pct) { var b = $(id); if (!b) return; pct = Math.max(0, Math.min(100, pct || 0)); b.style.width = pct + "%"; b.className = pct >= 90 ? "bad" : pct >= 75 ? "warn" : ""; }
    function toast(msg, ok) {
        var t = document.createElement("div"); t.className = "dk-toast " + (ok ? "ok" : "erro"); t.textContent = msg;
        document.body.appendChild(t); setTimeout(function () { t.remove(); }, 6000);
    }
    document.querySelectorAll("dialog [data-close]").forEach(function (b) { b.addEventListener("click", function () { b.closest("dialog").close(); }); });

    // ================================================================ Containers
    if (page === "containers") {
        var data = null, timer = null, busy = {};
        var STATE = { running: ["badge-up", "rodando"], exited: ["badge-down", "parado"], restarting: ["badge-warn", "reiniciando"],
                      paused: ["badge-warn", "pausado"], created: ["badge-warn", "criado"], dead: ["badge-down", "morto"], removing: ["badge-warn", "saindo"] };
        function tiles(d) {
            var run = d.containers.filter(function (c) { return c.state === "running"; });
            $("dk-run").textContent = run.length; $("dk-total").textContent = " / " + d.containers.length;
            $("dk-run-d").textContent = "rodando · " + (d.containers.length - run.length) + " parado(s)";
            var cpu = run.reduce(function (s, c) { return s + (c.cpu || 0); }, 0) / 100;          // em CPUs
            var cap = d.caps.cpus || 1;
            $("dk-cpu").textContent = cpu.toFixed(2) + " CPU"; bar("dk-cpu-bar", cpu * 100 / cap);
            $("dk-cpu-d").textContent = "teto " + cap + " CPUs (" + d.caps.pct + "% do servidor)";
            var mem = run.reduce(function (s, c) { return s + (c.mem || 0); }, 0), capm = d.caps.mem_mb * 1048576;
            $("dk-mem").textContent = bytes(mem); bar("dk-mem-bar", mem * 100 / capm);
            $("dk-mem-d").textContent = "teto " + bytes(capm) + " (" + d.caps.pct + "% da RAM)";
            $("dk-var").textContent = d.var.pct + "%"; bar("dk-var-bar", d.var.pct);
            $("dk-var-mnt").textContent = "(" + (d.var.mount || "/var") + ")";
            var di = d.disk || {}, parts = [];
            if (di.Images) parts.push("imagens " + di.Images.size); if (di["Local Volumes"]) parts.push("volumes " + di["Local Volumes"].size);
            $("dk-var-d").textContent = bytes(d.var.free) + " livres" + (parts.length ? " · Docker: " + parts.join(", ") : "")
                + (d.var.pct >= 85 ? " · acima de 85%: novos containers recusados" : "");
        }
        function row(c) {
            var st = STATE[c.state] || ["badge-warn", c.state], run = c.state === "running";
            var when = run ? "há " + since(c.started) : (c.state === "exited" ? "saiu (código " + c.exit + ") há " + since(c.finished) : "");
            var host = location.hostname;
            var ports = c.ports.length ? c.ports.map(function (p) {
                var lbl = p.host + (p.host !== p.container ? "→" + p.container : "") + (p.proto === "udp" ? "/udp" : "");
                return p.proto === "tcp" && run ? '<a class="dk-port" href="http://' + esc(host) + ":" + p.host + '/" target="_blank" rel="noopener">' + esc(lbl) + "</a>" : '<span class="dk-port">' + esc(lbl) + "</span>";
            }).join(" ") : '<span class="nic-sub">—</span>';
            var memPct = c.mem_limit ? c.mem * 100 / c.mem_limit : 0, cpuPct = c.cpus ? (c.cpu || 0) / c.cpus : (c.cpu || 0);
            var acts = "";
            if (admin) {
                var dis = busy[c.name] ? " disabled" : "";
                acts = (run ? '<button type="button" class="btn btn-ghost btn-sm" data-act="stop" data-n="' + esc(c.name) + '"' + dis + '><i class="bi bi-stop-fill"></i> Parar</button>'
                    + '<button type="button" class="btn btn-ghost btn-sm" data-act="restart" data-n="' + esc(c.name) + '"' + dis + '><i class="bi bi-arrow-clockwise"></i></button>'
                    : '<button type="button" class="btn btn-ghost btn-sm" data-act="start" data-n="' + esc(c.name) + '"' + dis + '><i class="bi bi-play-fill"></i> Iniciar</button>');
            }
            if (admin && c.updatable) acts += '<button type="button" class="btn btn-ghost btn-sm" data-upd="' + esc(c.name) + '" title="Atualizar imagem"' + (busy[c.name] ? " disabled" : "") + '><i class="bi bi-cloud-download"></i></button>';
            acts += '<button type="button" class="btn btn-ghost btn-sm" data-logs="' + esc(c.name) + '" title="Logs"><i class="bi bi-terminal"></i></button>';
            if (admin) acts += '<button type="button" class="btn btn-ghost btn-sm" data-rm="' + esc(c.name) + '" title="Excluir"' + (busy[c.name] ? " disabled" : "") + '><i class="bi bi-trash"></i></button>';
            return '<tr data-q="' + esc((c.name + " " + c.image + " " + c.ports.map(function (p) { return p.host; }).join(" ")).toLowerCase()) + '">'
                + '<td><strong>' + esc(c.name) + '</strong>' + (c.project ? ' <a class="badge" href="/docker/compose" title="Projeto Compose">compose: ' + esc(c.project) + "</a>" : (c.managed ? "" : ' <span class="badge badge-warn" title="Criado fora do painel">fora do painel</span>'))
                + '<div class="nic-sub mono">' + esc(c.image) + "</div></td>"
                + '<td><span class="badge ' + st[0] + '">' + (busy[c.name] ? '<i class="bi bi-hourglass-split"></i> ' + esc(busy[c.name]) : st[1]) + "</span>"
                + (c.health ? ' <span class="badge ' + (c.health === "healthy" ? "badge-up" : "badge-warn") + '">' + esc(c.health) + "</span>" : "")
                + '<div class="nic-sub">' + esc(when) + (c.restarts ? " · " + c.restarts + " reinício(s)" : "") + "</div></td>"
                + "<td>" + ports + "</td>"
                + '<td class="dk-num">' + (run ? (c.cpu || 0).toFixed(1) + '%<div class="dk-bar mini"><i style="width:' + Math.min(100, cpuPct) + '%" class="' + (cpuPct >= 90 ? "bad" : cpuPct >= 75 ? "warn" : "") + '"></i></div><div class="nic-sub">de ' + (c.cpus || "?") + " CPU</div>" : "—") + "</td>"
                + '<td class="dk-num">' + (run ? bytes(c.mem) + '<div class="dk-bar mini"><i style="width:' + Math.min(100, memPct) + '%" class="' + (memPct >= 90 ? "bad" : memPct >= 75 ? "warn" : "") + '"></i></div><div class="nic-sub">de ' + bytes(c.mem_limit) + "</div>" : "—") + "</td>"
                + '<td class="dk-num nic-sub">' + (run ? "↓ " + bytes(c.net_rx) + "<br>↑ " + bytes(c.net_tx) : "—") + "</td>"
                + '<td class="nic-sub">' + esc({ "unless-stopped": "sempre (se eu não parar)", always: "sempre", "on-failure": "se falhar", no: "nunca" }[c.restart] || c.restart) + "</td>"
                + '<td class="actions">' + acts + "</td></tr>";
        }
        function table() {
            if (!data) return;
            var q = ($("dk-q").value || "").trim().toLowerCase();
            var rows = data.containers.map(row).join("");
            $("dk-body").innerHTML = rows || '<tr><td colspan="8" class="empty">Nenhum container ainda.' + (admin ? ' <a href="/docker/novo">Suba o primeiro</a>.' : "") + "</td></tr>";
            if (q) $("dk-body").querySelectorAll("tr[data-q]").forEach(function (tr) { tr.hidden = tr.getAttribute("data-q").indexOf(q) < 0; });
        }
        function load() {
            getState().then(function (d) {
                $("dk-dot").classList.toggle("off", !d.ok);
                if (!d.ok) { showErr(d.message || "Não consegui ler o Docker."); return; }
                showErr(d.error ? "O Docker não está respondendo: " + d.error : "");
                data = d; tiles(d); table();
                $("dk-clock").textContent = "ao vivo · " + new Date().toLocaleTimeString("pt-BR");
            }).catch(function () { showErr("Sem resposta do painel."); });
        }
        $("dk-q").addEventListener("input", table);
        $("dk-body").addEventListener("click", function (e) {
            var b = e.target.closest("button"); if (!b) return;
            if (b.hasAttribute("data-act")) {
                var act = b.getAttribute("data-act"), n = b.getAttribute("data-n");
                busy[n] = { start: "iniciando", stop: "parando", restart: "reiniciando" }[act]; table();
                post("/api/docker/acao", { acao: act, nome: n }).then(function (r) { delete busy[n]; toast(r.message || (r.ok ? "Feito." : "Falhou."), r.ok); load(); });
            } else if (b.hasAttribute("data-logs")) {
                openLogs(b.getAttribute("data-logs"));
            } else if (b.hasAttribute("data-rm")) {
                openRm(b.getAttribute("data-rm"));
            } else if (b.hasAttribute("data-upd")) {
                updName = b.getAttribute("data-upd");
                var c = (data.containers || []).filter(function (x) { return x.name === updName; })[0] || {};
                $("dk-upd-name").textContent = updName; $("dk-upd-img").textContent = c.image || ""; $("dk-upd-force").checked = false;
                $("dk-upd").showModal();
            }
        });
        var updName = "";
        $("dk-upd-go").addEventListener("click", function () {
            var n = updName, force = $("dk-upd-force").checked; $("dk-upd").close();
            busy[n] = "atualizando"; table();
            post("/api/docker/acao", { acao: "update", nome: n, force: force }).then(function (r) { delete busy[n]; toast(r.message || "Falhou.", r.ok); load(); });
        });
        var logName = "";
        function loadLogs() {
            $("dk-logs-text").textContent = "carregando…";
            fetch("/api/docker/logs?nome=" + encodeURIComponent(logName) + "&linhas=" + $("dk-logs-n").value, { credentials: "same-origin" })
                .then(function (r) { return r.json(); }).then(function (d) {
                    var pre = $("dk-logs-text"); pre.textContent = d.ok ? (d.text || "(sem logs)") : d.message; pre.scrollTop = pre.scrollHeight;
                });
        }
        function openLogs(n) { logName = n; $("dk-logs-name").textContent = n; $("dk-logs").showModal(); loadLogs(); }
        $("dk-logs-reload").addEventListener("click", loadLogs);
        $("dk-logs-n").addEventListener("change", loadLogs);
        var rmName = "";
        function openRm(n) {
            rmName = n; var c = (data.containers || []).filter(function (x) { return x.name === n; })[0] || {};
            var vols = (c.volumes || []).filter(function (v) { return v.type === "volume"; }).map(function (v) { return v.src; });
            $("dk-rm-name").textContent = n; $("dk-rm-vols").textContent = vols.length ? vols.join(", ") : "nenhum";
            $("dk-rm-vol").checked = false; $("dk-rm-vol").disabled = !vols.length;
            $("dk-rm-confirm").value = ""; $("dk-rm-go").disabled = true; $("dk-rm").showModal(); $("dk-rm-confirm").focus();
        }
        $("dk-rm-confirm").addEventListener("input", function () { $("dk-rm-go").disabled = this.value.trim() !== rmName; });
        $("dk-rm-go").addEventListener("click", function () {
            var n = rmName, vol = $("dk-rm-vol").checked; $("dk-rm").close();
            busy[n] = "excluindo"; table();
            post("/api/docker/acao", { acao: "rm", nome: n, volumes: vol }).then(function (r) { delete busy[n]; toast(r.message || "Falhou.", r.ok); load(); });
        });
        load();
        timer = setInterval(function () { if (!document.hidden) load(); }, 5000);
    }

    // ================================================================ Novo container
    if (page === "novo") {
        var last = null;
        $("dk-example").addEventListener("click", function () {
            $("dk-cmd").value = "docker run -d --name dockermigrate --restart unless-stopped -p 8080:8080 -v dockermigrate-data:/data evertonpasqualin/dockermigrate:latest";
            check();
        });
        function q(s) { return /^[A-Za-z0-9_./:=@%+-]+$/.test(s) ? s : "'" + s.replace(/'/g, "'\\''") + "'"; }
        $("dk-build").addEventListener("click", function () {
            var parts = ["docker run -d"];
            if ($("f-name").value.trim()) parts.push("--name " + q($("f-name").value.trim()));
            parts.push("--restart " + $("f-restart").value);
            $("f-ports").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean).forEach(function (p) { parts.push("-p " + q(p)); });
            $("f-vols").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean).forEach(function (v) { parts.push("-v " + q(v)); });
            $("f-env").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean).forEach(function (v) { parts.push("-e " + q(v)); });
            if ($("f-mem").value.trim()) parts.push("--memory " + q($("f-mem").value.trim()));
            if ($("f-cpus").value.trim()) parts.push("--cpus " + q($("f-cpus").value.trim()));
            parts.push(q($("f-image").value.trim() || "imagem:tag"));
            $("dk-cmd").value = parts.join(" ");
            check();
        });
        function list(title, items, cls) {
            return items.length ? '<div class="dk-msgs ' + cls + '"><b>' + title + "</b><ul>" + items.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div>" : "";
        }
        function check() {
            var cmd = $("dk-cmd").value.trim();
            if (!cmd) return;
            $("dk-check-out").innerHTML = '<p class="nic-sub"><i class="bi bi-hourglass-split"></i> conferindo…</p>';
            if ($("dk-run")) $("dk-run").disabled = true;
            post("/api/docker/conferir", { cmd: cmd }).then(function (r) {
                if (!r.ok) { $("dk-check-out").innerHTML = list("Não deu para conferir", [r.message || "falhou"], "bad"); return; }
                last = r; var s = r.spec;
                var kv = function (k, v) { return "<tr><th>" + k + "</th><td>" + v + "</td></tr>"; };
                var html = '<table class="dk-spec">'
                    + kv("Nome", '<span class="mono">' + esc(s.name) + "</span>") + kv("Imagem", '<span class="mono">' + esc(s.image) + "</span>")
                    + kv("Portas", s.ports.length ? s.ports.map(function (p) { return '<span class="dk-port">' + p.host + "→" + p.container + "/" + p.proto + "</span>"; }).join(" ") + ' <span class="nic-sub">abertas para qualquer origem</span>' : "nenhuma")
                    + kv("Volumes", s.volumes.length ? s.volumes.map(function (v) { return '<span class="mono">' + esc(v.src) + " → " + esc(v.dst) + (v.mode === "ro" ? " (leitura)" : "") + "</span>"; }).join("<br>") : "nenhum")
                    + kv("Variáveis", s.env.length ? s.env.map(function (e) { return '<span class="mono">' + esc(e.split("=")[0]) + "</span>"; }).join(", ") : "nenhuma")
                    + kv("Limites", s.memory_mb + " MB de memória · " + s.cpus + " CPU · até 1024 processos")
                    + kv("Reiniciar", esc(s.restart)) + "</table>";
                html += list("Recusado", r.errors, "bad") + list("Avisos", r.notes, "warn");
                html += '<details class="dk-preview"><summary>Comando que o NewOS vai rodar</summary><pre class="dk-pre small">' + esc(r.preview) + "</pre></details>";
                $("dk-check-out").innerHTML = html;
                if ($("dk-run")) $("dk-run").disabled = !!r.errors.length;
            });
        }
        $("dk-check").addEventListener("click", check);
        if ($("dk-run")) $("dk-run").addEventListener("click", function () {
            var b = this, msg = $("dk-run-msg");
            b.disabled = true; msg.innerHTML = '<i class="bi bi-hourglass-split"></i> baixando a imagem e subindo (pode levar alguns minutos)…';
            post("/api/docker/subir", { cmd: $("dk-cmd").value.trim() }).then(function (r) {
                msg.textContent = "";
                if (r.ok) { toast(r.message, true); setTimeout(function () { location.href = "/docker"; }, 900); }
                else { toast(r.message || "Falhou.", false); b.disabled = false; msg.textContent = r.message || ""; }
            });
        });
        getState().then(function (d) {
            if (d.ok && d.caps) {
                $("dk-caps").textContent = "teto " + d.caps.mem_mb + " MB · " + d.caps.cpus + " CPU · padrão " + d.settings.mem_mb + " MB / " + d.settings.cpus + " CPU";
                $("f-mem").placeholder = "padrão " + d.settings.mem_mb + "m"; $("f-cpus").placeholder = "padrão " + d.settings.cpus;
            }
        });
    }

    // ================================================================ Compose (2.20)
    if (page === "compose") {
        var projects = [], busyP = {}, logProj = "", rmProj = "";
        function cpRow(p) {
            var chips = p.containers.map(function (c) {
                return '<span class="badge ' + (c.state === "running" ? "badge-up" : "badge-down") + '" title="' + esc(c.image + " · " + c.status) + '">' + esc(c.name.replace(p.name + "-", "").replace(p.name + "_", "")) + "</span>";
            }).join(" ") || '<span class="nic-sub">nenhum container</span>';
            var dis = busyP[p.name] ? " disabled" : "", acts = "";
            if (admin) acts += '<button type="button" class="btn btn-ghost btn-sm" data-edit="' + esc(p.name) + '"' + dis + '><i class="bi bi-pencil"></i> Editar</button>'
                + (p.running ? '<button type="button" class="btn btn-ghost btn-sm" data-cp="stop" data-n="' + esc(p.name) + '"' + dis + '><i class="bi bi-stop-fill"></i> Parar</button>'
                             : '<button type="button" class="btn btn-ghost btn-sm" data-cp="up" data-n="' + esc(p.name) + '"' + dis + '><i class="bi bi-play-fill"></i> Subir</button>')
                + '<button type="button" class="btn btn-ghost btn-sm" data-cp="pull" data-n="' + esc(p.name) + '" title="Baixar as imagens novas e recriar"' + dis + '><i class="bi bi-cloud-download"></i></button>';
            acts += '<button type="button" class="btn btn-ghost btn-sm" data-plogs="' + esc(p.name) + '" title="Logs"><i class="bi bi-terminal"></i></button>';
            if (admin) acts += '<button type="button" class="btn btn-ghost btn-sm" data-prm="' + esc(p.name) + '" title="Excluir"' + dis + '><i class="bi bi-trash"></i></button>';
            return "<tr><td><strong>" + esc(p.name) + "</strong>" + (busyP[p.name] ? ' <span class="badge badge-warn"><i class="bi bi-hourglass-split"></i> ' + esc(busyP[p.name]) + "</span>" : "")
                + '<div class="nic-sub mono">/srv/docker/compose/' + esc(p.name) + "</div></td><td>" + p.running + "/" + p.containers.length + " rodando<div>" + chips + "</div></td>"
                + '<td class="nic-sub">' + new Date(p.updated * 1000).toLocaleString("pt-BR") + '</td><td class="actions">' + acts + "</td></tr>";
        }
        function cpTable() {
            $("cp-n").textContent = projects.length + " projeto(s)";
            $("cp-body").innerHTML = projects.map(cpRow).join("") || '<tr><td colspan="4" class="empty">Nenhum projeto ainda.</td></tr>';
        }
        function cpLoad() {
            fetch("/api/docker/compose", { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (d) {
                showErr(d.ok ? "" : (d.message || "Não consegui ler os projetos."));
                if (d.ok) { projects = d.projects; cpTable(); }
            });
        }
        var EX = "services:\n  web:\n    image: nginx:alpine\n    ports:\n      - \"8088:80\"\n    volumes:\n      - ./html:/usr/share/nginx/html:ro\n    restart: unless-stopped\n  cache:\n    image: redis:7-alpine\n    mem_limit: 256m\n    volumes:\n      - redis-dados:/data\nvolumes:\n  redis-dados: {}\n";
        function editor(name, yaml, existing) {
            $("cp-name").value = name || ""; $("cp-name").readOnly = !!existing; $("cp-yaml").value = yaml || "";
            $("cp-title").textContent = existing ? "Editar " + name : "Novo projeto";
            $("cp-out").innerHTML = '<p class="empty">Cole o arquivo e clique em <strong>Conferir</strong>.</p>';
            if ($("cp-up")) { $("cp-up").disabled = true; $("cp-up").querySelector("span").textContent = existing ? "Aplicar a alteração" : "Subir o projeto"; }
            $("cp-editor").scrollIntoView({ behavior: "smooth", block: "start" });
        }
        if ($("cp-new")) $("cp-new").addEventListener("click", function () { editor("", "", false); $("cp-name").focus(); });
        $("cp-example").addEventListener("click", function () { if (!$("cp-name").readOnly) $("cp-name").value = $("cp-name").value || "exemplo-web"; $("cp-yaml").value = EX; cpCheck(); });
        function lst(title, items, cls) { return items.length ? '<div class="dk-msgs ' + cls + '"><b>' + title + "</b><ul>" + items.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div>" : ""; }
        function cpCheck() {
            $("cp-out").innerHTML = '<p class="nic-sub"><i class="bi bi-hourglass-split"></i> conferindo…</p>';
            if ($("cp-up")) $("cp-up").disabled = true;
            post("/api/docker/compose/conferir", { nome: $("cp-name").value.trim(), yaml: $("cp-yaml").value }).then(function (r) {
                if (!r.ok) { $("cp-out").innerHTML = lst("Não deu para conferir", [r.message || "falhou"], "bad"); return; }
                var html = r.services.length ? '<table class="dk-spec">' + r.services.map(function (s) {
                    return "<tr><th>" + esc(s.name) + '</th><td><span class="mono">' + esc(s.image) + "</span><br>" + (s.ports.length ? s.ports.map(function (p) { return '<span class="dk-port">' + esc(p) + "</span>"; }).join(" ") + " " : "")
                        + '<span class="nic-sub">' + esc(s.mem || "") + " · " + esc(s.cpus) + " CPU</span></td></tr>";
                }).join("") + "</table>" : "";
                html += lst("Recusado", r.errors, "bad") + lst("Avisos", r.notes, "warn");
                if (r.preview) html += '<details class="dk-preview"><summary>Arquivo que o NewOS vai usar (com os limites)</summary><pre class="dk-pre small">' + esc(r.preview) + "</pre></details>";
                $("cp-out").innerHTML = html;
                if ($("cp-up")) $("cp-up").disabled = !!r.errors.length;
            });
        }
        $("cp-check").addEventListener("click", cpCheck);
        if ($("cp-up")) $("cp-up").addEventListener("click", function () {
            var b = this; b.disabled = true; $("cp-msg").innerHTML = '<i class="bi bi-hourglass-split"></i> baixando as imagens e subindo (pode levar alguns minutos)…';
            post("/api/docker/compose/subir", { nome: $("cp-name").value.trim(), yaml: $("cp-yaml").value }).then(function (r) {
                $("cp-msg").textContent = ""; toast(r.message || "Falhou.", r.ok); b.disabled = !!r.ok; cpLoad();
            });
        });
        $("cp-body").addEventListener("click", function (e) {
            var b = e.target.closest("button"); if (!b) return;
            if (b.hasAttribute("data-edit")) {
                var n = b.getAttribute("data-edit");
                fetch("/api/docker/compose/arquivo?nome=" + encodeURIComponent(n), { credentials: "same-origin" }).then(function (r) { return r.json(); })
                    .then(function (d) { if (d.ok) { editor(n, d.yaml, true); cpCheck(); } else toast(d.message, false); });
            } else if (b.hasAttribute("data-cp")) {
                var act = b.getAttribute("data-cp"), pn = b.getAttribute("data-n");
                busyP[pn] = { up: "subindo", stop: "parando", pull: "baixando imagens" }[act]; cpTable();
                post("/api/docker/compose/acao", { acao: act, nome: pn }).then(function (r) { delete busyP[pn]; toast(r.message || "Falhou.", r.ok); cpLoad(); });
            } else if (b.hasAttribute("data-plogs")) {
                logProj = b.getAttribute("data-plogs"); $("dk-logs-name").textContent = logProj; $("dk-logs").showModal(); plogs();
            } else if (b.hasAttribute("data-prm")) {
                rmProj = b.getAttribute("data-prm"); $("dk-rm-name").textContent = rmProj; $("dk-rm-vol").checked = false;
                $("dk-rm-confirm").value = ""; $("dk-rm-go").disabled = true; $("dk-rm").showModal(); $("dk-rm-confirm").focus();
            }
        });
        function plogs() {
            $("dk-logs-text").textContent = "carregando…";
            fetch("/api/docker/compose/logs?nome=" + encodeURIComponent(logProj), { credentials: "same-origin" }).then(function (r) { return r.json(); })
                .then(function (d) { var pre = $("dk-logs-text"); pre.textContent = d.ok ? (d.text || "(sem logs)") : d.message; pre.scrollTop = pre.scrollHeight; });
        }
        $("dk-logs-reload").addEventListener("click", plogs);
        $("dk-rm-confirm").addEventListener("input", function () { $("dk-rm-go").disabled = this.value.trim() !== rmProj; });
        $("dk-rm-go").addEventListener("click", function () {
            var n = rmProj, vol = $("dk-rm-vol").checked; $("dk-rm").close();
            busyP[n] = "excluindo"; cpTable();
            post("/api/docker/compose/acao", { acao: "rm", nome: n, volumes: vol }).then(function (r) { delete busyP[n]; toast(r.message || "Falhou.", r.ok); cpLoad(); });
        });
        cpLoad();
        setInterval(function () { if (!document.hidden) cpLoad(); }, 10000);
    }

    // ================================================================ Imagens e ajustes
    if (page === "imagens") {
        function load() {
            getState().then(function (d) {
                if (!d.ok) { showErr(d.message || "Não consegui ler o Docker."); return; }
                showErr(d.error ? "O Docker não está respondendo: " + d.error : "");
                var di = d.disk || {}, names = { Images: "Imagens", Containers: "Containers", "Local Volumes": "Volumes", "Build Cache": "Cache de build" };
                $("dk-disk").innerHTML = '<div class="dk-var"><b>' + d.var.pct + "%</b> do /var em uso · " + bytes(d.var.free) + ' livres<div class="dk-bar"><i style="width:' + d.var.pct + '%" class="' + (d.var.pct >= 85 ? "bad" : d.var.pct >= 75 ? "warn" : "") + '"></i></div></div>'
                    + '<table class="dk-spec">' + Object.keys(names).filter(function (k) { return di[k]; }).map(function (k) {
                        return "<tr><th>" + names[k] + "</th><td>" + esc(di[k].size) + ' <span class="nic-sub">· recuperável ' + esc(di[k].reclaimable) + "</span></td></tr>";
                    }).join("") + "</table>";
                $("dk-img-n").textContent = d.images.length + " imagem(ns)";
                $("dk-img-body").innerHTML = d.images.map(function (im) {
                    return '<tr><td class="mono">' + esc(im.ref) + "</td><td>" + esc(im.size) + '</td><td class="nic-sub">' + esc(ptAgo(im.created)) + "</td><td>"
                        + (im.used ? '<span class="badge badge-up">em uso</span>' : '<span class="badge badge-warn">sem uso</span>') + '</td><td class="actions">'
                        + (admin && !im.used ? '<button type="button" class="btn btn-ghost btn-sm" data-rmi="' + esc(im.ref) + '"><i class="bi bi-trash"></i> Apagar</button>' : "") + "</td></tr>";
                }).join("") || '<tr><td colspan="5" class="empty">Nenhuma imagem baixada.</td></tr>';
                var mg = d.migrate || {}, box = $("dk-mig");
                $("dk-root-now").textContent = "agora: " + d.var.path + " (" + d.var.mount + ", " + bytes(d.var.free) + " livres)";
                box.hidden = !mg.state || (mg.state !== "running" && Date.now() / 1000 - (mg.finished || 0) > 3600);
                box.className = "alert " + (mg.state === "erro" ? "alert-erro" : mg.state === "ok" ? "alert-ok" : "alert-aviso");
                box.querySelector("span:last-child").textContent = mg.state === "running" ? "Movendo de " + mg.from + " para " + mg.to + ": " + (mg.message || "") : (mg.message || "");
                if ($("r-go")) $("r-go").disabled = mg.state === "running";
                if (mg.state === "running") setTimeout(load, 4000);
                if (!$("r-path").value) $("r-path").placeholder = d.var.path === "/var/lib/docker" ? "/dados/docker" : d.var.path;
                var s = d.settings;
                if (!$("dk-settings").dataset.loaded) {
                    $("s-cap").value = s.cap_pct; $("s-pool").value = s.pool; $("s-mem").value = s.mem_mb; $("s-cpus").value = s.cpus;
                    $("dk-settings").dataset.loaded = "1";
                }
            });
        }
        $("dk-img-body").addEventListener("click", function (e) {
            var b = e.target.closest("[data-rmi]"); if (!b) return;
            b.disabled = true;
            post("/api/docker/imagem/apagar", { ref: b.getAttribute("data-rmi") }).then(function (r) { toast(r.message || "Falhou.", r.ok); load(); });
        });
        if ($("dk-prune")) $("dk-prune").addEventListener("click", function () {
            var b = this; b.disabled = true; $("dk-prune-msg").textContent = "apagando…";
            post("/api/docker/limpar", {}).then(function (r) { b.disabled = false; $("dk-prune-msg").textContent = ""; toast(r.message || "Falhou.", r.ok); load(); });
        });
        $("dk-root").addEventListener("submit", function (e) {
            e.preventDefault();
            if (!admin) return;
            var btn = $("r-go"); btn.disabled = true;
            post("/api/docker/dados", { path: $("r-path").value.trim(), delete_old: $("r-del").checked })
                .then(function (r) { toast(r.message || "Falhou.", r.ok); btn.disabled = false; load(); });
        });
        $("dk-settings").addEventListener("submit", function (e) {
            e.preventDefault();
            if (!admin) return;
            var btn = this.querySelector("button[type=submit]"); btn.disabled = true;
            post("/api/docker/ajustes", { cap_pct: +$("s-cap").value, pool: $("s-pool").value.trim(), mem_mb: +$("s-mem").value, cpus: +$("s-cpus").value })
                .then(function (r) { btn.disabled = false; toast(r.message || "Falhou.", r.ok); load(); });
        });
        load();
    }
})();
