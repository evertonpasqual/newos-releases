/* =====================================================================
   NewOS Panel - menu lateral 2.21 (complementa nav.js e glass.js)
   ---------------------------------------------------------------------
   - aba ativa: um elemento so (.nm2-tab) atras do item da pagina; ao
     clicar em outro item ela desliza ate ele antes de a pagina trocar,
     e na pagina nova continua o movimento de onde estava
   - acompanha grupos abrindo/fechando (inclusive abertos pelo mouse)
   - busca no menu: filtra itens e subitens; Enter abre o 1o; Esc limpa;
     Ctrl/Cmd + K foca (com o menu recolhido, abre o menu antes)
   ===================================================================== */
(function () {
    "use strict";
    var side = document.querySelector(".sidebar.nm2");
    var nav = side && side.querySelector(".nav");
    if (!nav) return;
    var root = document.documentElement;
    var KEY = "nm2.tab";
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // ------------------------------------------------------------ aba
    var tab = document.createElement("div");
    tab.className = "nm2-tab off";
    tab.setAttribute("aria-hidden", "true");
    nav.insertBefore(tab, nav.firstChild);
    nav.classList.add("nm2-tabbed");

    var active = nav.querySelector("a.active");
    var pinned = null;               // item clicado (a aba vai ate ele antes de trocar de pagina)

    function visible(el) { return el && el.offsetParent !== null && el.getClientRects().length && el.getBoundingClientRect().height > 8; }
    function target() {
        var el = pinned || active;
        if (!el) return null;
        var g = el.closest(".nav-group");
        if (g && el.closest(".nav-sub")) {
            var title = g.querySelector(".nav-group-title");
            var subOpen = el.getBoundingClientRect().height > 20 && getComputedStyle(el).opacity > 0.5;
            g.classList.toggle("nm2-tab-on-title", !subOpen);
            if (!subOpen) return title;
        }
        return visible(el) ? el : null;
    }
    function place(instant) {
        if (root.classList.contains("nav-mini")) return;
        var el = target();
        nav.querySelectorAll(".nm2-on").forEach(function (o) { if (o !== el) o.classList.remove("nm2-on"); });
        if (!el) { tab.classList.add("off"); return; }
        el.classList.add("nm2-on");
        var nr = nav.getBoundingClientRect(), r = el.getBoundingClientRect();
        var top = r.top - nr.top + nav.scrollTop, left = r.left - nr.left;
        if (instant) tab.classList.add("instant");
        tab.style.top = top + "px";
        tab.style.left = left + "px";
        tab.style.width = (nr.width - left) + "px";
        tab.style.height = r.height + "px";
        tab.classList.remove("off");
        if (instant) { void tab.offsetWidth; tab.classList.remove("instant"); }
    }

    // segue o layout enquanto algo anima (grupo abrindo, menu recolhendo...)
    var followUntil = 0, raf = 0;
    function follow(ms) {
        followUntil = Math.max(followUntil, Date.now() + (ms || 450));
        nav.classList.add("nm2-follow");
        if (raf) return;
        (function step() {
            place(true);
            if (Date.now() < followUntil) { raf = requestAnimationFrame(step); }
            else { raf = 0; nav.classList.remove("nm2-follow"); }
        })();
    }

    // posicao da pagina anterior: a aba sai de la e desliza ate aqui
    var from = null;
    try {
        from = JSON.parse(sessionStorage.getItem(KEY) || "null");
        sessionStorage.removeItem(KEY);
    } catch (e) { /* sem storage */ }
    if (from && Date.now() - from.t < 5000 && !reduce && !root.classList.contains("nav-mini")) {
        nav.scrollTop = from.scroll || 0;
        tab.classList.add("instant");
        tab.style.top = from.top + "px"; tab.style.left = from.left + "px";
        tab.style.width = from.width + "px"; tab.style.height = from.height + "px";
        tab.classList.remove("off");
        void tab.offsetWidth;
        tab.classList.remove("instant");
        requestAnimationFrame(function () { requestAnimationFrame(function () { keepInView(); tab.classList.add("moving"); place(false); }); });
    } else {
        keepInView();
        place(true);
    }
    tab.addEventListener("animationend", function () { tab.classList.remove("moving"); });

    function keepInView() {
        var el = target();
        if (!el) return;
        var nr = nav.getBoundingClientRect(), r = el.getBoundingClientRect();
        if (r.top < nr.top + 8 || r.bottom > nr.bottom - 8) nav.scrollTop += (r.top - nr.top) - nr.height / 3;
    }

    // clique num item: a aba vai ate ele ja (a pagina nova continua dali)
    nav.addEventListener("click", function (e) {
        var a = e.target.closest("a[href]");
        if (!a || !nav.contains(a) || a.target === "_blank" || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;
        if (root.classList.contains("nav-mini") || reduce) return;
        if (active && active !== a) active.classList.add("nm2-going-from");
        pinned = a;
        tab.classList.add("moving");
        place(false);
        try {
            sessionStorage.setItem(KEY, JSON.stringify({ t: Date.now(), top: parseFloat(tab.style.top), left: parseFloat(tab.style.left),
                                                         width: parseFloat(tab.style.width), height: parseFloat(tab.style.height),
                                                         scroll: nav.scrollTop }));
        } catch (err) { /* sem storage */ }
    });

    nav.querySelectorAll(".nav-group").forEach(function (g) {
        g.addEventListener("mouseenter", function () { follow(520); });
        g.addEventListener("mouseleave", function () { follow(620); });
        g.querySelector(".nav-group-title").addEventListener("click", function () { follow(560); });
    });
    nav.addEventListener("transitionrun", function (e) { if (e.target !== tab) follow(400); });
    window.addEventListener("resize", function () { follow(200); });
    new MutationObserver(function () { follow(500); }).observe(root, { attributes: true, attributeFilter: ["class"] });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { place(true); });

    // ------------------------------------------------------------ recolhido: janelinha fixa ao lado do icone
    // (a lista rola, entao a janelinha nao pode ficar presa dentro dela)
    function flyPlace(g) {
        var sub = g.querySelector(".nav-sub"), t = g.querySelector(".nav-group-title");
        if (!sub || !t) return;
        var sr = side.getBoundingClientRect(), tr = t.getBoundingClientRect();
        sub.style.removeProperty("top");
        var h = sub.offsetHeight || 200;
        var y = Math.max(12, Math.min(tr.top - 8, window.innerHeight - h - 12));
        sub.style.setProperty("--nm2-fly-x", (sr.right + 14) + "px");
        sub.style.setProperty("--nm2-fly-y", y + "px");
    }
    new MutationObserver(function (list) {
        if (!root.classList.contains("nav-mini")) return;
        list.forEach(function (m) { if (m.target.classList && m.target.classList.contains("fly")) flyPlace(m.target); });
    }).observe(nav, { subtree: true, attributes: true, attributeFilter: ["class"] });
    nav.addEventListener("scroll", function () {
        if (root.classList.contains("nav-mini")) nav.querySelectorAll(".nav-group.fly").forEach(flyPlace);
    }, { passive: true });
    if (root.classList.contains("nav-mini")) nav.querySelectorAll(".nav-group.fly").forEach(function (g) {
        var t = g.querySelector(".nav-group-title");
        if (t && t.scrollIntoView) t.scrollIntoView({ block: "nearest" });
        flyPlace(g);
    });

    // ------------------------------------------------------------ busca
    var input = document.getElementById("nm2Find");
    if (!input) return;
    var kbd = side.querySelector(".nm2-kbd");
    if (kbd && /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent)) kbd.textContent = "⌘K";
    var empty = document.createElement("div");
    empty.className = "nm2-empty";
    empty.hidden = true;
    empty.textContent = "Nada no menu com esse nome.";
    nav.appendChild(empty);

    function norm(s) {
        return (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
    }
    function text(el) {
        var s = el.querySelector(":scope > span");
        return norm((s ? s.textContent : el.textContent));
    }
    function clear() {
        nav.classList.remove("nm2-filtering");
        nav.querySelectorAll(".nm2-miss, .nm2-hit, .nm2-first").forEach(function (el) { el.classList.remove("nm2-miss", "nm2-hit", "nm2-first"); });
        empty.hidden = true;
        follow(500);
    }
    function filter() {
        var q = norm(input.value);
        if (!q) { clear(); return; }
        nav.classList.add("nm2-filtering");
        nav.querySelectorAll(".nm2-hit, .nm2-first").forEach(function (el) { el.classList.remove("nm2-hit", "nm2-first"); });
        var first = null, any = false, section = null, sectionHas = false;
        function closeSection() { if (section) section.classList.toggle("nm2-miss", !sectionHas); }
        Array.prototype.forEach.call(nav.children, function (el) {
            if (el === tab || el === empty) return;
            if (el.classList.contains("nav-section")) { closeSection(); section = el; sectionHas = false; return; }
            var show = false;
            if (el.matches("a")) {
                show = text(el).indexOf(q) !== -1;
                if (show) { el.classList.add("nm2-hit"); first = first || el; }
            } else if (el.classList.contains("nav-group")) {
                var title = el.querySelector(".nav-group-title");
                var titleHit = text(title).indexOf(q) !== -1;
                var subs = el.querySelectorAll(".nav-sub a");
                var subHit = false;
                subs.forEach(function (a) {
                    var hit = titleHit || norm(a.textContent).indexOf(q) !== -1;
                    a.classList.toggle("nm2-miss", !hit);
                    if (hit && !titleHit) { a.classList.add("nm2-hit"); first = first || a; }
                    subHit = subHit || hit;
                });
                if (titleHit) { title.classList.add("nm2-hit"); first = first || subs[0] || title; }
                show = titleHit || subHit;
            }
            el.classList.toggle("nm2-miss", !show);
            if (show) { sectionHas = true; any = true; }
        });
        closeSection();
        if (first) first.classList.add("nm2-first");
        empty.hidden = any;
    }
    input.addEventListener("input", filter);
    input.addEventListener("keydown", function (e) {
        if (e.key === "Escape") { input.value = ""; clear(); input.blur(); }
        if (e.key === "Enter") {
            var f = nav.querySelector(".nm2-first");
            if (f && f.href) { e.preventDefault(); location.href = f.href; }
            else if (f) { f.click(); }
        }
        if (e.key === "ArrowDown") {
            var links = Array.prototype.filter.call(nav.querySelectorAll("a[href]"), function (a) { return !a.closest(".nm2-miss") && !a.classList.contains("nm2-miss") && visible(a); });
            if (links.length) { e.preventDefault(); links[0].focus(); }
        }
    });

    function openFind() {
        if (root.classList.contains("nav-mini")) {
            var t = side.querySelector(".nav-toggle");
            if (t) t.click();
            setTimeout(function () { input.focus(); input.select(); }, 340);
        } else { input.focus(); input.select(); }
    }
    side.querySelector(".nm2-find").addEventListener("click", function (e) {
        if (root.classList.contains("nav-mini")) { e.preventDefault(); openFind(); }
    });
    document.addEventListener("keydown", function (e) {
        if ((e.ctrlKey || e.metaKey) && !e.altKey && !e.shiftKey && (e.key === "k" || e.key === "K")) {
            var t = e.target;
            if (t && t !== input && (t.isContentEditable || /^(TEXTAREA)$/.test(t.tagName) || (t.closest && t.closest(".xterm")))) return;
            e.preventDefault();
            openFind();
        }
    });
})();
