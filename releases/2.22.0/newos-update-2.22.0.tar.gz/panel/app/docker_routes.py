"""
NewOS Panel - modulo Docker (2.19).

    /docker                      painel: containers ao vivo (estado, portas, CPU, memoria, rede, disco)
    /docker/novo                 colar um "docker run" (ou preencher) -> conferir -> subir
    /docker/imagens              imagens, espaco do Docker e ajustes (teto, padrao por container, rede)

    GET  /api/docker                    retrato (a tela pede a cada 5 s)
    GET  /api/docker/logs?nome=&linhas= logs do container
    POST /api/docker/acao               {acao: start|stop|restart|rm, nome, volumes?}   (admin)
    POST /api/docker/conferir           {cmd} -> spec normalizado, erros e avisos
    POST /api/docker/subir              {cmd} ou {spec}                                 (admin)
    POST /api/docker/imagem/apagar      {ref}                                           (admin)
    POST /api/docker/limpar             apaga imagens sem uso                           (admin)
    POST /api/docker/ajustes            {pool, cap_pct, mem_mb, cpus}                   (admin)

Tudo pelo helper newos-docker (sudo), que confere cada pedido de novo.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any, Callable

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from . import auth, db, modules, terminal_routes

log = logging.getLogger("newos.panel.docker")
HELPER = "/usr/local/sbin/newos-docker"


def helper(args: list[str], body: dict[str, Any] | None = None, timeout: int = 90) -> dict[str, Any]:
    try:
        proc = subprocess.run(["sudo", "-n", HELPER, *args], capture_output=True, text=True, timeout=timeout, check=False,
                              input=json.dumps(body) if body is not None else "")
    except subprocess.TimeoutExpired:
        return {"ok": False, "message": "O Docker demorou demais para responder."}
    except (OSError, subprocess.SubprocessError) as exc:
        return {"ok": False, "message": str(exc)}
    if proc.returncode != 0:
        lines = [ln for ln in (proc.stderr or proc.stdout).splitlines() if ln.strip()]
        return {"ok": False, "message": (lines[-1] if lines else "falhou").removeprefix("ERRO: ")}
    try:
        return json.loads(proc.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "message": "Resposta inválida do newos-docker."}


def register(app: FastAPI, *, render: Callable[..., HTMLResponse],
             flash: Callable[[Request, str, str], None],
             redirect: Callable[[str], Any]) -> None:

    def enabled() -> bool:
        return bool((modules.get_module("docker") or {}).get("enabled"))

    def page(request: Request, template: str, active: str) -> Any:
        user = auth.current_user(request)
        if not user:
            return redirect("/login")
        if not enabled():
            flash(request, "aviso", "Ligue o módulo Docker em Sistema > Módulos.")
            return redirect("/modulos")
        return render(request, template, active=active, admin=terminal_routes.is_admin(user))

    def api_guard(request: Request, admin: bool = False) -> tuple[dict[str, Any] | None, Any]:
        user = auth.current_user(request)
        if not user:
            return None, JSONResponse({"ok": False, "message": "Sessão expirada."}, status_code=401)
        if not enabled():
            return None, JSONResponse({"ok": False, "message": "Módulo Docker desligado."}, status_code=409)
        if admin and not terminal_routes.is_admin(user):
            return None, JSONResponse({"ok": False, "message": "Só administradores mexem nos containers."}, status_code=403)
        return user, None

    def audit(request: Request, user: dict[str, Any], what: str) -> None:
        db.log_audit(user["username"], "docker", what, auth.client_ip(request))
        log.info("Docker por %s: %s", user["username"], what)

    async def body_of(request: Request) -> dict[str, Any]:
        try:
            b = await request.json()
            return b if isinstance(b, dict) else {}
        except ValueError:
            return {}

    def answer(res: dict[str, Any]) -> Any:
        return res if res.get("ok") else JSONResponse(res, status_code=400)

    @app.get("/docker", response_class=HTMLResponse)
    async def docker_page(request: Request):
        return page(request, "docker.html", "docker")

    @app.get("/docker/novo", response_class=HTMLResponse)
    async def docker_new_page(request: Request):
        return page(request, "docker_new.html", "docker-novo")

    @app.get("/docker/imagens", response_class=HTMLResponse)
    async def docker_images_page(request: Request):
        return page(request, "docker_images.html", "docker-imagens")

    @app.get("/api/docker")
    async def docker_state(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        res = await run_in_threadpool(helper, ["state"])
        return res if res.get("ok") else JSONResponse(res, status_code=500)

    @app.get("/api/docker/logs")
    async def docker_logs(request: Request, nome: str = "", linhas: int = 300):
        _, bad = api_guard(request)
        if bad:
            return bad
        return answer(await run_in_threadpool(helper, ["logs", nome, str(max(10, min(linhas, 2000)))]))

    @app.post("/api/docker/acao")
    async def docker_action(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        acao, nome = str(b.get("acao", "")), str(b.get("nome", ""))
        if acao not in ("start", "stop", "restart", "rm", "update"):
            return JSONResponse({"ok": False, "message": "Ação inválida."}, status_code=400)
        args = [acao, nome] + (["--volumes"] if acao == "rm" and b.get("volumes") else []) + (["--force"] if acao == "update" and b.get("force") else [])
        res = await run_in_threadpool(helper, args, None, 2000 if acao == "update" else 240)
        if res.get("ok") and (acao != "update" or res.get("changed")):
            what = {"start": "iniciou o", "stop": "parou o", "restart": "reiniciou o", "rm": "excluiu o", "update": "atualizou a imagem do"}[acao]
            audit(request, user, f"{what} container {nome}" + (" e os volumes dele" if acao == "rm" and b.get("volumes") else ""))
        return answer(res)

    # ---------------------------------------------------------------- Compose (2.20)
    @app.get("/docker/compose", response_class=HTMLResponse)
    async def docker_compose_page(request: Request):
        return page(request, "docker_compose.html", "docker-compose")

    @app.get("/api/docker/compose")
    async def docker_compose_list(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        return answer(await run_in_threadpool(helper, ["compose-list"]))

    @app.get("/api/docker/compose/arquivo")
    async def docker_compose_get(request: Request, nome: str = ""):
        _, bad = api_guard(request)
        if bad:
            return bad
        return answer(await run_in_threadpool(helper, ["compose-get", nome]))

    @app.get("/api/docker/compose/logs")
    async def docker_compose_logs(request: Request, nome: str = ""):
        _, bad = api_guard(request)
        if bad:
            return bad
        return answer(await run_in_threadpool(helper, ["compose-logs", nome]))

    @app.post("/api/docker/compose/conferir")
    async def docker_compose_check(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        b = await body_of(request)
        return answer(await run_in_threadpool(helper, ["compose-check"], {"name": str(b.get("nome", "")), "yaml": str(b.get("yaml", ""))[:200000]}))

    @app.post("/api/docker/compose/subir")
    async def docker_compose_up(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        res = await run_in_threadpool(helper, ["compose-up"], {"name": str(b.get("nome", "")), "yaml": str(b.get("yaml", ""))[:200000]}, 2000)
        if res.get("ok"):
            audit(request, user, f"subiu o projeto Compose {res.get('name')}")
        return answer(res)

    @app.post("/api/docker/compose/acao")
    async def docker_compose_action(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        acao, nome = str(b.get("acao", "")), str(b.get("nome", ""))
        if acao not in ("up", "stop", "pull", "rm"):
            return JSONResponse({"ok": False, "message": "Ação inválida."}, status_code=400)
        res = await run_in_threadpool(helper, ["compose-action", nome, acao] + (["--volumes"] if acao == "rm" and b.get("volumes") else []), None, 2000)
        if res.get("ok"):
            what = {"up": "subiu o", "stop": "parou o", "pull": "atualizou as imagens do", "rm": "excluiu o"}[acao]
            audit(request, user, f"{what} projeto Compose {nome}" + (" com os volumes" if acao == "rm" and b.get("volumes") else ""))
        return answer(res)

    # ---------------------------------------------------------------- pasta dos dados (2.20)
    @app.post("/api/docker/dados")
    async def docker_data_root(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        res = await run_in_threadpool(helper, ["data-root"], {"path": str(b.get("path", "")), "delete_old": bool(b.get("delete_old"))}, 1800)
        if res.get("ok"):
            audit(request, user, f"mudou a pasta dos dados do Docker para {b.get('path')}")
        return answer(res)

    @app.post("/api/docker/conferir")
    async def docker_check(request: Request):
        _, bad = api_guard(request)
        if bad:
            return bad
        b = await body_of(request)
        return answer(await run_in_threadpool(helper, ["parse"], {"cmd": str(b.get("cmd", ""))[:20000]}))

    @app.post("/api/docker/subir")
    async def docker_run(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        req = {"cmd": str(b["cmd"])[:20000]} if b.get("cmd") else {"spec": b.get("spec") or {}}
        res = await run_in_threadpool(helper, ["run"], req, 2000)
        if res.get("ok"):
            audit(request, user, f"subiu o container {res.get('name')} ({res.get('message', '')})")
        return answer(res)

    @app.post("/api/docker/imagem/apagar")
    async def docker_rmi(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        ref = str((await body_of(request)).get("ref", ""))
        res = await run_in_threadpool(helper, ["rmi", ref], None, 240)
        if res.get("ok"):
            audit(request, user, f"apagou a imagem {ref}")
        return answer(res)

    @app.post("/api/docker/limpar")
    async def docker_prune(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        res = await run_in_threadpool(helper, ["prune"], None, 700)
        if res.get("ok"):
            audit(request, user, "apagou as imagens sem uso")
        return answer(res)

    @app.post("/api/docker/ajustes")
    async def docker_settings(request: Request):
        user, bad = api_guard(request, admin=True)
        if bad:
            return bad
        b = await body_of(request)
        res = await run_in_threadpool(helper, ["settings"], {k: b.get(k) for k in ("pool", "cap_pct", "mem_mb", "cpus")}, 400)
        if res.get("ok"):
            audit(request, user, f"ajustou o Docker: {json.dumps(res.get('settings'), ensure_ascii=False)}")
        return answer(res)
