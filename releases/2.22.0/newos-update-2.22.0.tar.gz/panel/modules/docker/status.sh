#!/usr/bin/env bash
set -Eeuo pipefail
printf 'installed=%s\n' "$(dpkg-query -W -f='${Status}' docker.io 2>/dev/null | grep -q 'ok installed' && echo yes || echo no)"
printf 'active=%s\n' "$(systemctl is-active -q docker.service && echo yes || echo no)"
