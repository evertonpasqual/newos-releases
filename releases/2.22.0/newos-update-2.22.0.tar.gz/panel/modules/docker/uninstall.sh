#!/usr/bin/env bash
# =====================================================================
#  Modulo Docker - desligar
#  Para o Docker e os containers. Imagens, volumes e containers ficam em
#  /var/lib/docker: religando o modulo, tudo volta.
# =====================================================================
set -Eeuo pipefail
# shellcheck disable=SC2034
MOD_TAG="docker"
# shellcheck source=../_lib/modlib.sh
source "${NEWOS_PANEL_DIR:-/opt/newos-panel}/modules/_lib/modlib.sh"

systemctl disable --now docker.service docker.socket >/dev/null 2>&1 || true
systemctl stop newos-docker.slice >/dev/null 2>&1 || true
[[ -x /usr/local/sbin/newos-firewall ]] && /usr/local/sbin/newos-firewall reload >/dev/null 2>&1 || true
mod_info "Docker desligado. Imagens e volumes guardados em /var/lib/docker."
